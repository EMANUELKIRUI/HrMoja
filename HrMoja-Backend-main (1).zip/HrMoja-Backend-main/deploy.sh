#!/bin/bash

# HRMoja Deployment Script
# This script builds and deploys the HRMoja backend application

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${GREEN}[HRMoja]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if .env file exists
if [ ! -f .env ]; then
    print_warning ".env file not found. Creating from .env.example..."
    cp .env.example .env
    print_warning "Please update .env file with your configuration before proceeding."
    exit 1
fi

# Parse command line arguments
REBUILD=false
DETACHED=true
WITH_TOOLS=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --rebuild)
            REBUILD=true
            shift
            ;;
        --attach)
            DETACHED=false
            shift
            ;;
        --with-tools)
            WITH_TOOLS=true
            shift
            ;;
        *)
            print_error "Unknown option: $1"
            echo "Usage: ./deploy.sh [--rebuild] [--attach] [--with-tools]"
            echo "  --rebuild     Rebuild Docker images"
            echo "  --attach      Run in attached mode (see logs)"
            echo "  --with-tools  Include pgAdmin and other tools"
            exit 1
            ;;
    esac
done

print_message "Starting HRMoja deployment..."

# Stop existing containers
print_message "Stopping existing containers..."
docker-compose down 2>/dev/null || true

# Build and start containers
if [ "$REBUILD" = true ]; then
    print_message "Building Docker images (this may take a few minutes)..."
    if [ "$WITH_TOOLS" = true ]; then
        docker-compose --profile tools build --no-cache
    else
        docker-compose build --no-cache
    fi
else
    print_message "Using existing Docker images..."
fi

# Start containers
print_message "Starting containers..."
if [ "$DETACHED" = true ]; then
    if [ "$WITH_TOOLS" = true ]; then
        docker-compose --profile tools up -d
    else
        docker-compose up -d
    fi
    
    print_message "Waiting for services to be healthy..."
    sleep 5
    
    # Check health status
    print_message "Checking service health..."
    docker-compose ps
    
    echo ""
    print_message "Deployment completed successfully!"
    echo ""
    echo "Services are running:"
    echo "  - Backend API: http://localhost:8080"
    echo "  - API Documentation: http://localhost:8080/api/swagger-ui.html"
    echo "  - Health Check: http://localhost:8080/api/actuator/health"
    if [ "$WITH_TOOLS" = true ]; then
        echo "  - PgAdmin: http://localhost:5050"
    fi
    echo ""
    echo "To view logs:"
    echo "  docker-compose logs -f backend"
    echo ""
    echo "To stop services:"
    echo "  docker-compose down"
else
    if [ "$WITH_TOOLS" = true ]; then
        docker-compose --profile tools up
    else
        docker-compose up
    fi
fi
