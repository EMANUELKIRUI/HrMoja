-- Run this to clean up the database before restarting

-- 1. Delete superadmin user and role assignments
DELETE FROM user_roles WHERE user_id = (SELECT id FROM users WHERE username = 'superadmin');
DELETE FROM users WHERE username = 'superadmin';

-- 2. Remove V9 and V10 from flyway history
DELETE FROM flyway_schema_history WHERE version IN ('9', '10');

-- 3. Verify cleanup
SELECT version, description, installed_on FROM flyway_schema_history ORDER BY installed_rank DESC LIMIT 5;
SELECT username, email FROM users WHERE username = 'superadmin';

-- You should see:
-- - No V9 or V10 in flyway history
-- - No superadmin user
-- - Last version should be 8
