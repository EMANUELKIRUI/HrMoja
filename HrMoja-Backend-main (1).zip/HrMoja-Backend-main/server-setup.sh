#!/bin/bash

# HRMoja Server Setup Script
# This script prepares a fresh Ubuntu/Debian server for HRMoja backend deployment

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_message() {
    echo -e "${GREEN}[Setup]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[Warning]${NC} $1"
}

print_error() {
    echo -e "${RED}[Error]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    print_error "Please run as root or with sudo"
    exit 1
fi

print_message "Starting HRMoja server setup..."

# Update system
print_message "Updating system packages..."
apt update && apt upgrade -y

# Install required packages
print_message "Installing required packages..."
apt install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg \
    lsb-release \
    git \
    ufw \
    fail2ban

# Install Docker
print_message "Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
    systemctl enable docker
    systemctl start docker
    print_message "Docker installed successfully"
else
    print_message "Docker already installed"
fi

# Install Docker Compose
print_message "Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    DOCKER_COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep 'tag_name' | cut -d\" -f4)
    curl -L "https://github.com/docker/compose/releases/download/${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    print_message "Docker Compose installed successfully"
else
    print_message "Docker Compose already installed"
fi

# Create application directory
print_message "Creating application directory..."
mkdir -p /opt/hrmoja-backend
cd /opt/hrmoja-backend

# Configure firewall
print_message "Configuring firewall..."
ufw --force enable
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 8080/tcp  # Backend API (can be removed if using reverse proxy)
print_message "Firewall configured"

# Configure fail2ban for SSH protection
print_message "Configuring fail2ban..."
systemctl enable fail2ban
systemctl start fail2ban

# Create deployment user (optional but recommended)
print_message "Creating deployment user..."
if ! id -u deployer &>/dev/null; then
    useradd -m -s /bin/bash deployer
    usermod -aG docker deployer
    print_message "Deployment user 'deployer' created"
else
    print_message "Deployment user already exists"
fi

# Set up SSH key authentication (manual step required)
print_warning "MANUAL STEP REQUIRED:"
print_warning "Add your GitHub Actions SSH public key to /home/deployer/.ssh/authorized_keys"
print_warning "Generate on your local machine with: ssh-keygen -t ed25519 -C 'github-actions'"

# Create .env file template
print_message "Creating .env template..."
cat > /opt/hrmoja-backend/.env.example << 'EOF'
# Database Configuration
DB_USERNAME=admin
DB_PASSWORD=mtulivu
DB_HOST=postgres
DB_PORT=5432
DB_NAME=hrmoja_db

# JWT Configuration (Generate with: openssl rand -base64 64)
JWT_SECRET=700ae72c731f3274d09189b80a9f5dc3be6deed24540c7399ef4051a508a2f260b8d77675a5841d091af1d58de5ac6fbcb38a894ccda27caedabb2aaae893bbc

# CORS Configuration
CORS_ORIGINS=https://coremoja.com,https://hr.coremoja.com

# Mail Configuration
MAIL_HOST=smtp.coremoja.com
MAIL_PORT=587
MAIL_USERNAME=no-reply@coremoja.com
MAIL_PASSWORD=T!m@r@866

# File Upload
FILE_UPLOAD_DIR=/app/uploads

# Active Profile
SPRING_PROFILES_ACTIVE=prod

# PgAdmin (Optional)
PGADMIN_EMAIL=admin@coremoja.com
PGADMIN_PASSWORD=T!m@r@866
EOF

print_message "Created .env.example - Copy and configure as .env"

# Install Nginx (optional reverse proxy)
print_message "Installing Nginx..."
apt install -y nginx
systemctl enable nginx
systemctl start nginx

# Create Nginx configuration template
print_message "Creating Nginx configuration template..."
cat > /etc/nginx/sites-available/hrmoja-backend.example << 'EOF'
server {
    listen 80;
    server_name hr.coremoja.com;

    # Redirect to HTTPS (after setting up SSL)
    # return 301 https://$server_name$request_uri;

    location / {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # WebSocket support (if needed)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
EOF

print_message "Nginx configuration template created at /etc/nginx/sites-available/hrmoja-backend.example"

# Print summary
echo ""
print_message "========================================"
print_message "Server setup completed successfully!"
print_message "========================================"
echo ""
print_message "Next steps:"
echo "1. Copy and configure environment file:"
echo "   cd /opt/hrmoja-backend"
echo "   cp .env.example .env"
echo "   nano .env"
echo ""
echo "2. Set up GitHub repository access:"
echo "   git clone https://github.com/Ronald866/HrMoja-Backend.git ."
echo "   # Or set up SSH deploy key"
echo ""
echo "3. Configure Nginx (if using reverse proxy):"
echo "   cp /etc/nginx/sites-available/hrmoja-backend.example /etc/nginx/sites-available/hrmoja-backend"
echo "   nano /etc/nginx/sites-available/hrmoja-backend"
echo "   ln -s /etc/nginx/sites-available/hrmoja-backend /etc/nginx/sites-enabled/"
echo "   nginx -t && systemctl reload nginx"
echo ""
echo "4. Set up SSL with Let's Encrypt:"
echo "   apt install certbot python3-certbot-nginx"
echo "   certbot --nginx -d api.yourdomain.com"
echo ""
echo "5. Configure GitHub Actions secrets:"
echo "   - SERVER_HOST: Your server IP/domain"
echo "   - SERVER_USER: deployer"
echo "   - SSH_PRIVATE_KEY: Private key for authentication"
echo "   - SERVER_PORT: 22 (or your SSH port)"
echo ""
echo "6. Deploy the application:"
echo "   ./deploy.sh --rebuild"
echo ""
print_message "System information:"
echo "Docker version: $(docker --version)"
echo "Docker Compose version: $(docker-compose --version)"
echo "Nginx version: $(nginx -v 2>&1)"
echo ""
print_warning "Remember to:"
print_warning "- Change all default passwords in .env"
print_warning "- Generate a strong JWT secret"
print_warning "- Set up SSL certificates for production"
print_warning "- Configure backup strategy"
print_warning "- Set up monitoring and alerting"
