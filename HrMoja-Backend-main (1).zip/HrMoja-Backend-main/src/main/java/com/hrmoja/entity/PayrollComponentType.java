package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Payroll Component Type Entity
 */
@Entity
@Table(name = "payroll_component_types")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollComponentType extends BaseEntity {

    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 50)
    private String code;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "calculation_category", nullable = false, length = 50)
    private String calculationCategory; // EARNING, DEDUCTION, BENEFIT, TAX, STATUTORY

    @Column(name = "is_system_type")
    private boolean isSystemType = false;

    @Column(name = "is_active")
    private boolean isActive = true;
}
