package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Master payment record for a payroll period
 * Tracks payment authorization, execution, and confirmation
 */
@Entity
@Table(name = "payroll_payments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payroll_period_id", nullable = false)
    private Long payrollPeriodId;

    // Payment Details
    @Column(name = "payment_date", nullable = false)
    private LocalDateTime paymentDate;

    @Column(name = "payment_method", nullable = false, length = 50)
    private String paymentMethod; // BANK_TRANSFER, CHEQUE, CASH, MOBILE_MONEY

    @Column(name = "payment_reference", length = 200)
    private String paymentReference;

    @Column(name = "payment_batch_number", length = 100)
    private String paymentBatchNumber;

    // Financial Summary
    @Column(name = "total_amount", nullable = false, precision = 15, scale = 2)
    private BigDecimal totalAmount;

    @Column(name = "total_employees", nullable = false)
    private Integer totalEmployees;

    @Column(name = "bank_transfer_amount", precision = 15, scale = 2)
    private BigDecimal bankTransferAmount;

    @Column(name = "other_payment_amount", precision = 15, scale = 2)
    private BigDecimal otherPaymentAmount;

    // Payment Execution
    @Column(name = "authorized_by", nullable = false)
    private Long authorizedBy;

    @Column(name = "authorized_by_name", length = 200)
    private String authorizedByName;

    @Column(name = "authorized_at", nullable = false)
    private LocalDateTime authorizedAt;

    @Column(name = "payment_executed_by")
    private Long paymentExecutedBy;

    @Column(name = "payment_executed_at")
    private LocalDateTime paymentExecutedAt;

    // Status
    @Column(name = "payment_status", nullable = false, length = 30)
    private String paymentStatus; // AUTHORIZED, PROCESSING, COMPLETED, FAILED, REVERSED

    // Bank File Details
    @Column(name = "bank_file_generated")
    private Boolean bankFileGenerated;

    @Column(name = "bank_file_name", length = 255)
    private String bankFileName;

    @Column(name = "bank_file_path", length = 500)
    private String bankFilePath;

    @Column(name = "bank_file_generated_at")
    private LocalDateTime bankFileGeneratedAt;

    @Column(name = "bank_file_generated_by")
    private Long bankFileGeneratedBy;

    // Confirmation
    @Column(name = "payment_confirmed")
    private Boolean paymentConfirmed;

    @Column(name = "payment_confirmed_by")
    private Long paymentConfirmedBy;

    @Column(name = "payment_confirmed_at")
    private LocalDateTime paymentConfirmedAt;

    @Column(name = "confirmation_notes", columnDefinition = "TEXT")
    private String confirmationNotes;

    // Failure Tracking
    @Column(name = "failure_reason", columnDefinition = "TEXT")
    private String failureReason;

    @Column(name = "retry_count")
    private Integer retryCount;

    @Column(name = "last_retry_at")
    private LocalDateTime lastRetryAt;

    // Notes and Audit
    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (paymentStatus == null) {
            paymentStatus = "AUTHORIZED";
        }
        if (bankFileGenerated == null) {
            bankFileGenerated = false;
        }
        if (paymentConfirmed == null) {
            paymentConfirmed = false;
        }
        if (retryCount == null) {
            retryCount = 0;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
