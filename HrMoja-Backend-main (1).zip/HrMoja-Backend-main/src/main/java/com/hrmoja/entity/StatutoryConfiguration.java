package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Statutory Configuration Entity (PAYE, NSSF, LST, etc.)
 */
@Entity
@Table(name = "statutory_configurations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StatutoryConfiguration extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id", nullable = false)
    private Country country;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 50)
    private String code;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "statutory_type", nullable = false, length = 30)
    private String statutoryType; // TAX, SOCIAL_SECURITY, INSURANCE, LEVY

    @Column(name = "employee_contribution_rate", precision = 5, scale = 2)
    private BigDecimal employeeContributionRate;

    @Column(name = "employer_contribution_rate", precision = 5, scale = 2)
    private BigDecimal employerContributionRate;

    @Column(name = "fixed_amount", precision = 15, scale = 2)
    private BigDecimal fixedAmount;

    @Column(name = "minimum_amount", precision = 15, scale = 2)
    private BigDecimal minimumAmount;

    @Column(name = "maximum_amount", precision = 15, scale = 2)
    private BigDecimal maximumAmount;

    @Column(name = "ceiling_amount", precision = 15, scale = 2)
    private BigDecimal ceilingAmount;

    @Column(name = "effective_from", nullable = false)
    private LocalDate effectiveFrom;

    @Column(name = "effective_to")
    private LocalDate effectiveTo;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(columnDefinition = "TEXT")
    private String calculation_rules;
}
