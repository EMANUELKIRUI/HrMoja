package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Bank Upload File Entity
 * Tracks both generated bank files and bank feedback/acknowledgement files
 */
@Entity
@Table(name = "bank_upload_files")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BankUploadFile implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payroll_period_id", nullable = false)
    private Long payrollPeriodId;

    @Column(name = "organization_id", nullable = false)
    private Long organizationId;

    @Column(name = "file_name", nullable = false, length = 255)
    private String fileName;

    @Column(name = "file_url", length = 500)
    private String fileUrl;

    @Column(name = "file_path", length = 500)
    private String filePath;

    @Column(name = "file_format", nullable = false, length = 20)
    private String fileFormat; // CSV, EXCEL

    @Column(name = "file_type", length = 30)
    private String fileType = "GENERATED"; // GENERATED, FEEDBACK

    @Column(name = "file_hash", length = 64)
    private String fileHash; // SHA-256 hash for integrity

    @Column(name = "file_size")
    private Long fileSize;

    @Column(name = "is_locked")
    private Boolean isLocked = false;

    @Column(name = "total_records", nullable = false)
    private Integer totalRecords;

    @Column(name = "total_amount", nullable = false, precision = 15, scale = 2)
    private BigDecimal totalAmount;

    @Column(name = "bank_id")
    private Long bankId;

    @Column(name = "upload_status", length = 30)
    private String uploadStatus = "PENDING"; // PENDING, UPLOADED, CONFIRMED

    @Column(name = "feedback_file_id")
    private Long feedbackFileId;

    @Column(name = "discrepancy_count")
    private Integer discrepancyCount = 0;

    @Column(name = "discrepancy_details", columnDefinition = "TEXT")
    private String discrepancyDetails;

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    @Column(name = "uploaded_at")
    private LocalDateTime uploadedAt;

    @Column(name = "uploaded_by")
    private Long uploadedBy;

    @CreatedDate
    @Column(name = "generated_at", nullable = false, updatable = false)
    private LocalDateTime generatedAt;

    @Column(name = "generated_by")
    private Long generatedBy;
}
