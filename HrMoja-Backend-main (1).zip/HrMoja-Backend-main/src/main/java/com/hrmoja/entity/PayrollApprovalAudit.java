package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Audit trail for payroll approval workflow
 * Tracks all approval/rejection actions across the 3 levels
 */
@Entity
@Table(name = "payroll_approval_audit")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollApprovalAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payroll_period_id", nullable = false)
    private Long payrollPeriodId;

    @Column(name = "action", nullable = false, length = 20)
    private String action; // PREPARED, REVIEWED, APPROVED, REJECTED, PAID

    @Column(name = "approval_level", nullable = false, length = 20)
    private String approvalLevel; // LEVEL_1, LEVEL_2, LEVEL_3

    @Column(name = "performed_by", nullable = false)
    private Long performedBy;

    @Column(name = "performed_by_name", length = 100)
    private String performedByName;

    @Column(name = "performed_at", nullable = false)
    private LocalDateTime performedAt;

    @Column(name = "previous_status", length = 20)
    private String previousStatus;

    @Column(name = "new_status", length = 20)
    private String newStatus;

    @Column(name = "comments", columnDefinition = "TEXT")
    private String comments;

    @Column(name = "rejection_reason", columnDefinition = "TEXT")
    private String rejectionReason;

    @Column(name = "ip_address", length = 45)
    private String ipAddress;

    @Column(name = "user_agent", columnDefinition = "TEXT")
    private String userAgent;
}
