package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Individual employee payment record
 * Tracks payment status for each employee within a payroll payment
 */
@Entity
@Table(name = "employee_payment_records")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeePaymentRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payroll_payment_id", nullable = false)
    private Long payrollPaymentId;

    @Column(name = "employee_payroll_record_id", nullable = false)
    private Long employeePayrollRecordId;

    @Column(name = "employee_id", nullable = false)
    private Long employeeId;

    // Payment Details
    @Column(name = "payment_amount", nullable = false, precision = 15, scale = 2)
    private BigDecimal paymentAmount;

    @Column(name = "payment_method", nullable = false, length = 50)
    private String paymentMethod;

    @Column(name = "payment_reference", length = 200)
    private String paymentReference;

    // Bank Details Used
    @Column(name = "bank_name", length = 200)
    private String bankName;

    @Column(name = "bank_account_number", length = 50)
    private String bankAccountNumber;

    @Column(name = "bank_account_name", length = 200)
    private String bankAccountName;

    @Column(name = "bank_branch", length = 200)
    private String bankBranch;

    // Status
    @Column(name = "payment_status", nullable = false, length = 30)
    private String paymentStatus; // PENDING, PROCESSED, COMPLETED, FAILED, RETURNED

    // Failure Tracking
    @Column(name = "failure_reason", columnDefinition = "TEXT")
    private String failureReason;

    @Column(name = "retry_count")
    private Integer retryCount;

    // Timestamps
    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "failed_at")
    private LocalDateTime failedAt;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (paymentStatus == null) {
            paymentStatus = "PENDING";
        }
        if (retryCount == null) {
            retryCount = 0;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
