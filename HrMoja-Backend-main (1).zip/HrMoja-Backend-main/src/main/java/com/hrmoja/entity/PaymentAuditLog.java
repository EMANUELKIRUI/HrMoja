package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Audit trail for payment-related actions
 * Tracks authorization, execution, confirmation, failures, retries, etc.
 */
@Entity
@Table(name = "payment_audit_log")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentAuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payroll_payment_id")
    private Long payrollPaymentId;

    @Column(name = "employee_payment_record_id")
    private Long employeePaymentRecordId;

    // Audit Details
    @Column(name = "action", nullable = false, length = 50)
    private String action; // AUTHORIZED, EXECUTED, CONFIRMED, FAILED, REVERSED, RETRY, FILE_GENERATED

    @Column(name = "performed_by", nullable = false)
    private Long performedBy;

    @Column(name = "performed_by_name", length = 200)
    private String performedByName;

    @Column(name = "performed_at", nullable = false)
    private LocalDateTime performedAt;

    // Action Details
    @Column(name = "previous_status", length = 30)
    private String previousStatus;

    @Column(name = "new_status", length = 30)
    private String newStatus;

    @Column(name = "action_details", columnDefinition = "TEXT")
    private String actionDetails;

    // System Info
    @Column(name = "ip_address", length = 45)
    private String ipAddress;

    @Column(name = "user_agent", columnDefinition = "TEXT")
    private String userAgent;

    @PrePersist
    protected void onCreate() {
        if (performedAt == null) {
            performedAt = LocalDateTime.now();
        }
    }
}
