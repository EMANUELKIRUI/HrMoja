package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * Payroll Record Entity - Employee payroll for a specific period
 */
@Entity
@Table(name = "payroll_records")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollRecord extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payroll_period_id", nullable = false)
    private PayrollPeriod payrollPeriod;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name = "employee_number", length = 50)
    private String employeeNumber;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "department_name", length = 200)
    private String departmentName;

    @Column(name = "job_title", length = 200)
    private String jobTitle;

    // Earnings
    @Column(name = "basic_salary", precision = 15, scale = 2)
    private BigDecimal basicSalary = BigDecimal.ZERO;

    @Column(name = "total_allowances", precision = 15, scale = 2)
    private BigDecimal totalAllowances = BigDecimal.ZERO;

    @Column(name = "total_earnings", precision = 15, scale = 2)
    private BigDecimal totalEarnings = BigDecimal.ZERO;

    @Column(name = "gross_salary", precision = 15, scale = 2)
    private BigDecimal grossSalary = BigDecimal.ZERO;

    // Deductions
    @Column(name = "paye_tax", precision = 15, scale = 2)
    private BigDecimal payeTax = BigDecimal.ZERO;

    @Column(name = "nssf_employee", precision = 15, scale = 2)
    private BigDecimal nssfEmployee = BigDecimal.ZERO;

    @Column(name = "lst_deduction", precision = 15, scale = 2)
    private BigDecimal lstDeduction = BigDecimal.ZERO;

    @Column(name = "total_statutory_deductions", precision = 15, scale = 2)
    private BigDecimal totalStatutoryDeductions = BigDecimal.ZERO;

    @Column(name = "total_other_deductions", precision = 15, scale = 2)
    private BigDecimal totalOtherDeductions = BigDecimal.ZERO;

    @Column(name = "total_deductions", precision = 15, scale = 2)
    private BigDecimal totalDeductions = BigDecimal.ZERO;

    // Employer Contributions
    @Column(name = "nssf_employer", precision = 15, scale = 2)
    private BigDecimal nssfEmployer = BigDecimal.ZERO;

    @Column(name = "total_employer_contributions", precision = 15, scale = 2)
    private BigDecimal totalEmployerContributions = BigDecimal.ZERO;

    // Net
    @Column(name = "net_salary", precision = 15, scale = 2)
    private BigDecimal netSalary = BigDecimal.ZERO;

    @Column(name = "taxable_income", precision = 15, scale = 2)
    private BigDecimal taxableIncome = BigDecimal.ZERO;

    @Column(name = "days_worked")
    private Integer daysWorked;

    @Column(name = "days_in_month")
    private Integer daysInMonth;

    @Column(nullable = false, length = 20)
    private String status = "DRAFT"; // DRAFT, CALCULATED, APPROVED, PAID

    @Column(name = "is_prorated")
    private boolean isProrated = false;

    @Column(name = "payment_method", length = 50)
    private String paymentMethod;

    @Column(name = "bank_name", length = 200)
    private String bankName;

    @Column(name = "account_number", length = 100)
    private String accountNumber;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
