package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Pay Frequency Entity
 */
@Entity
@Table(name = "pay_frequencies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayFrequency extends BaseEntity {

    @Column(nullable = false, unique = true, length = 50)
    private String name;

    @Column(nullable = false, unique = true, length = 20)
    private String code;

    @Column
    private String description;

    @Column(name = "periods_per_year", nullable = false)
    private Integer periodsPerYear;

    @Column(name = "is_active")
    private boolean isActive = true;
}
