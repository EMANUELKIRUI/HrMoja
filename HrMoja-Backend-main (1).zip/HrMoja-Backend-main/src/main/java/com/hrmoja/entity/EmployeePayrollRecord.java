package com.hrmoja.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "employee_payroll_records")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "payrollPeriod", "payrollRun", "employee"})
public class EmployeePayrollRecord extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payroll_period_id", nullable = false)
    private PayrollPeriod payrollPeriod;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payroll_run_id")
    private PayrollRun payrollRun;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name = "employee_name", length = 255)
    private String employeeName;

    @Column(name = "employee_number", length = 50)
    private String employeeNumber;

    @Column(name = "department_name", length = 100)
    private String departmentName;

    @Column(name = "position_title", length = 100)
    private String positionTitle;

    // Salary Information
    @Column(name = "basic_salary", precision = 15, scale = 2)
    private BigDecimal basicSalary = BigDecimal.ZERO;

    @Column(name = "gross_salary", precision = 15, scale = 2)
    private BigDecimal grossSalary = BigDecimal.ZERO;

    @Column(name = "taxable_income", precision = 15, scale = 2)
    private BigDecimal taxableIncome = BigDecimal.ZERO;

    @Column(name = "pensionable_income", precision = 15, scale = 2)
    private BigDecimal pensionableIncome = BigDecimal.ZERO;

    // Totals
    @Column(name = "total_earnings", precision = 15, scale = 2)
    private BigDecimal totalEarnings = BigDecimal.ZERO;

    @Column(name = "total_deductions", precision = 15, scale = 2)
    private BigDecimal totalDeductions = BigDecimal.ZERO;

    @Column(name = "total_statutory", precision = 15, scale = 2)
    private BigDecimal totalStatutory = BigDecimal.ZERO;

    @Column(name = "total_taxes", precision = 15, scale = 2)
    private BigDecimal totalTaxes = BigDecimal.ZERO;

    @Column(name = "net_salary", precision = 15, scale = 2)
    private BigDecimal netSalary = BigDecimal.ZERO;

    // Days & Hours
    @Column(name = "days_worked", precision = 5, scale = 2)
    private BigDecimal daysWorked = BigDecimal.ZERO;

    @Column(name = "days_absent", precision = 5, scale = 2)
    private BigDecimal daysAbsent = BigDecimal.ZERO;

    @Column(name = "overtime_hours", precision = 5, scale = 2)
    private BigDecimal overtimeHours = BigDecimal.ZERO;

    // Status
    @Column(nullable = false, length = 20)
    private String status = "DRAFT"; // DRAFT, CALCULATED, APPROVED, PAID

    @Column(name = "calculation_errors", columnDefinition = "TEXT")
    private String calculationErrors;

    // Partial Approval at Level 1 (HR)
    @Column(name = "approved_level1")
    private boolean approvedLevel1 = false;

    @Column(name = "level1_approved_by")
    private Long level1ApprovedBy;

    @Column(name = "level1_approved_at")
    private LocalDateTime level1ApprovedAt;

    // Level 2 Review (Finance)
    @Column(name = "reviewed_level2")
    private boolean reviewedLevel2 = false;

    @Column(name = "level2_reviewed_by")
    private Long level2ReviewedBy;

    @Column(name = "level2_reviewed_at")
    private LocalDateTime level2ReviewedAt;

    // Rejection/Exclusion (Soft Delete)
    @Column(name = "rejected")
    private boolean rejected = false;

    @Column(name = "rejection_reason", columnDefinition = "TEXT")
    private String rejectionReason;

    @Column(name = "rejected_by")
    private Long rejectedBy;

    @Column(name = "rejected_at")
    private LocalDateTime rejectedAt;

    @Column(name = "is_paid")
    private boolean isPaid = false;

    @Column(name = "payment_date")
    private LocalDateTime paymentDate;

    // Bank Details Check
    @Column(name = "has_bank_details")
    private boolean hasBankDetails = false;

    @Column(name = "payment_method", length = 50)
    private String paymentMethod; // BANK_TRANSFER, CHEQUE, CASH, MOBILE_MONEY

    @Column(name = "payment_reference", length = 100)
    private String paymentReference;

    @Column(columnDefinition = "TEXT")
    private String notes;

    // Retry tracking fields (added in V38)
    @Column(name = "processing_attempts")
    private Integer processingAttempts = 0;

    @Column(name = "last_error", columnDefinition = "TEXT")
    private String lastError;

    @Column(name = "skipped")
    private Boolean skipped = false;

    // Transient getter for JSON serialization (employee object is ignored)
    @Transient
    public Long getEmployeeId() {
        return employee != null ? employee.getId() : null;
    }
}
