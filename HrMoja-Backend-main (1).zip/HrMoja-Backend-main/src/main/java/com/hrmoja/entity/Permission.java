package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Permission Entity for fine-grained access control
 */
@Entity
@Table(name = "permissions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Permission extends BaseEntity {

    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 100)
    private String code;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, length = 50)
    private String module;

    @Column(name = "is_active")
    private boolean isActive = true;
}
