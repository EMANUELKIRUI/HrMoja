package com.hrmoja.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * Bank Branch Entity
 */
@Entity
@Table(name = "bank_branches")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BankBranch extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bank_id", nullable = false)
    private Bank bank;

    @Column(nullable = false)
    private String name;

    @Column(length = 50)
    private String code;

    @Column(length = 100)
    private String city;

    @Column(columnDefinition = "TEXT")
    private String address;

    @Column(name = "is_active")
    private boolean isActive = true;
}
