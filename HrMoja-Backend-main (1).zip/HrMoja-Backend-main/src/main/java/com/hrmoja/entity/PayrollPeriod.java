package com.hrmoja.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * Payroll Period Entity
 */
@Entity
@Table(name = "payroll_periods")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "organization", "payFrequency"})
public class PayrollPeriod extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organization_id", nullable = false)
    private Organization organization;

    @Column(name = "organization_id", insertable = false, updatable = false)
    private Long organizationId;

    @Column(name = "period_name", nullable = false, length = 100)
    private String periodName;
    
    @Column(name = "period_code", nullable = false, length = 50, unique = true)
    private String periodCode;
    
    @Column(name = "period_year")
    private Integer periodYear;
    
    @Column(name = "period_month")
    private Integer periodMonth;

    @Column(name = "period_type", nullable = false, length = 20)
    private String periodType = "MONTHLY"; // MONTHLY, BI_WEEKLY, WEEKLY

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    @Column(name = "end_date", nullable = false)
    private LocalDate endDate;

    @Column(name = "payment_date", nullable = false)
    private LocalDate paymentDate;

    @Column(nullable = false, length = 20)
    private String status = "DRAFT"; // DRAFT, PROCESSING, PREPARED, REVIEWED, APPROVED, PAID, CLOSED

    @Column(name = "approval_level", length = 20)
    private String approvalLevel = "NONE"; // NONE, LEVEL_1_PREPARED, LEVEL_2_REVIEWED, LEVEL_3_APPROVED

    @Column(name = "total_employees")
    private Integer totalEmployees = 0;

    @Column(name = "total_approved_level1")
    private Integer totalApprovedLevel1 = 0;

    @Column(name = "total_rejected")
    private Integer totalRejected = 0;

    @Column(name = "is_partially_approved")
    private boolean isPartiallyApproved = false;

    @Column(name = "total_gross_pay", precision = 15, scale = 2)
    private java.math.BigDecimal totalGrossPay = java.math.BigDecimal.ZERO;

    @Column(name = "total_deductions", precision = 15, scale = 2)
    private java.math.BigDecimal totalDeductions = java.math.BigDecimal.ZERO;

    @Column(name = "total_net_pay", precision = 15, scale = 2)
    private java.math.BigDecimal totalNetPay = java.math.BigDecimal.ZERO;

    @Column(name = "processed_by")
    private Long processedBy;

    @Column(name = "processed_at")
    private java.time.LocalDateTime processedAt;

    // Level 1: Prepared by (Payroll Officer)
    @Column(name = "prepared_by")
    private Long preparedBy;

    @Column(name = "prepared_at")
    private java.time.LocalDateTime preparedAt;

    // Level 2: Reviewed by (Payroll Manager)
    @Column(name = "reviewed_by")
    private Long reviewedBy;

    @Transient
    private String reviewedByName; // Populated from User entity for display

    @Column(name = "reviewed_at")
    private java.time.LocalDateTime reviewedAt;

    // Level 3: Final Approved by (Finance Director/CFO)
    @Column(name = "final_approved_by")
    private Long finalApprovedBy;

    @Column(name = "final_approved_at")
    private java.time.LocalDateTime finalApprovedAt;

    // Legacy approval fields (kept for backward compatibility)
    @Column(name = "approved_by")
    private Long approvedBy;

    @Column(name = "approved_at")
    private java.time.LocalDateTime approvedAt;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
