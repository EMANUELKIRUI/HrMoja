package com.hrmoja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Main Application Class for HRMoja HR Management System
 * 
 * @author HRMoja Team
 * @version 1.0.0
 */
@SpringBootApplication(exclude = {
    org.springframework.boot.autoconfigure.mail.MailSenderAutoConfiguration.class
})
@EnableAsync
@EnableTransactionManagement
public class HrMojaApplication {

    public static void main(String[] args) {
        SpringApplication.run(HrMojaApplication.class, args);
        System.out.println("""
            
            ╔═══════════════════════════════════════════════════════════╗
            ║                                                           ║
            ║        HRMoja - HR Management System Started!             ║
            ║        Version: 1.0.0                                     ║
            ║        Environment: Development                           ║
            ║        API Documentation: http://localhost:8080/api/swagger-ui.html
            ║                                                           ║
            ╚═══════════════════════════════════════════════════════════╝
            """);
    }
}
