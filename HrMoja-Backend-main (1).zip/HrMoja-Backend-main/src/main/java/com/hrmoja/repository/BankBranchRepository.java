package com.hrmoja.repository;

import com.hrmoja.entity.BankBranch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankBranchRepository extends JpaRepository<BankBranch, Long> {
    List<BankBranch> findByBankId(Long bankId);
    List<BankBranch> findByBankIdAndIsActiveTrue(Long bankId);
}
