package com.hrmoja.repository;

import com.hrmoja.entity.PayrollLineItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface PayrollLineItemRepository extends JpaRepository<PayrollLineItem, Long> {
    
    List<PayrollLineItem> findByEmployeePayrollRecordId(Long recordId);
    
    List<PayrollLineItem> findByEmployeePayrollRecordIdAndComponentCategory(Long employeePayrollRecordId, String componentCategory);
    
    @Modifying
    @Transactional
    @Query("DELETE FROM PayrollLineItem p WHERE p.employeePayrollRecord.id = :recordId")
    void deleteByEmployeePayrollRecordId(@Param("recordId") Long recordId);
}
