package com.hrmoja.repository;

import com.hrmoja.entity.EmployeeGrade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeGradeRepository extends JpaRepository<EmployeeGrade, Long> {
    List<EmployeeGrade> findByOrganizationId(Long organizationId);
    List<EmployeeGrade> findByOrganizationIdAndIsActiveTrue(Long organizationId);
    boolean existsByOrganizationIdAndCode(Long organizationId, String code);
}
