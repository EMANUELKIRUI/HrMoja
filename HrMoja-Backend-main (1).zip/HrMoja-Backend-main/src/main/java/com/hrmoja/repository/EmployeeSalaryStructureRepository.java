package com.hrmoja.repository;

import com.hrmoja.entity.EmployeeSalaryStructure;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeSalaryStructureRepository extends JpaRepository<EmployeeSalaryStructure, Long> {

    @Query(value = "SELECT * FROM employee_salary_structures s WHERE s.employee_id = :employeeId ORDER BY s.effective_date DESC LIMIT 1", nativeQuery = true)
    Optional<EmployeeSalaryStructure> findCurrentByEmployeeId(@Param("employeeId") Long employeeId);

    @Query("SELECT s FROM EmployeeSalaryStructure s WHERE s.employee.id = :employeeId ORDER BY s.effectiveDate DESC")
    List<EmployeeSalaryStructure> findAllByEmployeeId(@Param("employeeId") Long employeeId);

    @Query("SELECT s FROM EmployeeSalaryStructure s WHERE s.employee.id = :employeeId AND s.active = true")
    List<EmployeeSalaryStructure> findActiveByEmployeeId(@Param("employeeId") Long employeeId);
}
