package com.hrmoja.repository;

import com.hrmoja.entity.PayrollComponent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollComponentRepository extends JpaRepository<PayrollComponent, Long> {
    
    @Query("SELECT p FROM PayrollComponent p LEFT JOIN FETCH p.componentType WHERE p.id = :id")
    Optional<PayrollComponent> findByIdWithType(@Param("id") Long id);
    
    List<PayrollComponent> findByOrganizationId(Long organizationId);
    
    List<PayrollComponent> findByOrganizationIdAndIsActiveTrue(Long organizationId);
    
    @Query("SELECT p FROM PayrollComponent p WHERE p.organization.id = :orgId AND p.componentType.calculationCategory = :category")
    List<PayrollComponent> findByOrganizationAndCategory(@Param("orgId") Long organizationId, 
                                                         @Param("category") String category);
    
    boolean existsByOrganizationIdAndCode(Long organizationId, String code);
    
    List<PayrollComponent> findByOrganizationIdAndIsStatutoryTrue(Long organizationId);
}
