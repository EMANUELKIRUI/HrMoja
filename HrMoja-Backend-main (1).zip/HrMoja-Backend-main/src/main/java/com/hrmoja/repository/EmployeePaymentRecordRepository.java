package com.hrmoja.repository;

import com.hrmoja.entity.EmployeePaymentRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeePaymentRecordRepository extends JpaRepository<EmployeePaymentRecord, Long> {

    List<EmployeePaymentRecord> findByPayrollPaymentId(Long payrollPaymentId);

    List<EmployeePaymentRecord> findByEmployeeId(Long employeeId);

    List<EmployeePaymentRecord> findByPaymentStatus(String paymentStatus);

    @Query("SELECT e FROM EmployeePaymentRecord e WHERE e.payrollPaymentId = :paymentId AND e.paymentStatus = :status")
    List<EmployeePaymentRecord> findByPayrollPaymentIdAndStatus(
            @Param("paymentId") Long paymentId, 
            @Param("status") String status);

    @Query("SELECT COUNT(e) FROM EmployeePaymentRecord e WHERE e.payrollPaymentId = :paymentId AND e.paymentStatus = :status")
    long countByPayrollPaymentIdAndStatus(
            @Param("paymentId") Long paymentId, 
            @Param("status") String status);
}
