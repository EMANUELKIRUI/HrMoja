package com.hrmoja.repository;

import com.hrmoja.entity.TaxConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PayrollTaxConfigurationRepository extends JpaRepository<TaxConfiguration, Long> {
    
    @Query("SELECT t FROM TaxConfiguration t WHERE t.organization.id = :orgId " +
           "AND t.countryCode = :countryCode AND t.taxYear = :year " +
           "AND t.isActive = true AND t.effectiveFrom <= CURRENT_DATE " +
           "AND (t.effectiveTo IS NULL OR t.effectiveTo >= CURRENT_DATE) " +
           "ORDER BY t.effectiveFrom DESC")
    List<TaxConfiguration> findActiveConfigurations(@Param("orgId") Long organizationId, 
                                                    @Param("countryCode") String countryCode,
                                                    @Param("year") Integer taxYear);
}
