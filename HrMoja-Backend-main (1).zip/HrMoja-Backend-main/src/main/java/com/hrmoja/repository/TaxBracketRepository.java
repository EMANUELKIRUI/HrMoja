package com.hrmoja.repository;

import com.hrmoja.entity.TaxBracket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TaxBracketRepository extends JpaRepository<TaxBracket, Long> {
    
    List<TaxBracket> findByCountryIdOrderByBracketOrderAsc(Long countryId);
    
    @Query("SELECT t FROM TaxBracket t WHERE t.country.id = :countryId AND " +
           "t.effectiveFrom <= :date AND (t.effectiveTo IS NULL OR t.effectiveTo >= :date) AND " +
           "t.isActive = true ORDER BY t.bracketOrder ASC")
    List<TaxBracket> findActiveBracketsForDate(@Param("countryId") Long countryId, 
                                               @Param("date") LocalDate date);
    
    List<TaxBracket> findByCountryIdAndIsActiveTrue(Long countryId);
}
