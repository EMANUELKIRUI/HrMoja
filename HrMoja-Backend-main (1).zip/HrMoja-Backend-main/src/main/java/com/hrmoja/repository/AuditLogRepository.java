package com.hrmoja.repository;

import com.hrmoja.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Audit Log Repository
 */
@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    @Query("SELECT a FROM AuditLog a LEFT JOIN FETCH a.user u " +
           "WHERE (u.organizationId = :organizationId OR a.userId IS NULL) " +
           "ORDER BY a.performedAt DESC")
    List<AuditLog> findRecentByOrganization(@Param("organizationId") Long organizationId, Pageable pageable);

    @Query("SELECT a FROM AuditLog a WHERE a.userId = :userId ORDER BY a.performedAt DESC")
    Page<AuditLog> findByUserId(@Param("userId") Long userId, Pageable pageable);

    @Query("SELECT a FROM AuditLog a WHERE a.entityType = :entityType AND a.entityId = :entityId " +
           "ORDER BY a.performedAt DESC")
    List<AuditLog> findByEntity(@Param("entityType") String entityType, @Param("entityId") Long entityId);
}
