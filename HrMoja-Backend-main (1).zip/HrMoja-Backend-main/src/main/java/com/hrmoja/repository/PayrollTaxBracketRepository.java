package com.hrmoja.repository;

import com.hrmoja.entity.PayrollTaxBracket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PayrollTaxBracketRepository extends JpaRepository<PayrollTaxBracket, Long> {
    
    List<PayrollTaxBracket> findByTaxConfigurationIdOrderByBracketNumber(Long taxConfigurationId);
}
