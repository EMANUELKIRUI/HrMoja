package com.hrmoja.repository;

import com.hrmoja.entity.PayrollPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollPaymentRepository extends JpaRepository<PayrollPayment, Long> {

    Optional<PayrollPayment> findByPayrollPeriodId(Long payrollPeriodId);

    List<PayrollPayment> findByPaymentStatus(String paymentStatus);

    @Query("SELECT p FROM PayrollPayment p WHERE p.payrollPeriodId IN :periodIds ORDER BY p.paymentDate DESC")
    List<PayrollPayment> findByPayrollPeriodIdIn(@Param("periodIds") List<Long> periodIds);

    @Query("SELECT p FROM PayrollPayment p WHERE p.authorizedBy = :userId ORDER BY p.authorizedAt DESC")
    List<PayrollPayment> findByAuthorizedBy(@Param("userId") Long userId);

    @Query("SELECT COUNT(p) FROM PayrollPayment p WHERE p.paymentStatus = :status")
    long countByPaymentStatus(@Param("status") String status);
}
