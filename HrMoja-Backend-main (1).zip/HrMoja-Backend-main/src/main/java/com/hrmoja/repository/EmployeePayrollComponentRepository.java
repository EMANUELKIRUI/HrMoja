package com.hrmoja.repository;

import com.hrmoja.entity.EmployeePayrollComponent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface EmployeePayrollComponentRepository extends JpaRepository<EmployeePayrollComponent, Long> {
    
    List<EmployeePayrollComponent> findByEmployeeId(Long employeeId);
    
    List<EmployeePayrollComponent> findByEmployeeIdAndIsActiveTrue(Long employeeId);
    
    @Query("SELECT e FROM EmployeePayrollComponent e WHERE e.employee.id = :empId AND " +
           "e.effectiveFrom <= :date AND (e.effectiveTo IS NULL OR e.effectiveTo >= :date) AND e.isActive = true")
    List<EmployeePayrollComponent> findActiveComponentsForDate(@Param("empId") Long employeeId, 
                                                                @Param("date") LocalDate date);
    
    List<EmployeePayrollComponent> findByComponentId(Long componentId);
}
