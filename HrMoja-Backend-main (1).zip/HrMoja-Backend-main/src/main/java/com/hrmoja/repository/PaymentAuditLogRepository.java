package com.hrmoja.repository;

import com.hrmoja.entity.PaymentAuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentAuditLogRepository extends JpaRepository<PaymentAuditLog, Long> {

    @Query("SELECT p FROM PaymentAuditLog p WHERE p.payrollPaymentId = :paymentId ORDER BY p.performedAt DESC")
    List<PaymentAuditLog> findByPayrollPaymentId(@Param("paymentId") Long paymentId);

    @Query("SELECT p FROM PaymentAuditLog p WHERE p.employeePaymentRecordId = :empPaymentId ORDER BY p.performedAt DESC")
    List<PaymentAuditLog> findByEmployeePaymentRecordId(@Param("empPaymentId") Long empPaymentId);

    @Query("SELECT p FROM PaymentAuditLog p WHERE p.performedBy = :userId ORDER BY p.performedAt DESC")
    List<PaymentAuditLog> findByPerformedBy(@Param("userId") Long userId);
}
