package com.hrmoja.repository;

import com.hrmoja.entity.PayrollPeriod;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollPeriodRepository extends JpaRepository<PayrollPeriod, Long>, JpaSpecificationExecutor<PayrollPeriod> {
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId ORDER BY p.startDate DESC")
    List<PayrollPeriod> findByOrganizationIdOrderByStartDateDesc(@Param("orgId") Long organizationId);
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId")
    Page<PayrollPeriod> findByOrganizationId(@Param("orgId") Long organizationId, Pageable pageable);
    
    List<PayrollPeriod> findByOrganizationIdAndStatus(Long organizationId, String status);
    
    Page<PayrollPeriod> findByOrganizationIdAndStatus(Long organizationId, String status, Pageable pageable);
    
    Page<PayrollPeriod> findByOrganizationIdAndStatusIn(Long organizationId, List<String> statuses, Pageable pageable);
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId " +
           "AND p.status IN :statuses " +
           "AND (LOWER(p.periodName) LIKE LOWER(CONCAT('%', :search, '%')) " +
           "OR LOWER(p.periodCode) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<PayrollPeriod> searchByOrganizationAndStatusInAndNameOrCode(
            @Param("orgId") Long organizationId,
            @Param("statuses") List<String> statuses,
            @Param("search") String search,
            Pageable pageable);
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId AND " +
           "p.startDate <= :date AND p.endDate >= :date AND p.status != 'DELETED'")
    Optional<PayrollPeriod> findByOrganizationAndDate(@Param("orgId") Long organizationId, @Param("date") LocalDate date);
    
    Optional<PayrollPeriod> findByPeriodName(String periodName);
    
    Optional<PayrollPeriod> findByPeriodCode(String periodCode);
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId AND p.periodName = :periodName AND p.status != 'DELETED'")
    Optional<PayrollPeriod> findByOrganizationIdAndPeriodName(@Param("orgId") Long organizationId, @Param("periodName") String periodName);
    
    @Query("SELECT CASE WHEN COUNT(p) > 0 THEN true ELSE false END FROM PayrollPeriod p WHERE p.organization.id = :orgId AND p.periodName = :periodName AND p.status != 'DELETED'")
    boolean existsByOrganizationIdAndPeriodNameAndNotDeleted(@Param("orgId") Long organizationId, @Param("periodName") String periodName);
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId AND p.status = 'DRAFT' ORDER BY p.startDate DESC")
    List<PayrollPeriod> findDraftPeriods(@Param("orgId") Long organizationId);
    
    @Query("SELECT p FROM PayrollPeriod p WHERE p.organization.id = :orgId AND p.startDate <= :endDate AND p.endDate >= :startDate AND p.status != 'DELETED'")
    List<PayrollPeriod> findByOrganizationIdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
        @Param("orgId") Long organizationId,
        @Param("endDate") LocalDate endDate,
        @Param("startDate") LocalDate startDate);
    
    @Query("SELECT p FROM PayrollPeriod p " +
           "LEFT JOIN FETCH p.organization o " +
           "LEFT JOIN FETCH o.country " +
           "WHERE p.id = :periodId")
    Optional<PayrollPeriod> findByIdWithOrganizationAndCountry(@Param("periodId") Long periodId);
}
