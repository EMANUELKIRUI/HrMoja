package com.hrmoja.repository;

import com.hrmoja.entity.PayrollApprovalAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PayrollApprovalAuditRepository extends JpaRepository<PayrollApprovalAudit, Long> {
    
    List<PayrollApprovalAudit> findByPayrollPeriodIdOrderByPerformedAtDesc(Long payrollPeriodId);
    
    List<PayrollApprovalAudit> findByPayrollPeriodIdAndApprovalLevel(Long payrollPeriodId, String approvalLevel);
    
    @Query("SELECT a FROM PayrollApprovalAudit a WHERE a.payrollPeriodId = :periodId " +
           "ORDER BY a.performedAt DESC")
    List<PayrollApprovalAudit> getAuditTrail(@Param("periodId") Long periodId);
}
