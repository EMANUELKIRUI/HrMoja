package com.hrmoja.repository;

import com.hrmoja.entity.Branch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Branch Repository
 */
@Repository
public interface BranchRepository extends JpaRepository<Branch, Long> {

    @Query("SELECT b FROM Branch b LEFT JOIN FETCH b.organization LEFT JOIN FETCH b.country WHERE b.id = :id")
    Optional<Branch> findByIdWithDetails(@Param("id") Long id);

    List<Branch> findByOrganizationId(Long organizationId);

    List<Branch> findByOrganizationIdAndIsActiveTrue(Long organizationId);

    Optional<Branch> findByOrganizationIdAndIsHeadquartersTrue(Long organizationId);

    boolean existsByCode(String code);
}
