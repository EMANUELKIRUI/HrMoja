package com.hrmoja.repository;

import com.hrmoja.entity.EmployeePayrollRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeePayrollRecordRepository extends JpaRepository<EmployeePayrollRecord, Long> {
    
    List<EmployeePayrollRecord> findByPayrollPeriodId(Long payrollPeriodId);

    Long countByPayrollPeriodId(Long payrollPeriodId);

    Long countByPayrollPeriodIdAndApprovedLevel1True(Long payrollPeriodId);
    
    Page<EmployeePayrollRecord> findByPayrollPeriodId(Long payrollPeriodId, Pageable pageable);
    
    @Query("SELECT e FROM EmployeePayrollRecord e WHERE e.payrollPeriod.id = :payrollPeriodId AND e.employee.id = :employeeId")
    Optional<EmployeePayrollRecord> findByPayrollPeriodIdAndEmployeeId(@Param("payrollPeriodId") Long payrollPeriodId, @Param("employeeId") Long employeeId);
    
    @Query("SELECT e FROM EmployeePayrollRecord e WHERE e.employee.id = :employeeId")
    List<EmployeePayrollRecord> findByEmployeeId(@Param("employeeId") Long employeeId);
    
    @Query("SELECT e FROM EmployeePayrollRecord e WHERE e.payrollPeriod.id = :periodId AND e.status = :status")
    List<EmployeePayrollRecord> findByPayrollPeriodIdAndStatus(@Param("periodId") Long periodId, @Param("status") String status);
    
    @Query("SELECT COUNT(e) FROM EmployeePayrollRecord e WHERE e.payrollPeriod.id = :periodId AND e.isPaid = true")
    Long countPaidRecordsByPeriod(@Param("periodId") Long periodId);
    
    @Query("SELECT e FROM EmployeePayrollRecord e " +
           "LEFT JOIN FETCH e.employee emp " +
           "LEFT JOIN FETCH emp.department dept " +
           "WHERE e.payrollPeriod.id = :periodId " +
           "AND (:search IS NULL OR :search = '' OR " +
           "    LOWER(emp.firstName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "    LOWER(emp.lastName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "    LOWER(emp.employeeNumber) LIKE LOWER(CONCAT('%', :search, '%'))) " +
           "AND (:department IS NULL OR :department = '' OR dept.name = :department) " +
           "AND (:status IS NULL OR :status = '' OR e.status = :status) " +
           "AND (:approvalLevel IS NULL OR " +
           "    (:approvalLevel = 0 AND e.approvedLevel1 = false) OR " +
           "    (:approvalLevel = 1 AND e.approvedLevel1 = true))")
    Page<EmployeePayrollRecord> searchEmployeeRecords(
            @Param("periodId") Long periodId,
            @Param("search") String search,
            @Param("department") String department,
            @Param("status") String status,
            @Param("approvalLevel") Integer approvalLevel,
            Pageable pageable);
}
