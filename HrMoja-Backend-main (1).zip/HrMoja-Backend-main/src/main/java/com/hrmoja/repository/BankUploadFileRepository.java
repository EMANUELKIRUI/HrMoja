package com.hrmoja.repository;

import com.hrmoja.entity.BankUploadFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BankUploadFileRepository extends JpaRepository<BankUploadFile, Long> {

    @Query("SELECT b FROM BankUploadFile b WHERE b.payrollPeriodId = :periodId ORDER BY b.generatedAt DESC")
    List<BankUploadFile> findByPayrollPeriodId(@Param("periodId") Long periodId);

    @Query("SELECT b FROM BankUploadFile b WHERE b.payrollPeriodId = :periodId AND b.fileType = :fileType ORDER BY b.generatedAt DESC")
    List<BankUploadFile> findByPayrollPeriodIdAndFileType(@Param("periodId") Long periodId, @Param("fileType") String fileType);

    @Query("SELECT b FROM BankUploadFile b WHERE b.payrollPeriodId = :periodId AND b.fileType = 'GENERATED' AND b.isLocked = true ORDER BY b.generatedAt DESC")
    Optional<BankUploadFile> findLockedGeneratedFile(@Param("periodId") Long periodId);

    @Query("SELECT b FROM BankUploadFile b WHERE b.payrollPeriodId = :periodId AND b.fileType = 'FEEDBACK' ORDER BY b.uploadedAt DESC")
    List<BankUploadFile> findFeedbackFiles(@Param("periodId") Long periodId);

    @Query("SELECT COUNT(b) FROM BankUploadFile b WHERE b.payrollPeriodId = :periodId AND b.fileType = 'FEEDBACK'")
    Long countFeedbackFiles(@Param("periodId") Long periodId);
}
