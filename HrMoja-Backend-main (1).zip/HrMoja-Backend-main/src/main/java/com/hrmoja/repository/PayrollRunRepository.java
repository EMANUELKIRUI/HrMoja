package com.hrmoja.repository;

import com.hrmoja.entity.PayrollRun;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PayrollRunRepository extends JpaRepository<PayrollRun, Long> {
    
    List<PayrollRun> findByPayrollPeriodId(Long payrollPeriodId);
    
    List<PayrollRun> findByPayrollPeriodIdOrderByRunNumberDesc(Long payrollPeriodId);
    
    Optional<PayrollRun> findByPayrollPeriodIdAndRunNumber(Long payrollPeriodId, Integer runNumber);
    
    Optional<PayrollRun> findFirstByPayrollPeriodIdOrderByRunNumberDesc(Long payrollPeriodId);
}
