package com.hrmoja.controller;

import com.hrmoja.dto.bank.BankBranchDto;
import com.hrmoja.dto.bank.BankDto;
import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.service.BankBranchService;
import com.hrmoja.service.BankService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Bank Controller
 */
@RestController
@RequestMapping("/api/banks")
@RequiredArgsConstructor
@Tag(name = "Banks", description = "Bank and bank branch management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class BankController {

    private final BankService bankService;
    private final BankBranchService bankBranchService;

    @GetMapping("/active")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get all active banks")
    public ResponseEntity<ApiResponse<List<BankDto>>> getActiveBanks() {
        return ResponseEntity.ok(ApiResponse.success(bankService.getActiveBanks()));
    }

    @GetMapping("/country/{countryId}")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get banks by country")
    public ResponseEntity<ApiResponse<List<BankDto>>> getBanksByCountry(@PathVariable Long countryId) {
        return ResponseEntity.ok(ApiResponse.success(bankService.getBanksByCountry(countryId)));
    }

    @GetMapping("/{bankId}/branches")
    @PreAuthorize("hasAuthority('EMPLOYEE_READ')")
    @Operation(summary = "Get bank branches by bank ID")
    public ResponseEntity<ApiResponse<List<BankBranchDto>>> getBankBranches(@PathVariable Long bankId) {
        return ResponseEntity.ok(ApiResponse.success(bankBranchService.getBranchesByBank(bankId)));
    }
}
