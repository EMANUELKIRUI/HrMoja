package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.settings.CountryDto;
import com.hrmoja.service.CountryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/settings/countries")
@RequiredArgsConstructor
@Tag(name = "Settings - Countries", description = "Country management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class CountryController {

    private final CountryService countryService;

    @GetMapping
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get all countries")
    public ResponseEntity<ApiResponse<List<CountryDto>>> getAllCountries() {
        return ResponseEntity.ok(ApiResponse.success(countryService.getAllCountries()));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<CountryDto>>> getActiveCountries() {
        return ResponseEntity.ok(ApiResponse.success(countryService.getActiveCountries()));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<CountryDto>> getCountryById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(countryService.getCountryById(id)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<CountryDto>> createCountry(@Valid @RequestBody CountryDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Country created successfully", countryService.createCountry(dto)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<CountryDto>> updateCountry(@PathVariable Long id, @Valid @RequestBody CountryDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Country updated successfully", countryService.updateCountry(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<Void>> deleteCountry(@PathVariable Long id) {
        countryService.deleteCountry(id);
        return ResponseEntity.ok(ApiResponse.success("Country deactivated successfully", null));
    }
}
