package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.permission.PermissionCreateRequest;
import com.hrmoja.dto.permission.PermissionDto;
import com.hrmoja.service.PermissionManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/permissions")
@RequiredArgsConstructor
@Tag(name = "Permission Management", description = "Permission management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class PermissionManagementController {

    private final PermissionManagementService permissionManagementService;

    @GetMapping
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get all permissions")
    public ResponseEntity<ApiResponse<List<PermissionDto>>> getAllPermissions() {
        return ResponseEntity.ok(ApiResponse.success(permissionManagementService.getAllPermissions()));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get active permissions")
    public ResponseEntity<ApiResponse<List<PermissionDto>>> getActivePermissions() {
        return ResponseEntity.ok(ApiResponse.success(permissionManagementService.getActivePermissions()));
    }

    @GetMapping("/module/{module}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get permissions by module")
    public ResponseEntity<ApiResponse<List<PermissionDto>>> getPermissionsByModule(@PathVariable String module) {
        return ResponseEntity.ok(ApiResponse.success(permissionManagementService.getPermissionsByModule(module)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get permission by ID")
    public ResponseEntity<ApiResponse<PermissionDto>> getPermissionById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(permissionManagementService.getPermissionById(id)));
    }

    @GetMapping("/code/{code}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get permission by code")
    public ResponseEntity<ApiResponse<PermissionDto>> getPermissionByCode(@PathVariable String code) {
        return ResponseEntity.ok(ApiResponse.success(permissionManagementService.getPermissionByCode(code)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Create new permission")
    public ResponseEntity<ApiResponse<PermissionDto>> createPermission(@Valid @RequestBody PermissionCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Permission created successfully", permissionManagementService.createPermission(request)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Update permission")
    public ResponseEntity<ApiResponse<PermissionDto>> updatePermission(@PathVariable Long id, @Valid @RequestBody PermissionCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Permission updated successfully", permissionManagementService.updatePermission(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Deactivate permission")
    public ResponseEntity<ApiResponse<Void>> deletePermission(@PathVariable Long id) {
        permissionManagementService.deletePermission(id);
        return ResponseEntity.ok(ApiResponse.success("Permission deactivated successfully", null));
    }

    @PostMapping("/{id}/activate")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Activate permission")
    public ResponseEntity<ApiResponse<Void>> activatePermission(@PathVariable Long id) {
        permissionManagementService.activatePermission(id);
        return ResponseEntity.ok(ApiResponse.success("Permission activated successfully", null));
    }
}
