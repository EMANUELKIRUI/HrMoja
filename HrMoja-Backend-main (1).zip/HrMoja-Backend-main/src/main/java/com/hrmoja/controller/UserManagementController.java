package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.user.PasswordChangeRequest;
import com.hrmoja.dto.user.UserCreateRequest;
import com.hrmoja.dto.user.UserDto;
import com.hrmoja.dto.user.UserUpdateRequest;
import com.hrmoja.service.UserManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "User Management", description = "User management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class UserManagementController {

    private final UserManagementService userManagementService;

    @GetMapping
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get all users")
    public ResponseEntity<ApiResponse<List<UserDto>>> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.success(userManagementService.getAllUsers()));
    }

    @GetMapping("/paginated")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get users paginated")
    public ResponseEntity<ApiResponse<Page<UserDto>>> getUsersPaginated(Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(userManagementService.getUsersPaginated(pageable)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get user by ID")
    public ResponseEntity<ApiResponse<UserDto>> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(userManagementService.getUserById(id)));
    }

    @GetMapping("/username/{username}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get user by username")
    public ResponseEntity<ApiResponse<UserDto>> getUserByUsername(@PathVariable String username) {
        return ResponseEntity.ok(ApiResponse.success(userManagementService.getUserByUsername(username)));
    }

    @GetMapping("/organization/{organizationId}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Get users by organization")
    public ResponseEntity<ApiResponse<List<UserDto>>> getUsersByOrganization(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(userManagementService.getUsersByOrganization(organizationId)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Create new user")
    public ResponseEntity<ApiResponse<UserDto>> createUser(@Valid @RequestBody UserCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("User created successfully", userManagementService.createUser(request)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Update user")
    public ResponseEntity<ApiResponse<UserDto>> updateUser(@PathVariable Long id, @Valid @RequestBody UserUpdateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("User updated successfully", userManagementService.updateUser(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Deactivate user")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        userManagementService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.success("User deactivated successfully", null));
    }

    @PostMapping("/{id}/activate")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Activate user")
    public ResponseEntity<ApiResponse<Void>> activateUser(@PathVariable Long id) {
        userManagementService.activateUser(id);
        return ResponseEntity.ok(ApiResponse.success("User activated successfully", null));
    }

    @PostMapping("/{id}/change-password")
    @PreAuthorize("hasAuthority('USER_MANAGE') or #id == authentication.principal.id")
    @Operation(summary = "Change user password")
    public ResponseEntity<ApiResponse<Void>> changePassword(@PathVariable Long id, @Valid @RequestBody PasswordChangeRequest request) {
        userManagementService.changePassword(id, request);
        return ResponseEntity.ok(ApiResponse.success("Password changed successfully", null));
    }

    @PostMapping("/{id}/reset-password")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Reset user password")
    public ResponseEntity<ApiResponse<Void>> resetPassword(@PathVariable Long id, @RequestParam String newPassword) {
        userManagementService.resetPassword(id, newPassword);
        return ResponseEntity.ok(ApiResponse.success("Password reset successfully", null));
    }

    @PostMapping("/{id}/lock")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Lock user account")
    public ResponseEntity<ApiResponse<Void>> lockUser(@PathVariable Long id) {
        userManagementService.lockUser(id);
        return ResponseEntity.ok(ApiResponse.success("User locked successfully", null));
    }

    @PostMapping("/{id}/unlock")
    @PreAuthorize("hasAuthority('USER_MANAGE')")
    @Operation(summary = "Unlock user account")
    public ResponseEntity<ApiResponse<Void>> unlockUser(@PathVariable Long id) {
        userManagementService.unlockUser(id);
        return ResponseEntity.ok(ApiResponse.success("User unlocked successfully", null));
    }
}
