package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollPayment;
import com.hrmoja.entity.PaymentAuditLog;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.service.BankFileGenerationService;
import com.hrmoja.service.FinancePayrollReviewService;
import com.hrmoja.service.PaymentProcessingService;
import com.hrmoja.util.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Finance Payroll Review Controller
 * Handles Finance department's payroll review tasks
 * - View periods submitted by HR (PREPARED status)
 * - Review payroll data and financial validation
 * - Approve or reject periods at Level 2
 * - Submit for Executive final approval
 */
@Slf4j
@RestController
@RequestMapping("/api/finance/payroll")
@RequiredArgsConstructor
@Tag(name = "Finance Payroll Review", description = "Finance department payroll review and validation")
public class FinancePayrollReviewController {

    private final FinancePayrollReviewService financeReviewService;
    private final PaymentProcessingService paymentProcessingService;
    private final BankFileGenerationService bankFileGenerationService;

    @GetMapping("/periods")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get payroll periods pending Finance review")
    public ResponseEntity<ApiResponse<List<PayrollPeriod>>> getPeriodsForReview(
            @RequestParam(required = false) String status) {
        log.info("Finance: Fetching periods for review, status: {}", status);
        List<PayrollPeriod> periods = financeReviewService.getPeriodsForReview(status);
        return ResponseEntity.ok(ApiResponse.success("Periods retrieved", periods));
    }

    @GetMapping("/periods/{periodId}")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get period details for Finance review")
    public ResponseEntity<ApiResponse<PayrollPeriod>> getPeriodDetails(@PathVariable Long periodId) {
        log.info("Finance: Fetching period {} details", periodId);
        PayrollPeriod period = financeReviewService.getPeriodForReview(periodId);
        return ResponseEntity.ok(ApiResponse.success("Period details retrieved", period));
    }

    @GetMapping("/periods/{periodId}/records")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get employee records for Finance review (excludes rejected records)")
    public ResponseEntity<ApiResponse<Page<EmployeePayrollRecord>>> getEmployeeRecords(
            @PathVariable Long periodId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String department,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Finance: Fetching employee records for period {}, search: {}, dept: {}", 
                periodId, search, department);
        Pageable pageable = PageRequest.of(page, size, Sort.by("employeeName").ascending());
        Page<EmployeePayrollRecord> records = financeReviewService.getEmployeeRecordsForReview(
                periodId, search, department, pageable);
        return ResponseEntity.ok(ApiResponse.success("Employee records retrieved", records));
    }

    @GetMapping("/periods/{periodId}/summary")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get financial summary for review")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getFinancialSummary(
            @PathVariable Long periodId) {
        log.info("Finance: Fetching financial summary for period {}", periodId);
        Map<String, Object> summary = financeReviewService.getFinancialSummary(periodId);
        return ResponseEntity.ok(ApiResponse.success("Financial summary retrieved", summary));
    }

    @PostMapping("/periods/{periodId}/review")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Mark period as reviewed by Finance (Level 2)")
    public ResponseEntity<ApiResponse<PayrollPeriod>> reviewPeriod(
            @PathVariable Long periodId,
            @RequestBody(required = false) Map<String, String> comments) {
        log.info("Finance: Reviewing period {}", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String comment = comments != null ? comments.get("comment") : null;
        PayrollPeriod period = financeReviewService.reviewPeriod(periodId, userId, comment);
        return ResponseEntity.ok(ApiResponse.success(
                "Period reviewed successfully (Level 2)", period));
    }

    @PostMapping("/periods/{periodId}/reject")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Reject period and return to HR")
    public ResponseEntity<ApiResponse<PayrollPeriod>> rejectPeriod(
            @PathVariable Long periodId,
            @RequestBody Map<String, String> request) {
        log.info("Finance: Rejecting period {}", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String reason = request.get("reason");
        PayrollPeriod period = financeReviewService.rejectPeriod(periodId, userId, reason);
        return ResponseEntity.ok(ApiResponse.success(
                "Period rejected and returned to HR for corrections", period));
    }

    @PostMapping("/periods/{periodId}/submit-for-approval")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Submit period for Executive final approval (Level 2 → Level 3)")
    public ResponseEntity<ApiResponse<PayrollPeriod>> submitForFinalApproval(@PathVariable Long periodId) {
        log.info("Finance: Submitting period {} for Executive approval", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        PayrollPeriod period = financeReviewService.submitForFinalApproval(periodId, userId);
        return ResponseEntity.ok(ApiResponse.success(
                "Period submitted for Executive final approval", period));
    }

    @GetMapping("/periods/{periodId}/validation-report")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get validation report for Finance review")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getValidationReport(
            @PathVariable Long periodId) {
        log.info("Finance: Generating validation report for period {}", periodId);
        Map<String, Object> report = financeReviewService.generateValidationReport(periodId);
        return ResponseEntity.ok(ApiResponse.success("Validation report generated", report));
    }

    @PostMapping("/records/{recordId}/review")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Mark individual record as reviewed by Finance (Level 2)")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> reviewRecord(
            @PathVariable Long recordId,
            @RequestBody(required = false) Map<String, String> request) {
        log.info("Finance: Reviewing individual record {}", recordId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String remarks = request != null ? request.get("remarks") : null;
        EmployeePayrollRecord record = financeReviewService.reviewIndividualRecord(recordId, userId, remarks);
        return ResponseEntity.ok(ApiResponse.success(
                "Record reviewed successfully", record));
    }

    @PostMapping("/records/review-bulk")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Bulk review multiple records by Finance (Level 2)")
    public ResponseEntity<ApiResponse<Map<String, Object>>> reviewBulkRecords(
            @RequestBody Map<String, Object> request) {
        log.info("Finance: Bulk reviewing records");
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        
        @SuppressWarnings("unchecked")
        List<Object> recordIdsRaw = (List<Object>) request.get("recordIds");
        // Convert to Long to handle both Integer and Long types from JSON
        List<Long> recordIds = recordIdsRaw.stream()
                .map(id -> id instanceof Integer ? ((Integer) id).longValue() : (Long) id)
                .collect(java.util.stream.Collectors.toList());
        String remarks = (String) request.get("remarks");
        
        Map<String, Object> result = financeReviewService.reviewBulkRecords(recordIds, userId, remarks);
        return ResponseEntity.ok(ApiResponse.success(
                String.format("%d record(s) reviewed successfully", recordIds.size()), result));
    }

    @PostMapping("/records/{recordId}/reject")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Disapprove/Reject employee record by Finance")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> rejectRecord(
            @PathVariable Long recordId,
            @RequestBody Map<String, String> request) {
        log.info("Finance: Rejecting/Disapproving record {}", recordId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String reason = request.get("reason");
        EmployeePayrollRecord record = financeReviewService.rejectRecord(recordId, userId, reason);
        return ResponseEntity.ok(ApiResponse.success(
                "Record disapproved and excluded from payroll", record));
    }

    // ============= PAYMENT PROCESSING ENDPOINTS =============

    @PostMapping("/periods/{periodId}/authorize-payment")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Authorize payment for approved payroll period")
    public ResponseEntity<ApiResponse<PayrollPayment>> authorizePayment(
            @PathVariable Long periodId,
            @RequestBody(required = false) Map<String, String> paymentDetails) {
        log.info("Finance: Authorizing payment for period {}", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        PayrollPayment payment = paymentProcessingService.authorizePayment(periodId, userId, paymentDetails);
        return ResponseEntity.ok(ApiResponse.success(
                "Payment authorized successfully", payment));
    }

    @PostMapping("/payments/{paymentId}/execute")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Mark payment as executed (after bank file upload)")
    public ResponseEntity<ApiResponse<PayrollPayment>> markPaymentAsExecuted(
            @PathVariable Long paymentId,
            @RequestBody(required = false) Map<String, String> executionDetails) {
        log.info("Finance: Marking payment {} as executed", paymentId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        PayrollPayment payment = paymentProcessingService.markPaymentAsExecuted(paymentId, userId, executionDetails);
        return ResponseEntity.ok(ApiResponse.success(
                "Payment marked as executed", payment));
    }

    @PostMapping("/payments/{paymentId}/confirm")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Confirm payment completion and mark period as PAID")
    public ResponseEntity<ApiResponse<PayrollPayment>> confirmPayment(
            @PathVariable Long paymentId,
            @RequestBody(required = false) Map<String, String> confirmationDetails) {
        log.info("Finance: Confirming payment {} completion", paymentId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        PayrollPayment payment = paymentProcessingService.confirmPaymentCompletion(paymentId, userId, confirmationDetails);
        return ResponseEntity.ok(ApiResponse.success(
                "Payment confirmed - Period marked as PAID", payment));
    }

    @GetMapping("/periods/{periodId}/payment-details")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get payment details for a period")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getPaymentDetails(@PathVariable Long periodId) {
        log.info("Finance: Fetching payment details for period {}", periodId);
        Map<String, Object> details = paymentProcessingService.getPaymentDetails(periodId);
        return ResponseEntity.ok(ApiResponse.success("Payment details retrieved", details));
    }

    @GetMapping("/payments/{paymentId}/audit-trail")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Get payment audit trail")
    public ResponseEntity<ApiResponse<List<PaymentAuditLog>>> getPaymentAuditTrail(@PathVariable Long paymentId) {
        log.info("Finance: Fetching payment audit trail for payment {}", paymentId);
        List<PaymentAuditLog> auditTrail = paymentProcessingService.getPaymentAuditTrail(paymentId);
        return ResponseEntity.ok(ApiResponse.success("Payment audit trail retrieved", auditTrail));
    }

    @PostMapping("/payments/{paymentId}/reverse")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Reverse/cancel a payment (if not completed)")
    public ResponseEntity<ApiResponse<PayrollPayment>> reversePayment(
            @PathVariable Long paymentId,
            @RequestBody Map<String, String> request) {
        log.info("Finance: Reversing payment {}", paymentId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String reason = request.get("reason");
        PayrollPayment payment = paymentProcessingService.reversePayment(paymentId, userId, reason);
        return ResponseEntity.ok(ApiResponse.success(
                "Payment reversed", payment));
    }

    // ============= BANK FILE GENERATION ENDPOINTS =============

    @GetMapping("/periods/{periodId}/bank-file-preview")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Preview bank file data before generation")
    public ResponseEntity<ApiResponse<List<BankFileGenerationService.BankFileEntry>>> getBankFilePreview(
            @PathVariable Long periodId) {
        log.info("Finance: Fetching bank file preview for period {}", periodId);
        List<BankFileGenerationService.BankFileEntry> preview = bankFileGenerationService.getBankFilePreview(periodId);
        return ResponseEntity.ok(ApiResponse.success("Bank file preview retrieved", preview));
    }

    @GetMapping("/payments/{paymentId}/generate-bank-file")
    @PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
    @Operation(summary = "Generate and download bank file for payment")
    public ResponseEntity<byte[]> generateBankFile(
            @PathVariable Long paymentId,
            @RequestParam(defaultValue = "CSV") String format) {
        log.info("Finance: Generating bank file for payment {} in {} format", paymentId, format);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        
        try {
            byte[] fileData = bankFileGenerationService.generateBankFileAndSave(paymentId, format, userId);
            
            String contentType = "EXCEL".equalsIgnoreCase(format) 
                    ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" 
                    : "text/csv";
            String extension = "EXCEL".equalsIgnoreCase(format) ? "xlsx" : "csv";
            String fileName = String.format("PAYROLL_BANK_FILE_%d.%s", paymentId, extension);
            
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=" + fileName)
                    .header("Content-Type", contentType)
                    .body(fileData);
        } catch (Exception e) {
            log.error("Error generating bank file for payment {}", paymentId, e);
            throw new RuntimeException("Failed to generate bank file: " + e.getMessage());
        }
    }
}
