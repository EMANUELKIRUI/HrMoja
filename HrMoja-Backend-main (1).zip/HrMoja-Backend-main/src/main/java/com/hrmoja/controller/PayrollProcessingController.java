package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.entity.PayrollJob;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.service.PayrollProcessingService;
import com.hrmoja.util.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payroll/processing")
@RequiredArgsConstructor
@Tag(name = "Payroll Processing", description = "Payroll period management and processing")
@SecurityRequirement(name = "bearerAuth")
public class PayrollProcessingController {

    private final PayrollProcessingService processingService;

    @GetMapping("/periods/organization/{organizationId}")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get all payroll periods for organization")
    public ResponseEntity<ApiResponse<List<PayrollPeriod>>> getPeriodsByOrganization(@PathVariable Long organizationId) {
        List<PayrollPeriod> periods = processingService.getPeriodsByOrganization(organizationId);
        return ResponseEntity.ok(ApiResponse.success(periods));
    }

    @GetMapping("/periods/{periodId}")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get payroll period by ID")
    public ResponseEntity<ApiResponse<PayrollPeriod>> getPeriodById(@PathVariable Long periodId) {
        PayrollPeriod period = processingService.getPeriodById(periodId);
        return ResponseEntity.ok(ApiResponse.success(period));
    }

    @PostMapping("/periods")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Create payroll period")
    public ResponseEntity<ApiResponse<PayrollPeriod>> createPeriod(
            @RequestParam Long organizationId,
            @RequestParam String periodName,
            @RequestParam(defaultValue = "MONTHLY") String periodType,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate paymentDate) {
        
        PayrollPeriod period = processingService.createPayrollPeriod(organizationId, periodName, periodType,
                                                                     startDate, endDate, paymentDate);
        return ResponseEntity.ok(ApiResponse.success("Period created", period));
    }

    @PostMapping("/periods/{periodId}/process")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Process payroll for period (async)")
    public ResponseEntity<ApiResponse<Map<String, Object>>> processPayroll(@PathVariable Long periodId) {
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow();
        
        try {
            PayrollJob job = processingService.initiatePayrollProcessing(periodId, userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("jobId", job.getId());
            response.put("periodId", periodId);
            response.put("status", job.getStatus().name());
            response.put("totalEmployees", job.getTotalEmployees());
            
            return ResponseEntity.ok(ApiResponse.success("Payroll processing started successfully", response));
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/jobs/{jobId}/status")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get payroll job status and progress")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getJobStatus(@PathVariable Long jobId) {
        try {
            PayrollJob job = processingService.getJobStatus(jobId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("jobId", job.getId());
            response.put("periodId", job.getPayrollPeriodId());
            response.put("status", job.getStatus().name());
            response.put("totalEmployees", job.getTotalEmployees());
            response.put("processedEmployees", job.getProcessedEmployees());
            response.put("failedEmployees", job.getFailedEmployees());
            response.put("progressPercentage", job.getProgressPercentage());
            response.put("startedAt", job.getStartedAt());
            response.put("completedAt", job.getCompletedAt());
            response.put("errorMessage", job.getErrorMessage());
            
            return ResponseEntity.ok(ApiResponse.success("Job status retrieved", response));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/periods/{periodId}/job-status")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get latest job status for a payroll period")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getPeriodJobStatus(@PathVariable Long periodId) {
        try {
            PayrollJob job = processingService.getLatestJobForPeriod(periodId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("jobId", job.getId());
            response.put("periodId", job.getPayrollPeriodId());
            response.put("status", job.getStatus().name());
            response.put("totalEmployees", job.getTotalEmployees());
            response.put("processedEmployees", job.getProcessedEmployees());
            response.put("failedEmployees", job.getFailedEmployees());
            response.put("progressPercentage", job.getProgressPercentage());
            response.put("startedAt", job.getStartedAt());
            response.put("completedAt", job.getCompletedAt());
            response.put("errorMessage", job.getErrorMessage());
            
            return ResponseEntity.ok(ApiResponse.success("Job status retrieved", response));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/periods/{periodId}/approve")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Approve payroll period")
    public ResponseEntity<ApiResponse<Void>> approvePayroll(@PathVariable Long periodId) {
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow();
        processingService.approvePayrollPeriod(periodId, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll approved", null));
    }

    @PostMapping("/periods/{periodId}/recalculate")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Recalculate payroll period (async)")
    public ResponseEntity<ApiResponse<Map<String, Object>>> recalculatePayroll(@PathVariable Long periodId) {
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow();
        
        try {
            PayrollJob job = processingService.recalculatePayroll(periodId, userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("jobId", job.getId());
            response.put("periodId", periodId);
            response.put("status", job.getStatus().name());
            response.put("totalEmployees", job.getTotalEmployees());
            response.put("message", "Payroll recalculation started. Existing data cleared and fresh calculation initiated.");
            
            return ResponseEntity.ok(ApiResponse.success("Payroll recalculation started successfully", response));
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/periods/{periodId}/paid")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Mark payroll as paid")
    public ResponseEntity<ApiResponse<Void>> markAsPaid(@PathVariable Long periodId) {
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow();
        processingService.markPayrollAsPaid(periodId, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll marked as paid", null));
    }

    @PutMapping("/periods/{periodId}")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Update payroll period")
    public ResponseEntity<ApiResponse<PayrollPeriod>> updatePeriod(
            @PathVariable Long periodId,
            @RequestParam String periodName,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate paymentDate) {
        PayrollPeriod period = processingService.updatePayrollPeriod(periodId, periodName, startDate, endDate, paymentDate);
        return ResponseEntity.ok(ApiResponse.success("Period updated", period));
    }

    @DeleteMapping("/periods/{periodId}")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Delete payroll period")
    public ResponseEntity<ApiResponse<Void>> deletePeriod(@PathVariable Long periodId) {
        processingService.deletePayrollPeriod(periodId);
        return ResponseEntity.ok(ApiResponse.success("Period deleted", null));
    }

    @PostMapping("/periods/{periodId}/close")
    @PreAuthorize("hasAuthority('PAYROLL_MANAGE')")
    @Operation(summary = "Close payroll period")
    public ResponseEntity<ApiResponse<Void>> closePayroll(@PathVariable Long periodId) {
        processingService.closePayrollPeriod(periodId);
        return ResponseEntity.ok(ApiResponse.success("Payroll period closed", null));
    }
}
