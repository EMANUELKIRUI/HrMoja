package com.hrmoja.controller;

import com.hrmoja.entity.BankUploadFile;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.repository.PayrollPeriodRepository;
import com.hrmoja.service.BankFeedbackService;
import com.hrmoja.service.BankFileGenerationService;
import com.hrmoja.service.PaymentProcessingService;
import com.hrmoja.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Payment Management Controller
 * Handles bank file generation, feedback upload, and payment management
 */
@Slf4j
@RestController
@RequestMapping("/api/finance/payment-management")
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('PAYROLL_REVIEW')")
public class PaymentManagementController {

    private final PaymentProcessingService paymentService;
    private final BankFileGenerationService bankFileService;
    private final BankFeedbackService feedbackService;
    private final PayrollPeriodRepository periodRepository;

    /**
     * Get period details for payment management (no review validation)
     */
    @GetMapping("/periods/{periodId}")
    public ResponseEntity<PayrollPeriod> getPeriodForPayment(@PathVariable Long periodId) {
        try {
            PayrollPeriod period = periodRepository.findById(periodId)
                    .orElseThrow(() -> new IllegalArgumentException("Period not found"));
            return ResponseEntity.ok(period);
        } catch (Exception e) {
            log.error("Error getting period details", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get payment details for management
     */
    @GetMapping("/periods/{periodId}/payment-details")
    public ResponseEntity<Map<String, Object>> getPaymentManagementDetails(@PathVariable Long periodId) {
        try {
            Map<String, Object> details = paymentService.getPaymentDetails(periodId);
            return ResponseEntity.ok(details);
        } catch (Exception e) {
            log.error("Error getting payment management details", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Download bank file (CSV or Excel)
     */
    @GetMapping("/payments/{paymentId}/bank-file")
    public ResponseEntity<byte[]> downloadBankFile(
            @PathVariable Long paymentId,
            @RequestParam(defaultValue = "CSV") String format,
            Authentication authentication) {
        
        try {
            Long userId = getUserId(authentication);
            byte[] fileData = bankFileService.generateBankFileAndSave(paymentId, format, userId);
            
            String fileName = format.equalsIgnoreCase("EXCEL") 
                    ? "bank_file.xlsx" 
                    : "bank_file.csv";
            
            MediaType mediaType = format.equalsIgnoreCase("EXCEL")
                    ? MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    : MediaType.parseMediaType("text/csv");
            
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                    .contentType(mediaType)
                    .body(fileData);
                    
        } catch (IOException e) {
            log.error("Error generating bank file", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get bank file preview
     */
    @GetMapping("/periods/{periodId}/bank-file-preview")
    public ResponseEntity<List<BankFileGenerationService.BankFileEntry>> getBankFilePreview(
            @PathVariable Long periodId) {
        try {
            List<BankFileGenerationService.BankFileEntry> preview = bankFileService.getBankFilePreview(periodId);
            return ResponseEntity.ok(preview);
        } catch (Exception e) {
            log.error("Error getting bank file preview", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Upload bank feedback/acknowledgement file
     */
    @PostMapping("/periods/{periodId}/feedback")
    public ResponseEntity<Map<String, Object>> uploadBankFeedback(
            @PathVariable Long periodId,
            @RequestParam("file") MultipartFile file,
            Authentication authentication) {
        
        try {
            Long userId = getUserId(authentication);
            String userName = authentication.getName();
            
            BankUploadFile feedback = feedbackService.uploadBankFeedback(periodId, file, userId, userName);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("feedbackFile", feedback);
            response.put("discrepancyCount", feedback.getDiscrepancyCount());
            response.put("hasDiscrepancies", feedback.getDiscrepancyCount() > 0);
            
            return ResponseEntity.ok(response);
            
        } catch (IOException e) {
            log.error("Error uploading bank feedback", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to process feedback file: " + e.getMessage()));
        }
    }

    /**
     * Get feedback files for a period
     */
    @GetMapping("/periods/{periodId}/feedback")
    public ResponseEntity<List<BankUploadFile>> getFeedbackFiles(@PathVariable Long periodId) {
        try {
            List<BankUploadFile> files = feedbackService.getFeedbackFiles(periodId);
            return ResponseEntity.ok(files);
        } catch (Exception e) {
            log.error("Error getting feedback files", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get discrepancy report
     */
    @GetMapping("/periods/{periodId}/discrepancy-report")
    public ResponseEntity<Map<String, Object>> getDiscrepancyReport(@PathVariable Long periodId) {
        try {
            Map<String, Object> report = feedbackService.getDiscrepancyReport(periodId);
            return ResponseEntity.ok(report);
        } catch (Exception e) {
            log.error("Error getting discrepancy report", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Authorize payment
     */
    @PostMapping("/periods/{periodId}/authorize")
    public ResponseEntity<Map<String, Object>> authorizePayment(
            @PathVariable Long periodId,
            @RequestBody Map<String, String> paymentDetails,
            Authentication authentication) {
        
        try {
            Long userId = getUserId(authentication);
            
            var payment = paymentService.authorizePayment(periodId, userId, paymentDetails);
            
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "payment", payment,
                    "message", "Payment authorized successfully"
            ));
            
        } catch (IllegalStateException e) {
            log.warn("Payment authorization validation failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "success", false,
                            "error", e.getMessage()
                    ));
        } catch (Exception e) {
            log.error("Error authorizing payment", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "error", "An unexpected error occurred: " + e.getMessage()
                    ));
        }
    }

    /**
     * Execute payment (after bank file upload)
     */
    @PostMapping("/payments/{paymentId}/execute")
    public ResponseEntity<Map<String, Object>> executePayment(
            @PathVariable Long paymentId,
            @RequestBody Map<String, String> executionDetails,
            Authentication authentication) {
        
        try {
            Long userId = getUserId(authentication);
            
            var payment = paymentService.markPaymentAsExecuted(paymentId, userId, executionDetails);
            
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "payment", payment,
                    "message", "Payment executed successfully"
            ));
            
        } catch (IllegalStateException e) {
            log.warn("Payment execution validation failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "success", false,
                            "error", e.getMessage()
                    ));
        } catch (Exception e) {
            log.error("Error executing payment", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "error", "An unexpected error occurred: " + e.getMessage()
                    ));
        }
    }

    /**
     * Confirm payment completion
     */
    @PostMapping("/payments/{paymentId}/confirm")
    public ResponseEntity<Map<String, Object>> confirmPayment(
            @PathVariable Long paymentId,
            @RequestBody Map<String, String> confirmationDetails,
            Authentication authentication) {
        
        try {
            Long userId = getUserId(authentication);
            
            var payment = paymentService.confirmPaymentCompletion(paymentId, userId, confirmationDetails);
            
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "payment", payment,
                    "message", "Payment confirmed successfully - Period marked as PAID"
            ));
            
        } catch (IllegalStateException e) {
            log.warn("Payment confirmation validation failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(
                            "success", false,
                            "error", e.getMessage()
                    ));
        } catch (Exception e) {
            log.error("Error confirming payment", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                            "success", false,
                            "error", "An unexpected error occurred: " + e.getMessage()
                    ));
        }
    }

    private Long getUserId(Authentication authentication) {
        return SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
    }
}
