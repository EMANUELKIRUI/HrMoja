package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.settings.*;
import com.hrmoja.service.SettingsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/settings")
@RequiredArgsConstructor
@Tag(name = "Settings", description = "System settings and reference data")
@SecurityRequirement(name = "bearerAuth")
public class SettingsController {

    private final SettingsService settingsService;

    // Pay Frequencies
    @GetMapping("/pay-frequencies")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get all pay frequencies")
    public ResponseEntity<ApiResponse<List<SimpleDto>>> getAllPayFrequencies() {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getAllPayFrequencies()));
    }

    @GetMapping("/pay-frequencies/active")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<SimpleDto>>> getActivePayFrequencies() {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getActivePayFrequencies()));
    }

    @PostMapping("/pay-frequencies")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<SimpleDto>> createPayFrequency(@Valid @RequestBody SimpleDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Pay frequency created", settingsService.createPayFrequency(dto)));
    }

    // Employment Types
    @GetMapping("/employment-types")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<SimpleDto>>> getAllEmploymentTypes() {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getAllEmploymentTypes()));
    }

    @PostMapping("/employment-types")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<SimpleDto>> createEmploymentType(@Valid @RequestBody SimpleDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Employment type created", settingsService.createEmploymentType(dto)));
    }

    // Payment Methods
    @GetMapping("/payment-methods")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<SimpleDto>>> getAllPaymentMethods() {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getAllPaymentMethods()));
    }

    // Job Titles
    @GetMapping("/job-titles/organization/{organizationId}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<JobTitleDto>>> getJobTitles(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getJobTitlesByOrganization(organizationId)));
    }

    @PostMapping("/job-titles")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<JobTitleDto>> createJobTitle(@Valid @RequestBody JobTitleDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Job title created", settingsService.createJobTitle(dto)));
    }

    @PutMapping("/job-titles/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<JobTitleDto>> updateJobTitle(@PathVariable Long id, @Valid @RequestBody JobTitleDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Job title updated", settingsService.updateJobTitle(id, dto)));
    }

    @DeleteMapping("/job-titles/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<Void>> deleteJobTitle(@PathVariable Long id) {
        settingsService.deleteJobTitle(id);
        return ResponseEntity.ok(ApiResponse.success("Job title deactivated", null));
    }

    // Employee Grades
    @GetMapping("/grades/organization/{organizationId}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<EmployeeGradeDto>>> getGrades(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getGradesByOrganization(organizationId)));
    }

    @PostMapping("/grades")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<EmployeeGradeDto>> createGrade(@Valid @RequestBody EmployeeGradeDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Grade created", settingsService.createGrade(dto)));
    }

    // Banks
    @GetMapping("/banks/country/{countryId}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    public ResponseEntity<ApiResponse<List<BankDto>>> getBanksByCountry(@PathVariable Long countryId) {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getBanksByCountry(countryId)));
    }

    @PostMapping("/banks")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    public ResponseEntity<ApiResponse<BankDto>> createBank(@Valid @RequestBody BankDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Bank created", settingsService.createBank(dto)));
    }

    // Component Types
    @GetMapping("/component-types")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    @Operation(summary = "Get all payroll component types")
    public ResponseEntity<ApiResponse<List<ComponentTypeDto>>> getAllComponentTypes() {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getAllComponentTypes()));
    }

    @GetMapping("/component-types/active")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    public ResponseEntity<ApiResponse<List<ComponentTypeDto>>> getActiveComponentTypes() {
        return ResponseEntity.ok(ApiResponse.success(settingsService.getActiveComponentTypes()));
    }
}
