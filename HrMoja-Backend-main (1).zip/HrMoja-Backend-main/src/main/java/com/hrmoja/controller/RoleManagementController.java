package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.role.RoleCreateRequest;
import com.hrmoja.dto.role.RoleDto;
import com.hrmoja.service.RoleManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/roles")
@RequiredArgsConstructor
@Tag(name = "Role Management", description = "Role management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class RoleManagementController {

    private final RoleManagementService roleManagementService;

    @GetMapping
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Get all roles")
    public ResponseEntity<ApiResponse<List<RoleDto>>> getAllRoles() {
        return ResponseEntity.ok(ApiResponse.success(roleManagementService.getAllRoles()));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAuthority('USER_MANAGE') or hasAuthority('EMPLOYEE_CREATE')")
    @Operation(summary = "Get active roles for user assignment")
    public ResponseEntity<ApiResponse<List<RoleDto>>> getActiveRoles() {
        return ResponseEntity.ok(ApiResponse.success(roleManagementService.getActiveRoles()));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Get role by ID")
    public ResponseEntity<ApiResponse<RoleDto>> getRoleById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(roleManagementService.getRoleById(id)));
    }

    @GetMapping("/code/{code}")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Get role by code")
    public ResponseEntity<ApiResponse<RoleDto>> getRoleByCode(@PathVariable String code) {
        return ResponseEntity.ok(ApiResponse.success(roleManagementService.getRoleByCode(code)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Create new role")
    public ResponseEntity<ApiResponse<RoleDto>> createRole(@Valid @RequestBody RoleCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Role created successfully", roleManagementService.createRole(request)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Update role")
    public ResponseEntity<ApiResponse<RoleDto>> updateRole(@PathVariable Long id, @Valid @RequestBody RoleCreateRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Role updated successfully", roleManagementService.updateRole(id, request)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Deactivate role")
    public ResponseEntity<ApiResponse<Void>> deleteRole(@PathVariable Long id) {
        roleManagementService.deleteRole(id);
        return ResponseEntity.ok(ApiResponse.success("Role deactivated successfully", null));
    }

    @PostMapping("/{id}/permissions/add")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Add permissions to role")
    public ResponseEntity<ApiResponse<Void>> addPermissionsToRole(@PathVariable Long id, @RequestBody Set<Long> permissionIds) {
        roleManagementService.addPermissionsToRole(id, permissionIds);
        return ResponseEntity.ok(ApiResponse.success("Permissions added successfully", null));
    }

    @PostMapping("/{id}/permissions/remove")
    @PreAuthorize("hasAuthority('ROLE_MANAGE')")
    @Operation(summary = "Remove permissions from role")
    public ResponseEntity<ApiResponse<Void>> removePermissionsFromRole(@PathVariable Long id, @RequestBody Set<Long> permissionIds) {
        roleManagementService.removePermissionsFromRole(id, permissionIds);
        return ResponseEntity.ok(ApiResponse.success("Permissions removed successfully", null));
    }
}
