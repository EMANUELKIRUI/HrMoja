package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.settings.BranchDto;
import com.hrmoja.service.BranchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/settings/branches")
@RequiredArgsConstructor
@Tag(name = "Settings - Branches", description = "Branch management endpoints")
@SecurityRequirement(name = "bearerAuth")
public class BranchController {

    private final BranchService branchService;

    @GetMapping("/organization/{organizationId}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get branches by organization")
    public ResponseEntity<ApiResponse<List<BranchDto>>> getBranchesByOrganization(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(branchService.getBranchesByOrganization(organizationId)));
    }

    @GetMapping("/organization/{organizationId}/active")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get active branches by organization")
    public ResponseEntity<ApiResponse<List<BranchDto>>> getActiveBranches(@PathVariable Long organizationId) {
        return ResponseEntity.ok(ApiResponse.success(branchService.getActiveBranchesByOrganization(organizationId)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_READ')")
    @Operation(summary = "Get branch by ID")
    public ResponseEntity<ApiResponse<BranchDto>> getBranchById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(branchService.getBranchById(id)));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    @Operation(summary = "Create branch")
    public ResponseEntity<ApiResponse<BranchDto>> createBranch(@Valid @RequestBody BranchDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Branch created successfully", branchService.createBranch(dto)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    @Operation(summary = "Update branch")
    public ResponseEntity<ApiResponse<BranchDto>> updateBranch(@PathVariable Long id, @Valid @RequestBody BranchDto dto) {
        return ResponseEntity.ok(ApiResponse.success("Branch updated successfully", branchService.updateBranch(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SETTINGS_MANAGE')")
    @Operation(summary = "Delete branch")
    public ResponseEntity<ApiResponse<Void>> deleteBranch(@PathVariable Long id) {
        branchService.deleteBranch(id);
        return ResponseEntity.ok(ApiResponse.success("Branch deactivated successfully", null));
    }
}
