package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollApprovalAudit;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.service.ExecutivePayrollApprovalService;
import com.hrmoja.service.PayrollApprovalAuditService;
import com.hrmoja.service.FinancePayrollReviewService;
import com.hrmoja.util.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Executive Payroll Approval Controller
 * Handles Executive/CEO final approval tasks
 * - View periods reviewed by Finance (REVIEWED status)
 * - Final validation and approval at Level 3
 * - Authorize payment (APPROVED → PAID)
 */
@Slf4j
@RestController
@RequestMapping("/api/executive/payroll")
@RequiredArgsConstructor
@Tag(name = "Executive Payroll Approval", description = "Executive final payroll approval")
public class ExecutivePayrollApprovalController {

    private final ExecutivePayrollApprovalService executiveApprovalService;
    private final PayrollApprovalAuditService auditService;
    private final FinancePayrollReviewService financeReviewService;

    @GetMapping("/periods")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get payroll periods pending Executive approval")
    public ResponseEntity<ApiResponse<List<PayrollPeriod>>> getPeriodsForApproval(
            @RequestParam(required = false) String status) {
        log.info("Executive: Fetching periods for final approval, status: {}", status);
        List<PayrollPeriod> periods = executiveApprovalService.getPeriodsForApproval(status);
        return ResponseEntity.ok(ApiResponse.success("Periods retrieved", periods));
    }

    @GetMapping("/periods/{periodId}")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get period details for Executive approval")
    public ResponseEntity<ApiResponse<PayrollPeriod>> getPeriodDetails(@PathVariable Long periodId) {
        log.info("Executive: Fetching period {} details", periodId);
        PayrollPeriod period = executiveApprovalService.getPeriodForApproval(periodId);
        return ResponseEntity.ok(ApiResponse.success("Period details retrieved", period));
    }

    @GetMapping("/periods/{periodId}/records")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get paginated employee records for Executive review")
    public ResponseEntity<ApiResponse<Page<EmployeePayrollRecord>>> getEmployeeRecords(
            @PathVariable Long periodId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String department,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Executive: Fetching paginated employee records for period {}", periodId);
        Pageable pageable = PageRequest.of(page, size);
        Page<EmployeePayrollRecord> records = financeReviewService.getEmployeeRecordsForReview(periodId, search, department, pageable);
        return ResponseEntity.ok(ApiResponse.success("Employee records retrieved", records));
    }

    @GetMapping("/periods/{periodId}/summary")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get financial summary for Executive review")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getFinancialSummary(@PathVariable Long periodId) {
        log.info("Executive: Fetching financial summary for period {}", periodId);
        Map<String, Object> summary = financeReviewService.getFinancialSummary(periodId);
        return ResponseEntity.ok(ApiResponse.success("Financial summary retrieved", summary));
    }

    @GetMapping("/periods/{periodId}/validation-report")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get validation report for Executive review")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getValidationReport(@PathVariable Long periodId) {
        log.info("Executive: Fetching validation report for period {}", periodId);
        Map<String, Object> report = financeReviewService.generateValidationReport(periodId);
        return ResponseEntity.ok(ApiResponse.success("Validation report retrieved", report));
    }

    @GetMapping("/periods/{periodId}/executive-summary")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get executive summary with approval trail")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getExecutiveSummary(
            @PathVariable Long periodId) {
        log.info("Executive: Fetching executive summary for period {}", periodId);
        Map<String, Object> summary = executiveApprovalService.getExecutiveSummary(periodId);
        return ResponseEntity.ok(ApiResponse.success("Executive summary retrieved", summary));
    }

    @PostMapping("/periods/{periodId}/approve")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Give final approval (Level 3)")
    public ResponseEntity<ApiResponse<PayrollPeriod>> giveFinApproval(
            @PathVariable Long periodId,
            @RequestBody(required = false) Map<String, String> comments) {
        log.info("Executive: Giving final approval to period {}", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String comment = comments != null ? comments.get("comment") : null;
        PayrollPeriod period = executiveApprovalService.giveFinalApproval(periodId, userId, comment);
        return ResponseEntity.ok(ApiResponse.success(
                "Payroll finally approved (Level 3) - Ready for payment", period));
    }

    @PostMapping("/periods/{periodId}/reject")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Reject period and return to Finance/HR")
    public ResponseEntity<ApiResponse<PayrollPeriod>> rejectPeriod(
            @PathVariable Long periodId,
            @RequestBody Map<String, String> request) {
        log.info("Executive: Rejecting period {}", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String reason = request.get("reason");
        PayrollPeriod period = executiveApprovalService.rejectPeriod(periodId, userId, reason);
        return ResponseEntity.ok(ApiResponse.success(
                "Period rejected and returned for corrections", period));
    }

    @PostMapping("/periods/{periodId}/authorize-payment")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Authorize payment - Mark as PAID")
    public ResponseEntity<ApiResponse<PayrollPeriod>> authorizePayment(@PathVariable Long periodId) {
        log.info("Executive: Authorizing payment for period {}", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        PayrollPeriod period = executiveApprovalService.authorizePayment(periodId, userId);
        return ResponseEntity.ok(ApiResponse.success(
                "Payment authorized - Payroll marked as PAID", period));
    }

    @GetMapping("/dashboard")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get Executive payroll dashboard")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getExecutiveDashboard() {
        log.info("Executive: Fetching payroll dashboard");
        Map<String, Object> dashboard = executiveApprovalService.getExecutiveDashboard();
        return ResponseEntity.ok(ApiResponse.success("Dashboard data retrieved", dashboard));
    }

    @GetMapping("/periods/{periodId}/audit-trail")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    @Operation(summary = "Get complete audit trail for a period")
    public ResponseEntity<ApiResponse<List<PayrollApprovalAudit>>> getAuditTrail(@PathVariable Long periodId) {
        log.info("Executive: Fetching audit trail for period {}", periodId);
        List<PayrollApprovalAudit> auditTrail = auditService.getAuditTrail(periodId);
        return ResponseEntity.ok(ApiResponse.success("Audit trail retrieved", auditTrail));
    }
}
