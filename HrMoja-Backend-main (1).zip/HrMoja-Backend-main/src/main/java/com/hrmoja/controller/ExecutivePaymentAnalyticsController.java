package com.hrmoja.controller;

import com.hrmoja.entity.BankUploadFile;
import com.hrmoja.service.BankFeedbackService;
import com.hrmoja.service.PaymentProcessingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Executive Payment Analytics Controller
 * Provides payment oversight and discrepancy visibility for executives/CEO
 */
@Slf4j
@RestController
@RequestMapping("/api/executive/payment-analytics")
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
public class ExecutivePaymentAnalyticsController {

    private final PaymentProcessingService paymentService;
    private final BankFeedbackService feedbackService;

    /**
     * Get all payment periods with discrepancy overview
     */
    @GetMapping("/overview")
    public ResponseEntity<Map<String, Object>> getPaymentOverview() {
        try {
            Map<String, Object> overview = new HashMap<>();
            overview.put("message", "Payment overview - implementation pending");
            return ResponseEntity.ok(overview);
        } catch (Exception e) {
            log.error("Error getting payment overview", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get discrepancy report for a specific period
     */
    @GetMapping("/periods/{periodId}/discrepancies")
    public ResponseEntity<Map<String, Object>> getDiscrepancyReport(@PathVariable Long periodId) {
        try {
            Map<String, Object> report = feedbackService.getDiscrepancyReport(periodId);
            return ResponseEntity.ok(report);
        } catch (Exception e) {
            log.error("Error getting discrepancy report for period {}", periodId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get all periods with discrepancies (alert view)
     */
    @GetMapping("/discrepancies/alert")
    public ResponseEntity<Map<String, Object>> getDiscrepancyAlerts() {
        try {
            Map<String, Object> alerts = new HashMap<>();
            
            // Get all feedback files with discrepancies
            // This would need a service method to aggregate across periods
            alerts.put("message", "Discrepancy alerts endpoint");
            alerts.put("hasAlerts", true);
            
            return ResponseEntity.ok(alerts);
        } catch (Exception e) {
            log.error("Error getting discrepancy alerts", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get feedback files for a period
     */
    @GetMapping("/periods/{periodId}/feedback-files")
    public ResponseEntity<List<BankUploadFile>> getFeedbackFiles(@PathVariable Long periodId) {
        try {
            List<BankUploadFile> files = feedbackService.getFeedbackFiles(periodId);
            return ResponseEntity.ok(files);
        } catch (Exception e) {
            log.error("Error getting feedback files for period {}", periodId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get payment analytics summary for a period
     */
    @GetMapping("/periods/{periodId}/analytics")
    public ResponseEntity<Map<String, Object>> getPaymentAnalytics(@PathVariable Long periodId) {
        try {
            Map<String, Object> analytics = new HashMap<>();
            
            // Get discrepancy report
            Map<String, Object> discrepancyReport = feedbackService.getDiscrepancyReport(periodId);
            
            // Get payment details
            Map<String, Object> paymentDetails = paymentService.getPaymentDetails(periodId);
            
            // Combine analytics
            analytics.put("periodId", periodId);
            analytics.put("discrepancyReport", discrepancyReport);
            analytics.put("paymentDetails", paymentDetails);
            analytics.put("hasDiscrepancies", discrepancyReport.get("hasDiscrepancies"));
            analytics.put("totalDiscrepancies", discrepancyReport.get("totalDiscrepancies"));
            analytics.put("feedbackFilesCount", discrepancyReport.get("totalFeedbackFiles"));
            
            return ResponseEntity.ok(analytics);
        } catch (Exception e) {
            log.error("Error getting payment analytics for period {}", periodId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Get payment integrity report (file hashing, locking status)
     */
    @GetMapping("/periods/{periodId}/integrity")
    public ResponseEntity<Map<String, Object>> getPaymentIntegrityReport(@PathVariable Long periodId) {
        try {
            Map<String, Object> integrity = new HashMap<>();
            
            // Get discrepancy report which includes file integrity info
            Map<String, Object> report = feedbackService.getDiscrepancyReport(periodId);
            
            BankUploadFile generatedFile = (BankUploadFile) report.get("generatedFile");
            
            if (generatedFile != null) {
                integrity.put("fileGenerated", true);
                integrity.put("fileLocked", generatedFile.getIsLocked());
                integrity.put("fileHash", generatedFile.getFileHash());
                integrity.put("fileName", generatedFile.getFileName());
                integrity.put("fileSize", generatedFile.getFileSize());
                integrity.put("totalRecords", generatedFile.getTotalRecords());
                integrity.put("totalAmount", generatedFile.getTotalAmount());
            } else {
                integrity.put("fileGenerated", false);
            }
            
            integrity.put("feedbackFilesCount", report.get("totalFeedbackFiles"));
            integrity.put("hasDiscrepancies", report.get("hasDiscrepancies"));
            
            return ResponseEntity.ok(integrity);
        } catch (Exception e) {
            log.error("Error getting integrity report for period {}", periodId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }
}
