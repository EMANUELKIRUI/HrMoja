package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollLineItem;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.service.HRPayrollPreparationService;
import com.hrmoja.service.PartialApprovalService;
import com.hrmoja.service.PayrollLineItemService;
import com.hrmoja.util.SecurityUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * HR Payroll Preparation Controller
 * Handles HR department's payroll preparation tasks
 * - View processed payroll periods
 * - Edit employee payroll line items
 * - Approve individual employee records (Level 1)
 * - Submit period for Finance review
 */
@Slf4j
@RestController
@RequestMapping("/api/hr/payroll")
@RequiredArgsConstructor
@Tag(name = "HR Payroll Preparation", description = "HR department payroll preparation and editing")
public class HRPayrollPreparationController {

    private final HRPayrollPreparationService hrPayrollService;
    private final PayrollLineItemService lineItemService;
    private final PartialApprovalService partialApprovalService;

    @GetMapping("/periods")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Get payroll periods available for HR preparation (paginated with search)")
    public ResponseEntity<ApiResponse<Page<PayrollPeriod>>> getPeriodsForPreparation(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        log.info("HR: Fetching periods for preparation, status: {}, search: {}, page: {}, size: {}", status, search, page, size);
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "startDate"));
        Page<PayrollPeriod> periods = hrPayrollService.getPeriodsForPreparation(status, search, pageable);
        return ResponseEntity.ok(ApiResponse.success("Periods retrieved", periods));
    }

    @GetMapping("/periods/{periodId}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Get period details for HR preparation")
    public ResponseEntity<ApiResponse<PayrollPeriod>> getPeriodDetails(@PathVariable Long periodId) {
        log.info("HR: Fetching period {} details", periodId);
        PayrollPeriod period = hrPayrollService.getPeriodForEdit(periodId);
        return ResponseEntity.ok(ApiResponse.success("Period details retrieved", period));
    }

    @GetMapping("/periods/{periodId}/records")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Get employee records for a period (paginated with search and filters)")
    public ResponseEntity<ApiResponse<Page<EmployeePayrollRecord>>> getEmployeeRecords(
            @PathVariable Long periodId,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer approvalLevel,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("HR: Fetching employee records for period {}, search: {}, dept: {}, status: {}, level: {}", 
                periodId, search, department, status, approvalLevel);
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.ASC, "employee.employeeNumber"));
        Page<EmployeePayrollRecord> records = hrPayrollService.getEmployeeRecordsPaginated(
                periodId, search, department, status, approvalLevel, pageable);
        return ResponseEntity.ok(ApiResponse.success("Employee records retrieved", records));
    }

    @GetMapping("/records/{recordId}/line-items")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Get line items for an employee record")
    public ResponseEntity<ApiResponse<List<PayrollLineItem>>> getLineItems(@PathVariable Long recordId) {
        log.info("HR: Fetching line items for record {}", recordId);
        List<PayrollLineItem> lineItems = lineItemService.getLineItemsByRecordId(recordId);
        return ResponseEntity.ok(ApiResponse.success("Line items retrieved", lineItems));
    }

    @PutMapping("/line-items/{lineItemId}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Update a payroll line item")
    public ResponseEntity<ApiResponse<PayrollLineItem>> updateLineItem(
            @PathVariable Long lineItemId,
            @RequestBody Map<String, Object> updates) {
        log.info("HR: Updating line item {}", lineItemId);
        
        BigDecimal amount = updates.containsKey("amount") ? 
                new BigDecimal(updates.get("amount").toString()) : null;
        
        // Use existing updateLineItemAmount method
        PayrollLineItem updated = lineItemService.updateLineItemAmount(lineItemId, amount);
        return ResponseEntity.ok(ApiResponse.success("Line item updated", updated));
    }

    @PostMapping("/line-items")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Add a new payroll line item")
    public ResponseEntity<ApiResponse<PayrollLineItem>> addLineItem(
            @RequestBody Map<String, Object> lineItemData) {
        log.info("HR: Adding new line item");
        
        Long recordId = Long.parseLong(lineItemData.get("recordId").toString());
        String componentName = (String) lineItemData.get("componentName");
        String componentCode = (String) lineItemData.get("componentCode");
        String category = (String) lineItemData.get("category");
        BigDecimal amount = new BigDecimal(lineItemData.get("amount").toString());
        
        PayrollLineItem item = lineItemService.addLineItem(recordId, componentName, componentCode, category, amount);
        return ResponseEntity.ok(ApiResponse.success("Line item added", item));
    }

    @DeleteMapping("/line-items/{lineItemId}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Delete a payroll line item")
    public ResponseEntity<ApiResponse<Void>> deleteLineItem(@PathVariable Long lineItemId) {
        log.info("HR: Deleting line item {}", lineItemId);
        lineItemService.deleteLineItem(lineItemId);
        return ResponseEntity.ok(ApiResponse.success("Line item deleted", null));
    }

    @PostMapping("/records/{recordId}/recalculate")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Recalculate employee record after edits")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> recalculateRecord(@PathVariable Long recordId) {
        log.info("HR: Recalculating employee record {}", recordId);
        EmployeePayrollRecord record = hrPayrollService.recalculateEmployeeRecord(recordId);
        return ResponseEntity.ok(ApiResponse.success("Record recalculated", record));
    }

    // Level 1 Approvals
    @PostMapping("/records/{recordId}/approve")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Approve employee record at Level 1 (HR)")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> approveRecord(@PathVariable Long recordId) {
        log.info("HR: Approving employee record {} at Level 1", recordId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        EmployeePayrollRecord record = partialApprovalService.approveRecord(recordId, userId);
        return ResponseEntity.ok(ApiResponse.success("Record approved at Level 1", record));
    }

    @PostMapping("/records/{recordId}/unapprove")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Remove Level 1 approval from employee record")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> unapproveRecord(@PathVariable Long recordId) {
        log.info("HR: Unapproving employee record {}", recordId);
        EmployeePayrollRecord record = partialApprovalService.unapproveRecord(recordId);
        return ResponseEntity.ok(ApiResponse.success("Record unapproved", record));
    }

    @PostMapping("/records/{recordId}/reject")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Reject employee record with reason")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> rejectRecord(
            @PathVariable Long recordId,
            @RequestBody Map<String, String> request) {
        log.info("HR: Rejecting employee record {}", recordId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String reason = request.get("reason");
        EmployeePayrollRecord record = partialApprovalService.rejectRecord(recordId, userId, reason);
        return ResponseEntity.ok(ApiResponse.success("Record rejected", record));
    }

    @PostMapping("/periods/{periodId}/approve-all")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Approve all records in period at Level 1")
    public ResponseEntity<ApiResponse<Integer>> approveAllRecords(@PathVariable Long periodId) {
        log.info("HR: Approving all records in period {} at Level 1", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        int approved = partialApprovalService.approveAllRecords(periodId, userId);
        return ResponseEntity.ok(ApiResponse.success(
                String.format("%d records approved at Level 1", approved), approved));
    }

    @PostMapping("/periods/{periodId}/submit-for-review")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Submit period for Finance review (Level 1 → Level 2)")
    public ResponseEntity<ApiResponse<PayrollPeriod>> submitForReview(
            @PathVariable Long periodId,
            @RequestBody(required = false) Map<String, String> request) {
        log.info("HR: Submitting period {} for Finance review", periodId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
                new IllegalStateException("User not authenticated"));
        String comment = request != null ? request.get("comment") : null;
        PayrollPeriod period = hrPayrollService.submitForReview(periodId, userId, comment);
        return ResponseEntity.ok(ApiResponse.success(
                "Period submitted for Finance review", period));
    }

    @GetMapping("/periods/{periodId}/approval-stats")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    @Operation(summary = "Get approval statistics for a period")
    public ResponseEntity<ApiResponse<PartialApprovalService.ApprovalStats>> getApprovalStats(
            @PathVariable Long periodId) {
        log.info("HR: Fetching approval stats for period {}", periodId);
        PartialApprovalService.ApprovalStats stats = partialApprovalService.getApprovalStats(periodId);
        return ResponseEntity.ok(ApiResponse.success("Approval stats retrieved", stats));
    }
}
