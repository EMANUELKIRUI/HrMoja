package com.hrmoja.controller;

import com.hrmoja.dto.common.ApiResponse;
import com.hrmoja.dto.PayrollJobStatusDto;
import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollJob;
import com.hrmoja.entity.PayrollLineItem;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.entity.PayrollRun;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.service.PayrollProcessingService;
import com.hrmoja.service.PayrollApprovalService;
import com.hrmoja.service.PayrollLineItemService;
import com.hrmoja.service.PartialApprovalService;
import com.hrmoja.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payroll/periods")
@RequiredArgsConstructor
@Slf4j
public class PayrollPeriodController {

    private final PayrollProcessingService payrollProcessingService;
    private final PayrollApprovalService payrollApprovalService;
    private final PayrollLineItemService payrollLineItemService;
    private final PartialApprovalService partialApprovalService;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<List<PayrollPeriod>>> getPeriods(
            @RequestParam Long organizationId) {
        log.info("Fetching payroll periods for organization: {}", organizationId);
        List<PayrollPeriod> periods = payrollProcessingService.getPeriodsByOrganization(organizationId);
        return ResponseEntity.ok(ApiResponse.success("Periods retrieved successfully", periods));
    }
    
    @GetMapping("/paginated")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Page<PayrollPeriod>>> getPeriodsPaginated(
            @RequestParam Long organizationId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String periodType,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        log.info("Fetching paginated payroll periods for organization: {}, page: {}, size: {}", organizationId, page, size);
        
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "startDate"));
        
        Page<PayrollPeriod> periods = payrollProcessingService.getPeriodsPaginated(
                organizationId, status, search, periodType, 
                startDate != null ? LocalDate.parse(startDate) : null,
                endDate != null ? LocalDate.parse(endDate) : null,
                pageable);
        
        return ResponseEntity.ok(ApiResponse.success("Periods retrieved successfully", periods));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> getPeriodById(@PathVariable Long id) {
        log.info("Fetching payroll period: {}", id);
        PayrollPeriod period = payrollProcessingService.getPeriodById(id);
        return ResponseEntity.ok(ApiResponse.success("Period retrieved successfully", period));
    }

    @PostMapping
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> createPeriod(
            @RequestParam Long organizationId,
            @RequestParam String periodName,
            @RequestParam String periodType,
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam String paymentDate) {
        log.info("Creating payroll period: {} for organization: {}", periodName, organizationId);
        
        PayrollPeriod period = payrollProcessingService.createPayrollPeriod(
                organizationId,
                periodName,
                periodType,
                LocalDate.parse(startDate),
                LocalDate.parse(endDate),
                LocalDate.parse(paymentDate)
        );
        
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Period created successfully", period));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> updatePeriod(
            @PathVariable Long id,
            @RequestParam String periodName,
            @RequestParam String startDate,
            @RequestParam String endDate,
            @RequestParam String paymentDate) {
        log.info("Updating payroll period: {}", id);
        
        PayrollPeriod period = payrollProcessingService.updatePayrollPeriod(
                id,
                periodName,
                LocalDate.parse(startDate),
                LocalDate.parse(endDate),
                LocalDate.parse(paymentDate)
        );
        
        return ResponseEntity.ok(ApiResponse.success("Period updated successfully", period));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Void>> deletePeriod(@PathVariable Long id) {
        log.info("Deleting payroll period: {}", id);
        payrollProcessingService.deletePayrollPeriod(id);
        return ResponseEntity.ok(ApiResponse.success("Period deleted successfully", null));
    }

    @PostMapping("/{id}/process")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> processPeriod(@PathVariable Long id) {
        log.info("Processing payroll period: {}", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        
        try {
            PayrollJob job = payrollProcessingService.initiatePayrollProcessing(id, userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("jobId", job.getId());
            response.put("periodId", id);
            response.put("status", job.getStatus().name());
            response.put("totalEmployees", job.getTotalEmployees());
            
            return ResponseEntity.ok(ApiResponse.success("Payroll processing started successfully", response));
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/{id}/job-status")
    @PreAuthorize("hasAuthority('PAYROLL_READ')")
    public ResponseEntity<ApiResponse<PayrollJobStatusDto>> getJobStatus(@PathVariable Long id) {
        log.debug("Getting job status for payroll period: {}", id);
        
        try {
            // Get latest job for the period (id is period ID, not job ID)
            PayrollJob job = payrollProcessingService.getLatestJobForPeriod(id);
            
            PayrollJobStatusDto dto = PayrollJobStatusDto.builder()
                    .jobId(job.getId())
                    .payrollPeriodId(job.getPayrollPeriodId())
                    .status(job.getStatus())
                    .totalEmployees(job.getTotalEmployees())
                    .processedEmployees(job.getProcessedEmployees())
                    .failedEmployees(job.getFailedEmployees())
                    .progressPercentage(job.getProgressPercentage())
                    .startedAt(job.getStartedAt())
                    .completedAt(job.getCompletedAt())
                    .errorMessage(job.getErrorMessage())
                    .build();
            
            // Calculate duration if job is complete
            if (dto.getStartedAt() != null && dto.getCompletedAt() != null) {
                long seconds = java.time.Duration.between(dto.getStartedAt(), dto.getCompletedAt()).getSeconds();
                dto.setDurationSeconds(seconds);
            }
            
            return ResponseEntity.ok(ApiResponse.success("Job status retrieved", dto));
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{id}/recalculate")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Void>> recalculatePeriod(@PathVariable Long id) {
        log.info("Recalculating payroll period: {}", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        payrollProcessingService.recalculatePayroll(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll recalculated successfully", null));
    }

    // 3-Level Approval Workflow
    @PostMapping("/{id}/prepare")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> markAsPrepared(@PathVariable Long id) {
        log.info("Marking payroll period as prepared: {}", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        PayrollPeriod period = payrollApprovalService.markAsPrepared(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll marked as prepared (Level 1)", period));
    }

    @PostMapping("/{id}/review")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> markAsReviewed(@PathVariable Long id) {
        log.info("Marking payroll period as reviewed: {}", id);
        // TODO: Get actual userId from security context
        Long userId = 2L; // Different user for review
        PayrollPeriod period = payrollApprovalService.markAsReviewed(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll reviewed successfully (Level 2)", period));
    }

    @PostMapping("/{id}/final-approve")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> giveFinalApproval(@PathVariable Long id) {
        log.info("Giving final approval to payroll period: {}", id);
        // TODO: Get actual userId from security context
        Long userId = 3L; // Different user for final approval
        PayrollPeriod period = payrollApprovalService.givesFinalApproval(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll finally approved (Level 3)", period));
    }

    @PostMapping("/{id}/reject")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    public ResponseEntity<ApiResponse<PayrollPeriod>> rejectPayroll(
            @PathVariable Long id,
            @RequestParam String reason) {
        log.info("Rejecting payroll period: {}", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        PayrollPeriod period = payrollApprovalService.rejectPayroll(id, userId, reason);
        return ResponseEntity.ok(ApiResponse.success("Payroll rejected", period));
    }

    // Legacy single-step approval (kept for backward compatibility)
    @PostMapping("/{id}/approve")
    @PreAuthorize("hasAuthority('PAYROLL_APPROVE')")
    public ResponseEntity<ApiResponse<Void>> approvePeriod(@PathVariable Long id) {
        log.info("Approving payroll period: {}", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        payrollProcessingService.approvePayrollPeriod(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll approved successfully", null));
    }

    @PostMapping("/{id}/paid")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Void>> markAsPaid(@PathVariable Long id) {
        log.info("Marking payroll period as paid: {}", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        payrollProcessingService.markPayrollAsPaid(id, userId);
        return ResponseEntity.ok(ApiResponse.success("Payroll marked as paid successfully", null));
    }

    @PostMapping("/{id}/close")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Void>> closePeriod(@PathVariable Long id) {
        log.info("Closing payroll period: {}", id);
        payrollProcessingService.closePayrollPeriod(id);
        return ResponseEntity.ok(ApiResponse.success("Payroll period closed successfully", null));
    }

    // Payroll Records Endpoints
    @GetMapping("/{id}/records")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    @Transactional(readOnly = true) // Keep session open for lazy-loaded relationships
    public ResponseEntity<ApiResponse<List<EmployeePayrollRecord>>> getPeriodRecords(@PathVariable Long id) {
        log.info("Fetching payroll records for period: {}", id);
        List<EmployeePayrollRecord> records = payrollProcessingService.getPayrollRecordsByPeriod(id);
        return ResponseEntity.ok(ApiResponse.success("Records retrieved successfully", records));
    }

    @GetMapping("/records/{recordId}")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> getRecordById(@PathVariable Long recordId) {
        log.info("Fetching payroll record: {}", recordId);
        // This will need to be implemented in the service
        return ResponseEntity.ok(ApiResponse.success("Record retrieved successfully", null));
    }

    @GetMapping("/records/{recordId}/line-items")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<List<PayrollLineItem>>> getRecordLineItems(@PathVariable Long recordId) {
        log.info("Fetching line items for record: {}", recordId);
        List<PayrollLineItem> lineItems = payrollProcessingService.getLineItemsByRecord(recordId);
        return ResponseEntity.ok(ApiResponse.success("Line items retrieved successfully", lineItems));
    }

    @GetMapping("/{id}/runs")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<List<PayrollRun>>> getPeriodRuns(@PathVariable Long id) {
        log.info("Fetching payroll runs for period: {}", id);
        // This will need to be implemented in the service
        return ResponseEntity.ok(ApiResponse.success("Runs retrieved successfully", null));
    }

    // Line Item Editing Endpoints (Level 1 - PREPARED stage)
    @PutMapping("/line-items/{lineItemId}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PayrollLineItem>> updateLineItem(
            @PathVariable Long lineItemId,
            @RequestParam java.math.BigDecimal amount) {
        log.info("Updating line item {} with amount {}", lineItemId, amount);
        PayrollLineItem updated = payrollLineItemService.updateLineItemAmount(lineItemId, amount);
        return ResponseEntity.ok(ApiResponse.success("Line item updated successfully", updated));
    }

    @PostMapping("/records/{recordId}/line-items")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PayrollLineItem>> addLineItem(
            @PathVariable Long recordId,
            @RequestParam String componentName,
            @RequestParam String componentCode,
            @RequestParam String category,
            @RequestParam java.math.BigDecimal amount) {
        log.info("Adding line item {} to record {}", componentName, recordId);
        PayrollLineItem lineItem = payrollLineItemService.addLineItem(
                recordId, componentName, componentCode, category, amount);
        return ResponseEntity.ok(ApiResponse.success("Line item added successfully", lineItem));
    }

    @DeleteMapping("/line-items/{lineItemId}")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Void>> deleteLineItem(@PathVariable Long lineItemId) {
        log.info("Deleting line item {}", lineItemId);
        payrollLineItemService.deleteLineItem(lineItemId);
        return ResponseEntity.ok(ApiResponse.success("Line item deleted successfully", null));
    }

    @PostMapping("/records/{recordId}/recalculate")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Void>> recalculateEmployeeRecord(@PathVariable Long recordId) {
        log.info("Recalculating employee record {}", recordId);
        payrollLineItemService.recalculateEmployeeRecord(recordId);
        return ResponseEntity.ok(ApiResponse.success("Employee record recalculated successfully", null));
    }

    // Partial Approval Endpoints (Level 1)
    @PostMapping("/records/{recordId}/approve-level1")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> approveRecordLevel1(@PathVariable Long recordId) {
        log.info("Approving employee record {} at Level 1", recordId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        EmployeePayrollRecord record = partialApprovalService.approveRecord(recordId, userId);
        return ResponseEntity.ok(ApiResponse.success("Record approved at Level 1", record));
    }

    @PostMapping("/records/{recordId}/unapprove-level1")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> unapproveRecordLevel1(@PathVariable Long recordId) {
        log.info("Unapproving employee record {} at Level 1", recordId);
        EmployeePayrollRecord record = partialApprovalService.unapproveRecord(recordId);
        return ResponseEntity.ok(ApiResponse.success("Record unapproved", record));
    }

    @PostMapping("/records/bulk-approve-level1")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Integer>> bulkApproveLevel1(@RequestBody List<Long> recordIds) {
        log.info("Bulk approving {} records at Level 1", recordIds.size());
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        int approved = partialApprovalService.approveRecords(recordIds, userId);
        return ResponseEntity.ok(ApiResponse.success(String.format("%d records approved", approved), approved));
    }

    @PostMapping("/{id}/approve-all-level1")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<Integer>> approveAllLevel1(@PathVariable Long id) {
        log.info("Approving all records in period {} at Level 1", id);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        int approved = partialApprovalService.approveAllRecords(id, userId);
        return ResponseEntity.ok(ApiResponse.success(String.format("%d records approved", approved), approved));
    }

    @PostMapping("/records/{recordId}/reject")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> rejectRecord(
            @PathVariable Long recordId,
            @RequestParam String reason) {
        log.info("Rejecting employee record {}", recordId);
        Long userId = SecurityUtils.getCurrentUserId().orElseThrow(() -> 
            new IllegalStateException("User not authenticated"));
        EmployeePayrollRecord record = partialApprovalService.rejectRecord(recordId, userId, reason);
        return ResponseEntity.ok(ApiResponse.success("Record rejected", record));
    }

    @PostMapping("/records/{recordId}/restore")
    @PreAuthorize("hasAuthority('PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<EmployeePayrollRecord>> restoreRecord(@PathVariable Long recordId) {
        log.info("Restoring rejected employee record {}", recordId);
        EmployeePayrollRecord record = partialApprovalService.restoreRecord(recordId);
        return ResponseEntity.ok(ApiResponse.success("Record restored", record));
    }

    @GetMapping("/{id}/approval-stats")
    @PreAuthorize("hasAnyAuthority('PAYROLL_READ', 'PAYROLL_PROCESS')")
    public ResponseEntity<ApiResponse<PartialApprovalService.ApprovalStats>> getApprovalStats(@PathVariable Long id) {
        log.info("Fetching approval stats for period {}", id);
        PartialApprovalService.ApprovalStats stats = partialApprovalService.getApprovalStats(id);
        return ResponseEntity.ok(ApiResponse.success("Stats retrieved", stats));
    }
}
