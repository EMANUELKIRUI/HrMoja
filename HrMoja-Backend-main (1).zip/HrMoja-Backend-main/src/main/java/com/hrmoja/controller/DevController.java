package com.hrmoja.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

/**
 * Development Controller - FOR DEVELOPMENT ONLY
 * Remove or disable in production
 */
@RestController
@RequestMapping("/api/dev")
@RequiredArgsConstructor
@Profile("default") // Only available in default profile
public class DevController {

    private final PasswordEncoder passwordEncoder;

    @GetMapping("/encode-password")
    public String encodePassword(@RequestParam String password) {
        String encoded = passwordEncoder.encode(password);
        return String.format("Password: %s\nEncoded: %s", password, encoded);
    }

    @GetMapping("/verify-password")
    public String verifyPassword(@RequestParam String raw, @RequestParam String encoded) {
        boolean matches = passwordEncoder.matches(raw, encoded);
        return String.format("Raw: %s\nEncoded: %s\nMatches: %s", raw, encoded, matches);
    }
}
