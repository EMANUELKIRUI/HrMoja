package com.hrmoja.dto.organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Organization Registration Response DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrganizationRegistrationResponse {

    private Long organizationId;
    private String organizationName;
    private Long adminUserId;
    private String adminUsername;
    private String adminEmail;
    private Long branchId;
    private String branchName;
    private String message;
    private boolean emailVerificationRequired;
}
