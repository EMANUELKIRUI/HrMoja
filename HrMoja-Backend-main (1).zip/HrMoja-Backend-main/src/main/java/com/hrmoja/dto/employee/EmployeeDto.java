package com.hrmoja.dto.employee;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Employee DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeDto {

    private Long id;

    @NotBlank(message = "Employee number is required")
    private String employeeNumber;

    @NotNull(message = "Organization is required")
    private Long organizationId;

    private Long branchId;
    private String branchName;

    private Long departmentId;
    private String departmentName;

    // Personal Information
    @NotBlank(message = "First name is required")
    private String firstName;

    private String middleName;

    @NotBlank(message = "Last name is required")
    private String lastName;

    @NotNull(message = "Date of birth is required")
    @Past(message = "Date of birth must be in the past")
    private LocalDate dateOfBirth;

    private String gender;
    private String maritalStatus;
    private String nationality;
    private String nationalId;
    private String passportNumber;

    // Contact Information
    @Email(message = "Personal email must be valid")
    private String personalEmail;

    @Email(message = "Work email must be valid")
    private String workEmail;

    private String mobilePhone;
    private String homePhone;
    private String emergencyContactName;
    private String emergencyContactPhone;
    private String emergencyContactRelationship;

    // Address
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String postalCode;
    private Long countryId;
    private String countryName;

    // Employment Information
    @NotNull(message = "Hire date is required")
    private LocalDate hireDate;

    private LocalDate confirmationDate;
    private LocalDate probationEndDate;
    private LocalDate terminationDate;
    private String terminationReason;

    private Long employmentTypeId;
    private String employmentTypeName;

    private Long jobTitleId;
    private String jobTitleName;

    private Long employeeGradeId;
    private String employeeGradeName;

    private Long reportsToEmployeeId;
    private String reportsToEmployeeName;

    private String employmentStatus;
    private boolean isActive;

    private String photoUrl;
    private String bio;

    private Long userId;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
