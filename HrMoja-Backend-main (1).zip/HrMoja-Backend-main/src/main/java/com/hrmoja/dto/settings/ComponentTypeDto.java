package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComponentTypeDto {
    private Long id;
    
    @NotBlank(message = "Name is required")
    private String name;
    
    @NotBlank(message = "Code is required")
    private String code;
    
    private String description;
    
    @NotBlank(message = "Calculation category is required")
    private String calculationCategory; // EARNING, DEDUCTION, BENEFIT, TAX, STATUTORY
    
    private Boolean isSystemType;
    private Boolean isActive;
}
