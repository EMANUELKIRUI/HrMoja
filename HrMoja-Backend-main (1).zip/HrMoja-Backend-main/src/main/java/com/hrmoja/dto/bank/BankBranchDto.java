package com.hrmoja.dto.bank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Bank Branch DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BankBranchDto {

    private Long id;
    private Long bankId;
    private String name;
    private String code;
    private String address;
    private boolean active;
}
