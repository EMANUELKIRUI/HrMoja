package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BankDto {

    private Long id;

    @NotNull(message = "Country is required")
    private Long countryId;

    private String countryName;

    @NotBlank(message = "Bank name is required")
    private String name;

    private String code;
    private String swiftCode;
    private boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
