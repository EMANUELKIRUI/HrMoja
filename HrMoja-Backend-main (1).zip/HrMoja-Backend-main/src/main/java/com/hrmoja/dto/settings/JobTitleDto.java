package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobTitleDto {

    private Long id;

    @NotNull(message = "Organization is required")
    private Long organizationId;

    @NotBlank(message = "Title is required")
    private String title;

    private String code;
    private String description;
    private Integer level;
    private boolean isActive;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
