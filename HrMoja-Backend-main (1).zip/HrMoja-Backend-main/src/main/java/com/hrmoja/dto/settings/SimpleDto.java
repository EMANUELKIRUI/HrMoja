package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Simple DTO for basic entities (PayFrequency, EmploymentType, PaymentMethod)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SimpleDto {

    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Code is required")
    private String code;

    private String description;

    private Integer periodsPerYear; // For PayFrequency

    private boolean isActive;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
