package com.hrmoja.dto.permission;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for creating/updating permissions
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PermissionCreateRequest {

    @NotBlank(message = "Permission name is required")
    @Size(max = 100, message = "Name must not exceed 100 characters")
    private String name;

    @NotBlank(message = "Permission code is required")
    @Size(max = 100, message = "Code must not exceed 100 characters")
    private String code;

    private String description;

    @NotBlank(message = "Module is required")
    @Size(max = 50, message = "Module must not exceed 50 characters")
    private String module;
}
