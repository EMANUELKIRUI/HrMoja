package com.hrmoja.dto.report;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PayrollSummaryReport {
    private String periodName;
    private LocalDate startDate;
    private LocalDate endDate;
    private LocalDate paymentDate;
    
    private Integer totalEmployees;
    private Integer activeEmployees;
    private Integer processedEmployees;
    
    private BigDecimal totalBasicSalary;
    private BigDecimal totalAllowances;
    private BigDecimal totalGrossSalary;
    private BigDecimal totalDeductions;
    private BigDecimal totalNetSalary;
    
    private BigDecimal totalPaye;
    private BigDecimal totalNssfEmployee;
    private BigDecimal totalNssfEmployer;
    private BigDecimal totalLst;
    
    private BigDecimal averageGrossSalary;
    private BigDecimal averageNetSalary;
    
    private String status;
}
