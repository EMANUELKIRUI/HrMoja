package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Branch DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BranchDto {
    
    private Long id;
    
    @NotNull(message = "Organization ID is required")
    private Long organizationId;
    
    @NotBlank(message = "Branch name is required")
    @Size(max = 255, message = "Branch name cannot exceed 255 characters")
    private String name;
    
    @NotBlank(message = "Branch code is required")
    @Size(max = 50, message = "Branch code cannot exceed 50 characters")
    private String code;
    
    @Size(max = 500, message = "Description cannot exceed 500 characters")
    private String description;
    
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvince;
    private String postalCode;
    private Long countryId;
    private String countryName;
    
    @Size(max = 50, message = "Phone cannot exceed 50 characters")
    private String phoneNumber;
    
    @Size(max = 255, message = "Email cannot exceed 255 characters")
    private String email;
    
    private Long managerId;
    private String managerName;
    
    private Boolean isActive;
    private Boolean isHeadOffice;
}
