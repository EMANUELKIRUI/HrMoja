package com.hrmoja.dto.settings;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Country DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CountryDto {

    private Long id;

    @NotBlank(message = "Country name is required")
    @Size(max = 100)
    private String name;

    @NotBlank(message = "Country code is required")
    @Size(min = 3, max = 3, message = "Country code must be 3 characters")
    private String code;

    @NotBlank(message = "ISO code is required")
    @Size(min = 2, max = 2, message = "ISO code must be 2 characters")
    private String isoCode;

    @NotBlank(message = "Currency code is required")
    @Size(min = 3, max = 3, message = "Currency code must be 3 characters")
    private String currencyCode;

    @NotBlank(message = "Currency name is required")
    private String currencyName;

    private String currencySymbol;

    @NotBlank(message = "Timezone is required")
    private String timezone;

    private String dateFormat;

    private boolean isActive;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
