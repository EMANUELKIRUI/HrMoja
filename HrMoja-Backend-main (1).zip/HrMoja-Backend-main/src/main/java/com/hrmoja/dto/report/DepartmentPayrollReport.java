package com.hrmoja.dto.report;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DepartmentPayrollReport {
    private String departmentName;
    private Integer employeeCount;
    private BigDecimal totalGrossSalary;
    private BigDecimal totalNetSalary;
    private BigDecimal totalDeductions;
    private BigDecimal averageSalary;
    private BigDecimal percentageOfTotal;
}
