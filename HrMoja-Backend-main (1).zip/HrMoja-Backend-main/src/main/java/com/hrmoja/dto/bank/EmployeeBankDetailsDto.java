package com.hrmoja.dto.bank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Employee Bank Details DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeBankDetailsDto {

    private Long id;
    private Long employeeId;
    private Long bankId;
    private String bankName;
    private Long bankBranchId;
    private String bankBranchName;
    private String accountNumber;
    private String accountName;
    private String accountType;
    private String swiftCode;
    private String iban;
    private boolean primary;
    private boolean active;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
