package com.hrmoja.dto.settings;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Organization DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrganizationDto {

    private Long id;

    @NotBlank(message = "Organization name is required")
    private String name;

    private String legalName;

    private String registrationNumber;

    private String taxIdentificationNumber;

    @NotNull(message = "Country is required")
    private Long countryId;

    private String countryName;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String stateProvince;

    private String postalCode;

    private String phoneNumber;

    @Email(message = "Email must be valid")
    private String email;

    private String website;

    private String logoUrl;

    private boolean isActive;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
