package com.hrmoja.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Organization Context Filter for Multi-Tenancy
 * Sets the organization context for each request based on authenticated user
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OrganizationContextFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {
        
        try {
            // Extract organization ID from authenticated user
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            
            if (authentication != null && authentication.isAuthenticated() 
                    && authentication.getPrincipal() instanceof UserDetailsImpl) {
                UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
                Long organizationId = userDetails.getOrganizationId();
                
                if (organizationId != null) {
                    OrganizationContext.setCurrentOrganizationId(organizationId);
                    log.debug("Organization context set from authenticated user: {}", organizationId);
                }
            }
            
            // Fallback to header if no authenticated user (for public endpoints)
            if (OrganizationContext.getCurrentOrganizationId() == null) {
                String orgIdHeader = request.getHeader("X-Organization-Id");
                if (orgIdHeader != null) {
                    try {
                        Long organizationId = Long.parseLong(orgIdHeader);
                        OrganizationContext.setCurrentOrganizationId(organizationId);
                        log.debug("Organization context set from header: {}", organizationId);
                    } catch (NumberFormatException e) {
                        log.warn("Invalid organization ID header: {}", orgIdHeader);
                    }
                }
            }

            filterChain.doFilter(request, response);
        } finally {
            // Always clear the context after request processing
            OrganizationContext.clear();
            log.debug("Clearing organization context");
        }
    }
}
