package com.hrmoja.service;

import com.hrmoja.dto.permission.PermissionCreateRequest;
import com.hrmoja.dto.permission.PermissionDto;
import com.hrmoja.entity.Permission;
import com.hrmoja.exception.DuplicateResourceException;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.PermissionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Permission Management Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PermissionManagementService {

    private final PermissionRepository permissionRepository;

    @Transactional(readOnly = true)
    public List<PermissionDto> getAllPermissions() {
        return permissionRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PermissionDto> getActivePermissions() {
        return permissionRepository.findByIsActiveTrue().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PermissionDto> getPermissionsByModule(String module) {
        return permissionRepository.findByModule(module).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PermissionDto getPermissionById(Long id) {
        Permission permission = permissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + id));
        return convertToDto(permission);
    }

    @Transactional(readOnly = true)
    public PermissionDto getPermissionByCode(String code) {
        Permission permission = permissionRepository.findByCode(code)
                .orElseThrow(() -> new ResourceNotFoundException("Permission not found with code: " + code));
        return convertToDto(permission);
    }

    @Transactional
    public PermissionDto createPermission(PermissionCreateRequest request) {
        log.info("Creating new permission with code: {}", request.getCode());

        // Check for duplicate code
        if (permissionRepository.findByCode(request.getCode()).isPresent()) {
            throw new DuplicateResourceException("Permission with code '" + request.getCode() + "' already exists");
        }

        Permission permission = Permission.builder()
                .name(request.getName())
                .code(request.getCode())
                .description(request.getDescription())
                .module(request.getModule())
                .isActive(true)
                .build();

        permission = permissionRepository.save(permission);
        log.info("Permission created successfully with ID: {}", permission.getId());

        return convertToDto(permission);
    }

    @Transactional
    public PermissionDto updatePermission(Long id, PermissionCreateRequest request) {
        log.info("Updating permission with ID: {}", id);

        Permission permission = permissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + id));

        // Check for duplicate code if code is being changed
        if (!permission.getCode().equals(request.getCode())) {
            if (permissionRepository.findByCode(request.getCode()).isPresent()) {
                throw new DuplicateResourceException("Permission with code '" + request.getCode() + "' already exists");
            }
        }

        permission.setName(request.getName());
        permission.setCode(request.getCode());
        permission.setDescription(request.getDescription());
        permission.setModule(request.getModule());

        permission = permissionRepository.save(permission);
        log.info("Permission updated successfully: {}", id);

        return convertToDto(permission);
    }

    @Transactional
    public void deletePermission(Long id) {
        log.info("Deactivating permission with ID: {}", id);

        Permission permission = permissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + id));

        permission.setActive(false);
        permissionRepository.save(permission);

        log.info("Permission deactivated successfully: {}", id);
    }

    @Transactional
    public void activatePermission(Long id) {
        log.info("Activating permission with ID: {}", id);

        Permission permission = permissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + id));

        permission.setActive(true);
        permissionRepository.save(permission);

        log.info("Permission activated successfully: {}", id);
    }

    private PermissionDto convertToDto(Permission permission) {
        return PermissionDto.builder()
                .id(permission.getId())
                .name(permission.getName())
                .code(permission.getCode())
                .description(permission.getDescription())
                .module(permission.getModule())
                .isActive(permission.isActive())
                .createdAt(permission.getCreatedAt())
                .updatedAt(permission.getUpdatedAt())
                .build();
    }
}
