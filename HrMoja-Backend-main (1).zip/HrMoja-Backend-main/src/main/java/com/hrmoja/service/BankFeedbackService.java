package com.hrmoja.service;

import com.hrmoja.entity.BankUploadFile;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.BankUploadFileRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Service for handling bank feedback/acknowledgement files
 * and performing fraud detection analytics
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BankFeedbackService {

    private final BankUploadFileRepository bankUploadFileRepository;
    private final PayrollPeriodRepository periodRepository;

    /**
     * Upload and process bank feedback file
     */
    @Transactional
    public BankUploadFile uploadBankFeedback(Long periodId, MultipartFile file, Long userId, String userName) 
            throws IOException {
        
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        // Get original generated file
        BankUploadFile generatedFile = bankUploadFileRepository.findLockedGeneratedFile(periodId)
                .orElseThrow(() -> new IllegalStateException("No locked generated file found for this period"));

        // Read and parse feedback file
        byte[] fileBytes = file.getBytes();
        String fileHash = calculateSHA256(fileBytes);
        
        // Create feedback file record
        BankUploadFile feedbackFile = BankUploadFile.builder()
                .payrollPeriodId(periodId)
                .organizationId(period.getOrganization().getId())
                .fileName(file.getOriginalFilename())
                .fileFormat(getFileFormat(file.getOriginalFilename()))
                .fileType("FEEDBACK")
                .fileHash(fileHash)
                .fileSize(file.getSize())
                .totalRecords(0) // Will be updated after parsing
                .totalAmount(BigDecimal.ZERO) // Will be updated after parsing
                .uploadStatus("UPLOADED")
                .uploadedAt(LocalDateTime.now())
                .uploadedBy(userId)
                .generatedBy(userId)
                .isLocked(true)
                .notes("Bank feedback file uploaded by " + userName)
                .build();

        // Parse and analyze feedback file
        Map<String, Object> analysisResult = analyzeFeedbackFile(fileBytes, generatedFile);
        
        feedbackFile.setTotalRecords((Integer) analysisResult.get("totalRecords"));
        feedbackFile.setTotalAmount((BigDecimal) analysisResult.get("totalAmount"));
        feedbackFile.setDiscrepancyCount((Integer) analysisResult.get("discrepancyCount"));
        feedbackFile.setDiscrepancyDetails((String) analysisResult.get("discrepancyDetails"));

        // Link feedback to generated file
        feedbackFile.setFeedbackFileId(generatedFile.getId());
        
        BankUploadFile savedFeedback = bankUploadFileRepository.save(feedbackFile);
        
        log.info("Bank feedback file uploaded for period {} with {} discrepancies", 
                periodId, feedbackFile.getDiscrepancyCount());
        
        return savedFeedback;
    }

    /**
     * Analyze feedback file and compare with generated file
     */
    private Map<String, Object> analyzeFeedbackFile(byte[] feedbackBytes, BankUploadFile generatedFile) 
            throws IOException {
        
        Map<String, Object> result = new HashMap<>();
        List<String> discrepancies = new ArrayList<>();
        
        try (CSVParser parser = CSVParser.parse(
                new String(feedbackBytes, StandardCharsets.UTF_8), 
                CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreEmptyLines())) {
            
            int recordCount = 0;
            BigDecimal totalAmount = BigDecimal.ZERO;
            
            for (CSVRecord record : parser) {
                recordCount++;
                
                // Parse feedback record
                String accountNumber = getRecordValue(record, "Account Number");
                String amountStr = getRecordValue(record, "Amount", "Amount (UGX)");
                BigDecimal amount = parseAmount(amountStr);
                
                if (amount != null) {
                    totalAmount = totalAmount.add(amount);
                }
                
                // TODO: Compare with original generated file data
                // For now, just track basic info
            }
            
            // Check for amount discrepancy
            if (!totalAmount.equals(generatedFile.getTotalAmount())) {
                discrepancies.add(String.format("Total amount mismatch: Generated=%.2f, Feedback=%.2f",
                        generatedFile.getTotalAmount(), totalAmount));
            }
            
            // Check for record count discrepancy
            if (recordCount != generatedFile.getTotalRecords()) {
                discrepancies.add(String.format("Record count mismatch: Generated=%d, Feedback=%d",
                        generatedFile.getTotalRecords(), recordCount));
            }
            
            result.put("totalRecords", recordCount);
            result.put("totalAmount", totalAmount);
            result.put("discrepancyCount", discrepancies.size());
            result.put("discrepancyDetails", String.join("\n", discrepancies));
            
        } catch (Exception e) {
            log.error("Error analyzing feedback file", e);
            result.put("totalRecords", 0);
            result.put("totalAmount", BigDecimal.ZERO);
            result.put("discrepancyCount", 1);
            result.put("discrepancyDetails", "Error parsing feedback file: " + e.getMessage());
        }
        
        return result;
    }

    /**
     * Get feedback file details for a period
     */
    public List<BankUploadFile> getFeedbackFiles(Long periodId) {
        return bankUploadFileRepository.findFeedbackFiles(periodId);
    }

    /**
     * Get discrepancy report
     */
    public Map<String, Object> getDiscrepancyReport(Long periodId) {
        List<BankUploadFile> feedbackFiles = bankUploadFileRepository.findFeedbackFiles(periodId);
        BankUploadFile generatedFile = bankUploadFileRepository.findLockedGeneratedFile(periodId)
                .orElse(null);

        Map<String, Object> report = new HashMap<>();
        report.put("periodId", periodId);
        report.put("generatedFile", generatedFile);
        report.put("feedbackFiles", feedbackFiles);
        report.put("totalFeedbackFiles", feedbackFiles.size());
        
        int totalDiscrepancies = feedbackFiles.stream()
                .mapToInt(f -> f.getDiscrepancyCount() != null ? f.getDiscrepancyCount() : 0)
                .sum();
        
        report.put("totalDiscrepancies", totalDiscrepancies);
        report.put("hasDiscrepancies", totalDiscrepancies > 0);
        
        return report;
    }

    // Helper methods
    
    private String calculateSHA256(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            return bytesToHex(hash);
        } catch (NoSuchAlgorithmException e) {
            log.error("SHA-256 algorithm not available", e);
            return null;
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    private String getFileFormat(String fileName) {
        if (fileName.toLowerCase().endsWith(".csv")) {
            return "CSV";
        } else if (fileName.toLowerCase().endsWith(".xlsx") || fileName.toLowerCase().endsWith(".xls")) {
            return "EXCEL";
        }
        return "UNKNOWN";
    }

    private String getRecordValue(CSVRecord record, String... possibleHeaders) {
        for (String header : possibleHeaders) {
            try {
                if (record.isMapped(header)) {
                    return record.get(header);
                }
            } catch (Exception e) {
                // Continue to next header
            }
        }
        return "";
    }

    private BigDecimal parseAmount(String amountStr) {
        try {
            // Remove currency symbols and commas
            String cleaned = amountStr.replaceAll("[^0-9.]", "");
            return new BigDecimal(cleaned);
        } catch (Exception e) {
            return null;
        }
    }
}
