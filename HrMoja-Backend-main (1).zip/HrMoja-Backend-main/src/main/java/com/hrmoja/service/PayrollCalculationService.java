package com.hrmoja.service;

import com.hrmoja.entity.*;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

/**
 * Payroll Calculation Service
 * Handles all payroll calculations including PAYE, NSSF, LST
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollCalculationService {

    private final TaxBracketRepository taxBracketRepository;
    private final StatutoryConfigurationRepository statutoryConfigurationRepository;
    private final EmployeePayrollComponentRepository employeePayrollComponentRepository;

    /**
     * Calculate PAYE tax using progressive tax brackets
     */
    public BigDecimal calculatePAYE(BigDecimal taxableIncome, Long countryId, LocalDate periodDate) {
        List<TaxBracket> brackets = taxBracketRepository.findActiveBracketsForDate(countryId, periodDate);
        
        if (brackets.isEmpty()) {
            log.warn("No tax brackets found for country {} on date {}", countryId, periodDate);
            return BigDecimal.ZERO;
        }

        BigDecimal totalTax = BigDecimal.ZERO;
        BigDecimal remainingIncome = taxableIncome;

        for (TaxBracket bracket : brackets) {
            if (remainingIncome.compareTo(BigDecimal.ZERO) <= 0) {
                break;
            }

            BigDecimal bracketAmount;
            if (bracket.getMaxIncome() != null) {
                // Not the top bracket
                BigDecimal bracketMax = bracket.getMaxIncome().subtract(bracket.getMinIncome());
                bracketAmount = remainingIncome.min(bracketMax);
            } else {
                // Top bracket (no maximum)
                bracketAmount = remainingIncome;
            }

            BigDecimal bracketTax = bracketAmount
                    .multiply(bracket.getTaxRate())
                    .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

            totalTax = totalTax.add(bracketTax);
            remainingIncome = remainingIncome.subtract(bracketAmount);
        }

        return totalTax.setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Calculate NSSF employee contribution
     */
    public BigDecimal calculateNSSFEmployee(BigDecimal grossSalary, Long countryId, LocalDate periodDate) {
        return calculateStatutoryAmount(grossSalary, countryId, "NSSF", periodDate, true);
    }

    /**
     * Calculate NSSF employer contribution
     */
    public BigDecimal calculateNSSFEmployer(BigDecimal grossSalary, Long countryId, LocalDate periodDate) {
        return calculateStatutoryAmount(grossSalary, countryId, "NSSF", periodDate, false);
    }

    /**
     * Calculate LST (Local Service Tax)
     */
    public BigDecimal calculateLST(Long countryId, LocalDate periodDate) {
        StatutoryConfiguration lstConfig = statutoryConfigurationRepository
                .findActiveConfigurationForDate(countryId, "LST", periodDate)
                .orElse(null);

        if (lstConfig != null && lstConfig.getFixedAmount() != null) {
            return lstConfig.getFixedAmount();
        }

        return BigDecimal.ZERO;
    }

    /**
     * Calculate taxable income
     */
    public BigDecimal calculateTaxableIncome(BigDecimal grossSalary, BigDecimal nssfEmployee, BigDecimal totalNonTaxableAllowances) {
        return grossSalary
                .subtract(nssfEmployee)
                .subtract(totalNonTaxableAllowances)
                .max(BigDecimal.ZERO);
    }

    /**
     * Calculate gross salary
     */
    public BigDecimal calculateGrossSalary(BigDecimal basicSalary, BigDecimal totalAllowances) {
        return basicSalary.add(totalAllowances);
    }

    /**
     * Calculate net salary
     */
    public BigDecimal calculateNetSalary(BigDecimal grossSalary, BigDecimal totalDeductions) {
        return grossSalary.subtract(totalDeductions).max(BigDecimal.ZERO);
    }

    /**
     * Pro-rate salary based on days worked
     */
    public BigDecimal prorateSalary(BigDecimal fullSalary, int daysWorked, int daysInMonth) {
        if (daysWorked >= daysInMonth) {
            return fullSalary;
        }

        return fullSalary
                .multiply(BigDecimal.valueOf(daysWorked))
                .divide(BigDecimal.valueOf(daysInMonth), 2, RoundingMode.HALF_UP);
    }

    /**
     * Helper method to calculate statutory amounts
     */
    private BigDecimal calculateStatutoryAmount(BigDecimal grossSalary, Long countryId, String code, 
                                                LocalDate periodDate, boolean isEmployee) {
        StatutoryConfiguration config = statutoryConfigurationRepository
                .findActiveConfigurationForDate(countryId, code, periodDate)
                .orElse(null);

        if (config == null) {
            log.warn("No statutory configuration found for {} on date {}", code, periodDate);
            return BigDecimal.ZERO;
        }

        BigDecimal rate = isEmployee ? config.getEmployeeContributionRate() : config.getEmployerContributionRate();
        
        if (rate == null) {
            return BigDecimal.ZERO;
        }

        BigDecimal amount = grossSalary
                .multiply(rate)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);

        // Apply ceiling if configured
        if (config.getCeilingAmount() != null && amount.compareTo(config.getCeilingAmount()) > 0) {
            amount = config.getCeilingAmount();
        }

        // Apply minimum if configured
        if (config.getMinimumAmount() != null && amount.compareTo(config.getMinimumAmount()) < 0) {
            amount = config.getMinimumAmount();
        }

        return amount.setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Validate payroll calculation
     */
    public boolean validatePayrollCalculation(PayrollRecord record) {
        // Basic validation
        if (record.getGrossSalary().compareTo(BigDecimal.ZERO) < 0) {
            log.error("Invalid gross salary for employee {}", record.getEmployeeNumber());
            return false;
        }

        if (record.getNetSalary().compareTo(BigDecimal.ZERO) < 0) {
            log.error("Invalid net salary for employee {}", record.getEmployeeNumber());
            return false;
        }

        // Verify calculation accuracy
        BigDecimal calculatedGross = record.getBasicSalary().add(record.getTotalAllowances());
        if (calculatedGross.compareTo(record.getGrossSalary()) != 0) {
            log.warn("Gross salary mismatch for employee {}", record.getEmployeeNumber());
        }

        BigDecimal calculatedDeductions = record.getTotalStatutoryDeductions().add(record.getTotalOtherDeductions());
        if (calculatedDeductions.compareTo(record.getTotalDeductions()) != 0) {
            log.warn("Total deductions mismatch for employee {}", record.getEmployeeNumber());
        }

        BigDecimal calculatedNet = record.getGrossSalary().subtract(record.getTotalDeductions());
        if (calculatedNet.compareTo(record.getNetSalary()) != 0) {
            log.error("Net salary calculation error for employee {}", record.getEmployeeNumber());
            return false;
        }

        return true;
    }
}
