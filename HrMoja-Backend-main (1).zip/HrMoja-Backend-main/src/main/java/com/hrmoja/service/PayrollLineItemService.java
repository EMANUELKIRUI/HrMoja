package com.hrmoja.service;

import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollLineItem;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.PayrollLineItemRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * Service for editing payroll line items at Level 1 (PREPARED stage)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollLineItemService {

    private final PayrollLineItemRepository lineItemRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollPeriodRepository periodRepository;

    /**
     * Get all line items for an employee payroll record
     */
    public List<PayrollLineItem> getLineItemsByRecordId(Long recordId) {
        return lineItemRepository.findByEmployeePayrollRecordId(recordId);
    }

    /**
     * Update a line item amount (only at PREPARED stage - Level 1)
     */
    @Transactional
    public PayrollLineItem updateLineItemAmount(Long lineItemId, BigDecimal newAmount) {
        PayrollLineItem lineItem = lineItemRepository.findById(lineItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Line item not found"));

        EmployeePayrollRecord record = lineItem.getEmployeePayrollRecord();
        PayrollPeriod period = record.getPayrollPeriod();

        // Only allow editing at PREPARED stage (Level 1)
        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only edit line items at PREPARED stage (Level 1). Current status: " + period.getStatus());
        }

        lineItem.setAmount(newAmount);
        PayrollLineItem saved = lineItemRepository.save(lineItem);

        // Recalculate the employee record totals
        recalculateEmployeeRecord(record.getId());

        log.info("Updated line item {} amount to {}", lineItemId, newAmount);
        return saved;
    }

    /**
     * Add a new line item to an employee record
     */
    @Transactional
    public PayrollLineItem addLineItem(Long recordId, String componentName, String componentCode,
                                       String category, BigDecimal amount) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll record not found"));

        PayrollPeriod period = record.getPayrollPeriod();

        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only add line items at PREPARED stage (Level 1)");
        }

        PayrollLineItem lineItem = PayrollLineItem.builder()
                .employeePayrollRecord(record)
                .componentName(componentName)
                .componentCode(componentCode)
                .componentCategory(category)
                .calculationMethod("MANUAL")
                .amount(amount)
                .quantity(BigDecimal.ONE)
                .isTaxable("EARNING".equals(category))
                .isPensionable(false)
                .isStatutory(false)
                .displayOrder(90) // Manual items at the end
                .build();

        PayrollLineItem saved = lineItemRepository.save(lineItem);
        recalculateEmployeeRecord(recordId);

        log.info("Added new line item {} to record {}", componentName, recordId);
        return saved;
    }

    /**
     * Delete a line item (only manual/non-statutory items)
     */
    @Transactional
    public void deleteLineItem(Long lineItemId) {
        PayrollLineItem lineItem = lineItemRepository.findById(lineItemId)
                .orElseThrow(() -> new ResourceNotFoundException("Line item not found"));

        EmployeePayrollRecord record = lineItem.getEmployeePayrollRecord();
        PayrollPeriod period = record.getPayrollPeriod();

        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only delete line items at PREPARED stage (Level 1)");
        }

        if (lineItem.isStatutory()) {
            throw new IllegalStateException("Cannot delete statutory line items (NSSF, PAYE, LST)");
        }

        Long recordId = record.getId();
        lineItemRepository.delete(lineItem);
        recalculateEmployeeRecord(recordId);

        log.info("Deleted line item {}", lineItemId);
    }

    /**
     * Recalculate employee record totals after line item changes
     */
    @Transactional
    public void recalculateEmployeeRecord(Long recordId) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll record not found"));

        List<PayrollLineItem> lineItems = lineItemRepository.findByEmployeePayrollRecordId(recordId);

        BigDecimal totalEarnings = BigDecimal.ZERO;
        BigDecimal totalDeductions = BigDecimal.ZERO;
        BigDecimal totalStatutory = BigDecimal.ZERO;
        BigDecimal totalTaxes = BigDecimal.ZERO;

        for (PayrollLineItem item : lineItems) {
            if ("EARNING".equals(item.getComponentCategory())) {
                totalEarnings = totalEarnings.add(item.getAmount());
            } else if ("DEDUCTION".equals(item.getComponentCategory())) {
                totalDeductions = totalDeductions.add(item.getAmount());
            } else if ("STATUTORY".equals(item.getComponentCategory())) {
                totalStatutory = totalStatutory.add(item.getAmount());
            } else if ("TAX".equals(item.getComponentCategory())) {
                totalTaxes = totalTaxes.add(item.getAmount());
            }
        }

        BigDecimal grossSalary = record.getBasicSalary().add(totalEarnings);
        BigDecimal allDeductions = totalStatutory.add(totalTaxes).add(totalDeductions);
        BigDecimal netSalary = grossSalary.subtract(allDeductions);

        record.setGrossSalary(grossSalary);
        record.setTotalEarnings(totalEarnings);
        record.setTotalStatutory(totalStatutory);
        record.setTotalTaxes(totalTaxes);
        record.setTotalDeductions(allDeductions);
        record.setNetSalary(netSalary);

        recordRepository.save(record);

        // Update period totals
        updatePeriodTotals(record.getPayrollPeriod().getId());

        log.info("Recalculated employee record {}: Gross={}, Net={}", recordId, grossSalary, netSalary);
    }

    /**
     * Update period totals after employee record changes
     */
    private void updatePeriodTotals(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);

        BigDecimal totalGross = BigDecimal.ZERO;
        BigDecimal totalDeductions = BigDecimal.ZERO;
        BigDecimal totalNet = BigDecimal.ZERO;

        for (EmployeePayrollRecord record : records) {
            totalGross = totalGross.add(record.getGrossSalary());
            totalDeductions = totalDeductions.add(record.getTotalDeductions());
            totalNet = totalNet.add(record.getNetSalary());
        }

        period.setTotalGrossPay(totalGross);
        period.setTotalDeductions(totalDeductions);
        period.setTotalNetPay(totalNet);

        periodRepository.save(period);
    }
}
