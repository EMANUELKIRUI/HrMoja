package com.hrmoja.service;

import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.PayrollPeriodRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Payroll Approval Service - Handles 3-level approval workflow
 * Level 1: PREPARED (Payroll Officer)
 * Level 2: REVIEWED (Payroll Manager)
 * Level 3: APPROVED (Finance Director/CFO)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollApprovalService {

    private final PayrollPeriodRepository periodRepository;
    private final PayrollApprovalAuditService auditService;

    /**
     * Level 1: Mark payroll as prepared (after processing)
     */
    @Transactional
    public PayrollPeriod markAsPrepared(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Only processed periods can be marked as prepared");
        }

        String previousStatus = period.getStatus();
        period.setStatus("PREPARED");
        period.setApprovalLevel("LEVEL_1_PREPARED");
        period.setPreparedBy(userId);
        period.setPreparedAt(LocalDateTime.now());
        
        PayrollPeriod saved = periodRepository.save(period);
        
        // Log audit trail
        auditService.logStatusChange(saved, "PREPARED", "LEVEL_1", userId, null, 
                previousStatus, "PREPARED", "HR preparation completed");
        
        log.info("Payroll period {} marked as PREPARED by user {}", periodId, userId);
        return saved;
    }

    /**
     * Level 2: Mark payroll as reviewed
     */
    @Transactional
    public PayrollPeriod markAsReviewed(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"PREPARED".equals(period.getStatus())) {
            throw new IllegalStateException("Only prepared periods can be reviewed");
        }

        // Prevent self-approval
        if (userId.equals(period.getPreparedBy())) {
            throw new IllegalStateException("Reviewer cannot be the same as preparer");
        }

        String previousStatus = period.getStatus();
        period.setStatus("REVIEWED");
        period.setApprovalLevel("LEVEL_2_REVIEWED");
        period.setReviewedBy(userId);
        period.setReviewedAt(LocalDateTime.now());
        
        PayrollPeriod saved = periodRepository.save(period);
        
        // Log audit trail
        auditService.logStatusChange(saved, "REVIEWED", "LEVEL_2", userId, null,
                previousStatus, "REVIEWED", "Finance review completed");
        
        log.info("Payroll period {} marked as REVIEWED by user {}", periodId, userId);
        return saved;
    }

    /**
     * Level 3: Final approval
     */
    @Transactional
    public PayrollPeriod givesFinalApproval(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"REVIEWED".equals(period.getStatus())) {
            throw new IllegalStateException("Only reviewed periods can be finally approved");
        }

        // Prevent self-approval
        if (userId.equals(period.getPreparedBy()) || userId.equals(period.getReviewedBy())) {
            throw new IllegalStateException("Final approver cannot be the preparer or reviewer");
        }

        String previousStatus = period.getStatus();
        period.setStatus("APPROVED");
        period.setApprovalLevel("LEVEL_3_APPROVED");
        period.setFinalApprovedBy(userId);
        period.setFinalApprovedAt(LocalDateTime.now());
        
        // Set legacy approved fields for backward compatibility
        period.setApprovedBy(userId);
        period.setApprovedAt(LocalDateTime.now());
        
        PayrollPeriod saved = periodRepository.save(period);
        
        // Log audit trail
        auditService.logStatusChange(saved, "APPROVED", "LEVEL_3", userId, null,
                previousStatus, "APPROVED", "Executive final approval granted");
        
        log.info("Payroll period {} FINALLY APPROVED by user {}", periodId, userId);
        return saved;
    }

    /**
     * Reject payroll at any approval level
     */
    @Transactional
    public PayrollPeriod rejectPayroll(Long periodId, Long userId, String reason) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!canReject(period.getStatus())) {
            throw new IllegalStateException("Cannot reject payroll in current status: " + period.getStatus());
        }

        // Capture original status and determine approval level BEFORE changing
        String previousStatus = period.getStatus();
        String level = "PREPARED".equals(previousStatus) ? "LEVEL_2" : 
                       "REVIEWED".equals(previousStatus) ? "LEVEL_3" : "LEVEL_1";
        
        // Reset to PROCESSING for corrections (one step back in workflow)
        period.setStatus("PROCESSING");
        period.setApprovalLevel("NONE");
        
        // Clear approval tracking to allow reprocessing
        period.setPreparedBy(null);
        period.setPreparedAt(null);
        if ("REVIEWED".equals(previousStatus)) {
            period.setReviewedBy(null);
            period.setReviewedAt(null);
        }
        
        // Append rejection note
        String rejectNote = String.format("\n[REJECTED at %s by user %d]: %s", 
                LocalDateTime.now(), userId, reason);
        period.setNotes(period.getNotes() != null ? period.getNotes() + rejectNote : rejectNote);
        
        PayrollPeriod saved = periodRepository.save(period);
        
        // Log rejection in audit trail - pass periodId explicitly
        auditService.logRejection(periodId, level, userId, null, previousStatus, "PROCESSING", reason);
        
        log.info("Payroll period {} REJECTED by user {} from status {} - Reason: {}", 
                periodId, userId, previousStatus, reason);
        return saved;
    }

    private boolean canReject(String status) {
        return "PREPARED".equals(status) || "REVIEWED".equals(status);
    }

    /**
     * Get approval progress summary
     */
    public String getApprovalProgress(PayrollPeriod period) {
        StringBuilder progress = new StringBuilder();
        
        if (period.getPreparedBy() != null) {
            progress.append("✓ Prepared");
        } else {
            progress.append("⏳ Prepared");
        }
        
        progress.append(" → ");
        
        if (period.getReviewedBy() != null) {
            progress.append("✓ Reviewed");
        } else {
            progress.append("⏳ Reviewed");
        }
        
        progress.append(" → ");
        
        if (period.getFinalApprovedBy() != null) {
            progress.append("✓ Approved");
        } else {
            progress.append("⏳ Approved");
        }
        
        return progress.toString();
    }
}
