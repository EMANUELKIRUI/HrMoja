package com.hrmoja.service;

import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Payment Processing Service
 * Handles payment authorization, execution, and confirmation
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentProcessingService {

    private final PayrollPeriodRepository periodRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollPaymentRepository paymentRepository;
    private final EmployeePaymentRecordRepository employeePaymentRepository;
    private final PaymentAuditLogRepository auditLogRepository;
    private final EmployeeBankDetailsRepository bankDetailsRepository;
    private final UserRepository userRepository;

    /**
     * Authorize payment for an approved payroll period
     * Creates a payment record and prepares for execution
     */
    @Transactional
    public PayrollPayment authorizePayment(Long periodId, Long userId, Map<String, String> paymentDetails) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        // Validate period is approved
        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Only APPROVED periods can be authorized for payment");
        }

        // Check if payment already exists
        paymentRepository.findByPayrollPeriodId(periodId).ifPresent(existing -> {
            throw new IllegalStateException("Payment already authorized for this period");
        });

        // Get all active (non-rejected) employee records
        List<EmployeePayrollRecord> activeRecords = recordRepository.findByPayrollPeriodId(periodId)
                .stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());

        if (activeRecords.isEmpty()) {
            throw new IllegalStateException("No active employee records found for payment");
        }

        // Calculate payment totals
        BigDecimal totalAmount = activeRecords.stream()
                .map(EmployeePayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Get user name
        String userName = userRepository.findById(userId)
                .map(u -> u.getFirstName() + " " + u.getLastName())
                .orElse("Unknown User");

        // Create payment record
        PayrollPayment payment = PayrollPayment.builder()
                .payrollPeriodId(periodId)
                .paymentDate(LocalDateTime.now())
                .paymentMethod(paymentDetails.getOrDefault("paymentMethod", "BANK_TRANSFER"))
                .paymentReference(paymentDetails.get("paymentReference"))
                .paymentBatchNumber(generateBatchNumber(periodId))
                .totalAmount(totalAmount)
                .totalEmployees(activeRecords.size())
                .bankTransferAmount(totalAmount) // Assuming all via bank for now
                .otherPaymentAmount(BigDecimal.ZERO)
                .authorizedBy(userId)
                .authorizedByName(userName)
                .authorizedAt(LocalDateTime.now())
                .paymentStatus("AUTHORIZED")
                .bankFileGenerated(false)
                .paymentConfirmed(false)
                .retryCount(0)
                .notes(paymentDetails.get("notes"))
                .build();

        PayrollPayment savedPayment = paymentRepository.save(payment);
        log.info("Payment authorized for period {} by user {} - Total: {}, Employees: {}",
                periodId, userId, totalAmount, activeRecords.size());

        // Create individual employee payment records
        createEmployeePaymentRecords(savedPayment.getId(), activeRecords);

        // Log audit trail
        logPaymentAudit(savedPayment.getId(), null, "AUTHORIZED", userId, userName,
                null, "AUTHORIZED", "Payment authorized for execution");

        return savedPayment;
    }

    /**
     * Create individual employee payment records
     */
    private void createEmployeePaymentRecords(Long paymentId, List<EmployeePayrollRecord> payrollRecords) {
        for (EmployeePayrollRecord record : payrollRecords) {
            // Get bank details
            EmployeeBankDetails bankDetails = bankDetailsRepository.findPrimaryByEmployeeId(record.getEmployeeId())
                    .orElse(null);

            EmployeePaymentRecord empPayment = EmployeePaymentRecord.builder()
                    .payrollPaymentId(paymentId)
                    .employeePayrollRecordId(record.getId())
                    .employeeId(record.getEmployeeId())
                    .paymentAmount(record.getNetSalary())
                    .paymentMethod("BANK_TRANSFER")
                    .paymentStatus("PENDING")
                    .retryCount(0)
                    .build();

            // Add bank details if available
            if (bankDetails != null) {
                empPayment.setBankName(bankDetails.getBank() != null ? bankDetails.getBank().getName() : null);
                empPayment.setBankAccountNumber(bankDetails.getAccountNumber());
                empPayment.setBankAccountName(bankDetails.getAccountName());
                empPayment.setBankBranch(bankDetails.getBankBranch() != null ? bankDetails.getBankBranch().getName() : null);
            }

            employeePaymentRepository.save(empPayment);
        }

        log.info("Created {} employee payment records for payment {}", payrollRecords.size(), paymentId);
    }

    /**
     * Mark payment as executed (after bank file upload)
     */
    @Transactional
    public PayrollPayment markPaymentAsExecuted(Long paymentId, Long userId, Map<String, String> executionDetails) {
        PayrollPayment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));

        if (!"AUTHORIZED".equals(payment.getPaymentStatus())) {
            throw new IllegalStateException("Only AUTHORIZED payments can be marked as executed");
        }

        String userName = userRepository.findById(userId)
                .map(u -> u.getFirstName() + " " + u.getLastName())
                .orElse("Unknown User");

        payment.setPaymentExecutedBy(userId);
        payment.setPaymentExecutedAt(LocalDateTime.now());
        payment.setPaymentStatus("PROCESSING");
        
        if (executionDetails != null && executionDetails.containsKey("transactionReference")) {
            payment.setPaymentReference(executionDetails.get("transactionReference"));
        }

        PayrollPayment saved = paymentRepository.save(payment);

        // Update employee payment records to PROCESSED
        List<EmployeePaymentRecord> empPayments = employeePaymentRepository.findByPayrollPaymentId(paymentId);
        empPayments.forEach(emp -> {
            emp.setPaymentStatus("PROCESSED");
            emp.setProcessedAt(LocalDateTime.now());
            employeePaymentRepository.save(emp);
        });

        logPaymentAudit(paymentId, null, "EXECUTED", userId, userName,
                "AUTHORIZED", "PROCESSING", "Payment executed via bank");

        log.info("Payment {} marked as executed by user {}", paymentId, userId);
        return saved;
    }

    /**
     * Confirm payment completion and mark period as PAID
     */
    @Transactional
    public PayrollPayment confirmPaymentCompletion(Long paymentId, Long userId, Map<String, String> confirmationDetails) {
        PayrollPayment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));

        if (!"PROCESSING".equals(payment.getPaymentStatus()) && !"AUTHORIZED".equals(payment.getPaymentStatus())) {
            throw new IllegalStateException("Payment must be AUTHORIZED or PROCESSING to confirm");
        }

        String userName = userRepository.findById(userId)
                .map(u -> u.getFirstName() + " " + u.getLastName())
                .orElse("Unknown User");

        // Update payment status
        payment.setPaymentConfirmed(true);
        payment.setPaymentConfirmedBy(userId);
        payment.setPaymentConfirmedAt(LocalDateTime.now());
        payment.setPaymentStatus("COMPLETED");
        payment.setConfirmationNotes(confirmationDetails != null ? confirmationDetails.get("notes") : null);

        PayrollPayment saved = paymentRepository.save(payment);

        // Update employee payment records to COMPLETED
        List<EmployeePaymentRecord> empPayments = employeePaymentRepository.findByPayrollPaymentId(paymentId);
        empPayments.forEach(emp -> {
            emp.setPaymentStatus("COMPLETED");
            emp.setCompletedAt(LocalDateTime.now());
            employeePaymentRepository.save(emp);
        });

        // Mark payroll period as PAID
        PayrollPeriod period = periodRepository.findById(payment.getPayrollPeriodId())
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));
        
        period.setStatus("PAID");
        period.setPaymentDate(LocalDateTime.now().toLocalDate());
        periodRepository.save(period);

        logPaymentAudit(paymentId, null, "CONFIRMED", userId, userName,
                payment.getPaymentStatus(), "COMPLETED", 
                "Payment completed and confirmed. Period marked as PAID.");

        log.info("Payment {} confirmed as completed by user {}. Period {} marked as PAID",
                paymentId, userId, payment.getPayrollPeriodId());

        return saved;
    }

    /**
     * Get payment details for a period
     */
    public Map<String, Object> getPaymentDetails(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        Map<String, Object> details = new HashMap<>();
        details.put("periodId", periodId);
        details.put("periodName", period.getPeriodName());
        details.put("periodStatus", period.getStatus());
        details.put("isPaid", "PAID".equals(period.getStatus()));

        // Get payment record if exists
        paymentRepository.findByPayrollPeriodId(periodId).ifPresent(payment -> {
            details.put("paymentId", payment.getId());
            details.put("paymentStatus", payment.getPaymentStatus());
            details.put("paymentMethod", payment.getPaymentMethod());
            details.put("paymentReference", payment.getPaymentReference());
            details.put("totalAmount", payment.getTotalAmount());
            details.put("totalEmployees", payment.getTotalEmployees());
            details.put("authorizedBy", payment.getAuthorizedByName());
            details.put("authorizedAt", payment.getAuthorizedAt());
            details.put("paymentConfirmed", payment.getPaymentConfirmed());
            details.put("paymentConfirmedAt", payment.getPaymentConfirmedAt());
            details.put("bankFileGenerated", payment.getBankFileGenerated());

            // Get employee payment statistics
            List<EmployeePaymentRecord> empPayments = employeePaymentRepository.findByPayrollPaymentId(payment.getId());
            Map<String, Long> statusCounts = empPayments.stream()
                    .collect(Collectors.groupingBy(EmployeePaymentRecord::getPaymentStatus, Collectors.counting()));
            details.put("employeePaymentStatus", statusCounts);
        });

        return details;
    }

    /**
     * Get payment audit trail
     */
    public List<PaymentAuditLog> getPaymentAuditTrail(Long paymentId) {
        return auditLogRepository.findByPayrollPaymentId(paymentId);
    }

    /**
     * Log payment audit trail
     */
    private void logPaymentAudit(Long paymentId, Long empPaymentId, String action,
                                  Long userId, String userName, String previousStatus,
                                  String newStatus, String details) {
        PaymentAuditLog audit = PaymentAuditLog.builder()
                .payrollPaymentId(paymentId)
                .employeePaymentRecordId(empPaymentId)
                .action(action)
                .performedBy(userId)
                .performedByName(userName)
                .performedAt(LocalDateTime.now())
                .previousStatus(previousStatus)
                .newStatus(newStatus)
                .actionDetails(details)
                .build();

        auditLogRepository.save(audit);
    }

    /**
     * Generate unique batch number
     */
    private String generateBatchNumber(Long periodId) {
        return String.format("PAY-%d-%s", periodId, 
                LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
    }

    /**
     * Reverse/cancel a payment (if not yet completed)
     */
    @Transactional
    public PayrollPayment reversePayment(Long paymentId, Long userId, String reason) {
        PayrollPayment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));

        if ("COMPLETED".equals(payment.getPaymentStatus())) {
            throw new IllegalStateException("Cannot reverse a completed payment");
        }

        String userName = userRepository.findById(userId)
                .map(u -> u.getFirstName() + " " + u.getLastName())
                .orElse("Unknown User");

        String previousStatus = payment.getPaymentStatus();
        payment.setPaymentStatus("REVERSED");
        payment.setFailureReason(reason);

        PayrollPayment saved = paymentRepository.save(payment);

        logPaymentAudit(paymentId, null, "REVERSED", userId, userName,
                previousStatus, "REVERSED", "Payment reversed: " + reason);

        log.warn("Payment {} reversed by user {}: {}", paymentId, userId, reason);
        return saved;
    }
}
