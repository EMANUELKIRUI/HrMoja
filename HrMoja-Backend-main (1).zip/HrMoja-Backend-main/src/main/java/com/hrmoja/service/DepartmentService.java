package com.hrmoja.service;

import com.hrmoja.dto.settings.DepartmentDto;
import com.hrmoja.entity.Branch;
import com.hrmoja.entity.Department;
import com.hrmoja.entity.Organization;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.BranchRepository;
import com.hrmoja.repository.DepartmentRepository;
import com.hrmoja.repository.OrganizationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Department Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final OrganizationRepository organizationRepository;
    private final BranchRepository branchRepository;

    @Transactional(readOnly = true)
    public List<DepartmentDto> getDepartmentsByOrganization(Long organizationId) {
        return departmentRepository.findByOrganizationId(organizationId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<DepartmentDto> getActiveDepartmentsByOrganization(Long organizationId) {
        return departmentRepository.findByOrganizationIdAndIsActiveTrue(organizationId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<DepartmentDto> getRootDepartments(Long organizationId) {
        return departmentRepository.findRootDepartments(organizationId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public DepartmentDto getDepartmentById(Long id) {
        Department department = departmentRepository.findByIdWithDetails(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));
        return mapToDto(department);
    }

    @Transactional
    public DepartmentDto createDepartment(DepartmentDto dto) {
        Organization organization = organizationRepository.findById(dto.getOrganizationId())
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        if (departmentRepository.existsByOrganizationIdAndCode(dto.getOrganizationId(), dto.getCode())) {
            throw new IllegalArgumentException("Department code already exists in this organization");
        }

        Department department = Department.builder()
                .organization(organization)
                .name(dto.getName())
                .code(dto.getCode())
                .description(dto.getDescription())
                .costCenterCode(dto.getCostCenterCode())
                .managerId(dto.getManagerId())
                .isActive(true)
                .build();

        if (dto.getBranchId() != null) {
            Branch branch = branchRepository.findById(dto.getBranchId())
                    .orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
            department.setBranch(branch);
        }

        if (dto.getParentDepartmentId() != null) {
            Department parent = departmentRepository.findById(dto.getParentDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Parent department not found"));
            department.setParentDepartment(parent);
        }

        Department savedDepartment = departmentRepository.save(department);
        log.info("Department created: {} for organization: {}", savedDepartment.getName(), organization.getName());

        return mapToDto(savedDepartment);
    }

    @Transactional
    public DepartmentDto updateDepartment(Long id, DepartmentDto dto) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));

        department.setName(dto.getName());
        department.setDescription(dto.getDescription());
        department.setCostCenterCode(dto.getCostCenterCode());
        department.setManagerId(dto.getManagerId());
        department.setActive(dto.isActive());

        if (dto.getBranchId() != null) {
            Branch branch = branchRepository.findById(dto.getBranchId())
                    .orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
            department.setBranch(branch);
        }

        if (dto.getParentDepartmentId() != null && !dto.getParentDepartmentId().equals(id)) {
            Department parent = departmentRepository.findById(dto.getParentDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Parent department not found"));
            department.setParentDepartment(parent);
        }

        Department updatedDepartment = departmentRepository.save(department);
        log.info("Department updated: {}", updatedDepartment.getName());

        return mapToDto(updatedDepartment);
    }

    @Transactional
    public void deleteDepartment(Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + id));

        department.setActive(false);
        departmentRepository.save(department);
        log.info("Department deactivated: {}", department.getName());
    }

    private DepartmentDto mapToDto(Department dept) {
        return DepartmentDto.builder()
                .id(dept.getId())
                .organizationId(dept.getOrganization().getId())
                .branchId(dept.getBranch() != null ? dept.getBranch().getId() : null)
                .name(dept.getName())
                .code(dept.getCode())
                .description(dept.getDescription())
                .parentDepartmentId(dept.getParentDepartment() != null ? dept.getParentDepartment().getId() : null)
                .parentDepartmentName(dept.getParentDepartment() != null ? dept.getParentDepartment().getName() : null)
                .managerId(dept.getManagerId())
                .costCenterCode(dept.getCostCenterCode())
                .isActive(dept.isActive())
                .createdAt(dept.getCreatedAt())
                .updatedAt(dept.getUpdatedAt())
                .build();
    }
}
