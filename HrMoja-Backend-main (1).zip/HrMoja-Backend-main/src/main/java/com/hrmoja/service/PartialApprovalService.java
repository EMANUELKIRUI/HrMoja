package com.hrmoja.service;

import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for partial approval of individual employee records at Level 1 (PREPARED stage)
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PartialApprovalService {

    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollPeriodRepository periodRepository;

    /**
     * Approve individual employee record at Level 1
     */
    @Transactional
    public EmployeePayrollRecord approveRecord(Long recordId, Long userId) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee record not found"));

        PayrollPeriod period = record.getPayrollPeriod();

        // Only allow at PREPARED or PROCESSING stage
        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only approve individual records at PREPARED stage. Current: " + period.getStatus());
        }

        // Check if already rejected
        if (record.isRejected()) {
            throw new IllegalStateException("Cannot approve a rejected record. Remove rejection first.");
        }

        record.setApprovedLevel1(true);
        record.setLevel1ApprovedBy(userId);
        record.setLevel1ApprovedAt(LocalDateTime.now());
        record.setStatus("APPROVED");

        EmployeePayrollRecord saved = recordRepository.save(record);
        updatePeriodApprovalStatus(period.getId());

        log.info("Employee record {} approved at Level 1 by user {}", recordId, userId);
        return saved;
    }

    /**
     * Approve multiple records at once (bulk approval)
     */
    @Transactional
    public int approveRecords(List<Long> recordIds, Long userId) {
        int approved = 0;
        for (Long recordId : recordIds) {
            try {
                approveRecord(recordId, userId);
                approved++;
            } catch (Exception e) {
                log.error("Failed to approve record {}: {}", recordId, e.getMessage());
            }
        }
        return approved;
    }

    /**
     * Approve all records in a period
     */
    @Transactional
    public int approveAllRecords(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);
        int approved = 0;

        for (EmployeePayrollRecord record : records) {
            if (!record.isRejected() && !record.isApprovedLevel1()) {
                record.setApprovedLevel1(true);
                record.setLevel1ApprovedBy(userId);
                record.setLevel1ApprovedAt(LocalDateTime.now());
                record.setStatus("APPROVED");
                recordRepository.save(record);
                approved++;
            }
        }

        updatePeriodApprovalStatus(periodId);
        log.info("Approved {} records in period {} by user {}", approved, periodId, userId);
        return approved;
    }

    /**
     * Unapprove a record (remove Level 1 approval)
     */
    @Transactional
    public EmployeePayrollRecord unapproveRecord(Long recordId) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee record not found"));

        PayrollPeriod period = record.getPayrollPeriod();

        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only unapprove at PREPARED stage");
        }

        record.setApprovedLevel1(false);
        record.setLevel1ApprovedBy(null);
        record.setLevel1ApprovedAt(null);
        record.setStatus("CALCULATED");

        EmployeePayrollRecord saved = recordRepository.save(record);
        updatePeriodApprovalStatus(period.getId());

        log.info("Employee record {} unapproved at Level 1", recordId);
        return saved;
    }

    /**
     * Reject/Exclude employee record with reason (soft delete)
     */
    @Transactional
    public EmployeePayrollRecord rejectRecord(Long recordId, Long userId, String reason) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee record not found"));

        PayrollPeriod period = record.getPayrollPeriod();

        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only reject at PREPARED stage");
        }

        if (reason == null || reason.trim().isEmpty()) {
            throw new IllegalArgumentException("Rejection reason is required");
        }

        // If it was approved, remove approval first
        record.setApprovedLevel1(false);
        record.setLevel1ApprovedBy(null);
        record.setLevel1ApprovedAt(null);

        // Mark as rejected
        record.setRejected(true);
        record.setRejectionReason(reason);
        record.setRejectedBy(userId);
        record.setRejectedAt(LocalDateTime.now());
        record.setStatus("REJECTED");

        EmployeePayrollRecord saved = recordRepository.save(record);
        updatePeriodApprovalStatus(period.getId());

        log.info("Employee record {} rejected by user {}: {}", recordId, userId, reason);
        return saved;
    }

    /**
     * Restore rejected record
     */
    @Transactional
    public EmployeePayrollRecord restoreRecord(Long recordId) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee record not found"));

        PayrollPeriod period = record.getPayrollPeriod();

        if (!"PREPARED".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Can only restore at PREPARED stage");
        }

        record.setRejected(false);
        record.setRejectionReason(null);
        record.setRejectedBy(null);
        record.setRejectedAt(null);
        record.setStatus("CALCULATED");

        EmployeePayrollRecord saved = recordRepository.save(record);
        updatePeriodApprovalStatus(period.getId());

        log.info("Employee record {} restored", recordId);
        return saved;
    }

    /**
     * Update period approval status based on individual record approvals
     */
    private void updatePeriodApprovalStatus(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        List<EmployeePayrollRecord> allRecords = recordRepository.findByPayrollPeriodId(periodId);
        
        int totalRecords = allRecords.size();
        long approvedCount = allRecords.stream().filter(EmployeePayrollRecord::isApprovedLevel1).count();
        long rejectedCount = allRecords.stream().filter(EmployeePayrollRecord::isRejected).count();
        int activeRecords = totalRecords - (int) rejectedCount;

        period.setTotalApprovedLevel1((int) approvedCount);
        period.setTotalRejected((int) rejectedCount);

        // Set partially approved flag
        if (approvedCount > 0 && approvedCount < activeRecords) {
            period.setPartiallyApproved(true);
        } else {
            period.setPartiallyApproved(false);
        }

        // Do NOT auto-submit - user must explicitly click "Submit for Review"
        // Status remains PROCESSING until manual submission

        periodRepository.save(period);
        log.debug("Period {} approval status updated: {}/{} approved, {} rejected", 
                periodId, approvedCount, activeRecords, rejectedCount);
    }

    /**
     * Get approval statistics for a period
     */
    public ApprovalStats getApprovalStats(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        List<EmployeePayrollRecord> allRecords = recordRepository.findByPayrollPeriodId(periodId);

        long totalRecords = allRecords.size();
        long approvedCount = allRecords.stream().filter(EmployeePayrollRecord::isApprovedLevel1).count();
        long rejectedCount = allRecords.stream().filter(EmployeePayrollRecord::isRejected).count();
        long pendingCount = totalRecords - approvedCount - rejectedCount;

        return ApprovalStats.builder()
                .totalRecords((int) totalRecords)
                .approvedCount((int) approvedCount)
                .rejectedCount((int) rejectedCount)
                .pendingCount((int) pendingCount)
                .isPartiallyApproved(period.isPartiallyApproved())
                .approvalPercentage(totalRecords > 0 ? (double) approvedCount / totalRecords * 100 : 0)
                .build();
    }

    @lombok.Data
    @lombok.Builder
    public static class ApprovalStats {
        private int totalRecords;
        private int approvedCount;
        private int rejectedCount;
        private int pendingCount;
        private boolean isPartiallyApproved;
        private double approvalPercentage;
    }
}
