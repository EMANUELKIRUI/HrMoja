package com.hrmoja.service;

import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Finance Payroll Review Service
 * Business logic for Finance department payroll review tasks
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FinancePayrollReviewService {

    private final PayrollPeriodRepository periodRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollApprovalService approvalService;

    /**
     * Get periods pending Finance review
     * Status: PREPARED (submitted by HR)
     */
    public List<PayrollPeriod> getPeriodsForReview(String status) {
        if (status != null && !status.isEmpty()) {
            return periodRepository.findByOrganizationIdAndStatus(
                    getOrganizationId(), status);
        }
        
        // Get periods ready for Finance review
        return periodRepository.findByOrganizationIdAndStatus(
                getOrganizationId(), "PREPARED");
    }

    /**
     * Get period for review
     */
    public PayrollPeriod getPeriodForReview(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        if (!"PREPARED".equals(period.getStatus())) {
            throw new IllegalStateException("Period is not ready for Finance review");
        }
        
        return period;
    }

    /**
     * Get employee records for review (excludes rejected records)
     * Supports pagination and search
     */
    public Page<EmployeePayrollRecord> getEmployeeRecordsForReview(
            Long periodId, String search, String department, Pageable pageable) {
        
        // Get all active (non-rejected) records
        List<EmployeePayrollRecord> allRecords = recordRepository.findByPayrollPeriodId(periodId);
        
        // Filter out rejected records and apply search/department filters
        List<EmployeePayrollRecord> filteredRecords = allRecords.stream()
                .filter(r -> !r.isRejected()) // Exclude rejected
                .filter(r -> {
                    if (search == null || search.trim().isEmpty()) return true;
                    String searchLower = search.toLowerCase();
                    return r.getEmployeeName().toLowerCase().contains(searchLower) ||
                           r.getEmployeeNumber().toLowerCase().contains(searchLower);
                })
                .filter(r -> {
                    if (department == null || department.trim().isEmpty()) return true;
                    return r.getDepartmentName().equals(department);
                })
                .sorted(Comparator.comparing(EmployeePayrollRecord::getEmployeeName))
                .collect(Collectors.toList());
        
        // Manual pagination
        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), filteredRecords.size());
        List<EmployeePayrollRecord> pageContent = start < filteredRecords.size() 
                ? filteredRecords.subList(start, end) 
                : new ArrayList<>();
        
        return new org.springframework.data.domain.PageImpl<>(
                pageContent, pageable, filteredRecords.size());
    }

    /**
     * Get comprehensive financial summary for review
     */
    public Map<String, Object> getFinancialSummary(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        List<EmployeePayrollRecord> allRecords = recordRepository.findByPayrollPeriodId(periodId);
        List<EmployeePayrollRecord> activeRecords = allRecords.stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());
        
        Map<String, Object> summary = new HashMap<>();
        
        // Basic period information
        summary.put("periodId", periodId);
        summary.put("periodName", period.getPeriodName());
        summary.put("periodCode", period.getPeriodCode());
        summary.put("preparedBy", period.getPreparedBy());
        summary.put("preparedAt", period.getPreparedAt());
        
        // Employee counts
        Map<String, Integer> employeeCounts = new HashMap<>();
        employeeCounts.put("total", allRecords.size());
        employeeCounts.put("active", activeRecords.size());
        employeeCounts.put("rejected", (int) allRecords.stream().filter(EmployeePayrollRecord::isRejected).count());
        employeeCounts.put("withBankDetails", (int) activeRecords.stream().filter(EmployeePayrollRecord::isHasBankDetails).count());
        employeeCounts.put("missingBankDetails", (int) activeRecords.stream().filter(r -> !r.isHasBankDetails()).count());
        summary.put("employeeCounts", employeeCounts);
        
        // Financial totals (active records only)
        BigDecimal totalGross = activeRecords.stream()
                .map(EmployeePayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalEarnings = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalEarnings)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalDeductions = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalDeductions)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalStatutory = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalStatutory)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalTaxes = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalTaxes)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalNet = activeRecords.stream()
                .map(EmployeePayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        summary.put("totalGrossPay", totalGross);
        summary.put("totalEarnings", totalEarnings);
        summary.put("totalDeductions", totalDeductions);
        summary.put("totalStatutoryDeductions", totalStatutory);
        summary.put("totalTaxes", totalTaxes);
        summary.put("totalNetPay", totalNet);
        summary.put("totalBankTransfers", totalNet); // Assuming all go via bank transfer
        
        // Department breakdown
        Map<String, Map<String, Object>> departmentBreakdown = activeRecords.stream()
                .collect(Collectors.groupingBy(
                        EmployeePayrollRecord::getDepartmentName,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                list -> {
                                    Map<String, Object> deptStats = new HashMap<>();
                                    deptStats.put("department", list.get(0).getDepartmentName());
                                    deptStats.put("employeeCount", list.size());
                                    deptStats.put("totalGross", list.stream()
                                            .map(EmployeePayrollRecord::getGrossSalary)
                                            .reduce(BigDecimal.ZERO, BigDecimal::add));
                                    deptStats.put("totalNet", list.stream()
                                            .map(EmployeePayrollRecord::getNetSalary)
                                            .reduce(BigDecimal.ZERO, BigDecimal::add));
                                    deptStats.put("totalTaxes", list.stream()
                                            .map(EmployeePayrollRecord::getTotalTaxes)
                                            .reduce(BigDecimal.ZERO, BigDecimal::add));
                                    return deptStats;
                                }
                        )
                ));
        summary.put("departmentBreakdown", new ArrayList<>(departmentBreakdown.values()));
        
        // Statutory contributions analysis
        Map<String, Object> statutoryAnalysis = new HashMap<>();
        statutoryAnalysis.put("totalNSSF", totalStatutory.multiply(new BigDecimal("0.60"))); // Estimate
        statutoryAnalysis.put("totalLST", totalStatutory.multiply(new BigDecimal("0.40"))); // Estimate
        statutoryAnalysis.put("totalPAYE", totalTaxes);
        summary.put("statutoryAnalysis", statutoryAnalysis);
        
        // Salary range distribution
        Map<String, Integer> salaryDistribution = new HashMap<>();
        salaryDistribution.put("below500k", (int) activeRecords.stream()
                .filter(r -> r.getGrossSalary().compareTo(new BigDecimal("500000")) < 0).count());
        salaryDistribution.put("500kTo1M", (int) activeRecords.stream()
                .filter(r -> r.getGrossSalary().compareTo(new BigDecimal("500000")) >= 0 &&
                            r.getGrossSalary().compareTo(new BigDecimal("1000000")) < 0).count());
        salaryDistribution.put("1MTo2M", (int) activeRecords.stream()
                .filter(r -> r.getGrossSalary().compareTo(new BigDecimal("1000000")) >= 0 &&
                            r.getGrossSalary().compareTo(new BigDecimal("2000000")) < 0).count());
        salaryDistribution.put("above2M", (int) activeRecords.stream()
                .filter(r -> r.getGrossSalary().compareTo(new BigDecimal("2000000")) >= 0).count());
        summary.put("salaryDistribution", salaryDistribution);
        
        // Average calculations
        if (!activeRecords.isEmpty()) {
            summary.put("averageGrossPay", totalGross.divide(
                    new BigDecimal(activeRecords.size()), 2, RoundingMode.HALF_UP));
            summary.put("averageNetPay", totalNet.divide(
                    new BigDecimal(activeRecords.size()), 2, RoundingMode.HALF_UP));
            summary.put("averageTax", totalTaxes.divide(
                    new BigDecimal(activeRecords.size()), 2, RoundingMode.HALF_UP));
        }
        
        return summary;
    }

    /**
     * Mark period as reviewed (Level 2)
     */
    @Transactional
    public PayrollPeriod reviewPeriod(Long periodId, Long userId, String comment) {
        PayrollPeriod period = approvalService.markAsReviewed(periodId, userId);
        
        if (comment != null && !comment.isEmpty()) {
            String reviewNote = String.format("\n[FINANCE REVIEW at %s by user %d]: %s", 
                    LocalDateTime.now(), userId, comment);
            period.setNotes(period.getNotes() != null ? period.getNotes() + reviewNote : reviewNote);
            period = periodRepository.save(period);
        }
        
        log.info("Period {} reviewed by Finance user {}", periodId, userId);
        return period;
    }

    /**
     * Reject period and return to HR
     */
    @Transactional
    public PayrollPeriod rejectPeriod(Long periodId, Long userId, String reason) {
        return approvalService.rejectPayroll(periodId, userId, reason);
    }

    /**
     * Submit for Executive final approval (Level 2 → Level 3)
     */
    @Transactional
    public PayrollPeriod submitForFinalApproval(Long periodId, Long userId) {
        // This is called after reviewPeriod, status should already be REVIEWED
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        if (!"REVIEWED".equals(period.getStatus())) {
            throw new IllegalStateException("Period must be reviewed before submitting for final approval");
        }
        
        log.info("Period {} submitted for Executive approval by Finance user {}", periodId, userId);
        return period;
    }

    /**
     * Generate comprehensive validation report for Finance review
     */
    public Map<String, Object> generateValidationReport(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        List<EmployeePayrollRecord> allRecords = recordRepository.findByPayrollPeriodId(periodId);
        List<EmployeePayrollRecord> activeRecords = allRecords.stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());
        
        Map<String, Object> report = new HashMap<>();
        List<String> errors = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        
        report.put("periodId", periodId);
        report.put("periodName", period.getPeriodName());
        report.put("validationDate", LocalDateTime.now());
        report.put("validatedBy", "Finance Review System");
        
        // Summary counts
        Map<String, Integer> summary = new HashMap<>();
        summary.put("totalRecords", allRecords.size());
        summary.put("activeRecords", activeRecords.size());
        summary.put("rejectedRecords", allRecords.size() - activeRecords.size());
        summary.put("validRecords", (int) activeRecords.stream()
                .filter(EmployeePayrollRecord::isHasBankDetails).count());
        summary.put("invalidRecords", (int) activeRecords.stream()
                .filter(r -> !r.isHasBankDetails()).count());
        summary.put("missingBankDetails", (int) activeRecords.stream()
                .filter(r -> !r.isHasBankDetails()).count());
        report.put("summary", summary);
        
        // Calculate actual totals from active records
        BigDecimal calculatedGross = activeRecords.stream()
                .map(EmployeePayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal calculatedNet = activeRecords.stream()
                .map(EmployeePayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal calculatedTaxes = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalTaxes)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal calculatedStatutory = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalStatutory)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal calculatedDeductions = activeRecords.stream()
                .map(EmployeePayrollRecord::getTotalDeductions)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Financial calculations
        Map<String, Object> calculations = new HashMap<>();
        calculations.put("calculatedGrossPay", calculatedGross);
        calculations.put("calculatedNetPay", calculatedNet);
        calculations.put("calculatedTaxes", calculatedTaxes);
        calculations.put("calculatedStatutory", calculatedStatutory);
        calculations.put("calculatedDeductions", calculatedDeductions);
        calculations.put("periodGrossPay", period.getTotalGrossPay());
        calculations.put("periodNetPay", period.getTotalNetPay());
        report.put("calculations", calculations);
        
        // Validation checks
        
        // 1. Bank details validation
        List<String> missingBankDetails = activeRecords.stream()
                .filter(r -> !r.isHasBankDetails())
                .map(r -> r.getEmployeeName() + " (" + r.getEmployeeNumber() + ")")
                .collect(Collectors.toList());
        if (!missingBankDetails.isEmpty()) {
            errors.add("Missing bank details for " + missingBankDetails.size() + " employee(s)");
            report.put("employeesMissingBankDetails", missingBankDetails);
        }
        
        // 2. Financial accuracy validation (with tolerance)
        BigDecimal tolerance = new BigDecimal("0.01");
        BigDecimal grossDiff = calculatedGross.subtract(period.getTotalGrossPay()).abs();
        BigDecimal netDiff = calculatedNet.subtract(period.getTotalNetPay()).abs();
        
        if (grossDiff.compareTo(tolerance) > 0) {
            errors.add(String.format("Gross pay mismatch: Calculated UGX %.2f vs Period UGX %.2f (Diff: UGX %.2f)",
                    calculatedGross, period.getTotalGrossPay(), grossDiff));
        }
        if (netDiff.compareTo(tolerance) > 0) {
            errors.add(String.format("Net pay mismatch: Calculated UGX %.2f vs Period UGX %.2f (Diff: UGX %.2f)",
                    calculatedNet, period.getTotalNetPay(), netDiff));
        }
        
        // 3. Individual calculation validation
        List<String> calculationErrors = new ArrayList<>();
        for (EmployeePayrollRecord record : activeRecords) {
            BigDecimal expectedNet = record.getGrossSalary().subtract(record.getTotalDeductions());
            BigDecimal actualNet = record.getNetSalary();
            BigDecimal diff = expectedNet.subtract(actualNet).abs();
            
            if (diff.compareTo(tolerance) > 0) {
                calculationErrors.add(record.getEmployeeName() + ": Net salary calculation mismatch (Diff: UGX " + diff + ")");
            }
        }
        if (!calculationErrors.isEmpty()) {
            warnings.addAll(calculationErrors.stream().limit(5).collect(Collectors.toList()));
            if (calculationErrors.size() > 5) {
                warnings.add("... and " + (calculationErrors.size() - 5) + " more calculation issues");
            }
        }
        
        // 4. Negative values check
        List<String> negativeValues = activeRecords.stream()
                .filter(r -> r.getNetSalary().compareTo(BigDecimal.ZERO) < 0)
                .map(r -> r.getEmployeeName() + ": Negative net salary (UGX " + r.getNetSalary() + ")")
                .collect(Collectors.toList());
        if (!negativeValues.isEmpty()) {
            errors.addAll(negativeValues);
        }
        
        // 5. Unreasonably high tax rates
        List<String> highTaxRates = activeRecords.stream()
                .filter(r -> {
                    if (r.getGrossSalary().compareTo(BigDecimal.ZERO) == 0) return false;
                    BigDecimal taxRate = r.getTotalTaxes()
                            .divide(r.getGrossSalary(), 4, RoundingMode.HALF_UP)
                            .multiply(new BigDecimal("100"));
                    return taxRate.compareTo(new BigDecimal("50")) > 0; // More than 50% tax
                })
                .map(r -> {
                    BigDecimal taxRate = r.getTotalTaxes()
                            .divide(r.getGrossSalary(), 2, RoundingMode.HALF_UP)
                            .multiply(new BigDecimal("100"));
                    return r.getEmployeeName() + ": Tax rate " + taxRate + "%";
                })
                .collect(Collectors.toList());
        if (!highTaxRates.isEmpty()) {
            warnings.add("Unusually high tax rates detected for " + highTaxRates.size() + " employee(s)");
        }
        
        // 6. Zero gross salary check
        List<String> zeroGross = activeRecords.stream()
                .filter(r -> r.getGrossSalary().compareTo(BigDecimal.ZERO) == 0)
                .map(r -> r.getEmployeeName() + " (" + r.getEmployeeNumber() + ")")
                .collect(Collectors.toList());
        if (!zeroGross.isEmpty()) {
            warnings.add("Zero gross salary for " + zeroGross.size() + " employee(s)");
        }
        
        // 7. Duplicate employee numbers check
        Map<String, Long> employeeNumberCounts = activeRecords.stream()
                .collect(Collectors.groupingBy(
                        EmployeePayrollRecord::getEmployeeNumber,
                        Collectors.counting()));
        List<String> duplicates = employeeNumberCounts.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .map(e -> "Employee number " + e.getKey() + " appears " + e.getValue() + " times")
                .collect(Collectors.toList());
        if (!duplicates.isEmpty()) {
            errors.addAll(duplicates);
        }
        
        // 8. Statutory compliance warnings
        long missingNSSF = activeRecords.stream()
                .filter(r -> r.getTotalStatutory().compareTo(BigDecimal.ZERO) == 0)
                .count();
        if (missingNSSF > 0) {
            warnings.add("No statutory deductions for " + missingNSSF + " employee(s)");
        }
        
        // Overall validation status
        boolean passed = errors.isEmpty();
        report.put("passed", passed);
        report.put("errors", errors);
        report.put("warnings", warnings);
        report.put("errorCount", errors.size());
        report.put("warningCount", warnings.size());
        
        // Compliance status
        Map<String, Object> compliance = new HashMap<>();
        compliance.put("allBankDetailsProvided", missingBankDetails.isEmpty());
        compliance.put("calculationsAccurate", grossDiff.compareTo(tolerance) <= 0 && netDiff.compareTo(tolerance) <= 0);
        compliance.put("noNegativeValues", negativeValues.isEmpty());
        compliance.put("noDuplicates", duplicates.isEmpty());
        report.put("compliance", compliance);
        
        return report;
    }

    private Long getOrganizationId() {
        return 1L; // TODO: Get from OrganizationContext
    }

    /**
     * Mark individual record as reviewed by Finance (Level 2)
     */
    @Transactional
    public EmployeePayrollRecord reviewIndividualRecord(Long recordId, Long userId, String remarks) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll record not found"));
        
        if (record.isRejected()) {
            throw new IllegalStateException("Cannot review a rejected record");
        }
        
        if (!record.isApprovedLevel1()) {
            throw new IllegalStateException("Record must be approved at Level 1 (HR) before Finance review");
        }
        
        // Mark as reviewed at Level 2
        record.setReviewedLevel2(true);
        record.setLevel2ReviewedBy(userId);
        record.setLevel2ReviewedAt(LocalDateTime.now());
        
        // Add remarks to notes if provided
        if (remarks != null && !remarks.trim().isEmpty()) {
            String reviewNote = String.format("\n[FINANCE REVIEW at %s by user %d]: %s", 
                    LocalDateTime.now(), userId, remarks);
            record.setNotes(record.getNotes() != null ? record.getNotes() + reviewNote : reviewNote);
        }
        
        EmployeePayrollRecord saved = recordRepository.save(record);
        log.info("Record {} reviewed by Finance user {}", recordId, userId);
        return saved;
    }

    /**
     * Bulk review multiple records
     */
    @Transactional
    public Map<String, Object> reviewBulkRecords(List<Long> recordIds, Long userId, String remarks) {
        int successCount = 0;
        int failureCount = 0;
        List<String> errors = new ArrayList<>();
        
        for (Long recordId : recordIds) {
            try {
                reviewIndividualRecord(recordId, userId, remarks);
                successCount++;
            } catch (Exception e) {
                failureCount++;
                errors.add(String.format("Record %d: %s", recordId, e.getMessage()));
                log.warn("Failed to review record {}: {}", recordId, e.getMessage());
            }
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("successCount", successCount);
        result.put("failureCount", failureCount);
        result.put("errors", errors);
        
        log.info("Bulk review completed: {} succeeded, {} failed", successCount, failureCount);
        return result;
    }

    /**
     * Reject/Disapprove individual record by Finance
     */
    @Transactional
    public EmployeePayrollRecord rejectRecord(Long recordId, Long userId, String reason) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll record not found"));
        
        if (record.isRejected()) {
            throw new IllegalStateException("Record is already rejected");
        }
        
        // Mark as rejected
        record.setRejected(true);
        record.setRejectedBy(userId);
        record.setRejectedAt(LocalDateTime.now());
        record.setRejectionReason(reason);
        
        // Clear any review status
        record.setReviewedLevel2(false);
        record.setLevel2ReviewedBy(null);
        record.setLevel2ReviewedAt(null);
        
        EmployeePayrollRecord saved = recordRepository.save(record);
        log.info("Record {} rejected/disapproved by Finance user {}", recordId, userId);
        return saved;
    }
}
