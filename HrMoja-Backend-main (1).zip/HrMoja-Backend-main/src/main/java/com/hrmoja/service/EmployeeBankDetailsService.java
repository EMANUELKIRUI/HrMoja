package com.hrmoja.service;

import com.hrmoja.dto.bank.EmployeeBankDetailsDto;
import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.exception.ValidationException;
import com.hrmoja.repository.BankBranchRepository;
import com.hrmoja.repository.BankRepository;
import com.hrmoja.repository.EmployeeBankDetailsRepository;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Employee Bank Details Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeBankDetailsService {

    private final EmployeeBankDetailsRepository bankDetailsRepository;
    private final EmployeeRepository employeeRepository;
    private final BankRepository bankRepository;
    private final BankBranchRepository bankBranchRepository;
    private final EmployeePayrollRecordRepository payrollRecordRepository;

    @Transactional(readOnly = true)
    public EmployeeBankDetailsDto getPrimaryBankDetails(Long employeeId) {
        EmployeeBankDetails bankDetails = bankDetailsRepository.findPrimaryByEmployeeId(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("No primary bank details found for employee: " + employeeId));
        return mapToDto(bankDetails);
    }

    @Transactional(readOnly = true)
    public List<EmployeeBankDetailsDto> getAllBankDetails(Long employeeId) {
        return bankDetailsRepository.findAllByEmployeeId(employeeId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public EmployeeBankDetailsDto createBankDetails(EmployeeBankDetailsDto dto) {
        // Validate employee exists
        Employee employee = employeeRepository.findById(dto.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        // Validate bank exists
        Bank bank = bankRepository.findById(dto.getBankId())
                .orElseThrow(() -> new ResourceNotFoundException("Bank not found"));

        // If this is set as primary, deactivate other primary bank details
        if (dto.isPrimary()) {
            List<EmployeeBankDetails> activeBankDetails = bankDetailsRepository.findActiveByEmployeeId(dto.getEmployeeId());
            for (EmployeeBankDetails activeDetail : activeBankDetails) {
                activeDetail.setPrimary(false);
            }
        }

        // Build bank details
        EmployeeBankDetails.EmployeeBankDetailsBuilder builder = EmployeeBankDetails.builder()
                .employee(employee)
                .bank(bank)
                .accountNumber(dto.getAccountNumber())
                .accountName(dto.getAccountName())
                .accountType(dto.getAccountType())
                .swiftCode(dto.getSwiftCode())
                .iban(dto.getIban())
                .primary(dto.isPrimary())
                .active(true);

        // Set bank branch if provided
        if (dto.getBankBranchId() != null) {
            BankBranch bankBranch = bankBranchRepository.findById(dto.getBankBranchId())
                    .orElseThrow(() -> new ResourceNotFoundException("Bank branch not found"));
            builder.bankBranch(bankBranch);
        }

        EmployeeBankDetails bankDetails = builder.build();
        bankDetails = bankDetailsRepository.save(bankDetails);
        
        log.info("Bank details created for employee {}: {} - {}", 
                employee.getEmployeeNumber(), bank.getName(), dto.getAccountNumber());

        // Update hasBankDetails flag in all payroll records for this employee
        updatePayrollRecordsBankStatus(employee.getId(), true);

        return mapToDto(bankDetails);
    }

    @Transactional
    public EmployeeBankDetailsDto updateBankDetails(Long employeeId, Long bankDetailsId, EmployeeBankDetailsDto dto) {
        EmployeeBankDetails bankDetails = bankDetailsRepository.findById(bankDetailsId)
                .orElseThrow(() -> new ResourceNotFoundException("Bank details not found"));

        if (!bankDetails.getEmployee().getId().equals(employeeId)) {
            throw new ValidationException("Bank details do not belong to this employee");
        }

        // Update fields
        if (dto.getBankId() != null) {
            Bank bank = bankRepository.findById(dto.getBankId())
                    .orElseThrow(() -> new ResourceNotFoundException("Bank not found"));
            bankDetails.setBank(bank);
        }

        if (dto.getBankBranchId() != null) {
            BankBranch bankBranch = bankBranchRepository.findById(dto.getBankBranchId())
                    .orElseThrow(() -> new ResourceNotFoundException("Bank branch not found"));
            bankDetails.setBankBranch(bankBranch);
        }

        if (dto.getAccountNumber() != null) {
            bankDetails.setAccountNumber(dto.getAccountNumber());
        }

        if (dto.getAccountName() != null) {
            bankDetails.setAccountName(dto.getAccountName());
        }

        if (dto.getAccountType() != null) {
            bankDetails.setAccountType(dto.getAccountType());
        }

        if (dto.getSwiftCode() != null) {
            bankDetails.setSwiftCode(dto.getSwiftCode());
        }

        if (dto.getIban() != null) {
            bankDetails.setIban(dto.getIban());
        }

        // If setting as primary, deactivate other primary bank details
        if (dto.isPrimary() && !bankDetails.isPrimary()) {
            List<EmployeeBankDetails> activeBankDetails = bankDetailsRepository.findActiveByEmployeeId(employeeId);
            for (EmployeeBankDetails activeDetail : activeBankDetails) {
                if (!activeDetail.getId().equals(bankDetailsId)) {
                    activeDetail.setPrimary(false);
                }
            }
            bankDetails.setPrimary(true);
        }

        EmployeeBankDetails saved = bankDetailsRepository.save(bankDetails);
        log.info("Bank details updated for employee: {}", employeeId);

        // Update hasBankDetails flag in all payroll records for this employee
        updatePayrollRecordsBankStatus(employeeId, true);

        return mapToDto(saved);
    }

    @Transactional
    public void deactivateBankDetails(Long employeeId, Long bankDetailsId) {
        EmployeeBankDetails bankDetails = bankDetailsRepository.findById(bankDetailsId)
                .orElseThrow(() -> new ResourceNotFoundException("Bank details not found"));

        if (!bankDetails.getEmployee().getId().equals(employeeId)) {
            throw new ValidationException("Bank details do not belong to this employee");
        }

        bankDetails.setActive(false);
        bankDetailsRepository.save(bankDetails);
        log.info("Bank details deactivated for employee: {}", employeeId);
    }

    private EmployeeBankDetailsDto mapToDto(EmployeeBankDetails bankDetails) {
        return EmployeeBankDetailsDto.builder()
                .id(bankDetails.getId())
                .employeeId(bankDetails.getEmployee().getId())
                .bankId(bankDetails.getBank().getId())
                .bankName(bankDetails.getBank().getName())
                .bankBranchId(bankDetails.getBankBranch() != null ? bankDetails.getBankBranch().getId() : null)
                .bankBranchName(bankDetails.getBankBranch() != null ? bankDetails.getBankBranch().getName() : null)
                .accountNumber(bankDetails.getAccountNumber())
                .accountName(bankDetails.getAccountName())
                .accountType(bankDetails.getAccountType())
                .swiftCode(bankDetails.getSwiftCode())
                .iban(bankDetails.getIban())
                .primary(bankDetails.isPrimary())
                .active(bankDetails.isActive())
                .createdAt(bankDetails.getCreatedAt())
                .updatedAt(bankDetails.getUpdatedAt())
                .build();
    }

    /**
     * Update hasBankDetails flag in all payroll records for an employee
     */
    private void updatePayrollRecordsBankStatus(Long employeeId, boolean hasBankDetails) {
        try {
            List<EmployeePayrollRecord> payrollRecords = payrollRecordRepository.findByEmployeeId(employeeId);
            if (!payrollRecords.isEmpty()) {
                payrollRecords.forEach(record -> record.setHasBankDetails(hasBankDetails));
                payrollRecordRepository.saveAll(payrollRecords);
                log.info("Updated hasBankDetails flag for {} payroll records for employee {}", 
                        payrollRecords.size(), employeeId);
            }
        } catch (Exception e) {
            log.error("Failed to update payroll records bank status for employee {}: {}", 
                    employeeId, e.getMessage());
        }
    }
}
