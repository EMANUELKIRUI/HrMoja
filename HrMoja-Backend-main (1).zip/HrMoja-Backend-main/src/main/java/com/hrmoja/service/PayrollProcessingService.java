package com.hrmoja.service;

import com.hrmoja.entity.*;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.scheduling.annotation.Async;

import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Refactored Payroll Processing Service
 * 
 * Key improvements:
 * - Uses centralized PayrollCalculationEngine for consistency
 * - Uses PayrollBatchProcessor for optimized batch operations
 * - Both processing and recalculation use identical async pattern
 * - Comprehensive error handling and audit logging
 * - Transaction management optimized for large datasets
 */
@Service
@RequiredArgsConstructor
public class PayrollProcessingService {

    private static final Logger log = LoggerFactory.getLogger(PayrollProcessingService.class);

    private final PayrollPeriodRepository periodRepository;
    private final PayrollRunRepository runRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollLineItemRepository lineItemRepository;
    private final EmployeeRepository employeeRepository;
    private final OrganizationRepository organizationRepository;
    private final PayrollJobRepository payrollJobRepository;
    
    // New services for centralized processing
    private final PayrollCalculationEngine calculationEngine;
    private final PayrollBatchProcessor batchProcessor;
    
    // Self-injection for @Transactional and @Async proxies
    @Autowired
    @Lazy
    private PayrollProcessingService self;

    /**
     * Get all payroll periods for an organization
     */
    public List<PayrollPeriod> getPeriodsByOrganization(Long organizationId) {
        return periodRepository.findByOrganizationIdOrderByStartDateDesc(organizationId);
    }

    /**
     * Get payroll periods with pagination and filters (wrapper for controllers)
     */
    public Page<PayrollPeriod> getPeriodsPaginated(Long organizationId, String status, String search,
                                                    String periodType, LocalDate startDate, LocalDate endDate,
                                                    Pageable pageable) {
        return getPayrollPeriods(organizationId, status, startDate, endDate, pageable);
    }

    /**
     * Get payroll periods with pagination and filters
     */
    public Page<PayrollPeriod> getPayrollPeriods(Long organizationId, String status, 
                                                  LocalDate startDate, LocalDate endDate, 
                                                  Pageable pageable) {
        Specification<PayrollPeriod> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            
            predicates.add(cb.equal(root.get("organization").get("id"), organizationId));
            
            if (status != null && !status.isEmpty()) {
                predicates.add(cb.equal(root.get("status"), status));
            }
            
            if (startDate != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("startDate"), startDate));
            }
            
            if (endDate != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("endDate"), endDate));
            }
            
            return cb.and(predicates.toArray(new Predicate[0]));
        };
        
        return periodRepository.findAll(spec, pageable);
    }

    /**
     * Get payroll period by ID
     */
    public PayrollPeriod getPeriodById(Long id) {
        return periodRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));
    }

    /**
     * Create new payroll period (overloaded for controller use)
     */
    @Transactional
    public PayrollPeriod createPayrollPeriod(Long organizationId, String periodName, String periodType,
                                             LocalDate startDate, LocalDate endDate, LocalDate paymentDate) {
        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));
        
        PayrollPeriod period = new PayrollPeriod();
        period.setOrganization(organization);
        period.setPeriodName(periodName);
        period.setPeriodType(periodType != null ? periodType : "MONTHLY");
        period.setStartDate(startDate);
        period.setEndDate(endDate);
        period.setPaymentDate(paymentDate);
        
        // Generate period_code from dates (format: YYYY-MM)
        String periodCode = startDate.getYear() + "-" + String.format("%02d", startDate.getMonthValue());
        period.setPeriodCode(periodCode);
        
        // Set period_month and period_year
        period.setPeriodMonth(startDate.getMonthValue());
        period.setPeriodYear(startDate.getYear());
        
        return createPayrollPeriod(period);
    }

    /**
     * Create new payroll period
     */
    @Transactional
    public PayrollPeriod createPayrollPeriod(PayrollPeriod period) {
        // Validate no overlapping periods
        List<PayrollPeriod> overlapping = periodRepository
                .findByOrganizationIdAndStartDateLessThanEqualAndEndDateGreaterThanEqual(
                        period.getOrganization().getId(),
                        period.getEndDate(),
                        period.getStartDate()
                );
        
        if (!overlapping.isEmpty()) {
            throw new IllegalStateException("Payroll period overlaps with existing period");
        }
        
        period.setStatus("DRAFT");
        return periodRepository.save(period);
    }

    /**
     * Update payroll period (overloaded for controller use)
     */
    @Transactional
    public PayrollPeriod updatePayrollPeriod(Long id, String periodName, LocalDate startDate,
                                            LocalDate endDate, LocalDate paymentDate) {
        PayrollPeriod updates = new PayrollPeriod();
        updates.setPeriodName(periodName);
        updates.setStartDate(startDate);
        updates.setEndDate(endDate);
        updates.setPaymentDate(paymentDate);
        
        return updatePayrollPeriod(id, updates);
    }

    /**
     * Update payroll period
     */
    @Transactional
    public PayrollPeriod updatePayrollPeriod(Long id, PayrollPeriod updates) {
        PayrollPeriod period = getPeriodById(id);
        
        if (!"DRAFT".equals(period.getStatus())) {
            throw new IllegalStateException("Can only update periods in DRAFT status");
        }
        
        period.setPeriodName(updates.getPeriodName());
        period.setStartDate(updates.getStartDate());
        period.setEndDate(updates.getEndDate());
        period.setPaymentDate(updates.getPaymentDate());
        
        return periodRepository.save(period);
    }

    /**
     * Delete payroll period
     */
    @Transactional
    public void deletePayrollPeriod(Long id) {
        PayrollPeriod period = getPeriodById(id);
        
        if (!"DRAFT".equals(period.getStatus())) {
            throw new IllegalStateException("Can only delete periods in DRAFT status");
        }
        
        periodRepository.delete(period);
    }

    /**
     * Get employee payroll records for a period
     */
    public List<EmployeePayrollRecord> getEmployeeRecords(Long periodId) {
        return recordRepository.findByPayrollPeriodId(periodId);
    }

    /**
     * Get payroll records by period (wrapper for controllers)
     */
    public List<EmployeePayrollRecord> getPayrollRecordsByPeriod(Long periodId) {
        return getEmployeeRecords(periodId);
    }

    /**
     * Get employee records with pagination
     */
    public Page<EmployeePayrollRecord> getEmployeeRecords(Long periodId, Pageable pageable) {
        return recordRepository.findByPayrollPeriodId(periodId, pageable);
    }

    /**
     * Get single employee record
     */
    public EmployeePayrollRecord getEmployeeRecord(Long recordId) {
        return recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee payroll record not found"));
    }

    /**
     * Get payroll line items for an employee record
     */
    public List<PayrollLineItem> getLineItems(Long recordId) {
        return lineItemRepository.findByEmployeePayrollRecordId(recordId);
    }

    /**
     * Get line items by record (wrapper for controllers)
     */
    public List<PayrollLineItem> getLineItemsByRecord(Long recordId) {
        return getLineItems(recordId);
    }

    /**
     * Get all payroll runs for a period
     */
    public List<PayrollRun> getPayrollRuns(Long periodId) {
        return runRepository.findByPayrollPeriodIdOrderByRunNumberDesc(periodId);
    }

    /**
     * Get specific payroll run
     */
    public PayrollRun getPayrollRun(Long runId) {
        return runRepository.findById(runId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll run not found"));
    }

    /**
     * Initiate async payroll processing
     * Creates job and starts background processing
     */
    @Transactional
    public PayrollJob initiatePayrollProcessing(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        if (!"DRAFT".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Period must be in DRAFT status. Current: " + period.getStatus());
        }

        // Check if there's already an active job
        Optional<PayrollJob> existingJob = payrollJobRepository
                .findFirstByPayrollPeriodIdOrderByCreatedAtDesc(periodId);
        
        if (existingJob.isPresent()) {
            PayrollJob job = existingJob.get();
            if (job.getStatus() == PayrollJob.JobStatus.QUEUED || 
                job.getStatus() == PayrollJob.JobStatus.PROCESSING) {
                throw new IllegalStateException("Payroll processing is already in progress for this period");
            }
        }

        // Count active employees
        int totalEmployees = employeeRepository.findActiveEmployeesWithDetailsForPayroll(
                period.getOrganization().getId()).size();
        
        if (totalEmployees == 0) {
            throw new IllegalStateException("No active employees found for this organization");
        }

        // Create job record
        PayrollJob job = createAndCommitJob(periodId, totalEmployees, userId);

        // Start async processing
        self.processPayrollAsync(periodId, userId, job.getId());

        return job;
    }

    /**
     * Create and commit job in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public PayrollJob createAndCommitJob(Long periodId, int totalEmployees, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));
        
        PayrollJob job = PayrollJob.builder()
                .payrollPeriod(period)
                .status(PayrollJob.JobStatus.QUEUED)
                .totalEmployees(totalEmployees)
                .processedEmployees(0)
                .failedEmployees(0)
                .progressPercentage(0)
                .startedBy(userId)
                .build();
        
        job = payrollJobRepository.save(job);
        // Transaction commits when method returns
        return job;
    }

    /**
     * Async payroll processing - runs in background thread
     * Refactored to use batch processing for better performance and scalability
     */
    @Async("payrollTaskExecutor")
    public void processPayrollAsync(Long periodId, Long userId, Long jobId) {
        log.info("Async thread started for period {} with job {}", periodId, jobId);
        
        // Small delay to ensure job commit completes
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        PayrollJob job = payrollJobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll job not found: " + jobId));

        try {
            // Update job status to processing
            job.setStatus(PayrollJob.JobStatus.PROCESSING);
            job.setStartedAt(LocalDateTime.now());
            payrollJobRepository.save(job);

            log.info("Starting payroll processing for period {} with job {}", periodId, jobId);
            
            // Process payroll using optimized batch processing
            processPayrollInternal(periodId, userId, jobId);

            // Mark as completed
            job = payrollJobRepository.findById(jobId).orElseThrow();
            job.setStatus(PayrollJob.JobStatus.COMPLETED);
            job.setCompletedAt(LocalDateTime.now());
            payrollJobRepository.save(job);

            log.info("Payroll processing completed successfully for period {}. Processed: {}, Failed: {}", 
                    periodId, job.getProcessedEmployees(), job.getFailedEmployees());

        } catch (Exception e) {
            log.error("Payroll processing failed for period {}: {}", periodId, e.getMessage(), e);
            
            // Mark job as failed with detailed error
            job = payrollJobRepository.findById(jobId).orElseThrow();
            job.setStatus(PayrollJob.JobStatus.FAILED);
            String errorMsg = String.format("Processing failed: %s. Processed: %d, Failed: %d",
                    e.getMessage(), job.getProcessedEmployees(), job.getFailedEmployees());
            job.setErrorMessage(errorMsg);
            job.setCompletedAt(LocalDateTime.now());
            payrollJobRepository.save(job);
            
            // Try to revert period status
            try {
                PayrollPeriod period = periodRepository.findById(periodId).orElse(null);
                if (period != null && "PROCESSING".equals(period.getStatus())) {
                    period.setStatus("DRAFT"); // Revert to DRAFT on failure
                    periodRepository.save(period);
                }
            } catch (Exception ex) {
                log.error("Failed to revert period status: {}", ex.getMessage());
            }
        }
    }

    /**
     * Internal payroll processing with optimized batch operations
     * Processes employees in batches for better performance and resource management
     */
    private void processPayrollInternal(Long periodId, Long processedByUserId, Long jobId) {
        // Eager load organization and country to avoid LazyInitializationException in async context
        PayrollPeriod period = periodRepository.findByIdWithOrganizationAndCountry(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        if (!"DRAFT".equals(period.getStatus()) && !"PROCESSING".equals(period.getStatus())) {
            throw new IllegalStateException("Period must be in DRAFT or PROCESSING status to process. Current: " + period.getStatus());
        }

        // Create and commit PayrollRun in separate transaction
        PayrollRun run = self.createAndCommitPayrollRun(periodId);
        log.info("Created payroll run {} for period {}", run.getId(), periodId);

        // Update period status
        period.setStatus("PROCESSING");
        periodRepository.save(period);

        // Get all active employees with salary structures (eager load department and jobTitle)
        List<Employee> employees = employeeRepository.findActiveEmployeesWithDetailsForPayroll(
                period.getOrganization().getId());
        
        if (employees.isEmpty()) {
            log.warn("No active employees found for organization {}", period.getOrganization().getId());
            period.setStatus("DRAFT");
            periodRepository.save(period);
            throw new IllegalStateException("No active employees found to process payroll");
        }

        log.info("Processing payroll for {} employees in batches of 50", employees.size());

        // Process in batches of 50
        int batchSize = 50;
        int totalProcessed = 0;
        int totalFailed = 0;
        BigDecimal totalGross = BigDecimal.ZERO;
        BigDecimal totalDeductions = BigDecimal.ZERO;
        BigDecimal totalNet = BigDecimal.ZERO;
        List<String> allErrors = new ArrayList<>();

        for (int i = 0; i < employees.size(); i += batchSize) {
            int end = Math.min(i + batchSize, employees.size());
            List<Employee> batch = employees.subList(i, end);
            
            try {
                // Process batch in separate transaction
                PayrollBatchProcessor.BatchResult batchResult = 
                        batchProcessor.processBatch(period, run, batch, jobId);
                
                totalProcessed += batchResult.getProcessed();
                totalFailed += batchResult.getFailed();
                totalGross = totalGross.add(batchResult.getTotalGross());
                totalDeductions = totalDeductions.add(batchResult.getTotalDeductions());
                totalNet = totalNet.add(batchResult.getTotalNet());
                allErrors.addAll(batchResult.getErrors());
                
                // Update job progress after each batch
                batchProcessor.updateJobProgress(jobId, totalProcessed, totalFailed, batchResult.getErrors());
                
                log.info("Batch {}-{} completed. Processed: {}, Failed: {}", 
                        i + 1, end, batchResult.getProcessed(), batchResult.getFailed());
                
            } catch (Exception e) {
                log.error("Batch processing failed for employees {}-{}: {}", 
                        i + 1, end, e.getMessage(), e);
                totalFailed += batch.size();
                allErrors.add(String.format("Batch %d-%d failed: %s", i + 1, end, e.getMessage()));
                batchProcessor.updateJobProgress(jobId, totalProcessed, totalFailed, 
                        List.of("Batch " + (i/batchSize + 1) + " failed: " + e.getMessage()));
            }
        }

        // Update run totals in separate transaction
        self.updateRunTotals(run.getId(), totalProcessed, totalFailed, 
                totalGross, totalDeductions, totalNet);

        // Update period totals
        self.updatePeriodTotals(periodId, employees.size(), totalGross, 
                totalDeductions, totalNet, processedByUserId);

        log.info("Payroll processing completed for period {}. Total Processed: {}, Total Failed: {}, Errors: {}", 
                periodId, totalProcessed, totalFailed, allErrors.size());
    }

    private Integer getNextRunNumber(Long periodId) {
        return runRepository.findFirstByPayrollPeriodIdOrderByRunNumberDesc(periodId)
                .map(r -> r.getRunNumber() + 1)
                .orElse(1);
    }
    
    /**
     * Create and commit PayrollRun in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public PayrollRun createAndCommitPayrollRun(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        PayrollRun run = PayrollRun.builder()
                .payrollPeriod(period)
                .runNumber(getNextRunNumber(periodId))
                .runType("REGULAR")
                .status("PROCESSING")
                .totalEmployeesProcessed(0)
                .totalEmployeesFailed(0)
                .totalGrossPay(BigDecimal.ZERO)
                .totalDeductions(BigDecimal.ZERO)
                .totalNetPay(BigDecimal.ZERO)
                .processingStartedAt(LocalDateTime.now())
                .build();
        
        run = runRepository.save(run);
        // Transaction commits when method returns
        return run;
    }

    /**
     * Update run totals in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateRunTotals(Long runId, int processed, int failed,
                               BigDecimal totalGross, BigDecimal totalDeductions, BigDecimal totalNet) {
        PayrollRun run = runRepository.findById(runId).orElse(null);
        if (run != null) {
            run.setTotalEmployeesProcessed(processed);
            run.setTotalEmployeesFailed(failed);
            run.setTotalGrossPay(totalGross);
            run.setTotalDeductions(totalDeductions);
            run.setTotalNetPay(totalNet);
            run.setStatus("COMPLETED");
            run.setProcessingCompletedAt(LocalDateTime.now());
            runRepository.save(run);
            log.info("Updated run {} totals: Processed={}, Failed={}, Gross={}, Net={}",
                    runId, processed, failed, totalGross, totalNet);
        }
    }

    /**
     * Update period totals in separate transaction
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updatePeriodTotals(Long periodId, int totalEmployees, BigDecimal totalGross,
                                  BigDecimal totalDeductions, BigDecimal totalNet, Long processedBy) {
        PayrollPeriod period = periodRepository.findById(periodId).orElse(null);
        if (period != null) {
            period.setTotalEmployees(totalEmployees);
            period.setTotalGrossPay(totalGross);
            period.setTotalDeductions(totalDeductions);
            period.setTotalNetPay(totalNet);
            period.setProcessedBy(processedBy);
            period.setProcessedAt(LocalDateTime.now());
            // Keep status as PROCESSING - will move to PREPARED/REVIEWED/APPROVED via approval workflow
            periodRepository.save(period);
            log.info("Updated period {} totals: Employees={}, Gross={}, Net={}",
                    periodId, totalEmployees, totalGross, totalNet);
        }
    }

    /**
     * Get job status by job ID
     */
    public PayrollJob getJobStatus(Long jobId) {
        return payrollJobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll job not found with ID: " + jobId));
    }

    /**
     * Get latest job status for a payroll period
     */
    public PayrollJob getLatestJobForPeriod(Long periodId) {
        return payrollJobRepository.findFirstByPayrollPeriodIdOrderByCreatedAtDesc(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("No payroll job found for period: " + periodId));
    }


    /**
     * Approve payroll period
     */
    @Transactional
    public void approvePayrollPeriod(Long periodId, Long approvedByUserId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Period must be in APPROVED status");
        }

        period.setApprovedBy(approvedByUserId);
        period.setApprovedAt(LocalDateTime.now());
        periodRepository.save(period);
        
        log.info("Payroll period {} approved by user {}", periodId, approvedByUserId);
    }

    /**
     * Mark payroll as paid
     */
    @Transactional
    public void markPayrollAsPaid(Long periodId, Long paidByUserId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Only approved payroll can be marked as paid");
        }

        period.setStatus("PAID");
        periodRepository.save(period);
        
        // Mark all employee records as paid
        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);
        for (EmployeePayrollRecord record : records) {
            record.setPaid(true);
            record.setPaymentDate(LocalDateTime.now());
            recordRepository.save(record);
        }
        
        log.info("Payroll period {} marked as paid", periodId);
    }

    /**
     * Recalculate payroll for a period - REFACTORED to use async pattern
     * Now uses the SAME processing logic as initial processing for consistency
     */
    @Transactional
    public PayrollJob recalculatePayroll(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        // Allow recalculation at DRAFT, PROCESSING, and PREPARED (Level 1) stages
        if ("REVIEWED".equals(period.getStatus()) || 
            "APPROVED".equals(period.getStatus()) || 
            "PAID".equals(period.getStatus()) || 
            "CLOSED".equals(period.getStatus())) {
            throw new IllegalStateException("Cannot recalculate after Level 2 review. Current status: " + period.getStatus());
        }

        log.info("Starting recalculation for period {} by user {}", periodId, userId);

        // Cancel any active jobs for this period
        List<PayrollJob> activeJobs = payrollJobRepository.findByPayrollPeriodIdOrderByCreatedAtDesc(periodId);
        for (PayrollJob job : activeJobs) {
            if (job.getStatus() == PayrollJob.JobStatus.QUEUED || 
                job.getStatus() == PayrollJob.JobStatus.PROCESSING) {
                job.setStatus(PayrollJob.JobStatus.CANCELLED);
                job.setCompletedAt(LocalDateTime.now());
                job.setErrorMessage("Cancelled for recalculation");
                payrollJobRepository.save(job);
                log.info("Cancelled active job {} for recalculation", job.getId());
            }
        }
        
        // Delete existing payroll data using batch processor
        batchProcessor.batchDeletePayrollData(periodId);
        
        // Reset period status to DRAFT
        period.setStatus("DRAFT");
        period.setTotalEmployees(0);
        period.setTotalGrossPay(BigDecimal.ZERO);
        period.setTotalDeductions(BigDecimal.ZERO);
        period.setTotalNetPay(BigDecimal.ZERO);
        periodRepository.save(period);
        
        log.info("Cleared existing payroll data for period {}. Starting fresh calculation.", periodId);
        
        // Initiate async processing (uses SAME logic as initial processing)
        PayrollJob job = initiatePayrollProcessing(periodId, userId);
        log.info("Recalculation initiated with job ID: {}. Processing {} employees asynchronously.",
                job.getId(), job.getTotalEmployees());
        
        return job;
    }

    /**
     * Close payroll period (final lock)
     */
    @Transactional
    public void closePayrollPeriod(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));

        if (!"PAID".equals(period.getStatus())) {
            throw new IllegalStateException("Only paid payroll periods can be closed");
        }

        period.setStatus("CLOSED");
        periodRepository.save(period);
        
        log.info("Payroll period {} closed", periodId);
    }
}
