package com.hrmoja.service;

import com.hrmoja.entity.*;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Payroll Batch Processor - Handles batch processing of payroll with optimized database operations
 */
@Service
@RequiredArgsConstructor
public class PayrollBatchProcessor {

    private static final Logger log = LoggerFactory.getLogger(PayrollBatchProcessor.class);

    private final PayrollCalculationEngine calculationEngine;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollLineItemRepository lineItemRepository;
    private final PayrollJobRepository payrollJobRepository;

    private static final int BATCH_SIZE = 50;

    /**
     * Process a batch of employees for payroll
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public BatchResult processBatch(PayrollPeriod period, PayrollRun run, 
                                   List<Employee> employees, Long jobId) {
        
        BatchResult result = new BatchResult();
        List<EmployeePayrollRecord> recordsToSave = new ArrayList<>();
        List<PayrollLineItem> lineItemsToSave = new ArrayList<>();

        for (Employee employee : employees) {
            try {
                // Check if record already exists
                EmployeePayrollRecord existingRecord = recordRepository
                        .findByPayrollPeriodIdAndEmployeeId(period.getId(), employee.getId())
                        .orElse(null);

                // Calculate payroll using centralized engine
                PayrollCalculationEngine.CalculatedPayroll calculated = 
                        calculationEngine.calculatePayroll(employee, period, existingRecord);

                if (!calculated.isSuccess()) {
                    result.incrementFailed();
                    result.addError(employee.getEmployeeNumber() + ": " + calculated.getErrorMessage());
                    
                    // Save skipped record
                    if (existingRecord == null) {
                        existingRecord = new EmployeePayrollRecord();
                    }
                    existingRecord.setPayrollPeriod(period);
                    existingRecord.setPayrollRun(run);
                    existingRecord.setEmployee(employee);
                    existingRecord.setEmployeeName(employee.getFirstName() + " " + employee.getLastName());
                    existingRecord.setEmployeeNumber(employee.getEmployeeNumber());
                    existingRecord.setStatus("SKIPPED");
                    existingRecord.setCalculationErrors(calculated.getErrorMessage());
                    existingRecord.setSkipped(true);
                    existingRecord.setProcessingAttempts(existingRecord.getProcessingAttempts() + 1);
                    existingRecord.setLastError(calculated.getErrorMessage());
                    recordsToSave.add(existingRecord);
                    continue;
                }

                EmployeePayrollRecord record = calculated.getRecord();
                record.setPayrollPeriod(period);
                record.setPayrollRun(run);
                record.setProcessingAttempts(existingRecord != null ? existingRecord.getProcessingAttempts() + 1 : 1);
                record.setSkipped(false);
                record.setLastError(null);
                
                recordsToSave.add(record);
                result.incrementProcessed();
                result.addGross(record.getGrossSalary());
                result.addDeductions(record.getTotalDeductions());
                result.addNet(record.getNetSalary());

                // Store line items temporarily
                for (PayrollLineItem lineItem : calculated.getLineItems()) {
                    lineItem.setEmployeePayrollRecord(record);
                    lineItemsToSave.add(lineItem);
                }

            } catch (Exception e) {
                result.incrementFailed();
                result.addError(employee.getEmployeeNumber() + ": " + e.getMessage());
                log.error("Error processing employee {}: {}", employee.getEmployeeNumber(), e.getMessage(), e);
            }
        }

        // Batch save all records
        if (!recordsToSave.isEmpty()) {
            try {
                List<EmployeePayrollRecord> savedRecords = recordRepository.saveAll(recordsToSave);
                recordRepository.flush();
                
                // Update line items with saved record IDs
                for (int i = 0; i < savedRecords.size(); i++) {
                    EmployeePayrollRecord savedRecord = savedRecords.get(i);
                    
                    // Delete existing line items
                    lineItemRepository.deleteByEmployeePayrollRecordId(savedRecord.getId());
                    
                    // Find and update line items
                    lineItemsToSave.stream()
                            .filter(li -> li.getEmployeePayrollRecord().getEmployee().getId()
                                    .equals(savedRecord.getEmployee().getId()))
                            .forEach(li -> li.setEmployeePayrollRecord(savedRecord));
                }
                
                // Batch save line items
                if (!lineItemsToSave.isEmpty()) {
                    lineItemRepository.saveAll(lineItemsToSave);
                    lineItemRepository.flush();
                }
                
                log.info("Batch saved {} records and {} line items", 
                        savedRecords.size(), lineItemsToSave.size());
                
            } catch (Exception e) {
                log.error("Error during batch save: {}", e.getMessage(), e);
                throw e;
            }
        }

        return result;
    }

    /**
     * Update job progress
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateJobProgress(Long jobId, int processed, int failed, List<String> errors) {
        PayrollJob job = payrollJobRepository.findById(jobId).orElse(null);
        if (job != null) {
            job.setProcessedEmployees(processed);
            job.setFailedEmployees(failed);
            
            if (!errors.isEmpty()) {
                String newErrors = String.join("\n", errors);
                String existingErrors = job.getErrorMessage() != null ? job.getErrorMessage() : "";
                job.setErrorMessage(existingErrors.isEmpty() ? newErrors : existingErrors + "\n" + newErrors);
            }
            
            payrollJobRepository.save(job);
        }
    }

    /**
     * Batch delete records
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void batchDeletePayrollData(Long periodId) {
        log.info("Deleting existing payroll data for period {}", periodId);
        
        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId);
        
        if (!records.isEmpty()) {
            for (EmployeePayrollRecord record : records) {
                lineItemRepository.deleteByEmployeePayrollRecordId(record.getId());
            }
            
            recordRepository.deleteAll(records);
            recordRepository.flush();
            
            log.info("Deleted {} employee records", records.size());
        }
    }

    /**
     * Result class
     */
    public static class BatchResult {
        private final AtomicInteger processed = new AtomicInteger(0);
        private final AtomicInteger failed = new AtomicInteger(0);
        private BigDecimal totalGross = BigDecimal.ZERO;
        private BigDecimal totalDeductions = BigDecimal.ZERO;
        private BigDecimal totalNet = BigDecimal.ZERO;
        private final List<String> errors = new ArrayList<>();

        public void incrementProcessed() { processed.incrementAndGet(); }
        public void incrementFailed() { failed.incrementAndGet(); }
        
        public synchronized void addGross(BigDecimal amount) { 
            totalGross = totalGross.add(amount); 
        }
        public synchronized void addDeductions(BigDecimal amount) { 
            totalDeductions = totalDeductions.add(amount); 
        }
        public synchronized void addNet(BigDecimal amount) { 
            totalNet = totalNet.add(amount); 
        }
        public synchronized void addError(String error) { 
            errors.add(error); 
        }

        public int getProcessed() { return processed.get(); }
        public int getFailed() { return failed.get(); }
        public BigDecimal getTotalGross() { return totalGross; }
        public BigDecimal getTotalDeductions() { return totalDeductions; }
        public BigDecimal getTotalNet() { return totalNet; }
        public List<String> getErrors() { return new ArrayList<>(errors); }
    }
}
