package com.hrmoja.service;

import com.hrmoja.dto.settings.OrganizationDto;
import com.hrmoja.entity.Country;
import com.hrmoja.entity.Organization;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.CountryRepository;
import com.hrmoja.repository.OrganizationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Organization Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationService {

    private final OrganizationRepository organizationRepository;
    private final CountryRepository countryRepository;

    @Transactional(readOnly = true)
    public List<OrganizationDto> getAllOrganizations() {
        return organizationRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrganizationDto> getActiveOrganizations() {
        return organizationRepository.findByIsActiveTrue().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public OrganizationDto getOrganizationById(Long id) {
        Organization organization = organizationRepository.findByIdWithCountry(id)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found with id: " + id));
        return mapToDto(organization);
    }

    @Transactional
    public OrganizationDto createOrganization(OrganizationDto dto) {
        Country country = countryRepository.findById(dto.getCountryId())
                .orElseThrow(() -> new ResourceNotFoundException("Country not found"));

        Organization organization = Organization.builder()
                .name(dto.getName())
                .legalName(dto.getLegalName())
                .registrationNumber(dto.getRegistrationNumber())
                .taxIdentificationNumber(dto.getTaxIdentificationNumber())
                .country(country)
                .addressLine1(dto.getAddressLine1())
                .addressLine2(dto.getAddressLine2())
                .city(dto.getCity())
                .stateProvince(dto.getStateProvince())
                .postalCode(dto.getPostalCode())
                .phoneNumber(dto.getPhoneNumber())
                .email(dto.getEmail())
                .website(dto.getWebsite())
                .logoUrl(dto.getLogoUrl())
                .isActive(true)
                .build();

        Organization savedOrganization = organizationRepository.save(organization);
        log.info("Organization created: {}", savedOrganization.getName());

        return mapToDto(savedOrganization);
    }

    @Transactional
    public OrganizationDto updateOrganization(Long id, OrganizationDto dto) {
        Organization organization = organizationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found with id: " + id));

        if (dto.getCountryId() != null) {
            Country country = countryRepository.findById(dto.getCountryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Country not found"));
            organization.setCountry(country);
        }

        organization.setName(dto.getName());
        organization.setLegalName(dto.getLegalName());
        organization.setRegistrationNumber(dto.getRegistrationNumber());
        organization.setTaxIdentificationNumber(dto.getTaxIdentificationNumber());
        organization.setAddressLine1(dto.getAddressLine1());
        organization.setAddressLine2(dto.getAddressLine2());
        organization.setCity(dto.getCity());
        organization.setStateProvince(dto.getStateProvince());
        organization.setPostalCode(dto.getPostalCode());
        organization.setPhoneNumber(dto.getPhoneNumber());
        organization.setEmail(dto.getEmail());
        organization.setWebsite(dto.getWebsite());
        organization.setLogoUrl(dto.getLogoUrl());
        organization.setActive(dto.isActive());

        Organization updatedOrganization = organizationRepository.save(organization);
        log.info("Organization updated: {}", updatedOrganization.getName());

        return mapToDto(updatedOrganization);
    }

    @Transactional
    public void toggleOrganizationStatus(Long id) {
        Organization organization = organizationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found with id: " + id));

        // Toggle organization active status
        boolean newStatus = !organization.isActive();
        organization.setActive(newStatus);
        organizationRepository.save(organization);
        log.info("Organization {} {}", newStatus ? "activated" : "deactivated", organization.getName());
    }

    private OrganizationDto mapToDto(Organization org) {
        return OrganizationDto.builder()
                .id(org.getId())
                .name(org.getName())
                .legalName(org.getLegalName())
                .registrationNumber(org.getRegistrationNumber())
                .taxIdentificationNumber(org.getTaxIdentificationNumber())
                .countryId(org.getCountry().getId())
                .countryName(org.getCountry().getName())
                .addressLine1(org.getAddressLine1())
                .addressLine2(org.getAddressLine2())
                .city(org.getCity())
                .stateProvince(org.getStateProvince())
                .postalCode(org.getPostalCode())
                .phoneNumber(org.getPhoneNumber())
                .email(org.getEmail())
                .website(org.getWebsite())
                .logoUrl(org.getLogoUrl())
                .isActive(org.isActive())
                .createdAt(org.getCreatedAt())
                .updatedAt(org.getUpdatedAt())
                .build();
    }
}
