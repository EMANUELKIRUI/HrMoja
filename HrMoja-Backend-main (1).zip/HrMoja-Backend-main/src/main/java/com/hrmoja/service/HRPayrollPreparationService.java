package com.hrmoja.service;

import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeeBankDetailsRepository;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * HR Payroll Preparation Service
 * Business logic for HR department payroll preparation tasks
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class HRPayrollPreparationService {

    private final PayrollPeriodRepository periodRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollApprovalService approvalService;
    private final PayrollCalculationEngine calculationEngine;
    private final EmployeeBankDetailsRepository bankDetailsRepository;

    /**
     * Get periods available for HR preparation (paginated with search)
     * Status: PROCESSING (just completed) or DRAFT (returned for corrections)
     * Search: filters by periodName or periodCode
     */
    public Page<PayrollPeriod> getPeriodsForPreparation(String status, String search, Pageable pageable) {
        Long orgId = getOrganizationId();
        List<String> statuses = (status != null && !status.isEmpty()) 
                ? List.of(status) 
                : List.of("PROCESSING", "DRAFT");
        
        if (search != null && !search.trim().isEmpty()) {
            return periodRepository.searchByOrganizationAndStatusInAndNameOrCode(
                    orgId, statuses, search.trim(), pageable);
        }
        
        return periodRepository.findByOrganizationIdAndStatusIn(orgId, statuses, pageable);
    }

    /**
     * Get period for editing
     */
    public PayrollPeriod getPeriodForEdit(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        if (!canEditPeriod(period)) {
            throw new IllegalStateException("Period is not editable in current status: " + period.getStatus());
        }
        
        return period;
    }

    /**
     * Get employee records for a period (paginated with search and filters)
     */
    public Page<EmployeePayrollRecord> getEmployeeRecordsPaginated(
            Long periodId, String search, String department, 
            String status, Integer approvalLevel, Pageable pageable) {
        return recordRepository.searchEmployeeRecords(
                periodId, search, department, status, approvalLevel, pageable);
    }

    /**
     * Get all employee records for a period
     */
    public List<EmployeePayrollRecord> getEmployeeRecords(Long periodId) {
        return recordRepository.findByPayrollPeriodId(periodId);
    }

    /**
     * Recalculate employee record after line item edits
     */
    @Transactional
    public EmployeePayrollRecord recalculateEmployeeRecord(Long recordId) {
        EmployeePayrollRecord record = recordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Record not found"));
        
        // TODO: Implement recalculation logic based on line items
        // For now, return the record as-is
        log.info("Recalculating employee record {} - implementation pending", recordId);
        
        return record;
    }

    /**
     * Submit period for Finance review (Level 1 → Level 2)
     * Validates that all active (non-rejected) records are approved
     */
    @Transactional
    public PayrollPeriod submitForReview(Long periodId, Long userId, String comment) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        // Get all records to check approval status
        List<EmployeePayrollRecord> allRecords = recordRepository.findByPayrollPeriodId(periodId);
        
        // Count active (non-rejected) records
        long activeRecords = allRecords.stream().filter(r -> !r.isRejected()).count();
        long approvedRecords = allRecords.stream()
                .filter(r -> !r.isRejected() && r.isApprovedLevel1())
                .count();
        long pendingRecords = activeRecords - approvedRecords;
        long rejectedRecords = allRecords.stream().filter(EmployeePayrollRecord::isRejected).count();
        
        // Validate all active records are approved
        if (pendingRecords > 0) {
            throw new IllegalStateException(
                    String.format("Cannot submit: %d of %d active records are pending approval. " +
                            "Please approve or reject all records before submitting for Finance review.",
                            pendingRecords, activeRecords));
        }
        
        // Ensure there's at least one active record
        if (activeRecords == 0) {
            throw new IllegalStateException(
                    "Cannot submit: No active employee records found. All records have been rejected.");
        }
        
        // Validate all active records have bank details
        long missingBankDetails = allRecords.stream()
                .filter(r -> !r.isRejected() && !r.isHasBankDetails())
                .count();
        
        if (missingBankDetails > 0) {
            throw new IllegalStateException(
                    String.format("Cannot submit: %d employee(s) are missing bank details. " +
                            "Please update bank details for all employees before submitting for Finance review.",
                            missingBankDetails));
        }
        
        log.info("Submitting period {} for review: {} approved, {} rejected", 
                periodId, approvedRecords, rejectedRecords);
        
        // Recalculate period totals excluding rejected records
        // This ensures Finance sees accurate totals matching the records they will review
        List<EmployeePayrollRecord> activeRecordsList = allRecords.stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());
        
        BigDecimal totalGross = activeRecordsList.stream()
                .map(EmployeePayrollRecord::getGrossSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalNet = activeRecordsList.stream()
                .map(EmployeePayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalDeductions = activeRecordsList.stream()
                .map(EmployeePayrollRecord::getTotalDeductions)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalTaxes = activeRecordsList.stream()
                .map(EmployeePayrollRecord::getTotalTaxes)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalStatutory = activeRecordsList.stream()
                .map(EmployeePayrollRecord::getTotalStatutory)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Update period with recalculated totals
        period.setTotalEmployees(activeRecordsList.size());
        period.setTotalGrossPay(totalGross);
        period.setTotalNetPay(totalNet);
        period.setTotalDeductions(totalDeductions);
        periodRepository.save(period);
        
        log.info("Recalculated period {} totals: {} active employees, Gross: {}, Net: {}",
                periodId, activeRecordsList.size(), totalGross, totalNet);
        
        // Mark as prepared using approval service
        PayrollPeriod prepared = approvalService.markAsPrepared(periodId, userId);
        
        // Add HR submission comment if provided
        if (comment != null && !comment.trim().isEmpty()) {
            String submissionNote = String.format("\n[HR SUBMISSION at %s by user %d]: %s", 
                    LocalDateTime.now(), userId, comment);
            prepared.setNotes(prepared.getNotes() != null ? prepared.getNotes() + submissionNote : submissionNote);
            prepared = periodRepository.save(prepared);
        }
        
        return prepared;
    }

    private boolean canEditPeriod(PayrollPeriod period) {
        String status = period.getStatus();
        return "DRAFT".equals(status) || "PROCESSING".equals(status);
    }

    private Long getOrganizationId() {
        // Get from security context
        return 1L; // TODO: Get from OrganizationContext
    }
}
