package com.hrmoja.service;

import com.hrmoja.entity.EmployeeBankDetails;
import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollPayment;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.entity.BankUploadFile;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeeBankDetailsRepository;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.PayrollPaymentRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import com.hrmoja.repository.BankUploadFileRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Bank File Generation Service
 * Generates bank transfer files in various formats (CSV, Excel)
 * for approved payroll periods
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BankFileGenerationService {

    private final PayrollPeriodRepository periodRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollPaymentRepository paymentRepository;
    private final EmployeeBankDetailsRepository bankDetailsRepository;
    private final BankUploadFileRepository bankUploadFileRepository;

    /**
     * Generate CSV bank file for payroll payment
     * Standard format: Account Number, Account Name, Amount, Reference
     */
    public byte[] generateCSVBankFile(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Only APPROVED periods can generate bank files");
        }

        // Get active (non-rejected) employee records
        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId)
                .stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());

        if (records.isEmpty()) {
            throw new IllegalStateException("No active employee records found");
        }

        StringBuilder csv = new StringBuilder();
        
        // Column headers - start directly with data
        csv.append("S/N,Employee Number,Employee Name,Department,Bank Name,Branch,Account Number,Account Name,Amount (UGX),Payment Reference\n");

        // Data rows
        int rowNum = 1;
        for (EmployeePayrollRecord record : records) {
            EmployeeBankDetails bankDetails = bankDetailsRepository.findPrimaryByEmployeeId(record.getEmployeeId())
                    .orElse(null);

            if (bankDetails == null || !record.isHasBankDetails()) {
                log.warn("Employee {} missing bank details - skipping from bank file", record.getEmployeeNumber());
                continue;
            }

            // Prefix account number with single quote to force text format (won't be visible in Excel)
            String accountNumber = "'" + bankDetails.getAccountNumber();
            
            csv.append(String.format("%d,\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%.2f,\"%s\"\n",
                    rowNum++,
                    record.getEmployeeNumber(),
                    record.getEmployeeName(),
                    record.getDepartmentName(),
                    bankDetails.getBank() != null ? bankDetails.getBank().getName() : "",
                    bankDetails.getBankBranch() != null ? bankDetails.getBankBranch().getName() : "",
                    accountNumber,
                    bankDetails.getAccountName(),
                    record.getNetSalary(),
                    generatePaymentReference(period, record)
            ));
        }

        log.info("Generated CSV bank file for period {} with {} employees", periodId, records.size());
        return csv.toString().getBytes(StandardCharsets.UTF_8);
    }

    /**
     * Generate Excel bank file with detailed information
     */
    public byte[] generateExcelBankFile(Long periodId) throws IOException {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Only APPROVED periods can generate bank files");
        }

        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId)
                .stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());

        if (records.isEmpty()) {
            throw new IllegalStateException("No active employee records found");
        }

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            
            // Create main sheet
            Sheet sheet = workbook.createSheet("Bank Transfer");
            
            // Create styles
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle currencyStyle = createCurrencyStyle(workbook);
            CellStyle normalStyle = createNormalStyle(workbook);
            CellStyle textStyle = createTextStyle(workbook); // For account numbers

            // Column headers - start directly with data
            Row headerRow = sheet.createRow(0);
            String[] headers = {
                "S/N", "Employee Number", "Employee Name", "Department",
                "Bank Name", "Branch", "Account Number", "Account Name",
                "Amount (UGX)", "Payment Reference"
            };
            
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data rows
            int rowNum = 1; // Start after header row
            int serialNum = 1;
            BigDecimal totalAmount = BigDecimal.ZERO;

            for (EmployeePayrollRecord record : records) {
                EmployeeBankDetails bankDetails = bankDetailsRepository.findPrimaryByEmployeeId(record.getEmployeeId())
                        .orElse(null);

                if (bankDetails == null || !record.isHasBankDetails()) {
                    log.warn("Employee {} missing bank details - skipping", record.getEmployeeNumber());
                    continue;
                }

                Row row = sheet.createRow(rowNum);
                
                // S/N
                Cell cell0 = row.createCell(0);
                cell0.setCellValue(serialNum++);
                cell0.setCellStyle(normalStyle);

                // Employee Number
                Cell cell1 = row.createCell(1);
                cell1.setCellValue(record.getEmployeeNumber());
                cell1.setCellStyle(normalStyle);

                // Employee Name
                Cell cell2 = row.createCell(2);
                cell2.setCellValue(record.getEmployeeName());
                cell2.setCellStyle(normalStyle);

                // Department
                Cell cell3 = row.createCell(3);
                cell3.setCellValue(record.getDepartmentName());
                cell3.setCellStyle(normalStyle);

                // Bank Name
                Cell cell4 = row.createCell(4);
                cell4.setCellValue(bankDetails.getBank() != null ? bankDetails.getBank().getName() : "");
                cell4.setCellStyle(normalStyle);

                // Branch
                Cell cell5 = row.createCell(5);
                cell5.setCellValue(bankDetails.getBankBranch() != null ? bankDetails.getBankBranch().getName() : "");
                cell5.setCellStyle(normalStyle);

                // Account Number - Force as text to prevent scientific notation
                Cell cell6 = row.createCell(6);
                cell6.setCellValue(bankDetails.getAccountNumber());
                cell6.setCellStyle(textStyle);

                // Account Name
                Cell cell7 = row.createCell(7);
                cell7.setCellValue(bankDetails.getAccountName());
                cell7.setCellStyle(normalStyle);

                // Amount (UGX) - Net Salary
                Cell cell8 = row.createCell(8);
                cell8.setCellValue(record.getNetSalary().doubleValue());
                cell8.setCellStyle(currencyStyle);
                totalAmount = totalAmount.add(record.getNetSalary());

                // Payment Reference
                Cell cell9 = row.createCell(9);
                cell9.setCellValue(generatePaymentReference(period, record));
                cell9.setCellStyle(normalStyle);

                rowNum++;
            }

            // Summary row
            Row summaryRow = sheet.createRow(rowNum + 1);
            Cell summaryLabel = summaryRow.createCell(7);
            summaryLabel.setCellValue("TOTAL AMOUNT:");
            summaryLabel.setCellStyle(headerStyle);

            Cell totalAmountCell = summaryRow.createCell(8);
            totalAmountCell.setCellValue(totalAmount.doubleValue());
            totalAmountCell.setCellStyle(currencyStyle);
            
            // Total employees
            Row countRow = sheet.createRow(rowNum + 2);
            countRow.createCell(7).setCellValue("Total Employees:");
            countRow.createCell(8).setCellValue(serialNum - 1);

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(out);
            log.info("Generated Excel bank file for period {} with {} employees", periodId, records.size());
            return out.toByteArray();
        }
    }

    /**
     * Generate bank file and save with locking (prevents tampering)
     * If file already locked, return existing file
     */
    @Transactional
    public byte[] generateBankFileAndSave(Long paymentId, String format, Long userId) throws IOException {
        PayrollPayment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));

        PayrollPeriod period = periodRepository.findById(payment.getPayrollPeriodId())
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        // Check if locked file already exists
        var existingFile = bankUploadFileRepository.findLockedGeneratedFile(payment.getPayrollPeriodId());
        if (existingFile.isPresent()) {
            log.info("Locked bank file already exists for period {}, returning existing file", payment.getPayrollPeriodId());
            // TODO: Load from file storage - for now regenerate
        }

        byte[] fileData;
        String fileName;
        String fileFormat;

        if ("EXCEL".equalsIgnoreCase(format)) {
            fileData = generateExcelBankFile(payment.getPayrollPeriodId());
            fileName = generateFileName(payment, "xlsx");
            fileFormat = "EXCEL";
        } else {
            fileData = generateCSVBankFile(payment.getPayrollPeriodId());
            fileName = generateFileName(payment, "csv");
            fileFormat = "CSV";
        }

        // Calculate file hash for integrity
        String fileHash = calculateSHA256(fileData);

        // Count records and calculate total
        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(payment.getPayrollPeriodId())
                .stream()
                .filter(r -> !r.isRejected() && r.isHasBankDetails())
                .collect(Collectors.toList());
        
        int totalRecords = records.size();
        BigDecimal totalAmount = records.stream()
                .map(EmployeePayrollRecord::getNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Save bank file record
        BankUploadFile bankFile = BankUploadFile.builder()
                .payrollPeriodId(payment.getPayrollPeriodId())
                .organizationId(period.getOrganization().getId())
                .fileName(fileName)
                .fileFormat(fileFormat)
                .fileType("GENERATED")
                .fileHash(fileHash)
                .fileSize((long) fileData.length)
                .totalRecords(totalRecords)
                .totalAmount(totalAmount)
                .uploadStatus("GENERATED")
                .generatedBy(userId)
                .isLocked(true)
                .notes("Bank file locked for integrity")
                .build();

        bankUploadFileRepository.save(bankFile);

        // Update payment record
        payment.setBankFileGenerated(true);
        payment.setBankFileName(fileName);
        payment.setBankFileGeneratedAt(LocalDateTime.now());
        payment.setBankFileGeneratedBy(userId);
        paymentRepository.save(payment);

        log.info("Generated and locked {} bank file for payment {} with hash {}", 
                format, paymentId, fileHash);
        return fileData;
    }

    /**
     * Get bank file preview data for a period
     */
    public List<BankFileEntry> getBankFilePreview(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Payroll period not found"));

        List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(periodId)
                .stream()
                .filter(r -> !r.isRejected())
                .collect(Collectors.toList());

        List<BankFileEntry> entries = new ArrayList<>();
        
        for (EmployeePayrollRecord record : records) {
            EmployeeBankDetails bankDetails = bankDetailsRepository.findPrimaryByEmployeeId(record.getEmployeeId())
                    .orElse(null);

            BankFileEntry entry = new BankFileEntry();
            entry.setEmployeeNumber(record.getEmployeeNumber());
            entry.setEmployeeName(record.getEmployeeName());
            entry.setDepartment(record.getDepartmentName());
            entry.setAmount(record.getNetSalary());
            entry.setHasBankDetails(bankDetails != null);
            
            if (bankDetails != null) {
                entry.setBankName(bankDetails.getBank() != null ? bankDetails.getBank().getName() : null);
                entry.setAccountNumber(bankDetails.getAccountNumber());
                entry.setAccountName(bankDetails.getAccountName());
                entry.setBranch(bankDetails.getBankBranch() != null ? bankDetails.getBankBranch().getName() : null);
            }
            
            entry.setPaymentReference(generatePaymentReference(period, record));
            entries.add(entry);
        }

        return entries;
    }

    // Helper methods

    private String generatePaymentReference(PayrollPeriod period, EmployeePayrollRecord record) {
        return String.format("%s-SALARY-%s", period.getPeriodCode(), record.getEmployeeNumber());
    }

    private String generateFileName(PayrollPayment payment, String extension) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        return String.format("PAYROLL_BANK_FILE_%s_%s.%s", 
                payment.getPaymentBatchNumber(), timestamp, extension);
    }

    /**
     * Calculate SHA-256 hash of file data for integrity verification
     */
    private String calculateSHA256(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);
            return bytesToHex(hash);
        } catch (NoSuchAlgorithmException e) {
            log.error("SHA-256 algorithm not available", e);
            return null;
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private CellStyle createCurrencyStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("#,##0.00"));
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    private CellStyle createNormalStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.LEFT);
        return style;
    }

    private CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    private CellStyle createTextStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("@")); // @ means text format
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.LEFT);
        return style;
    }

    /**
     * Bank file entry DTO
     */
    @lombok.Data
    public static class BankFileEntry {
        private String employeeNumber;
        private String employeeName;
        private String department;
        private String bankName;
        private String accountNumber;
        private String accountName;
        private String branch;
        private BigDecimal amount;
        private String paymentReference;
        private boolean hasBankDetails;
    }
}
