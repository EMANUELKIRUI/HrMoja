package com.hrmoja.service;

import com.hrmoja.dto.dashboard.DashboardMetricsDto;
import com.hrmoja.entity.AuditLog;
import com.hrmoja.repository.AuditLogRepository;
import com.hrmoja.repository.EmployeeRepository;
import com.hrmoja.repository.PayrollRecordRepository;
import com.hrmoja.repository.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Dashboard Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DashboardService {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final PayrollRecordRepository payrollRecordRepository;
    private final AuditLogRepository auditLogRepository;

    @Transactional(readOnly = true)
    public DashboardMetricsDto getOrganizationMetrics(Long organizationId) {
        log.info("Fetching dashboard metrics for organization: {}", organizationId);
        
        // Employee counts
        Long totalEmployees = employeeRepository.countByOrganizationId(organizationId);
        Long activeEmployees = employeeRepository.countByOrganizationIdAndIsActiveTrue(organizationId);
        Long inactiveEmployees = totalEmployees - activeEmployees;
        
        // Calculate monthly payroll (current month)
        BigDecimal monthlyPayroll = calculateCurrentMonthPayroll(organizationId);
        
        // Get department distribution
        List<DashboardMetricsDto.DepartmentStatsDto> departmentStats = getDepartmentDistribution(organizationId);
        
        // Get payroll trends (last 6 months)
        List<DashboardMetricsDto.MonthlyTrendDto> payrollTrend = getPayrollTrend(organizationId);
        
        // Get employee trends (last 6 months)
        List<DashboardMetricsDto.MonthlyTrendDto> employeeTrend = getEmployeeTrend(organizationId);
        
        // Get recent activities
        List<DashboardMetricsDto.ActivityDto> recentActivities = getRecentActivities(organizationId);
        
        return DashboardMetricsDto.builder()
                .totalEmployees(totalEmployees)
                .activeEmployees(activeEmployees)
                .inactiveEmployees(inactiveEmployees)
                .monthlyPayroll(monthlyPayroll)
                .pendingTasks(0) // TODO: Implement when approval workflow is ready
                .teamPerformance(95.0) // TODO: Implement performance tracking
                .payrollTrend(payrollTrend)
                .employeeTrend(employeeTrend)
                .departmentDistribution(departmentStats)
                .recentActivities(recentActivities)
                .build();
    }

    private BigDecimal calculateCurrentMonthPayroll(Long organizationId) {
        // TODO: Calculate from actual payroll records
        // For now, estimate based on employee count and average salary
        Long employeeCount = employeeRepository.countByOrganizationIdAndIsActiveTrue(organizationId);
        return BigDecimal.valueOf(employeeCount * 2_500_000L); // Average 2.5M per employee
    }

    private List<DashboardMetricsDto.DepartmentStatsDto> getDepartmentDistribution(Long organizationId) {
        List<DashboardMetricsDto.DepartmentStatsDto> stats = new ArrayList<>();
        
        departmentRepository.findByOrganizationIdAndIsActiveTrue(organizationId).forEach(dept -> {
            Long count = employeeRepository.countByDepartmentIdAndIsActiveTrue(dept.getId());
            if (count > 0) {
                stats.add(DashboardMetricsDto.DepartmentStatsDto.builder()
                        .departmentName(dept.getName())
                        .employeeCount(count)
                        .totalSalary(BigDecimal.valueOf(count * 2_500_000L))
                        .build());
            }
        });
        
        return stats;
    }

    private List<DashboardMetricsDto.MonthlyTrendDto> getPayrollTrend(Long organizationId) {
        // TODO: Get from actual payroll records
        // Mock data for last 6 months
        List<DashboardMetricsDto.MonthlyTrendDto> trend = new ArrayList<>();
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun"};
        long[] amounts = {12_000_000L, 13_500_000L, 14_200_000L, 13_800_000L, 15_000_000L, 16_500_000L};
        
        for (int i = 0; i < months.length; i++) {
            trend.add(DashboardMetricsDto.MonthlyTrendDto.builder()
                    .month(months[i])
                    .amount(BigDecimal.valueOf(amounts[i]))
                    .build());
        }
        
        return trend;
    }

    private List<DashboardMetricsDto.MonthlyTrendDto> getEmployeeTrend(Long organizationId) {
        // TODO: Get from employee history
        // Mock data for last 6 months
        List<DashboardMetricsDto.MonthlyTrendDto> trend = new ArrayList<>();
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun"};
        long[] counts = {285L, 290L, 295L, 300L, 305L, 312L};
        
        for (int i = 0; i < months.length; i++) {
            trend.add(DashboardMetricsDto.MonthlyTrendDto.builder()
                    .month(months[i])
                    .count(counts[i])
                    .build());
        }
        
        return trend;
    }

    private List<DashboardMetricsDto.ActivityDto> getRecentActivities(Long organizationId) {
        List<DashboardMetricsDto.ActivityDto> activities = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        
        // Fetch last 10 audit logs for this organization
        List<AuditLog> auditLogs = auditLogRepository.findRecentByOrganization(
            organizationId, 
            PageRequest.of(0, 10)
        );
        
        for (AuditLog log : auditLogs) {
            String description = buildActivityDescription(log);
            String userName = log.getUser() != null ? log.getUser().getFullName() : "System";
            
            activities.add(DashboardMetricsDto.ActivityDto.builder()
                    .type(log.getAction())
                    .description(description)
                    .timestamp(log.getPerformedAt() != null ? 
                        log.getPerformedAt().format(formatter) : "")
                    .user(userName)
                    .build());
        }
        
        return activities;
    }
    
    private String buildActivityDescription(AuditLog log) {
        String action = log.getAction();
        String entityType = log.getEntityType();
        
        // Build user-friendly descriptions based on action type
        switch (action) {
            case "CREATE":
                return "Created " + (entityType != null ? entityType.toLowerCase() : "record") + 
                       " #" + log.getEntityId();
            case "UPDATE":
                return "Updated " + (entityType != null ? entityType.toLowerCase() : "record") + 
                       " #" + log.getEntityId();
            case "DELETE":
                return "Deleted " + (entityType != null ? entityType.toLowerCase() : "record") + 
                       " #" + log.getEntityId();
            case "LOGIN":
                return "User logged in";
            case "LOGOUT":
                return "User logged out";
            case "EMPLOYEE_CREATED":
                return "New employee added";
            case "PAYROLL_PROCESSED":
                return "Payroll processed for period #" + log.getEntityId();
            case "PAYROLL_APPROVED":
                return "Payroll approved for period #" + log.getEntityId();
            default:
                return action.replace("_", " ").toLowerCase();
        }
    }
}
