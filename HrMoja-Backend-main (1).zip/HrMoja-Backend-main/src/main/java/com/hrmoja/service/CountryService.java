package com.hrmoja.service;

import com.hrmoja.dto.settings.CountryDto;
import com.hrmoja.entity.Country;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.CountryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Country Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CountryService {

    private final CountryRepository countryRepository;

    @Transactional(readOnly = true)
    public List<CountryDto> getAllCountries() {
        return countryRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<CountryDto> getActiveCountries() {
        return countryRepository.findByIsActiveTrue().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public CountryDto getCountryById(Long id) {
        Country country = countryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Country not found with id: " + id));
        return mapToDto(country);
    }

    @Transactional(readOnly = true)
    public CountryDto getCountryByCode(String code) {
        Country country = countryRepository.findByCode(code)
                .orElseThrow(() -> new ResourceNotFoundException("Country not found with code: " + code));
        return mapToDto(country);
    }

    @Transactional
    public CountryDto createCountry(CountryDto dto) {
        if (countryRepository.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Country with code " + dto.getCode() + " already exists");
        }

        Country country = Country.builder()
                .name(dto.getName())
                .code(dto.getCode())
                .isoCode(dto.getIsoCode())
                .currencyCode(dto.getCurrencyCode())
                .currencyName(dto.getCurrencyName())
                .currencySymbol(dto.getCurrencySymbol())
                .timezone(dto.getTimezone())
                .dateFormat(dto.getDateFormat())
                .isActive(true)
                .build();

        Country savedCountry = countryRepository.save(country);
        log.info("Country created: {}", savedCountry.getName());

        return mapToDto(savedCountry);
    }

    @Transactional
    public CountryDto updateCountry(Long id, CountryDto dto) {
        Country country = countryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Country not found with id: " + id));

        country.setName(dto.getName());
        country.setCurrencyCode(dto.getCurrencyCode());
        country.setCurrencyName(dto.getCurrencyName());
        country.setCurrencySymbol(dto.getCurrencySymbol());
        country.setTimezone(dto.getTimezone());
        country.setDateFormat(dto.getDateFormat());
        country.setActive(dto.isActive());

        Country updatedCountry = countryRepository.save(country);
        log.info("Country updated: {}", updatedCountry.getName());

        return mapToDto(updatedCountry);
    }

    @Transactional
    public void deleteCountry(Long id) {
        Country country = countryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Country not found with id: " + id));

        country.setActive(false);
        countryRepository.save(country);
        log.info("Country deactivated: {}", country.getName());
    }

    private CountryDto mapToDto(Country country) {
        return CountryDto.builder()
                .id(country.getId())
                .name(country.getName())
                .code(country.getCode())
                .isoCode(country.getIsoCode())
                .currencyCode(country.getCurrencyCode())
                .currencyName(country.getCurrencyName())
                .currencySymbol(country.getCurrencySymbol())
                .timezone(country.getTimezone())
                .dateFormat(country.getDateFormat())
                .isActive(country.isActive())
                .createdAt(country.getCreatedAt())
                .updatedAt(country.getUpdatedAt())
                .build();
    }
}
