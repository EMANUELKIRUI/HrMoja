package com.hrmoja.service;

import com.hrmoja.dto.role.RoleCreateRequest;
import com.hrmoja.dto.role.RoleDto;
import com.hrmoja.entity.Permission;
import com.hrmoja.entity.Role;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.exception.ValidationException;
import com.hrmoja.repository.PermissionRepository;
import com.hrmoja.repository.RoleRepository;
import com.hrmoja.util.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Role Management Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RoleManagementService {

    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;

    @Transactional(readOnly = true)
    public List<RoleDto> getAllRoles() {
        return roleRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<RoleDto> getActiveRoles() {
        return roleRepository.findByIsActiveTrue().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public RoleDto getRoleById(Long id) {
        Role role = roleRepository.findByIdWithPermissions(id)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + id));
        return convertToDto(role);
    }

    @Transactional(readOnly = true)
    public RoleDto getRoleByCode(String code) {
        Role role = roleRepository.findByCodeWithPermissions(code)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with code: " + code));
        return convertToDto(role);
    }

    @Transactional
    public RoleDto createRole(RoleCreateRequest request) {
        // Validate uniqueness
        if (roleRepository.existsByCode(request.getCode())) {
            throw new ValidationException("Role code already exists");
        }
        if (roleRepository.existsByName(request.getName())) {
            throw new ValidationException("Role name already exists");
        }

        // Get permissions
        Set<Permission> permissions = new HashSet<>();
        if (request.getPermissionIds() != null && !request.getPermissionIds().isEmpty()) {
            permissions = request.getPermissionIds().stream()
                    .map(permId -> permissionRepository.findById(permId)
                            .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + permId)))
                    .collect(Collectors.toSet());
        }

        // Build role
        Role role = Role.builder()
                .name(request.getName())
                .code(request.getCode())
                .description(request.getDescription())
                .level(request.getLevel())
                .isSystemRole(false)
                .isActive(true)
                .permissions(permissions)
                .build();

        role = roleRepository.save(role);
        log.info("Role created: {}", role.getName());

        return convertToDto(role);
    }

    @Transactional
    public RoleDto updateRole(Long id, RoleCreateRequest request) {
        Role role = roleRepository.findByIdWithPermissions(id)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + id));

        // Prevent modification of system roles (unless user is SUPER_ADMIN)
        if (role.isSystemRole() && !SecurityUtils.hasRole("SUPER_ADMIN")) {
            throw new ValidationException("Cannot modify system roles");
        }

        // Validate uniqueness if changing
        if (!role.getCode().equals(request.getCode()) && roleRepository.existsByCode(request.getCode())) {
            throw new ValidationException("Role code already exists");
        }
        if (!role.getName().equals(request.getName()) && roleRepository.existsByName(request.getName())) {
            throw new ValidationException("Role name already exists");
        }

        // Update fields
        role.setName(request.getName());
        role.setCode(request.getCode());
        role.setDescription(request.getDescription());
        role.setLevel(request.getLevel());

        // Update permissions
        if (request.getPermissionIds() != null) {
            Set<Permission> permissions = request.getPermissionIds().stream()
                    .map(permId -> permissionRepository.findById(permId)
                            .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + permId)))
                    .collect(Collectors.toSet());
            role.setPermissions(permissions);
        }

        role = roleRepository.save(role);
        log.info("Role updated: {}", role.getName());

        return convertToDto(role);
    }

    @Transactional
    public void deleteRole(Long id) {
        Role role = roleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + id));

        if (role.isSystemRole()) {
            throw new ValidationException("Cannot delete system roles");
        }

        role.setActive(false);
        roleRepository.save(role);
        log.info("Role deactivated: {}", role.getName());
    }

    @Transactional
    public void addPermissionsToRole(Long roleId, Set<Long> permissionIds) {
        Role role = roleRepository.findByIdWithPermissions(roleId)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found"));

        Set<Permission> newPermissions = permissionIds.stream()
                .map(permId -> permissionRepository.findById(permId)
                        .orElseThrow(() -> new ResourceNotFoundException("Permission not found with id: " + permId)))
                .collect(Collectors.toSet());

        role.getPermissions().addAll(newPermissions);
        roleRepository.save(role);

        log.info("Added {} permissions to role: {}", newPermissions.size(), role.getName());
    }

    @Transactional
    public void removePermissionsFromRole(Long roleId, Set<Long> permissionIds) {
        Role role = roleRepository.findByIdWithPermissions(roleId)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found"));

        role.getPermissions().removeIf(permission -> permissionIds.contains(permission.getId()));
        roleRepository.save(role);

        log.info("Removed {} permissions from role: {}", permissionIds.size(), role.getName());
    }

    private RoleDto convertToDto(Role role) {
        List<String> permissionNames = role.getPermissions().stream()
                .map(Permission::getName)
                .collect(Collectors.toList());

        List<Long> permissionIds = role.getPermissions().stream()
                .map(Permission::getId)
                .collect(Collectors.toList());

        return RoleDto.builder()
                .id(role.getId())
                .name(role.getName())
                .code(role.getCode())
                .description(role.getDescription())
                .level(role.getLevel())
                .isSystemRole(role.isSystemRole())
                .isActive(role.isActive())
                .permissions(permissionNames)
                .permissionIds(permissionIds)
                .createdAt(role.getCreatedAt())
                .updatedAt(role.getUpdatedAt())
                .build();
    }
}
