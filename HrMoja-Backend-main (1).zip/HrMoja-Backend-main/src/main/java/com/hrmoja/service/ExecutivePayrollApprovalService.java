package com.hrmoja.service;

import com.hrmoja.entity.EmployeePayrollRecord;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.entity.User;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.EmployeePayrollRecordRepository;
import com.hrmoja.repository.PayrollPeriodRepository;
import com.hrmoja.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Executive Payroll Approval Service
 * Business logic for Executive/CEO final approval tasks
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ExecutivePayrollApprovalService {

    private final PayrollPeriodRepository periodRepository;
    private final EmployeePayrollRecordRepository recordRepository;
    private final PayrollApprovalService approvalService;
    private final UserRepository userRepository;

    /**
     * Get periods pending Executive approval
     * Status: REVIEWED (Finance completed)
     */
    public List<PayrollPeriod> getPeriodsForApproval(String status) {
        List<PayrollPeriod> periods;
        if (status != null && !status.isEmpty()) {
            periods = periodRepository.findByOrganizationIdAndStatus(
                    getOrganizationId(), status);
        } else {
            // Get periods ready for Executive approval
            periods = periodRepository.findByOrganizationIdAndStatus(
                    getOrganizationId(), "REVIEWED");
        }
        
        // Populate reviewer names
        periods.forEach(this::populateReviewerName);
        return periods;
    }

    /**
     * Get period for final approval
     */
    public PayrollPeriod getPeriodForApproval(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        if (!"REVIEWED".equals(period.getStatus())) {
            throw new IllegalStateException("Period is not ready for Executive approval");
        }
        
        return period;
    }

    /**
     * Get employee records summary
     */
    public List<EmployeePayrollRecord> getEmployeeRecordsSummary(Long periodId) {
        return recordRepository.findByPayrollPeriodId(periodId);
    }

    /**
     * Get executive summary with full approval trail
     */
    public Map<String, Object> getExecutiveSummary(Long periodId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        Map<String, Object> summary = new HashMap<>();
        summary.put("periodId", periodId);
        summary.put("periodName", period.getPeriodName());
        summary.put("periodCode", period.getPeriodCode());
        summary.put("startDate", period.getStartDate());
        summary.put("endDate", period.getEndDate());
        summary.put("paymentDate", period.getPaymentDate());
        summary.put("status", period.getStatus());
        summary.put("approvalLevel", period.getApprovalLevel());
        
        // Financial summary
        summary.put("totalEmployees", period.getTotalEmployees());
        summary.put("totalGrossPay", period.getTotalGrossPay());
        summary.put("totalDeductions", period.getTotalDeductions());
        summary.put("totalNetPay", period.getTotalNetPay());
        
        // Approval trail
        Map<String, Object> approvalTrail = new HashMap<>();
        approvalTrail.put("processedBy", period.getProcessedBy());
        approvalTrail.put("processedAt", period.getProcessedAt());
        approvalTrail.put("preparedBy", period.getPreparedBy());
        approvalTrail.put("preparedAt", period.getPreparedAt());
        approvalTrail.put("reviewedBy", period.getReviewedBy());
        approvalTrail.put("reviewedAt", period.getReviewedAt());
        summary.put("approvalTrail", approvalTrail);
        
        // Approval progress
        summary.put("approvalProgress", approvalService.getApprovalProgress(period));
        
        return summary;
    }

    /**
     * Give final approval (Level 3)
     */
    @Transactional
    public PayrollPeriod giveFinalApproval(Long periodId, Long userId, String comment) {
        PayrollPeriod period = approvalService.givesFinalApproval(periodId, userId);
        
        if (comment != null && !comment.isEmpty()) {
            String approvalNote = String.format("\n[EXECUTIVE APPROVAL at %s by user %d]: %s", 
                    LocalDateTime.now(), userId, comment);
            period.setNotes(period.getNotes() != null ? period.getNotes() + approvalNote : approvalNote);
            period = periodRepository.save(period);
        }
        
        log.info("Period {} finally approved by Executive user {}", periodId, userId);
        return period;
    }

    /**
     * Reject period
     */
    @Transactional
    public PayrollPeriod rejectPeriod(Long periodId, Long userId, String reason) {
        return approvalService.rejectPayroll(periodId, userId, reason);
    }

    /**
     * Authorize payment - Mark as PAID
     */
    @Transactional
    public PayrollPeriod authorizePayment(Long periodId, Long userId) {
        PayrollPeriod period = periodRepository.findById(periodId)
                .orElseThrow(() -> new ResourceNotFoundException("Period not found"));
        
        if (!"APPROVED".equals(period.getStatus())) {
            throw new IllegalStateException("Only approved periods can be marked as paid");
        }
        
        period.setStatus("PAID");
        
        String paymentNote = String.format("\n[PAYMENT AUTHORIZED at %s by user %d]", 
                LocalDateTime.now(), userId);
        period.setNotes(period.getNotes() != null ? period.getNotes() + paymentNote : paymentNote);
        
        PayrollPeriod saved = periodRepository.save(period);
        log.info("Payment authorized for period {} by user {}", periodId, userId);
        return saved;
    }

    /**
     * Get Executive dashboard data
     */
    public Map<String, Object> getExecutiveDashboard() {
        Long orgId = getOrganizationId();
        
        Map<String, Object> dashboard = new HashMap<>();
        
        // Periods pending approval
        List<PayrollPeriod> pendingApproval = periodRepository.findByOrganizationIdAndStatus(orgId, "REVIEWED");
        dashboard.put("pendingApprovals", pendingApproval.size());
        
        // Calculate total payroll value from pending approvals
        java.math.BigDecimal totalPayrollValue = pendingApproval.stream()
                .map(PayrollPeriod::getTotalNetPay)
                .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add);
        dashboard.put("totalPayrollAmount", totalPayrollValue);
        
        // Calculate unique employees across all pending approval periods
        Set<Long> uniqueEmployeeIds = new HashSet<>();
        for (PayrollPeriod period : pendingApproval) {
            List<EmployeePayrollRecord> records = recordRepository.findByPayrollPeriodId(period.getId());
            records.stream()
                    .filter(r -> !r.isRejected())
                    .map(EmployeePayrollRecord::getEmployeeId)
                    .forEach(uniqueEmployeeIds::add);
        }
        dashboard.put("totalEmployees", uniqueEmployeeIds.size());
        
        // Recently approved this month
        List<PayrollPeriod> approved = periodRepository.findByOrganizationIdAndStatus(orgId, "APPROVED");
        long approvedThisMonth = approved.stream()
                .filter(p -> p.getFinalApprovedAt() != null && 
                            p.getFinalApprovedAt().getMonth() == LocalDateTime.now().getMonth())
                .count();
        dashboard.put("approvedThisMonth", approvedThisMonth);
        
        // Additional metrics
        dashboard.put("averageProcessingTime", 0); // TODO: Calculate from audit trail
        dashboard.put("complianceScore", 100); // TODO: Calculate based on validation reports
        
        return dashboard;
    }

    private Long getOrganizationId() {
        return 1L; // TODO: Get from OrganizationContext
    }

    /**
     * Populate reviewer name from User entity
     */
    private void populateReviewerName(PayrollPeriod period) {
        if (period.getReviewedBy() != null) {
            userRepository.findById(period.getReviewedBy())
                    .ifPresent(user -> {
                        String fullName = user.getFirstName() + " " + user.getLastName();
                        period.setReviewedByName(fullName);
                    });
        }
    }
}
