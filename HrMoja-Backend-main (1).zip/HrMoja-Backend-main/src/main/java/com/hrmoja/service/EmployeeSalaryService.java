package com.hrmoja.service;

import com.hrmoja.dto.salary.EmployeeSalaryDto;
import com.hrmoja.entity.Employee;
import com.hrmoja.entity.EmployeeSalaryStructure;
import com.hrmoja.entity.PayFrequency;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.exception.ValidationException;
import com.hrmoja.repository.EmployeeRepository;
import com.hrmoja.repository.EmployeeSalaryStructureRepository;
import com.hrmoja.repository.PayFrequencyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Employee Salary Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeSalaryService {

    private final EmployeeSalaryStructureRepository salaryRepository;
    private final EmployeeRepository employeeRepository;
    private final PayFrequencyRepository payFrequencyRepository;

    @Transactional(readOnly = true)
    public EmployeeSalaryDto getCurrentSalary(Long employeeId) {
        EmployeeSalaryStructure salary = salaryRepository.findCurrentByEmployeeId(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("No active salary found for employee: " + employeeId));
        return mapToDto(salary);
    }

    @Transactional(readOnly = true)
    public List<EmployeeSalaryDto> getSalaryHistory(Long employeeId) {
        return salaryRepository.findAllByEmployeeId(employeeId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public EmployeeSalaryDto createSalary(EmployeeSalaryDto dto) {
        // Validate employee exists
        Employee employee = employeeRepository.findById(dto.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        // Validate pay frequency
        PayFrequency payFrequency = payFrequencyRepository.findById(dto.getPayFrequencyId())
                .orElseThrow(() -> new ResourceNotFoundException("Pay frequency not found"));

        // Deactivate existing active salary structures
        List<EmployeeSalaryStructure> activeSalaries = salaryRepository.findActiveByEmployeeId(dto.getEmployeeId());
        for (EmployeeSalaryStructure activeSalary : activeSalaries) {
            activeSalary.setActive(false);
            activeSalary.setEndDate(dto.getEffectiveDate().minusDays(1));
        }

        // Create new salary structure
        EmployeeSalaryStructure salary = EmployeeSalaryStructure.builder()
                .employee(employee)
                .effectiveDate(dto.getEffectiveDate())
                .basicSalary(dto.getBasicSalary())
                .currencyCode(dto.getCurrencyCode())
                .payFrequency(payFrequency)
                .paymentMethodId(dto.getPaymentMethodId())
                .active(true)
                .build();

        salary = salaryRepository.save(salary);
        log.info("Salary structure created for employee {}: {} {}", employee.getEmployeeNumber(), 
                salary.getCurrencyCode(), salary.getBasicSalary());

        return mapToDto(salary);
    }

    @Transactional
    public EmployeeSalaryDto updateSalary(Long employeeId, Long salaryId, EmployeeSalaryDto dto) {
        EmployeeSalaryStructure salary = salaryRepository.findById(salaryId)
                .orElseThrow(() -> new ResourceNotFoundException("Salary structure not found"));

        if (!salary.getEmployee().getId().equals(employeeId)) {
            throw new ValidationException("Salary structure does not belong to this employee");
        }

        // Update fields
        if (dto.getBasicSalary() != null) {
            salary.setBasicSalary(dto.getBasicSalary());
        }

        if (dto.getCurrencyCode() != null) {
            salary.setCurrencyCode(dto.getCurrencyCode());
        }

        if (dto.getPayFrequencyId() != null) {
            PayFrequency payFrequency = payFrequencyRepository.findById(dto.getPayFrequencyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Pay frequency not found"));
            salary.setPayFrequency(payFrequency);
        }

        if (dto.getEffectiveDate() != null) {
            salary.setEffectiveDate(dto.getEffectiveDate());
        }

        if (dto.getEndDate() != null) {
            salary.setEndDate(dto.getEndDate());
        }

        if (dto.getPaymentMethodId() != null) {
            salary.setPaymentMethodId(dto.getPaymentMethodId());
        }

        salary = salaryRepository.save(salary);
        log.info("Salary structure updated for employee: {}", employeeId);

        return mapToDto(salary);
    }

    @Transactional
    public void deactivateSalary(Long employeeId, Long salaryId) {
        EmployeeSalaryStructure salary = salaryRepository.findById(salaryId)
                .orElseThrow(() -> new ResourceNotFoundException("Salary structure not found"));

        if (!salary.getEmployee().getId().equals(employeeId)) {
            throw new ValidationException("Salary structure does not belong to this employee");
        }

        salary.setActive(false);
        salary.setEndDate(LocalDate.now());
        salaryRepository.save(salary);
        log.info("Salary structure deactivated for employee: {}", employeeId);
    }

    private EmployeeSalaryDto mapToDto(EmployeeSalaryStructure salary) {
        return EmployeeSalaryDto.builder()
                .id(salary.getId())
                .employeeId(salary.getEmployee().getId())
                .effectiveDate(salary.getEffectiveDate())
                .endDate(salary.getEndDate())
                .basicSalary(salary.getBasicSalary())
                .currencyCode(salary.getCurrencyCode())
                .payFrequencyId(salary.getPayFrequency().getId())
                .payFrequencyName(salary.getPayFrequency().getName())
                .paymentMethodId(salary.getPaymentMethodId())
                .active(salary.isActive())
                .approvedBy(salary.getApprovedBy())
                .approvedAt(salary.getApprovedAt())
                .createdAt(salary.getCreatedAt())
                .updatedAt(salary.getUpdatedAt())
                .build();
    }
}
