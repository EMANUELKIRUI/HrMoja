package com.hrmoja.service;

import com.hrmoja.dto.settings.BranchDto;
import com.hrmoja.entity.Branch;
import com.hrmoja.entity.Country;
import com.hrmoja.entity.Organization;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.BranchRepository;
import com.hrmoja.repository.CountryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Branch Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BranchService {

    private final BranchRepository branchRepository;
    private final CountryRepository countryRepository;

    @Transactional(readOnly = true)
    public List<BranchDto> getBranchesByOrganization(Long organizationId) {
        return branchRepository.findByOrganizationId(organizationId).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BranchDto> getActiveBranchesByOrganization(Long organizationId) {
        return branchRepository.findByOrganizationIdAndIsActiveTrue(organizationId).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public BranchDto getBranchById(Long id) {
        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found with id: " + id));
        return toDto(branch);
    }

    @Transactional
    public BranchDto createBranch(BranchDto dto) {
        Branch branch = new Branch();
        mapDtoToEntity(dto, branch);
        branch.setActive(true);
        
        Branch saved = branchRepository.save(branch);
        log.info("Branch created: {}", saved.getName());
        return toDto(saved);
    }

    @Transactional
    public BranchDto updateBranch(Long id, BranchDto dto) {
        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found with id: " + id));
        
        mapDtoToEntity(dto, branch);
        Branch updated = branchRepository.save(branch);
        log.info("Branch updated: {}", updated.getName());
        return toDto(updated);
    }

    @Transactional
    public void deleteBranch(Long id) {
        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found with id: " + id));
        
        branch.setActive(false);
        branchRepository.save(branch);
        log.info("Branch deactivated: {}", branch.getName());
    }

    private void mapDtoToEntity(BranchDto dto, Branch entity) {
        // Set organization
        Organization org = new Organization();
        org.setId(dto.getOrganizationId());
        entity.setOrganization(org);
        
        entity.setName(dto.getName());
        entity.setCode(dto.getCode());
        entity.setAddressLine1(dto.getAddressLine1());
        entity.setAddressLine2(dto.getAddressLine2());
        entity.setCity(dto.getCity());
        entity.setStateProvince(dto.getStateProvince());
        entity.setPostalCode(dto.getPostalCode());
        entity.setPhoneNumber(dto.getPhoneNumber());
        entity.setEmail(dto.getEmail());
        entity.setManagerId(dto.getManagerId());
        entity.setHeadquarters(dto.getIsHeadOffice() != null && dto.getIsHeadOffice());
        
        if (dto.getCountryId() != null) {
            Country country = countryRepository.findById(dto.getCountryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Country not found"));
            entity.setCountry(country);
        }
        
        if (dto.getIsActive() != null) {
            entity.setActive(dto.getIsActive());
        }
    }

    private BranchDto toDto(Branch entity) {
        return BranchDto.builder()
                .id(entity.getId())
                .organizationId(entity.getOrganization() != null ? entity.getOrganization().getId() : null)
                .name(entity.getName())
                .code(entity.getCode())
                .addressLine1(entity.getAddressLine1())
                .addressLine2(entity.getAddressLine2())
                .city(entity.getCity())
                .stateProvince(entity.getStateProvince())
                .postalCode(entity.getPostalCode())
                .countryId(entity.getCountry() != null ? entity.getCountry().getId() : null)
                .countryName(entity.getCountry() != null ? entity.getCountry().getName() : null)
                .phoneNumber(entity.getPhoneNumber())
                .email(entity.getEmail())
                .managerId(entity.getManagerId())
                .isActive(entity.isActive())
                .isHeadOffice(entity.isHeadquarters())
                .build();
    }
}
