package com.hrmoja.service;

import com.hrmoja.dto.payroll.PayrollComponentDto;
import com.hrmoja.entity.Organization;
import com.hrmoja.entity.PayrollComponent;
import com.hrmoja.entity.PayrollComponentType;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.repository.OrganizationRepository;
import com.hrmoja.repository.PayrollComponentRepository;
import com.hrmoja.repository.PayrollComponentTypeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Payroll Component Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollComponentService {

    private final PayrollComponentRepository componentRepository;
    private final PayrollComponentTypeRepository componentTypeRepository;
    private final OrganizationRepository organizationRepository;

    @Transactional
    public PayrollComponentDto createComponent(PayrollComponentDto dto) {
        Organization organization = organizationRepository.findById(dto.getOrganizationId())
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        PayrollComponentType componentType = componentTypeRepository.findById(dto.getComponentTypeId())
                .orElseThrow(() -> new ResourceNotFoundException("Component type not found"));

        if (componentRepository.existsByOrganizationIdAndCode(dto.getOrganizationId(), dto.getCode())) {
            throw new IllegalArgumentException("Component code already exists in this organization");
        }

        PayrollComponent component = PayrollComponent.builder()
                .organization(organization)
                .componentType(componentType)
                .name(dto.getName())
                .code(dto.getCode())
                .description(dto.getDescription())
                .calculationMethod(dto.getCalculationMethod())
                .calculationBasis(dto.getCalculationBasis())
                .fixedAmount(dto.getFixedAmount())
                .percentageValue(dto.getPercentageValue())
                .maxAmount(dto.getMaxAmount())
                .formula(dto.getFormula())
                .isTaxable(dto.isTaxable())
                .isPensionable(dto.isPensionable())
                .affectsGross(dto.isAffectsGross())
                .affectsNet(dto.isAffectsNet())
                .displayOnPayslip(dto.isDisplayOnPayslip())
                .priorityOrder(dto.getPriorityOrder() != null ? dto.getPriorityOrder() : 0)
                .isStatutory(dto.isStatutory())
                .isActive(true)
                .notes(dto.getNotes())
                .build();

        PayrollComponent saved = componentRepository.save(component);
        log.info("Payroll component created: {} for organization: {}", saved.getName(), organization.getName());

        return mapToDto(saved);
    }

    @Transactional(readOnly = true)
    public List<PayrollComponentDto> getComponentsByOrganization(Long organizationId) {
        return componentRepository.findByOrganizationId(organizationId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PayrollComponentDto> getActiveComponents(Long organizationId) {
        return componentRepository.findByOrganizationIdAndIsActiveTrue(organizationId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<PayrollComponentDto> getComponentsByCategory(Long organizationId, String category) {
        return componentRepository.findByOrganizationAndCategory(organizationId, category).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PayrollComponentDto getComponentById(Long id) {
        PayrollComponent component = componentRepository.findByIdWithType(id)
                .orElseThrow(() -> new ResourceNotFoundException("Component not found with id: " + id));
        return mapToDto(component);
    }

    @Transactional
    public PayrollComponentDto updateComponent(Long id, PayrollComponentDto dto) {
        PayrollComponent component = componentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Component not found with id: " + id));

        component.setName(dto.getName());
        component.setDescription(dto.getDescription());
        component.setCalculationMethod(dto.getCalculationMethod());
        component.setCalculationBasis(dto.getCalculationBasis());
        component.setFixedAmount(dto.getFixedAmount());
        component.setPercentageValue(dto.getPercentageValue());
        component.setMaxAmount(dto.getMaxAmount());
        component.setFormula(dto.getFormula());
        component.setTaxable(dto.isTaxable());
        component.setPensionable(dto.isPensionable());
        component.setAffectsGross(dto.isAffectsGross());
        component.setAffectsNet(dto.isAffectsNet());
        component.setDisplayOnPayslip(dto.isDisplayOnPayslip());
        component.setPriorityOrder(dto.getPriorityOrder());
        component.setActive(dto.isActive());
        component.setNotes(dto.getNotes());

        PayrollComponent updated = componentRepository.save(component);
        log.info("Payroll component updated: {}", updated.getName());

        return mapToDto(updated);
    }

    @Transactional
    public void deleteComponent(Long id) {
        PayrollComponent component = componentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Component not found with id: " + id));

        component.setActive(false);
        componentRepository.save(component);
        log.info("Payroll component deactivated: {}", component.getName());
    }

    private PayrollComponentDto mapToDto(PayrollComponent component) {
        return PayrollComponentDto.builder()
                .id(component.getId())
                .organizationId(component.getOrganization().getId())
                .componentTypeId(component.getComponentType().getId())
                .componentTypeName(component.getComponentType().getName())
                .calculationCategory(component.getComponentType().getCalculationCategory())
                .name(component.getName())
                .code(component.getCode())
                .description(component.getDescription())
                .calculationMethod(component.getCalculationMethod())
                .calculationBasis(component.getCalculationBasis())
                .fixedAmount(component.getFixedAmount())
                .percentageValue(component.getPercentageValue())
                .maxAmount(component.getMaxAmount())
                .formula(component.getFormula())
                .isTaxable(component.isTaxable())
                .isPensionable(component.isPensionable())
                .affectsGross(component.isAffectsGross())
                .affectsNet(component.isAffectsNet())
                .displayOnPayslip(component.isDisplayOnPayslip())
                .priorityOrder(component.getPriorityOrder())
                .isStatutory(component.isStatutory())
                .isActive(component.isActive())
                .notes(component.getNotes())
                .createdAt(component.getCreatedAt())
                .updatedAt(component.getUpdatedAt())
                .build();
    }
}
