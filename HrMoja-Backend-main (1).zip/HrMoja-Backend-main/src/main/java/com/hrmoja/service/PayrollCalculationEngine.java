package com.hrmoja.service;

import com.hrmoja.entity.*;
import com.hrmoja.repository.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Centralized Payroll Calculation Engine
 * 
 * Single source of truth for all payroll calculations.
 * Used by both process and recalculate operations to ensure consistency.
 */
@Service
@RequiredArgsConstructor
public class PayrollCalculationEngine {

    private static final Logger log = LoggerFactory.getLogger(PayrollCalculationEngine.class);

    private final EmployeeSalaryStructureRepository employeeSalaryStructureRepository;
    private final PayrollComponentRepository componentRepository;
    private final TaxCalculationService taxCalculationService;

    /**
     * Calculate complete payroll for an employee
     * Returns structured result with record and line items
     */
    public CalculatedPayroll calculatePayroll(Employee employee, PayrollPeriod period, 
                                              EmployeePayrollRecord existingRecord) {
        try {
            // Get employee salary structure
            Optional<EmployeeSalaryStructure> salaryOpt = 
                    employeeSalaryStructureRepository.findCurrentByEmployeeId(employee.getId());
            
            if (!salaryOpt.isPresent()) {
                return CalculatedPayroll.error(
                    "No active salary structure found for employee: " + employee.getEmployeeNumber()
                );
            }
            
            EmployeeSalaryStructure salary = salaryOpt.get();
            BigDecimal basicSalary = BigDecimal.valueOf(salary.getBasicSalary());

            // Initialize or update record
            EmployeePayrollRecord record = existingRecord != null ? existingRecord : new EmployeePayrollRecord();
            record.setEmployee(employee);
            record.setEmployeeName(employee.getFirstName() + " " + employee.getLastName());
            record.setEmployeeNumber(employee.getEmployeeNumber());
            record.setDepartmentName(employee.getDepartment() != null ? employee.getDepartment().getName() : null);
            record.setPositionTitle(employee.getJobTitle() != null ? employee.getJobTitle().getTitle() : "");
            record.setBasicSalary(basicSalary);

            // Get country code for tax calculations
            String countryCode = period.getOrganization().getCountry() != null 
                    ? period.getOrganization().getCountry().getCode() 
                    : "UGA";

            // Get all active payroll components
            List<PayrollComponent> components = componentRepository
                    .findByOrganizationIdAndIsActiveTrue(period.getOrganization().getId());

            // Calculate earnings
            BigDecimal totalEarnings = BigDecimal.ZERO;
            List<PayrollLineItem> earningItems = new ArrayList<>();
            
            for (PayrollComponent component : components) {
                if ("EARNING".equals(component.getComponentType().getCalculationCategory())) {
                    BigDecimal amount = calculateComponentAmount(component, basicSalary, BigDecimal.ZERO);
                    if (amount.compareTo(BigDecimal.ZERO) > 0) {
                        totalEarnings = totalEarnings.add(amount);
                        earningItems.add(createLineItem(component, amount, 0));
                    }
                }
            }

            // Gross salary = Basic + Earnings
            BigDecimal grossSalary = basicSalary.add(totalEarnings);
            record.setGrossSalary(grossSalary);
            record.setTotalEarnings(totalEarnings);
            record.setPensionableIncome(grossSalary);

            // Calculate statutory deductions
            BigDecimal nssfEmployee = taxCalculationService.calculateNSSFEmployee(grossSalary, countryCode);
            BigDecimal lst = taxCalculationService.calculateLST(countryCode);
            BigDecimal totalStatutory = nssfEmployee.add(lst);

            // Calculate taxable income
            BigDecimal taxableIncome = taxCalculationService.calculateTaxableIncome(grossSalary, nssfEmployee, lst);
            record.setTaxableIncome(taxableIncome);

            // Calculate PAYE
            BigDecimal paye = taxCalculationService.calculatePAYE(taxableIncome, 
                    period.getOrganization().getId(), countryCode);
            BigDecimal totalTaxes = paye;

            // Calculate voluntary deductions
            BigDecimal totalVoluntaryDeductions = BigDecimal.ZERO;
            List<PayrollLineItem> deductionItems = new ArrayList<>();
            
            for (PayrollComponent component : components) {
                if ("DEDUCTION".equals(component.getComponentType().getCalculationCategory())) {
                    BigDecimal amount = calculateComponentAmount(component, basicSalary, grossSalary);
                    if (amount.compareTo(BigDecimal.ZERO) > 0) {
                        totalVoluntaryDeductions = totalVoluntaryDeductions.add(amount);
                        deductionItems.add(createLineItem(component, amount, 30));
                    }
                }
            }

            // Calculate totals
            BigDecimal allDeductions = totalStatutory.add(totalTaxes).add(totalVoluntaryDeductions);
            BigDecimal netSalary = grossSalary.subtract(allDeductions);

            record.setTotalStatutory(totalStatutory);
            record.setTotalTaxes(totalTaxes);
            record.setTotalDeductions(allDeductions);
            record.setNetSalary(netSalary);
            record.setStatus("CALCULATED");
            record.setSkipped(false);
            record.setCalculationErrors(null);

            // Build line items list
            List<PayrollLineItem> allLineItems = new ArrayList<>();
            allLineItems.addAll(earningItems);
            
            // Statutory line items
            allLineItems.add(createStatutoryLineItem("NSSF Employee", "NSSF_EMP", nssfEmployee, 20));
            if (lst.compareTo(BigDecimal.ZERO) > 0) {
                allLineItems.add(createStatutoryLineItem("Local Service Tax", "LST", lst, 23));
            }
            allLineItems.add(createStatutoryLineItem("PAYE Tax", "PAYE", paye, 22));
            
            // Voluntary deductions
            allLineItems.addAll(deductionItems);

            return CalculatedPayroll.success(record, allLineItems);

        } catch (Exception e) {
            log.error("Error calculating payroll for employee {}: {}", 
                    employee.getEmployeeNumber(), e.getMessage(), e);
            return CalculatedPayroll.error("Calculation failed: " + e.getMessage());
        }
    }

    /**
     * Calculate component amount based on calculation method
     */
    private BigDecimal calculateComponentAmount(PayrollComponent component, 
                                               BigDecimal basicSalary, 
                                               BigDecimal grossSalary) {
        String method = component.getCalculationMethod();
        
        if ("FIXED".equals(method)) {
            return component.getFixedAmount() != null ? component.getFixedAmount() : BigDecimal.ZERO;
        }
        
        if ("PERCENTAGE".equals(method)) {
            BigDecimal basis = getBasisAmount(component.getCalculationBasis(), basicSalary, grossSalary);
            BigDecimal percentage = component.getPercentageValue() != null ? 
                    component.getPercentageValue() : BigDecimal.ZERO;
            BigDecimal amount = basis.multiply(percentage).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            
            // Apply max amount if specified
            if (component.getMaxAmount() != null && component.getMaxAmount().compareTo(BigDecimal.ZERO) > 0) {
                amount = amount.min(component.getMaxAmount());
            }
            return amount;
        }
        
        return BigDecimal.ZERO;
    }
    
    private BigDecimal getBasisAmount(String basis, BigDecimal basicSalary, BigDecimal grossSalary) {
        if ("BASIC_SALARY".equals(basis)) {
            return basicSalary;
        }
        if ("GROSS_SALARY".equals(basis)) {
            return grossSalary;
        }
        return basicSalary;
    }
    
    /**
     * Create payroll line item from component
     */
    private PayrollLineItem createLineItem(PayrollComponent component, BigDecimal amount, int baseDisplayOrder) {
        return PayrollLineItem.builder()
                .component(component)
                .componentName(component.getName())
                .componentCode(component.getCode())
                .componentCategory(component.getComponentType().getCalculationCategory())
                .calculationMethod(component.getCalculationMethod())
                .calculationBasis(component.getCalculationBasis())
                .rateOrAmount(component.getPercentageValue() != null ? 
                        component.getPercentageValue() : component.getFixedAmount())
                .quantity(BigDecimal.ONE)
                .amount(amount)
                .isTaxable(component.isTaxable())
                .isPensionable(component.isPensionable())
                .isStatutory(component.isStatutory())
                .displayOrder(baseDisplayOrder + component.getPriorityOrder())
                .build();
    }
    
    /**
     * Create statutory line item (NSSF, PAYE, LST)
     */
    private PayrollLineItem createStatutoryLineItem(String name, String code, 
                                                    BigDecimal amount, int displayOrder) {
        return PayrollLineItem.builder()
                .component(null)
                .componentName(name)
                .componentCode(code)
                .componentCategory("STATUTORY")
                .calculationMethod("FORMULA")
                .amount(amount)
                .quantity(BigDecimal.ONE)
                .isTaxable(false)
                .isPensionable(false)
                .isStatutory(true)
                .displayOrder(displayOrder)
                .build();
    }

    /**
     * Result class for calculated payroll
     */
    public static class CalculatedPayroll {
        private final boolean success;
        private final EmployeePayrollRecord record;
        private final List<PayrollLineItem> lineItems;
        private final String errorMessage;

        private CalculatedPayroll(boolean success, EmployeePayrollRecord record, 
                                 List<PayrollLineItem> lineItems, String errorMessage) {
            this.success = success;
            this.record = record;
            this.lineItems = lineItems;
            this.errorMessage = errorMessage;
        }

        public static CalculatedPayroll success(EmployeePayrollRecord record, List<PayrollLineItem> lineItems) {
            return new CalculatedPayroll(true, record, lineItems, null);
        }

        public static CalculatedPayroll error(String errorMessage) {
            return new CalculatedPayroll(false, null, null, errorMessage);
        }

        public boolean isSuccess() { return success; }
        public EmployeePayrollRecord getRecord() { return record; }
        public List<PayrollLineItem> getLineItems() { return lineItems; }
        public String getErrorMessage() { return errorMessage; }
    }
}
