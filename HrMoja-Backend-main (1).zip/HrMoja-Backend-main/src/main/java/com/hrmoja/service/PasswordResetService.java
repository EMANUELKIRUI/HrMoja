package com.hrmoja.service;

import com.hrmoja.dto.auth.ForgotPasswordRequest;
import com.hrmoja.dto.auth.ResetPasswordRequest;
import com.hrmoja.entity.User;
import com.hrmoja.exception.ResourceNotFoundException;
import com.hrmoja.exception.ValidationException;
import com.hrmoja.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Password Reset Service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PasswordResetService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    // TODO: Inject EmailService when available for sending reset emails
    
    private static final int TOKEN_EXPIRY_HOURS = 24;

    @Transactional
    public void initiatePasswordReset(ForgotPasswordRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("No account found with that email address"));

        // Check if account is active
        if (!user.isActive() || user.isLocked()) {
            throw new ValidationException("Your account is inactive or locked. Please contact your administrator.");
        }

        // Generate reset token
        String resetToken = UUID.randomUUID().toString();
        
        // Set token and expiry
        user.setPasswordResetToken(resetToken);
        user.setPasswordResetExpiry(LocalDateTime.now().plusHours(TOKEN_EXPIRY_HOURS));
        
        userRepository.save(user);
        
        // TODO: Send email with reset link
        // For now, log the token (ONLY FOR DEVELOPMENT - REMOVE IN PRODUCTION)
        log.warn("Password reset token for {}: {}", user.getEmail(), resetToken);
        log.info("Password reset link: http://localhost:5173/reset-password?token={}", resetToken);
        
        // In production, send email like:
        // String resetLink = "http://yourdomain.com/reset-password?token=" + resetToken;
        // emailService.sendPasswordResetEmail(user.getEmail(), resetLink);
    }

    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        // Validate password match
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new ValidationException("Passwords do not match");
        }

        // Find user by token
        User user = userRepository.findByPasswordResetToken(request.getToken())
                .orElseThrow(() -> new ValidationException("Invalid or expired reset token"));

        // Check if account is active
        if (!user.isActive() || user.isLocked()) {
            throw new ValidationException("Your account is inactive or locked. Please contact your administrator.");
        }

        // Check if token is expired
        if (user.getPasswordResetExpiry() == null || 
            user.getPasswordResetExpiry().isBefore(LocalDateTime.now())) {
            throw new ValidationException("Password reset token has expired");
        }

        // Reset password
        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        user.setPasswordResetToken(null);
        user.setPasswordResetExpiry(null);
        user.setMustChangePassword(false);
        user.setFailedLoginAttempts(0);
        
        // Unlock account if it was locked due to failed attempts
        if (user.isLocked() && user.getLockedUntil() != null && 
            user.getLockedUntil().isBefore(LocalDateTime.now())) {
            user.setLocked(false);
            user.setLockedUntil(null);
        }
        
        userRepository.save(user);
        
        log.info("Password reset successfully for user: {}", user.getUsername());
    }

    @Transactional(readOnly = true)
    public boolean validateResetToken(String token) {
        return userRepository.findByPasswordResetToken(token)
                .map(user -> user.getPasswordResetExpiry() != null && 
                            user.getPasswordResetExpiry().isAfter(LocalDateTime.now()))
                .orElse(false);
    }
}
