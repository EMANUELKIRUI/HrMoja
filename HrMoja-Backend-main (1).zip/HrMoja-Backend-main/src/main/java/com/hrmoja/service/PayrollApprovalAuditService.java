package com.hrmoja.service;

import com.hrmoja.entity.PayrollApprovalAudit;
import com.hrmoja.entity.PayrollPeriod;
import com.hrmoja.repository.PayrollApprovalAuditRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for managing payroll approval audit trail
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollApprovalAuditService {

    private final PayrollApprovalAuditRepository auditRepository;

    @Transactional
    public void logApprovalAction(PayrollPeriod period, String action, String approvalLevel, 
                                  Long userId, String userName, String comments) {
        PayrollApprovalAudit audit = PayrollApprovalAudit.builder()
                .payrollPeriodId(period.getId())
                .action(action)
                .approvalLevel(approvalLevel)
                .performedBy(userId)
                .performedByName(userName)
                .performedAt(LocalDateTime.now())
                .previousStatus(period.getStatus())
                .comments(comments)
                .build();
        
        auditRepository.save(audit);
        log.info("Audit logged: {} by user {} for period {}", action, userId, period.getId());
    }

    @Transactional
    public void logStatusChange(PayrollPeriod period, String action, String approvalLevel,
                                Long userId, String userName, String previousStatus, 
                                String newStatus, String comments) {
        PayrollApprovalAudit audit = PayrollApprovalAudit.builder()
                .payrollPeriodId(period.getId())
                .action(action)
                .approvalLevel(approvalLevel)
                .performedBy(userId)
                .performedByName(userName)
                .performedAt(LocalDateTime.now())
                .previousStatus(previousStatus)
                .newStatus(newStatus)
                .comments(comments)
                .build();
        
        auditRepository.save(audit);
        log.info("Status change logged: {} -> {} by user {} for period {}", 
                previousStatus, newStatus, userId, period.getId());
    }

    @Transactional
    public void logRejection(Long periodId, String approvalLevel, Long userId, 
                            String userName, String previousStatus, String newStatus, String reason) {
        PayrollApprovalAudit audit = PayrollApprovalAudit.builder()
                .payrollPeriodId(periodId)
                .action("REJECTED")
                .approvalLevel(approvalLevel)
                .performedBy(userId)
                .performedByName(userName)
                .performedAt(LocalDateTime.now())
                .previousStatus(previousStatus)
                .newStatus(newStatus)
                .rejectionReason(reason)
                .build();
        
        auditRepository.save(audit);
        log.info("Rejection logged by user {} for period {}: {} ({} -> {})", 
                userId, periodId, reason, previousStatus, newStatus);
    }

    public List<PayrollApprovalAudit> getAuditTrail(Long periodId) {
        return auditRepository.getAuditTrail(periodId);
    }

    public List<PayrollApprovalAudit> getAuditByLevel(Long periodId, String approvalLevel) {
        return auditRepository.findByPayrollPeriodIdAndApprovalLevel(periodId, approvalLevel);
    }
}
