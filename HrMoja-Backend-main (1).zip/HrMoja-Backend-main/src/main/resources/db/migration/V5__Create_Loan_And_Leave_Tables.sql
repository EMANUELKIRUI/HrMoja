-- =====================================================
-- LOANS, ADVANCES, AND LEAVE TABLES
-- Version: 1.0
-- =====================================================

-- Employee Loans Table
CREATE TABLE employee_loans (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    loan_type VARCHAR(50) NOT NULL,
    loan_number VARCHAR(100) UNIQUE NOT NULL,
    principal_amount DECIMAL(15, 2) NOT NULL,
    interest_rate DECIMAL(5, 2) DEFAULT 0,
    total_amount DECIMAL(15, 2) NOT NULL,
    installment_amount DECIMAL(15, 2) NOT NULL,
    number_of_installments INTEGER NOT NULL,
    installments_paid INTEGER DEFAULT 0,
    outstanding_balance DECIMAL(15, 2) NOT NULL,
    start_date DATE NOT NULL,
    first_deduction_date DATE NOT NULL,
    completion_date DATE,
    status VARCHAR(30) DEFAULT 'ACTIVE',
    purpose TEXT,
    approved_by BIGINT,
    approved_at TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_loans_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_loans_approved_by FOREIGN KEY (approved_by) REFERENCES users(id)
);

CREATE INDEX idx_loans_employee ON employee_loans(employee_id);
CREATE INDEX idx_loans_status ON employee_loans(status);

-- Loan Repayment Schedule Table
CREATE TABLE loan_repayment_schedule (
    id BIGSERIAL PRIMARY KEY,
    loan_id BIGINT NOT NULL,
    installment_number INTEGER NOT NULL,
    due_date DATE NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    paid_amount DECIMAL(15, 2) DEFAULT 0,
    payment_status VARCHAR(30) DEFAULT 'PENDING',
    payroll_period_id BIGINT,
    paid_date DATE,
    
    CONSTRAINT fk_repayment_loan FOREIGN KEY (loan_id) REFERENCES employee_loans(id) ON DELETE CASCADE,
    CONSTRAINT fk_repayment_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id)
);

CREATE INDEX idx_repayment_loan ON loan_repayment_schedule(loan_id);

-- Salary Advances Table
CREATE TABLE salary_advances (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    advance_number VARCHAR(100) UNIQUE NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    reason TEXT,
    request_date DATE NOT NULL,
    approved_by BIGINT,
    approved_at TIMESTAMP,
    recovery_date DATE,
    recovery_status VARCHAR(30) DEFAULT 'PENDING',
    status VARCHAR(30) DEFAULT 'REQUESTED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_advances_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_advances_approved_by FOREIGN KEY (approved_by) REFERENCES users(id)
);

CREATE INDEX idx_advances_employee ON salary_advances(employee_id);

-- Leave Types Table
CREATE TABLE leave_types (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) NOT NULL,
    default_days_per_year DECIMAL(5, 2),
    is_paid BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_leave_types_organization FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

CREATE INDEX idx_leave_types_organization ON leave_types(organization_id);

-- Leave Applications Table
CREATE TABLE leave_applications (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    leave_type_id BIGINT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    number_of_days DECIMAL(5, 2) NOT NULL,
    reason TEXT,
    status VARCHAR(30) DEFAULT 'PENDING',
    approved_by BIGINT,
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_leave_app_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_leave_app_type FOREIGN KEY (leave_type_id) REFERENCES leave_types(id),
    CONSTRAINT fk_leave_app_approved_by FOREIGN KEY (approved_by) REFERENCES users(id)
);

CREATE INDEX idx_leave_app_employee ON leave_applications(employee_id);
