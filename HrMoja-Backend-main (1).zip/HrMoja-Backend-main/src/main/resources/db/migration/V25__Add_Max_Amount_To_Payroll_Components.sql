-- Add max_amount column for contribution ceilings (e.g., NSSF)
ALTER TABLE payroll_components ADD COLUMN IF NOT EXISTS max_amount DECIMAL(15, 2);

COMMENT ON COLUMN payroll_components.max_amount IS 'Maximum amount cap for percentage-based calculations (e.g., NSSF ceiling)';
