-- Payment Audit Log - Track all payment-related actions
-- Complete audit trail for payment authorization, execution, confirmation, and failures

CREATE TABLE payment_audit_log (
    id BIGSERIAL PRIMARY KEY,
    payroll_payment_id BIGINT,
    employee_payment_record_id BIGINT,
    
    -- Audit Details
    action VARCHAR(50) NOT NULL, -- AUTHORIZED, EXECUTED, CONFIRMED, FAILED, REVERSED, RETRY, FILE_GENERATED
    performed_by BIGINT NOT NULL,
    performed_by_name VARCHAR(200),
    performed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Action Details
    previous_status VARCHAR(30),
    new_status VARCHAR(30),
    action_details TEXT,
    
    -- System Info
    ip_address VARCHAR(45),
    user_agent TEXT,
    
    CONSTRAINT fk_payment_audit_payment FOREIGN KEY (payroll_payment_id) REFERENCES payroll_payments(id),
    CONSTRAINT fk_payment_audit_emp_payment FOREIGN KEY (employee_payment_record_id) REFERENCES employee_payment_records(id),
    CONSTRAINT fk_payment_audit_user FOREIGN KEY (performed_by) REFERENCES users(id)
);

-- Indexes for Performance
CREATE INDEX idx_payment_audit_payment ON payment_audit_log(payroll_payment_id);
CREATE INDEX idx_payment_audit_emp_payment ON payment_audit_log(employee_payment_record_id);
CREATE INDEX idx_payment_audit_performed_at ON payment_audit_log(performed_at DESC);

-- Comments
COMMENT ON TABLE payment_audit_log IS 'Audit trail for all payment actions';
