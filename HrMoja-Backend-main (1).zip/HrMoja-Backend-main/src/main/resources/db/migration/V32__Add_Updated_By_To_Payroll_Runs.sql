-- Add missing updated_by column to payroll_runs table
-- This field is expected by BaseEntity but was missing from V29 migration

ALTER TABLE payroll_runs
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

COMMENT ON COLUMN payroll_runs.updated_by IS 'User ID who last updated this payroll run record';
