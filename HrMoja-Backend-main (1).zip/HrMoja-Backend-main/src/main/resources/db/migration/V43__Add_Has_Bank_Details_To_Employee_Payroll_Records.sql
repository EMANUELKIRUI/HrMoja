-- Add hasBankDetails column to employee_payroll_records table
-- This tracks whether the employee has valid bank details for payroll payment

ALTER TABLE employee_payroll_records
ADD COLUMN has_bank_details BOOLEAN DEFAULT FALSE;

-- Update existing records to set hasBankDetails based on employee_bank_details table
UPDATE employee_payroll_records epr
SET has_bank_details = EXISTS (
    SELECT 1 
    FROM employee_bank_details ebd 
    WHERE ebd.employee_id = epr.employee_id 
    AND ebd.is_active = TRUE 
    AND ebd.is_primary = TRUE
);

-- Add index for performance
CREATE INDEX idx_employee_payroll_records_has_bank_details ON employee_payroll_records(has_bank_details);
