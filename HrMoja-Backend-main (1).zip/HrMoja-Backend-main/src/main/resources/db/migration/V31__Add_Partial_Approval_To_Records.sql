-- Add partial approval tracking to employee_payroll_records
-- Allows Level 1 users to approve records individually

ALTER TABLE employee_payroll_records
    ADD COLUMN approved_level1 BOOLEAN DEFAULT FALSE,
    ADD COLUMN level1_approved_by BIGINT,
    ADD COLUMN level1_approved_at TIMESTAMP,
    ADD COLUMN rejected BOOLEAN DEFAULT FALSE,
    ADD COLUMN rejection_reason TEXT,
    ADD COLUMN rejected_by BIGINT,
    ADD COLUMN rejected_at TIMESTAMP;

-- Add partial approval tracking to payroll_periods
ALTER TABLE payroll_periods
    ADD COLUMN total_approved_level1 INTEGER DEFAULT 0,
    ADD COLUMN total_rejected INTEGER DEFAULT 0,
    ADD COLUMN is_partially_approved BOOLEAN DEFAULT FALSE;

-- Add foreign keys
ALTER TABLE employee_payroll_records
    ADD CONSTRAINT fk_record_level1_approved_by FOREIGN KEY (level1_approved_by) REFERENCES users(id),
    ADD CONSTRAINT fk_record_rejected_by FOREIGN KEY (rejected_by) REFERENCES users(id);

-- Add comments
COMMENT ON COLUMN employee_payroll_records.approved_level1 IS 'Individual record approved at Level 1 (PREPARED stage)';
COMMENT ON COLUMN employee_payroll_records.rejected IS 'Soft delete - record excluded from payroll with reason';
COMMENT ON COLUMN employee_payroll_records.rejection_reason IS 'Reason for excluding this employee from payroll';
COMMENT ON COLUMN payroll_periods.is_partially_approved IS 'True when some but not all records are approved at Level 1';
COMMENT ON COLUMN payroll_periods.total_approved_level1 IS 'Count of records approved at Level 1';
COMMENT ON COLUMN payroll_periods.total_rejected IS 'Count of records rejected/excluded';
