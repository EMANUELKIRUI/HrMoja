-- =====================================================
-- Tax Configuration Tables for Multi-Country Support
-- Supports progressive tax brackets, reliefs, and country-specific rules
-- =====================================================

-- Tax Configuration Master (per country/organization)
CREATE TABLE IF NOT EXISTS payroll_tax_configurations (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    country_code VARCHAR(3) NOT NULL, -- UG, KE, etc.
    tax_year INTEGER NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    is_active BOOLEAN DEFAULT TRUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_by BIGINT,
    UNIQUE(organization_id, country_code, tax_year, effective_from)
);

-- Progressive Tax Brackets (PAYE bands)
CREATE TABLE IF NOT EXISTS payroll_tax_brackets (
    id BIGSERIAL PRIMARY KEY,
    tax_configuration_id BIGINT NOT NULL REFERENCES payroll_tax_configurations(id) ON DELETE CASCADE,
    bracket_number INTEGER NOT NULL,
    min_income DECIMAL(15, 2) NOT NULL,
    max_income DECIMAL(15, 2),
    tax_rate DECIMAL(5, 2) NOT NULL,
    fixed_amount DECIMAL(15, 2) DEFAULT 0,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_income_range CHECK (max_income IS NULL OR max_income > min_income)
);

-- Tax Reliefs/Exemptions (Kenya: Personal, Insurance, Pension, etc.)
CREATE TABLE IF NOT EXISTS payroll_tax_reliefs (
    id BIGSERIAL PRIMARY KEY,
    tax_configuration_id BIGINT NOT NULL REFERENCES payroll_tax_configurations(id) ON DELETE CASCADE,
    relief_code VARCHAR(50) NOT NULL,
    relief_name VARCHAR(200) NOT NULL,
    relief_type VARCHAR(50) NOT NULL, -- FIXED, PERCENTAGE, FORMULA
    fixed_amount DECIMAL(15, 2),
    percentage_value DECIMAL(5, 2),
    max_amount DECIMAL(15, 2),
    calculation_basis VARCHAR(50), -- GROSS, TAXABLE, CONTRIBUTION
    formula TEXT,
    is_mandatory BOOLEAN DEFAULT FALSE,
    applies_to VARCHAR(50) DEFAULT 'ALL', -- ALL, RESIDENT, NON_RESIDENT
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Employee-specific relief claims (optional reliefs like mortgage, insurance)
CREATE TABLE IF NOT EXISTS employee_relief_claims (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL REFERENCES employees(id),
    tax_relief_id BIGINT NOT NULL REFERENCES payroll_tax_reliefs(id),
    claimed_amount DECIMAL(15, 2),
    supporting_document VARCHAR(500),
    effective_from DATE NOT NULL,
    effective_to DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(employee_id, tax_relief_id, effective_from)
);

-- Statutory contribution ceilings (NSSF, SHIF, etc.)
CREATE TABLE IF NOT EXISTS payroll_statutory_ceilings (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL REFERENCES organizations(id),
    country_code VARCHAR(3) NOT NULL,
    contribution_type VARCHAR(100) NOT NULL, -- NSSF, SHIF, AHL, etc.
    ceiling_amount DECIMAL(15, 2),
    pensionable_ceiling DECIMAL(15, 2),
    tier_structure JSONB, -- For multi-tier systems like Kenya NSSF
    effective_from DATE NOT NULL,
    effective_to DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_payroll_tax_config_org_country ON payroll_tax_configurations(organization_id, country_code, is_active);
CREATE INDEX IF NOT EXISTS idx_payroll_tax_brackets_config ON payroll_tax_brackets(tax_configuration_id, bracket_number);
CREATE INDEX IF NOT EXISTS idx_payroll_tax_reliefs_config ON payroll_tax_reliefs(tax_configuration_id, relief_code);
CREATE INDEX IF NOT EXISTS idx_employee_reliefs ON employee_relief_claims(employee_id, is_active);
CREATE INDEX IF NOT EXISTS idx_payroll_statutory_ceilings_country ON payroll_statutory_ceilings(country_code, contribution_type, is_active);

-- Comments
COMMENT ON TABLE payroll_tax_configurations IS 'Master table for country-specific tax configurations';
COMMENT ON TABLE payroll_tax_brackets IS 'Progressive tax brackets (PAYE bands) for each tax configuration';
COMMENT ON TABLE payroll_tax_reliefs IS 'Tax reliefs and exemptions (Kenya: Personal, Insurance, Pension, Mortgage, etc.)';
COMMENT ON TABLE employee_relief_claims IS 'Employee-specific relief claims for optional reliefs';
COMMENT ON TABLE payroll_statutory_ceilings IS 'Statutory contribution ceilings (NSSF, SHIF, etc.) by country';
