-- Convert JSONB columns to TEXT in audit_logs table
ALTER TABLE audit_logs 
ALTER COLUMN old_values TYPE TEXT,
ALTER COLUMN new_values TYPE TEXT;

COMMENT ON COLUMN audit_logs.old_values IS 'Previous values of the entity (JSON format)';
COMMENT ON COLUMN audit_logs.new_values IS 'New values of the entity (JSON format)';
