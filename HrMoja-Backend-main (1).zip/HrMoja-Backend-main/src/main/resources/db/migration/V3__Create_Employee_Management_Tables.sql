-- =====================================================
-- EMPLOYEE MANAGEMENT MODULE - TABLES
-- Version: 1.0
-- Description: Employee records, contracts, and related data
-- =====================================================

-- Employees Table (Master Data)
CREATE TABLE employees (
    id BIGSERIAL PRIMARY KEY,
    employee_number VARCHAR(50) UNIQUE NOT NULL,
    organization_id BIGINT NOT NULL,
    branch_id BIGINT,
    department_id BIGINT,
    
    -- Personal Information
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(20),
    marital_status VARCHAR(20),
    nationality VARCHAR(100),
    national_id VARCHAR(100),
    passport_number VARCHAR(100),
    
    -- Contact Information
    personal_email VARCHAR(255),
    work_email VARCHAR(255),
    mobile_phone VARCHAR(20),
    home_phone VARCHAR(20),
    emergency_contact_name VARCHAR(255),
    emergency_contact_phone VARCHAR(20),
    emergency_contact_relationship VARCHAR(50),
    
    -- Address Information
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(100),
    state_province VARCHAR(100),
    postal_code VARCHAR(20),
    country_id BIGINT,
    
    -- Employment Information
    hire_date DATE NOT NULL,
    confirmation_date DATE,
    probation_end_date DATE,
    termination_date DATE,
    termination_reason TEXT,
    employment_type_id BIGINT,
    job_title_id BIGINT,
    employee_grade_id BIGINT,
    reports_to_employee_id BIGINT,
    
    -- Status
    employment_status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    is_active BOOLEAN DEFAULT TRUE,
    
    -- Profile
    photo_url VARCHAR(500),
    bio TEXT,
    
    -- System Fields
    user_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_by BIGINT,
    
    CONSTRAINT fk_employees_organization FOREIGN KEY (organization_id) REFERENCES organizations(id),
    CONSTRAINT fk_employees_branch FOREIGN KEY (branch_id) REFERENCES branches(id),
    CONSTRAINT fk_employees_department FOREIGN KEY (department_id) REFERENCES departments(id),
    CONSTRAINT fk_employees_country FOREIGN KEY (country_id) REFERENCES countries(id),
    CONSTRAINT fk_employees_employment_type FOREIGN KEY (employment_type_id) REFERENCES employment_types(id),
    CONSTRAINT fk_employees_job_title FOREIGN KEY (job_title_id) REFERENCES job_titles(id),
    CONSTRAINT fk_employees_grade FOREIGN KEY (employee_grade_id) REFERENCES employee_grades(id),
    CONSTRAINT fk_employees_reports_to FOREIGN KEY (reports_to_employee_id) REFERENCES employees(id),
    CONSTRAINT fk_employees_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_employees_created_by FOREIGN KEY (created_by) REFERENCES users(id),
    CONSTRAINT fk_employees_updated_by FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE INDEX idx_employees_number ON employees(employee_number);
CREATE INDEX idx_employees_organization ON employees(organization_id);
CREATE INDEX idx_employees_branch ON employees(branch_id);
CREATE INDEX idx_employees_department ON employees(department_id);
CREATE INDEX idx_employees_reports_to ON employees(reports_to_employee_id);
CREATE INDEX idx_employees_status ON employees(employment_status);
CREATE INDEX idx_employees_active ON employees(is_active);
CREATE INDEX idx_employees_hire_date ON employees(hire_date);

-- Employee Statutory Details Table (Country-specific)
CREATE TABLE employee_statutory_details (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    country_id BIGINT NOT NULL,
    
    -- Tax Information
    tax_identification_number VARCHAR(100),
    tax_exemption_certificate VARCHAR(100),
    
    -- Social Security (NSSF, NAPSA, etc.)
    social_security_number VARCHAR(100),
    social_security_start_date DATE,
    
    -- Health Insurance (NHIF, NHIMA, etc.)
    health_insurance_number VARCHAR(100),
    health_insurance_start_date DATE,
    
    -- Other Statutory Numbers
    pension_fund_number VARCHAR(100),
    housing_fund_number VARCHAR(100),
    
    -- Additional Fields (JSONB for flexibility)
    additional_details JSONB,
    
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_emp_statutory_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_emp_statutory_country FOREIGN KEY (country_id) REFERENCES countries(id),
    CONSTRAINT uk_employee_country_statutory UNIQUE (employee_id, country_id)
);

CREATE INDEX idx_emp_statutory_employee ON employee_statutory_details(employee_id);
CREATE INDEX idx_emp_statutory_country ON employee_statutory_details(country_id);

-- Employee Bank Details Table
CREATE TABLE employee_bank_details (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    bank_id BIGINT NOT NULL,
    bank_branch_id BIGINT,
    account_number VARCHAR(100) NOT NULL,
    account_name VARCHAR(255) NOT NULL,
    account_type VARCHAR(50),
    swift_code VARCHAR(20),
    iban VARCHAR(50),
    is_primary BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_emp_bank_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_emp_bank_bank FOREIGN KEY (bank_id) REFERENCES banks(id),
    CONSTRAINT fk_emp_bank_branch FOREIGN KEY (bank_branch_id) REFERENCES bank_branches(id)
);

CREATE INDEX idx_emp_bank_employee ON employee_bank_details(employee_id);
CREATE INDEX idx_emp_bank_primary ON employee_bank_details(is_primary);

-- Employee Contracts Table
CREATE TABLE employee_contracts (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    contract_type VARCHAR(50) NOT NULL,
    contract_number VARCHAR(100) UNIQUE,
    start_date DATE NOT NULL,
    end_date DATE,
    is_renewable BOOLEAN DEFAULT FALSE,
    notice_period_days INTEGER,
    contract_document_url VARCHAR(500),
    terms_and_conditions TEXT,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    signed_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    
    CONSTRAINT fk_contracts_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_contracts_created_by FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE INDEX idx_contracts_employee ON employee_contracts(employee_id);
CREATE INDEX idx_contracts_status ON employee_contracts(status);
CREATE INDEX idx_contracts_dates ON employee_contracts(start_date, end_date);

-- Employee Salary Structure Table
CREATE TABLE employee_salary_structures (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE,
    basic_salary DECIMAL(15, 2) NOT NULL,
    currency_code VARCHAR(3) NOT NULL,
    pay_frequency_id BIGINT NOT NULL,
    payment_method_id BIGINT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by BIGINT,
    approved_at TIMESTAMP,
    
    CONSTRAINT fk_salary_structure_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_salary_structure_frequency FOREIGN KEY (pay_frequency_id) REFERENCES pay_frequencies(id),
    CONSTRAINT fk_salary_structure_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id),
    CONSTRAINT fk_salary_structure_approved_by FOREIGN KEY (approved_by) REFERENCES users(id)
);

CREATE INDEX idx_salary_structure_employee ON employee_salary_structures(employee_id);
CREATE INDEX idx_salary_structure_effective_date ON employee_salary_structures(effective_date);
CREATE INDEX idx_salary_structure_active ON employee_salary_structures(is_active);

-- Employee Documents Table
CREATE TABLE employee_documents (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    document_type VARCHAR(100) NOT NULL,
    document_name VARCHAR(255) NOT NULL,
    document_number VARCHAR(100),
    file_url VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size BIGINT,
    issue_date DATE,
    expiry_date DATE,
    description TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by BIGINT,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    uploaded_by BIGINT,
    
    CONSTRAINT fk_documents_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_documents_verified_by FOREIGN KEY (verified_by) REFERENCES users(id),
    CONSTRAINT fk_documents_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

CREATE INDEX idx_documents_employee ON employee_documents(employee_id);
CREATE INDEX idx_documents_type ON employee_documents(document_type);
CREATE INDEX idx_documents_expiry ON employee_documents(expiry_date);

-- Employee Dependents Table
CREATE TABLE employee_dependents (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100),
    last_name VARCHAR(100) NOT NULL,
    relationship VARCHAR(50) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(20),
    national_id VARCHAR(100),
    is_beneficiary BOOLEAN DEFAULT FALSE,
    beneficiary_percentage DECIMAL(5, 2),
    phone_number VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_dependents_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE INDEX idx_dependents_employee ON employee_dependents(employee_id);
CREATE INDEX idx_dependents_beneficiary ON employee_dependents(is_beneficiary);

-- Employee Education Table
CREATE TABLE employee_education (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    institution_name VARCHAR(255) NOT NULL,
    degree_certificate VARCHAR(100) NOT NULL,
    field_of_study VARCHAR(255),
    start_date DATE,
    end_date DATE,
    grade_gpa VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_education_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE INDEX idx_education_employee ON employee_education(employee_id);

-- Employee Work Experience Table
CREATE TABLE employee_work_experience (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    job_title VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    is_current BOOLEAN DEFAULT FALSE,
    responsibilities TEXT,
    reason_for_leaving TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_work_experience_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE INDEX idx_work_experience_employee ON employee_work_experience(employee_id);

-- Employee Skills Table
CREATE TABLE employee_skills (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    skill_name VARCHAR(100) NOT NULL,
    proficiency_level VARCHAR(50),
    years_of_experience INTEGER,
    last_used_date DATE,
    is_certified BOOLEAN DEFAULT FALSE,
    certification_name VARCHAR(255),
    certification_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_skills_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE INDEX idx_skills_employee ON employee_skills(employee_id);

-- Employee History/Audit Table
CREATE TABLE employee_history (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    change_type VARCHAR(50) NOT NULL,
    field_name VARCHAR(100),
    old_value TEXT,
    new_value TEXT,
    effective_date DATE,
    reason TEXT,
    changed_by BIGINT,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_emp_history_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_emp_history_changed_by FOREIGN KEY (changed_by) REFERENCES users(id)
);

CREATE INDEX idx_emp_history_employee ON employee_history(employee_id);
CREATE INDEX idx_emp_history_change_type ON employee_history(change_type);
CREATE INDEX idx_emp_history_date ON employee_history(effective_date);

COMMENT ON TABLE employees IS 'Employee master data with personal and employment information';
COMMENT ON TABLE employee_statutory_details IS 'Country-specific statutory information (TIN, NSSF, NHIF, etc.)';
COMMENT ON TABLE employee_bank_details IS 'Employee banking information for salary disbursement';
COMMENT ON TABLE employee_contracts IS 'Employment contracts and terms';
COMMENT ON TABLE employee_salary_structures IS 'Employee salary history and current structure';
