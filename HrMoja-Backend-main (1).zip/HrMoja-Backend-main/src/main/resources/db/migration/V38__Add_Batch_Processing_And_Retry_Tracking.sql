-- =====================================================
-- Add Batch Processing and Retry Tracking Fields
-- Only adds NEW fields - respects existing audit columns
-- =====================================================

-- 1. Add missing audit fields to payroll_jobs (created_by, updated_by only)
-- Note: created_at and updated_at already exist from V33
ALTER TABLE payroll_jobs
    ADD COLUMN IF NOT EXISTS created_by BIGINT,
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- 2. Add batch processing tracking fields to payroll_runs
ALTER TABLE payroll_runs
    ADD COLUMN IF NOT EXISTS batch_size INTEGER DEFAULT 50,
    ADD COLUMN IF NOT EXISTS retry_count INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS last_processed_employee_id BIGINT;

-- 3. Add retry tracking to employee_payroll_records
ALTER TABLE employee_payroll_records
    ADD COLUMN IF NOT EXISTS processing_attempts INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS last_error TEXT,
    ADD COLUMN IF NOT EXISTS skipped BOOLEAN DEFAULT FALSE;

-- 4. Update indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_employee_payroll_records_created_at 
    ON employee_payroll_records(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_employee_payroll_records_employee 
    ON employee_payroll_records(employee_id, payroll_period_id);

CREATE INDEX IF NOT EXISTS idx_payroll_runs_status 
    ON payroll_runs(status, payroll_period_id);

CREATE INDEX IF NOT EXISTS idx_payroll_line_items_created_at 
    ON payroll_line_items(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_payroll_jobs_created_by
    ON payroll_jobs(created_by);

-- 5. Add trigger to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for auto-updating updated_at (only if they don't exist)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_employee_payroll_records_updated_at') THEN
        CREATE TRIGGER update_employee_payroll_records_updated_at 
            BEFORE UPDATE ON employee_payroll_records 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_payroll_runs_updated_at') THEN
        CREATE TRIGGER update_payroll_runs_updated_at 
            BEFORE UPDATE ON payroll_runs 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_payroll_periods_updated_at') THEN
        CREATE TRIGGER update_payroll_periods_updated_at 
            BEFORE UPDATE ON payroll_periods 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_payroll_line_items_updated_at') THEN
        CREATE TRIGGER update_payroll_line_items_updated_at 
            BEFORE UPDATE ON payroll_line_items 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_payroll_jobs_updated_at') THEN
        CREATE TRIGGER update_payroll_jobs_updated_at 
            BEFORE UPDATE ON payroll_jobs 
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- 6. Add foreign key constraints for audit fields
DO $$
BEGIN
    -- payroll_jobs.created_by FK
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_payroll_jobs_created_by') THEN
        ALTER TABLE payroll_jobs
            ADD CONSTRAINT fk_payroll_jobs_created_by 
            FOREIGN KEY (created_by) REFERENCES users(id);
    END IF;

    -- payroll_jobs.updated_by FK
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_payroll_jobs_updated_by') THEN
        ALTER TABLE payroll_jobs
            ADD CONSTRAINT fk_payroll_jobs_updated_by 
            FOREIGN KEY (updated_by) REFERENCES users(id);
    END IF;
END $$;

-- Comments
COMMENT ON COLUMN payroll_jobs.created_by IS 'User ID who initiated the payroll job';
COMMENT ON COLUMN payroll_jobs.updated_by IS 'User ID who last updated the job status';
COMMENT ON COLUMN employee_payroll_records.processing_attempts IS 'Number of times processing was attempted for this record';
COMMENT ON COLUMN employee_payroll_records.last_error IS 'Last error message if processing failed';
COMMENT ON COLUMN employee_payroll_records.skipped IS 'Whether this record was skipped during processing';
COMMENT ON COLUMN payroll_runs.batch_size IS 'Number of employees processed per batch';
COMMENT ON COLUMN payroll_runs.retry_count IS 'Number of retries for failed processing';
COMMENT ON COLUMN payroll_runs.last_processed_employee_id IS 'ID of the last employee processed in this run';
