-- Payroll Payment Tracking Table
-- Master payment records for payroll periods
-- Tracks payment execution details separately from payroll_periods

CREATE TABLE payroll_payments (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    
    -- Payment Details
    payment_date TIMESTAMP NOT NULL,
    payment_method VARCHAR(50) NOT NULL, -- BANK_TRANSFER, CHEQUE, CASH, MOBILE_MONEY
    payment_reference VARCHAR(200), -- Bank batch reference, transaction ID
    payment_batch_number VARCHAR(100), -- Internal batch tracking number
    
    -- Financial Summary
    total_amount DECIMAL(15, 2) NOT NULL, -- Total amount paid
    total_employees INTEGER NOT NULL, -- Number of employees paid
    bank_transfer_amount DECIMAL(15, 2), -- Amount via bank transfer
    other_payment_amount DECIMAL(15, 2), -- Amount via other methods
    
    -- Payment Execution
    authorized_by BIGINT NOT NULL, -- User who authorized payment
    authorized_by_name VARCHAR(200),
    authorized_at TIMESTAMP NOT NULL,
    payment_executed_by BIGINT, -- User who executed the payment (may be different)
    payment_executed_at TIMESTAMP,
    
    -- Status
    payment_status VARCHAR(30) NOT NULL DEFAULT 'AUTHORIZED', -- AUTHORIZED, PROCESSING, COMPLETED, FAILED, REVERSED
    
    -- Bank File Details
    bank_file_generated BOOLEAN DEFAULT FALSE,
    bank_file_name VARCHAR(255),
    bank_file_path VARCHAR(500),
    bank_file_generated_at TIMESTAMP,
    bank_file_generated_by BIGINT,
    
    -- Confirmation
    payment_confirmed BOOLEAN DEFAULT FALSE,
    payment_confirmed_by BIGINT,
    payment_confirmed_at TIMESTAMP,
    confirmation_notes TEXT,
    
    -- Failure Tracking
    failure_reason TEXT,
    retry_count INTEGER DEFAULT 0,
    last_retry_at TIMESTAMP,
    
    -- Notes and Audit
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign Keys
    CONSTRAINT fk_payment_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id),
    CONSTRAINT fk_payment_authorized_by FOREIGN KEY (authorized_by) REFERENCES users(id),
    CONSTRAINT fk_payment_executed_by FOREIGN KEY (payment_executed_by) REFERENCES users(id),
    CONSTRAINT fk_payment_confirmed_by FOREIGN KEY (payment_confirmed_by) REFERENCES users(id),
    CONSTRAINT fk_payment_file_generated_by FOREIGN KEY (bank_file_generated_by) REFERENCES users(id)
);

-- Indexes for Performance
CREATE INDEX idx_payroll_payments_period ON payroll_payments(payroll_period_id);
CREATE INDEX idx_payroll_payments_status ON payroll_payments(payment_status);
CREATE INDEX idx_payroll_payments_date ON payroll_payments(payment_date);
CREATE INDEX idx_payroll_payments_authorized_by ON payroll_payments(authorized_by);

-- Comments
COMMENT ON TABLE payroll_payments IS 'Master payment records for payroll periods';
COMMENT ON COLUMN payroll_payments.payment_status IS 'AUTHORIZED, PROCESSING, COMPLETED, FAILED, REVERSED';
