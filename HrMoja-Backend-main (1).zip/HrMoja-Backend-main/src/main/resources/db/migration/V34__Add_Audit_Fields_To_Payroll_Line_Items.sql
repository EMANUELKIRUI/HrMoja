-- =====================================================
-- Add missing audit fields to payroll_line_items
-- BaseEntity requires: created_at, updated_at, created_by, updated_by
-- =====================================================

-- Add missing columns
ALTER TABLE payroll_line_items
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ADD COLUMN IF NOT EXISTS created_by BIGINT,
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add comment
COMMENT ON COLUMN payroll_line_items.created_by IS 'User ID who created this line item';
COMMENT ON COLUMN payroll_line_items.updated_by IS 'User ID who last updated this line item';
