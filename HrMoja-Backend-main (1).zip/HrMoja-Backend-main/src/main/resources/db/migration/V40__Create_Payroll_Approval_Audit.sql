-- V40: Create payroll approval audit trail table
-- Tracks all approval/rejection actions across 3 levels

CREATE TABLE payroll_approval_audit (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL REFERENCES payroll_periods(id),
    action VARCHAR(20) NOT NULL,
    approval_level VARCHAR(20) NOT NULL,
    performed_by BIGINT NOT NULL,
    performed_by_name VARCHAR(100),
    performed_at TIMESTAMP NOT NULL,
    previous_status VARCHAR(20),
    new_status VARCHAR(20),
    comments TEXT,
    rejection_reason TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_action CHECK (action IN ('PREPARED', 'REVIEWED', 'APPROVED', 'REJECTED', 'PAID')),
    CONSTRAINT check_approval_level CHECK (approval_level IN ('LEVEL_1', 'LEVEL_2', 'LEVEL_3'))
);

CREATE INDEX idx_audit_period ON payroll_approval_audit(payroll_period_id);
CREATE INDEX idx_audit_performed_at ON payroll_approval_audit(performed_at);
CREATE INDEX idx_audit_performed_by ON payroll_approval_audit(performed_by);
