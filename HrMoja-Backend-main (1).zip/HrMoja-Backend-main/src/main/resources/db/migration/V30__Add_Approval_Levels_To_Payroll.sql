-- Add approval levels to payroll_periods table
-- 3-Level Approval: DRAFT → PREPARED → REVIEWED → APPROVED

ALTER TABLE payroll_periods
    ADD COLUMN approval_level VARCHAR(20) DEFAULT 'NONE',
    ADD COLUMN prepared_by BIGINT,
    ADD COLUMN prepared_at TIMESTAMP,
    ADD COLUMN reviewed_by BIGINT,
    ADD COLUMN reviewed_at TIMESTAMP,
    ADD COLUMN final_approved_by BIGINT,
    ADD COLUMN final_approved_at TIMESTAMP;

-- Update status to include new approval states
-- Old: DRAFT, PROCESSING, APPROVED, PAID, CLOSED
-- New: DRAFT, PROCESSING, PREPARED, REVIEWED, APPROVED, PAID, CLOSED

COMMENT ON COLUMN payroll_periods.approval_level IS 'Approval level: NONE, LEVEL_1_PREPARED, LEVEL_2_REVIEWED, LEVEL_3_APPROVED';
COMMENT ON COLUMN payroll_periods.prepared_by IS 'User who prepared the payroll (Level 1)';
COMMENT ON COLUMN payroll_periods.reviewed_by IS 'User who reviewed the payroll (Level 2)';
COMMENT ON COLUMN payroll_periods.final_approved_by IS 'User who gave final approval (Level 3)';

-- Add foreign key constraints
ALTER TABLE payroll_periods
    ADD CONSTRAINT fk_payroll_prepared_by FOREIGN KEY (prepared_by) REFERENCES users(id),
    ADD CONSTRAINT fk_payroll_reviewed_by FOREIGN KEY (reviewed_by) REFERENCES users(id),
    ADD CONSTRAINT fk_payroll_final_approved_by FOREIGN KEY (final_approved_by) REFERENCES users(id);
