-- =====================================================
-- Add USER_MANAGE Permission
-- Version: 1.0
-- Description: Add comprehensive USER_MANAGE permission for user management module
-- =====================================================

-- Insert USER_MANAGE permission
INSERT INTO permissions (name, code, description, module, is_active) VALUES
('Manage Users', 'USER_MANAGE', 'Full user management access (CRUD, roles, passwords)', 'USER_MANAGEMENT', true);

-- Assign USER_MANAGE to SUPER_ADMIN role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'SUPER_ADMIN'
AND p.code = 'USER_MANAGE';

-- Assign USER_MANAGE to ADMIN role (if you want admins to manage users)
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code = 'ADMIN'
AND p.code = 'USER_MANAGE';

COMMENT ON TABLE permissions IS 'Added USER_MANAGE permission for comprehensive user management';
