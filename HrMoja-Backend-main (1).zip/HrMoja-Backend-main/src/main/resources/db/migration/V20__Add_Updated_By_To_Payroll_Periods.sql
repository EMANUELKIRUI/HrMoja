-- =====================================================
-- Add updated_by column to payroll_periods table
-- This column is required by BaseEntity
-- =====================================================

-- Add updated_by column if it doesn't exist
ALTER TABLE payroll_periods 
ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add foreign key constraint
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_payroll_periods_updated_by'
    ) THEN
        ALTER TABLE payroll_periods 
        ADD CONSTRAINT fk_payroll_periods_updated_by 
        FOREIGN KEY (updated_by) REFERENCES users(id);
    END IF;
END $$;

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_payroll_periods_updated_by ON payroll_periods(updated_by);

COMMENT ON COLUMN payroll_periods.updated_by IS 'User who last updated the payroll period';
