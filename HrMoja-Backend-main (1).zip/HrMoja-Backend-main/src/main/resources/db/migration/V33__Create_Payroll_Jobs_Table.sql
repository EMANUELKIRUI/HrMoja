-- Create payroll_jobs table for async processing tracking
CREATE TABLE IF NOT EXISTS public.payroll_jobs (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'QUEUED',
    total_employees INTEGER,
    processed_employees INTEGER DEFAULT 0,
    failed_employees INTEGER DEFAULT 0,
    progress_percentage INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    started_by BIGINT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_payroll_jobs_period 
        FOREIGN KEY (payroll_period_id) 
        REFERENCES public.payroll_periods(id) 
        ON DELETE CASCADE,
    
    CONSTRAINT fk_payroll_jobs_started_by 
        FOREIGN KEY (started_by) 
        REFERENCES public.users(id) 
        ON DELETE SET NULL,
    
    CONSTRAINT chk_payroll_jobs_status 
        CHECK (status IN ('QUEUED', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED')),
    
    CONSTRAINT chk_payroll_jobs_progress 
        CHECK (progress_percentage >= 0 AND progress_percentage <= 100)
);

-- Create indexes for performance
CREATE INDEX idx_payroll_jobs_period_id ON public.payroll_jobs(payroll_period_id);
CREATE INDEX idx_payroll_jobs_status ON public.payroll_jobs(status);
CREATE INDEX idx_payroll_jobs_created_at ON public.payroll_jobs(created_at DESC);

-- Add comment
COMMENT ON TABLE public.payroll_jobs IS 'Tracks async payroll processing jobs with progress and status';
COMMENT ON COLUMN public.payroll_jobs.status IS 'Job status: QUEUED, PROCESSING, COMPLETED, FAILED, CANCELLED';
COMMENT ON COLUMN public.payroll_jobs.progress_percentage IS 'Processing progress from 0 to 100';
