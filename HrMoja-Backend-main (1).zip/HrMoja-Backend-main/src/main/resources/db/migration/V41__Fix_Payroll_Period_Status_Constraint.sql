-- Fix payroll_periods status constraint to include PREPARED and REVIEWED
-- These statuses are part of the 3-level approval workflow:
-- DRAFT → PROCESSING → PREPARED (L1) → REVIEWED (L2) → APPROVED (L3) → PAID → CLOSED

-- Drop old constraint
ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS check_period_status;

-- Add updated constraint with PREPARED and REVIEWED
ALTER TABLE payroll_periods ADD CONSTRAINT check_period_status 
    CHECK (status IN ('DRAFT', 'PROCESSING', 'PREPARED', 'REVIEWED', 'APPROVED', 'PAID', 'CLOSED', 'DELETED'));

-- Add comment
COMMENT ON COLUMN payroll_periods.status IS 'Period status: DRAFT, PROCESSING, PREPARED (L1), REVIEWED (L2), APPROVED (L3), PAID, CLOSED, DELETED';
