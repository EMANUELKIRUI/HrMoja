-- =====================================================
-- Fix Payroll Periods Table - Remove legacy frequency column
-- The entity uses pay_frequency_id (foreign key) instead of frequency (varchar)
-- Note: Keeping financial summary columns (total_gross_pay, etc.) for performance
-- and workflow columns (cutoff_date, approval_deadline) for compliance
-- =====================================================

-- Drop the NOT NULL constraint first if it exists
ALTER TABLE payroll_periods 
ALTER COLUMN frequency DROP NOT NULL;

-- Drop the frequency column since we're using pay_frequency_id instead
ALTER TABLE payroll_periods 
DROP COLUMN IF EXISTS frequency;

COMMENT ON TABLE payroll_periods IS 'Payroll periods - uses pay_frequency_id FK. Keeps financial summaries for performance.';
COMMENT ON COLUMN payroll_periods.total_gross_pay IS 'Denormalized sum of gross pay - updated during payroll processing';
COMMENT ON COLUMN payroll_periods.total_deductions IS 'Denormalized sum of deductions - updated during payroll processing';
COMMENT ON COLUMN payroll_periods.total_net_pay IS 'Denormalized sum of net pay - updated during payroll processing';
COMMENT ON COLUMN payroll_periods.cutoff_date IS 'Deadline for data entry (timesheets, adjustments)';
COMMENT ON COLUMN payroll_periods.approval_deadline IS 'Deadline for payroll approval';
