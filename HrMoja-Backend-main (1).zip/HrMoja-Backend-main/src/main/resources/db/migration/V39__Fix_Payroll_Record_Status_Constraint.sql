-- Fix check_record_status constraint to allow FAILED and SKIPPED statuses
-- V39: Update employee_payroll_records status constraint

-- Drop old constraint
ALTER TABLE employee_payroll_records DROP CONSTRAINT IF EXISTS check_record_status;

-- Add new constraint with FAILED and SKIPPED
ALTER TABLE employee_payroll_records 
ADD CONSTRAINT check_record_status 
CHECK (status IN ('DRAFT', 'CALCULATED', 'APPROVED', 'PAID', 'FAILED', 'SKIPPED'));
