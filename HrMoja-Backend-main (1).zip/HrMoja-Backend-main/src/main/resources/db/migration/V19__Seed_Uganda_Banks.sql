-- Seed Banks in Uganda
-- This migration adds all licensed commercial banks in Uganda as of 2025
-- Source: Bank of Uganda, official bank websites, SWIFT directories

INSERT INTO banks (country_id, name, code, swift_code, is_active) VALUES
-- Get Uganda's country_id from countries table (Uganda)
((SELECT id FROM countries WHERE code = 'UGA'), 'ABC Capital Bank Limited', 'ABCF', 'ABCFUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Absa Bank Uganda Limited', 'BARC', 'BARCUGKX', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Afriland First Bank Uganda Ltd', 'CCEI', 'CCEIUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Bank of Africa - Uganda Ltd', 'AFRI', 'AFRIUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Bank of Baroda (Uganda) Limited', 'BARB', 'BARBUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Bank of India (Uganda) Ltd', 'BKID', 'BKIDUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Bank of Uganda (Central Bank)', 'UGBA', 'UGBAUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Cairo International Bank Uganda', 'CAIE', 'CAIEUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Centenary Rural Development Bank Ltd', 'CERB', 'CERBUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Citibank Uganda Limited', 'CITI', 'CITIUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'DFCU Bank Limited', 'DFCU', 'DFCUUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Diamond Trust Bank (Uganda) Ltd', 'DTBL', 'DTBLUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Ecobank Uganda Limited', 'ECOB', 'ECOBUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Equity Bank Uganda Limited', 'EQBL', 'EQBLUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Exim Bank (Uganda) Limited', 'EXIM', 'EXIMUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Finance Trust Bank', 'FINC', 'FINCUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Guaranty Trust Bank (Uganda) Ltd', 'GTBL', 'GTBLUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Housing Finance Bank Ltd', 'HFIN', 'HFINUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'I&M Bank (Uganda) Limited', 'IMBL', 'IMBLUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'KCB Bank Uganda Limited', 'KCBL', 'KCBLUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'NCBA Bank Uganda Ltd', 'NCBL', 'NCBLUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Orient Bank Limited', 'ORIN', 'ORINUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'PostBank Uganda', 'PBUG', 'PBUGUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Standard Chartered Bank Uganda Ltd', 'SCBL', 'SCBLUGKX', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Stanbic Bank Uganda Limited', 'SBIC', 'SBICUGKX', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Tropical Bank Limited', 'TROB', 'TROBUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'United Bank for Africa (Uganda) Ltd', 'UNAF', 'UNAFUGKA', true),
((SELECT id FROM countries WHERE code = 'UGA'), 'Salaam Bank Uganda Ltd', 'SALA', 'SALAUGKA', true);

-- Add comment
COMMENT ON TABLE banks IS 'Banks and financial institutions. Seeded with Uganda banks as of 2025.';
