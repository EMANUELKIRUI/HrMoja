-- Employee Payment Records - Individual payment tracking
-- Tracks individual employee payments within a payroll payment batch

CREATE TABLE employee_payment_records (
    id BIGSERIAL PRIMARY KEY,
    payroll_payment_id BIGINT NOT NULL,
    employee_payroll_record_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    
    -- Payment Details
    payment_amount DECIMAL(15, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_reference VARCHAR(200), -- Individual transaction reference
    
    -- Bank Details Used
    bank_name VARCHAR(200),
    bank_account_number VARCHAR(50),
    bank_account_name VARCHAR(200),
    bank_branch VARCHAR(200),
    
    -- Status
    payment_status VARCHAR(30) NOT NULL DEFAULT 'PENDING', -- PENDING, PROCESSED, COMPLETED, FAILED, RETURNED
    
    -- Failure Tracking
    failure_reason TEXT,
    retry_count INTEGER DEFAULT 0,
    
    -- Timestamps
    processed_at TIMESTAMP,
    completed_at TIMESTAMP,
    failed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign Keys
    CONSTRAINT fk_emp_payment_payroll_payment FOREIGN KEY (payroll_payment_id) REFERENCES payroll_payments(id),
    CONSTRAINT fk_emp_payment_record FOREIGN KEY (employee_payroll_record_id) REFERENCES employee_payroll_records(id),
    CONSTRAINT fk_emp_payment_employee FOREIGN KEY (employee_id) REFERENCES employees(id)
);

-- Indexes for Performance
CREATE INDEX idx_employee_payment_records_payment ON employee_payment_records(payroll_payment_id);
CREATE INDEX idx_employee_payment_records_employee ON employee_payment_records(employee_id);
CREATE INDEX idx_employee_payment_records_status ON employee_payment_records(payment_status);
CREATE INDEX idx_employee_payment_records_payroll_record ON employee_payment_records(employee_payroll_record_id);

-- Comments
COMMENT ON TABLE employee_payment_records IS 'Individual employee payment tracking';
COMMENT ON COLUMN employee_payment_records.payment_status IS 'PENDING, PROCESSED, COMPLETED, FAILED, RETURNED';
