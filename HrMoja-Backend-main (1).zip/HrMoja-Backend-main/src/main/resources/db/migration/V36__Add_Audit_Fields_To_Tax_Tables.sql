-- =====================================================
-- Add missing audit fields to tax-related tables
-- BaseEntity requires: created_at, updated_at, created_by, updated_by
-- =====================================================

-- Add missing audit fields to payroll_tax_brackets
ALTER TABLE payroll_tax_brackets
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ADD COLUMN IF NOT EXISTS created_by BIGINT,
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add missing audit fields to payroll_tax_reliefs (already has created_at, updated_at)
ALTER TABLE payroll_tax_reliefs
    ADD COLUMN IF NOT EXISTS created_by BIGINT,
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add missing audit fields to employee_relief_claims (already has created_at, updated_at)
ALTER TABLE employee_relief_claims
    ADD COLUMN IF NOT EXISTS created_by BIGINT,
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add missing audit fields to payroll_statutory_ceilings (already has created_at, updated_at)
ALTER TABLE payroll_statutory_ceilings
    ADD COLUMN IF NOT EXISTS created_by BIGINT,
    ADD COLUMN IF NOT EXISTS updated_by BIGINT;

-- Add comments
COMMENT ON COLUMN payroll_tax_brackets.created_by IS 'User ID who created this tax bracket';
COMMENT ON COLUMN payroll_tax_brackets.updated_by IS 'User ID who last updated this tax bracket';
COMMENT ON COLUMN payroll_tax_reliefs.created_by IS 'User ID who created this relief';
COMMENT ON COLUMN payroll_tax_reliefs.updated_by IS 'User ID who last updated this relief';
