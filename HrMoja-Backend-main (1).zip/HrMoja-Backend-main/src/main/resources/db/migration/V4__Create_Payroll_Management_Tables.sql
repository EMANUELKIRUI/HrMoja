-- =====================================================
-- PAYROLL MANAGEMENT MODULE - TABLES
-- Version: 1.0
-- Description: Comprehensive payroll processing system
-- =====================================================

-- Payroll Component Types Table (Earnings, Deductions, etc.)
CREATE TABLE payroll_component_types (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL, -- EARNING, DEDUCTION, BENEFIT, CONTRIBUTION
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payroll_component_types_code ON payroll_component_types(code);
CREATE INDEX idx_payroll_component_types_category ON payroll_component_types(category);

-- Payroll Components Table (Master Data)
CREATE TABLE payroll_components (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    component_type_id BIGINT NOT NULL,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    description TEXT,
    calculation_type VARCHAR(50) NOT NULL, -- FIXED, PERCENTAGE, FORMULA, RATE_BASED
    calculation_formula TEXT,
    default_amount DECIMAL(15, 2),
    default_percentage DECIMAL(5, 2),
    is_taxable BOOLEAN DEFAULT FALSE,
    is_statutory BOOLEAN DEFAULT FALSE,
    is_pensionable BOOLEAN DEFAULT FALSE,
    affects_gross_pay BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_payroll_components_organization FOREIGN KEY (organization_id) REFERENCES organizations(id),
    CONSTRAINT fk_payroll_components_type FOREIGN KEY (component_type_id) REFERENCES payroll_component_types(id),
    CONSTRAINT uk_component_org_code UNIQUE (organization_id, code)
);

CREATE INDEX idx_payroll_components_organization ON payroll_components(organization_id);
CREATE INDEX idx_payroll_components_type ON payroll_components(component_type_id);
CREATE INDEX idx_payroll_components_code ON payroll_components(code);

-- Employee Payroll Components (Assignment)
CREATE TABLE employee_payroll_components (
    id BIGSERIAL PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    payroll_component_id BIGINT NOT NULL,
    amount DECIMAL(15, 2),
    percentage DECIMAL(5, 2),
    effective_date DATE NOT NULL,
    end_date DATE,
    is_recurring BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_emp_payroll_components_employee FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT fk_emp_payroll_components_component FOREIGN KEY (payroll_component_id) REFERENCES payroll_components(id)
);

CREATE INDEX idx_emp_payroll_components_employee ON employee_payroll_components(employee_id);
CREATE INDEX idx_emp_payroll_components_component ON employee_payroll_components(payroll_component_id);
CREATE INDEX idx_emp_payroll_components_dates ON employee_payroll_components(effective_date, end_date);

-- Statutory Configuration Table (Country-specific rates)
CREATE TABLE statutory_configurations (
    id BIGSERIAL PRIMARY KEY,
    country_id BIGINT NOT NULL,
    statutory_type VARCHAR(50) NOT NULL, -- PAYE, NSSF, NHIF, LST, NAPSA, etc.
    name VARCHAR(255) NOT NULL,
    description TEXT,
    effective_date DATE NOT NULL,
    end_date DATE,
    configuration_data JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    
    CONSTRAINT fk_statutory_config_country FOREIGN KEY (country_id) REFERENCES countries(id),
    CONSTRAINT fk_statutory_config_created_by FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE INDEX idx_statutory_config_country ON statutory_configurations(country_id);
CREATE INDEX idx_statutory_config_type ON statutory_configurations(statutory_type);
CREATE INDEX idx_statutory_config_dates ON statutory_configurations(effective_date, end_date);

-- Tax Brackets Table
CREATE TABLE tax_brackets (
    id BIGSERIAL PRIMARY KEY,
    country_id BIGINT NOT NULL,
    tax_year INTEGER NOT NULL,
    bracket_name VARCHAR(100),
    min_amount DECIMAL(15, 2) NOT NULL,
    max_amount DECIMAL(15, 2),
    tax_rate DECIMAL(5, 2) NOT NULL,
    fixed_amount DECIMAL(15, 2) DEFAULT 0,
    effective_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_tax_brackets_country FOREIGN KEY (country_id) REFERENCES countries(id)
);

CREATE INDEX idx_tax_brackets_country ON tax_brackets(country_id);
CREATE INDEX idx_tax_brackets_year ON tax_brackets(tax_year);
CREATE INDEX idx_tax_brackets_amounts ON tax_brackets(min_amount, max_amount);

-- Tax Reliefs/Exemptions Table
CREATE TABLE tax_reliefs (
    id BIGSERIAL PRIMARY KEY,
    country_id BIGINT NOT NULL,
    relief_type VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    relief_amount DECIMAL(15, 2),
    relief_percentage DECIMAL(5, 2),
    max_relief_amount DECIMAL(15, 2),
    effective_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_tax_reliefs_country FOREIGN KEY (country_id) REFERENCES countries(id)
);

CREATE INDEX idx_tax_reliefs_country ON tax_reliefs(country_id);
CREATE INDEX idx_tax_reliefs_type ON tax_reliefs(relief_type);

-- Payroll Periods Table
CREATE TABLE payroll_periods (
    id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    period_name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    pay_date DATE NOT NULL,
    frequency VARCHAR(20) NOT NULL,
    cutoff_date DATE,
    approval_deadline DATE,
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT', -- DRAFT, IN_PROGRESS, PROCESSED, APPROVED, PAID, CLOSED
    total_employees INTEGER DEFAULT 0,
    total_gross_pay DECIMAL(15, 2) DEFAULT 0,
    total_deductions DECIMAL(15, 2) DEFAULT 0,
    total_net_pay DECIMAL(15, 2) DEFAULT 0,
    total_employer_contributions DECIMAL(15, 2) DEFAULT 0,
    notes TEXT,
    is_locked BOOLEAN DEFAULT FALSE,
    locked_at TIMESTAMP,
    locked_by BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    
    CONSTRAINT fk_payroll_periods_organization FOREIGN KEY (organization_id) REFERENCES organizations(id),
    CONSTRAINT fk_payroll_periods_locked_by FOREIGN KEY (locked_by) REFERENCES users(id),
    CONSTRAINT fk_payroll_periods_created_by FOREIGN KEY (created_by) REFERENCES users(id),
    CONSTRAINT uk_period_org_dates UNIQUE (organization_id, start_date, end_date)
);

CREATE INDEX idx_payroll_periods_organization ON payroll_periods(organization_id);
CREATE INDEX idx_payroll_periods_dates ON payroll_periods(start_date, end_date);
CREATE INDEX idx_payroll_periods_status ON payroll_periods(status);
CREATE INDEX idx_payroll_periods_locked ON payroll_periods(is_locked);

-- Payroll Records Table (Employee payroll for each period)
CREATE TABLE payroll_records (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    
    -- Work Hours
    regular_hours DECIMAL(8, 2) DEFAULT 0,
    overtime_hours DECIMAL(8, 2) DEFAULT 0,
    night_shift_hours DECIMAL(8, 2) DEFAULT 0,
    weekend_hours DECIMAL(8, 2) DEFAULT 0,
    holiday_hours DECIMAL(8, 2) DEFAULT 0,
    on_call_hours DECIMAL(8, 2) DEFAULT 0,
    absence_days DECIMAL(5, 2) DEFAULT 0,
    
    -- Salary Components
    basic_salary DECIMAL(15, 2) NOT NULL,
    gross_earnings DECIMAL(15, 2) DEFAULT 0,
    total_deductions DECIMAL(15, 2) DEFAULT 0,
    net_pay DECIMAL(15, 2) DEFAULT 0,
    
    -- Statutory Deductions
    paye_tax DECIMAL(15, 2) DEFAULT 0,
    social_security_employee DECIMAL(15, 2) DEFAULT 0,
    social_security_employer DECIMAL(15, 2) DEFAULT 0,
    health_insurance DECIMAL(15, 2) DEFAULT 0,
    housing_levy DECIMAL(15, 2) DEFAULT 0,
    local_service_tax DECIMAL(15, 2) DEFAULT 0,
    
    -- Other Fields
    taxable_income DECIMAL(15, 2) DEFAULT 0,
    non_taxable_income DECIMAL(15, 2) DEFAULT 0,
    
    -- Status and Workflow
    status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
    is_approved BOOLEAN DEFAULT FALSE,
    is_paid BOOLEAN DEFAULT FALSE,
    payment_date DATE,
    payment_reference VARCHAR(100),
    payment_method VARCHAR(50),
    
    -- Notes and Metadata
    notes TEXT,
    calculation_breakdown JSONB,
    
    -- Timestamps
    processed_at TIMESTAMP,
    processed_by BIGINT,
    approved_at TIMESTAMP,
    approved_by BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_payroll_records_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id) ON DELETE CASCADE,
    CONSTRAINT fk_payroll_records_employee FOREIGN KEY (employee_id) REFERENCES employees(id),
    CONSTRAINT fk_payroll_records_processed_by FOREIGN KEY (processed_by) REFERENCES users(id),
    CONSTRAINT fk_payroll_records_approved_by FOREIGN KEY (approved_by) REFERENCES users(id),
    CONSTRAINT uk_payroll_record_period_employee UNIQUE (payroll_period_id, employee_id)
);

CREATE INDEX idx_payroll_records_period ON payroll_records(payroll_period_id);
CREATE INDEX idx_payroll_records_employee ON payroll_records(employee_id);
CREATE INDEX idx_payroll_records_status ON payroll_records(status);
CREATE INDEX idx_payroll_records_approved ON payroll_records(is_approved);
CREATE INDEX idx_payroll_records_paid ON payroll_records(is_paid);

-- Payroll Record Components Table (Detailed breakdown)
CREATE TABLE payroll_record_components (
    id BIGSERIAL PRIMARY KEY,
    payroll_record_id BIGINT NOT NULL,
    payroll_component_id BIGINT NOT NULL,
    component_name VARCHAR(255) NOT NULL,
    component_type VARCHAR(50) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    is_taxable BOOLEAN DEFAULT FALSE,
    is_statutory BOOLEAN DEFAULT FALSE,
    calculation_basis TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_record_components_record FOREIGN KEY (payroll_record_id) REFERENCES payroll_records(id) ON DELETE CASCADE,
    CONSTRAINT fk_record_components_component FOREIGN KEY (payroll_component_id) REFERENCES payroll_components(id)
);

CREATE INDEX idx_record_components_record ON payroll_record_components(payroll_record_id);
CREATE INDEX idx_record_components_component ON payroll_record_components(payroll_component_id);
CREATE INDEX idx_record_components_type ON payroll_record_components(component_type);

-- Payroll Adjustments Table
CREATE TABLE payroll_adjustments (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    adjustment_type VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    is_taxable BOOLEAN DEFAULT TRUE,
    is_recurring BOOLEAN DEFAULT FALSE,
    effective_periods INTEGER DEFAULT 1,
    reason TEXT,
    approved_by BIGINT,
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by BIGINT,
    
    CONSTRAINT fk_payroll_adjustments_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id),
    CONSTRAINT fk_payroll_adjustments_employee FOREIGN KEY (employee_id) REFERENCES employees(id),
    CONSTRAINT fk_payroll_adjustments_approved_by FOREIGN KEY (approved_by) REFERENCES users(id),
    CONSTRAINT fk_payroll_adjustments_created_by FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE INDEX idx_payroll_adjustments_period ON payroll_adjustments(payroll_period_id);
CREATE INDEX idx_payroll_adjustments_employee ON payroll_adjustments(employee_id);

-- Payroll Approvals Table (Multi-level approval workflow)
CREATE TABLE payroll_approvals (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    approval_level INTEGER NOT NULL,
    approver_role VARCHAR(50) NOT NULL,
    approver_user_id BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    approval_notes TEXT,
    is_final_approval BOOLEAN DEFAULT FALSE,
    approved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_payroll_approvals_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id) ON DELETE CASCADE,
    CONSTRAINT fk_payroll_approvals_user FOREIGN KEY (approver_user_id) REFERENCES users(id),
    CONSTRAINT uk_approval_period_level UNIQUE (payroll_period_id, approval_level)
);

CREATE INDEX idx_payroll_approvals_period ON payroll_approvals(payroll_period_id);
CREATE INDEX idx_payroll_approvals_user ON payroll_approvals(approver_user_id);
CREATE INDEX idx_payroll_approvals_status ON payroll_approvals(status);

-- Statutory Payments Table
CREATE TABLE statutory_payments (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    organization_id BIGINT NOT NULL,
    payment_type VARCHAR(50) NOT NULL,
    authority_name VARCHAR(255) NOT NULL,
    total_amount DECIMAL(15, 2) NOT NULL,
    payment_date DATE,
    payment_reference VARCHAR(100),
    receipt_number VARCHAR(100),
    payment_status VARCHAR(30) DEFAULT 'PENDING',
    due_date DATE,
    notes TEXT,
    paid_by BIGINT,
    paid_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_statutory_payments_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id),
    CONSTRAINT fk_statutory_payments_organization FOREIGN KEY (organization_id) REFERENCES organizations(id),
    CONSTRAINT fk_statutory_payments_paid_by FOREIGN KEY (paid_by) REFERENCES users(id)
);

CREATE INDEX idx_statutory_payments_period ON statutory_payments(payroll_period_id);
CREATE INDEX idx_statutory_payments_organization ON statutory_payments(organization_id);
CREATE INDEX idx_statutory_payments_type ON statutory_payments(payment_type);
CREATE INDEX idx_statutory_payments_status ON statutory_payments(payment_status);

-- Payslips Table
CREATE TABLE payslips (
    id BIGSERIAL PRIMARY KEY,
    payroll_record_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    payroll_period_id BIGINT NOT NULL,
    payslip_number VARCHAR(100) UNIQUE NOT NULL,
    file_url VARCHAR(500),
    file_format VARCHAR(20) DEFAULT 'PDF',
    is_sent BOOLEAN DEFAULT FALSE,
    sent_at TIMESTAMP,
    is_viewed BOOLEAN DEFAULT FALSE,
    viewed_at TIMESTAMP,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    generated_by BIGINT,
    
    CONSTRAINT fk_payslips_record FOREIGN KEY (payroll_record_id) REFERENCES payroll_records(id) ON DELETE CASCADE,
    CONSTRAINT fk_payslips_employee FOREIGN KEY (employee_id) REFERENCES employees(id),
    CONSTRAINT fk_payslips_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id),
    CONSTRAINT fk_payslips_generated_by FOREIGN KEY (generated_by) REFERENCES users(id)
);

CREATE INDEX idx_payslips_record ON payslips(payroll_record_id);
CREATE INDEX idx_payslips_employee ON payslips(employee_id);
CREATE INDEX idx_payslips_period ON payslips(payroll_period_id);
CREATE INDEX idx_payslips_number ON payslips(payslip_number);

-- Bank Upload Files Table
CREATE TABLE bank_upload_files (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    organization_id BIGINT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url VARCHAR(500),
    file_format VARCHAR(20) NOT NULL,
    total_records INTEGER NOT NULL,
    total_amount DECIMAL(15, 2) NOT NULL,
    bank_id BIGINT,
    upload_status VARCHAR(30) DEFAULT 'PENDING',
    uploaded_at TIMESTAMP,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    generated_by BIGINT,
    
    CONSTRAINT fk_bank_files_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id),
    CONSTRAINT fk_bank_files_organization FOREIGN KEY (organization_id) REFERENCES organizations(id),
    CONSTRAINT fk_bank_files_bank FOREIGN KEY (bank_id) REFERENCES banks(id),
    CONSTRAINT fk_bank_files_generated_by FOREIGN KEY (generated_by) REFERENCES users(id)
);

CREATE INDEX idx_bank_files_period ON bank_upload_files(payroll_period_id);
CREATE INDEX idx_bank_files_organization ON bank_upload_files(organization_id);

-- Payroll Validation Errors Table
CREATE TABLE payroll_validation_errors (
    id BIGSERIAL PRIMARY KEY,
    payroll_period_id BIGINT NOT NULL,
    employee_id BIGINT,
    error_code VARCHAR(50) NOT NULL,
    error_message TEXT NOT NULL,
    field_name VARCHAR(100),
    severity VARCHAR(20) NOT NULL,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP,
    resolved_by BIGINT,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT fk_validation_errors_period FOREIGN KEY (payroll_period_id) REFERENCES payroll_periods(id) ON DELETE CASCADE,
    CONSTRAINT fk_validation_errors_employee FOREIGN KEY (employee_id) REFERENCES employees(id),
    CONSTRAINT fk_validation_errors_resolved_by FOREIGN KEY (resolved_by) REFERENCES users(id)
);

CREATE INDEX idx_validation_errors_period ON payroll_validation_errors(payroll_period_id);
CREATE INDEX idx_validation_errors_employee ON payroll_validation_errors(employee_id);
CREATE INDEX idx_validation_errors_resolved ON payroll_validation_errors(is_resolved);
CREATE INDEX idx_validation_errors_severity ON payroll_validation_errors(severity);

COMMENT ON TABLE payroll_periods IS 'Payroll processing periods with status tracking';
COMMENT ON TABLE payroll_records IS 'Individual employee payroll records per period';
COMMENT ON TABLE payroll_components IS 'Configurable payroll components (earnings, deductions)';
COMMENT ON TABLE statutory_configurations IS 'Country-specific statutory rates and rules';
COMMENT ON TABLE payroll_approvals IS 'Multi-level payroll approval workflow';
COMMENT ON TABLE statutory_payments IS 'Statutory payment tracking (PAYE, NSSF, etc.)';
