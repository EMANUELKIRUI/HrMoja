-- =====================================================
-- Fix Uganda Country Code from UG to UGA
-- Align with ISO 3166-1 alpha-3 (3-letter codes)
-- =====================================================

-- Update tax configurations
UPDATE payroll_tax_configurations
SET country_code = 'UGA'
WHERE country_code = 'UG';

-- Update statutory ceilings
UPDATE payroll_statutory_ceilings
SET country_code = 'UGA'
WHERE country_code = 'UG';

-- Add comment
COMMENT ON COLUMN payroll_tax_configurations.country_code IS 'ISO 3166-1 alpha-3 country code (3 letters: UGA, KEN, TZA, RWA)';
COMMENT ON COLUMN payroll_statutory_ceilings.country_code IS 'ISO 3166-1 alpha-3 country code (3 letters: UGA, KEN, TZA, RWA)';
