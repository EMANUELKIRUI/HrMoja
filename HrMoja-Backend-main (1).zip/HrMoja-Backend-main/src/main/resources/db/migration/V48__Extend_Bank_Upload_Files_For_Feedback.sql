-- Extend bank_upload_files table to support bank feedback/acknowledgement files
-- and track file integrity for fraud detection

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS file_type VARCHAR(30) DEFAULT 'GENERATED'; 
-- GENERATED (system generated), FEEDBACK (bank acknowledgement)

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS file_path VARCHAR(500);
-- Local file path for storage

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS file_hash VARCHAR(64);
-- SHA-256 hash for file integrity verification

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS file_size BIGINT;
-- File size in bytes

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS is_locked BOOLEAN DEFAULT FALSE;
-- Lock file after first generation to prevent tampering

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS feedback_file_id BIGINT;
-- Link to bank feedback file

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS discrepancy_count INTEGER DEFAULT 0;
-- Number of discrepancies found when comparing with feedback

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS discrepancy_details TEXT;
-- JSON or text details of discrepancies

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS uploaded_by BIGINT;
-- User who uploaded feedback file

ALTER TABLE bank_upload_files ADD COLUMN IF NOT EXISTS notes TEXT;
-- Additional notes

-- Add foreign key for uploaded_by
ALTER TABLE bank_upload_files ADD CONSTRAINT fk_bank_files_uploaded_by 
    FOREIGN KEY (uploaded_by) REFERENCES users(id);

-- Add foreign key for feedback file linking
ALTER TABLE bank_upload_files ADD CONSTRAINT fk_bank_files_feedback 
    FOREIGN KEY (feedback_file_id) REFERENCES bank_upload_files(id);

-- Create index for file_type
CREATE INDEX idx_bank_files_type ON bank_upload_files(file_type);

-- Create index for is_locked
CREATE INDEX idx_bank_files_locked ON bank_upload_files(is_locked);

-- Comments
COMMENT ON COLUMN bank_upload_files.file_type IS 'GENERATED (system generated) or FEEDBACK (bank acknowledgement)';
COMMENT ON COLUMN bank_upload_files.file_hash IS 'SHA-256 hash for file integrity verification';
COMMENT ON COLUMN bank_upload_files.is_locked IS 'Lock file after first generation to prevent tampering';
COMMENT ON COLUMN bank_upload_files.discrepancy_count IS 'Number of discrepancies found between generated and feedback files';
