-- Add REJECTED status to employee_payroll_records
-- REJECTED is used when an employee record is excluded from payroll with a reason

-- Drop old constraint
ALTER TABLE employee_payroll_records DROP CONSTRAINT IF EXISTS check_record_status;

-- Add updated constraint with REJECTED
ALTER TABLE employee_payroll_records 
ADD CONSTRAINT check_record_status 
CHECK (status IN ('DRAFT', 'CALCULATED', 'APPROVED', 'PAID', 'FAILED', 'SKIPPED', 'REJECTED'));

-- Add comment
COMMENT ON COLUMN employee_payroll_records.status IS 'Record status: DRAFT, CALCULATED, APPROVED (L1), PAID, FAILED, SKIPPED, REJECTED (excluded from payroll)';
