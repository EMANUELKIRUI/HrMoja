-- Migration: Add partial unique index on period_name to allow same name for DELETED periods
-- This enables recreation of periods with same name after soft deletion

-- Drop any existing constraint on period_name
ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS uk_period_org_name;

-- Create a partial unique index that only applies to non-DELETED records
-- This allows multiple DELETED records with same name, but prevents duplicate active period names
CREATE UNIQUE INDEX IF NOT EXISTS uk_period_org_name_active 
ON payroll_periods (organization_id, period_name) 
WHERE status != 'DELETED';

-- Add comment for documentation
COMMENT ON INDEX uk_period_org_name_active IS 'Ensures unique period names per organization, excluding DELETED records';
