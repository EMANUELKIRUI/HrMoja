-- Add Finance Level 2 review tracking columns to employee_payroll_records
ALTER TABLE employee_payroll_records
ADD COLUMN reviewed_level2 BOOLEAN DEFAULT FALSE,
ADD COLUMN level2_reviewed_by BIGINT,
ADD COLUMN level2_reviewed_at TIMESTAMP;

-- Add foreign key for level2_reviewed_by
ALTER TABLE employee_payroll_records
ADD CONSTRAINT fk_record_level2_reviewer FOREIGN KEY (level2_reviewed_by) REFERENCES users(id);

-- Create index for faster filtering
CREATE INDEX idx_payroll_records_reviewed_level2 ON employee_payroll_records(reviewed_level2);

-- Add comment
COMMENT ON COLUMN employee_payroll_records.reviewed_level2 IS 'Indicates if record has been reviewed by Finance (Level 2)';
COMMENT ON COLUMN employee_payroll_records.level2_reviewed_by IS 'User ID of Finance reviewer';
COMMENT ON COLUMN employee_payroll_records.level2_reviewed_at IS 'Timestamp when Finance reviewed this record';
