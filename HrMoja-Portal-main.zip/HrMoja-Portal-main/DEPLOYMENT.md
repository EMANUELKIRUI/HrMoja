# HrMoja Frontend Deployment Guide

This guide explains how to deploy the HrMoja frontend application to production using GitHub Actions and Docker.

## Prerequisites

### 1. Server Requirements
- Ubuntu 20.04+ or similar Linux distribution
- Docker and Docker Compose installed
- Git installed
- SSH access configured
- Port 80 available (or configure alternative port)

### 2. GitHub Repository Setup
- Push your code to a GitHub repository
- Set up GitHub Actions (enabled by default)

### 3. Required GitHub Secrets

Navigate to your GitHub repository → Settings → Secrets and variables → Actions, and add the following secrets:

| Secret Name | Description | Example |
|-------------|-------------|---------|
| `SERVER_HOST` | Production server IP or domain | `192.168.1.100` or `app.hrmoja.com` |
| `SERVER_USER` | SSH username | `ubuntu` or `deploy` |
| `SERVER_PORT` | SSH port | `22` |
| `SSH_PRIVATE_KEY` | Private SSH key for authentication | `-----BEGIN RSA PRIVATE KEY-----...` |
| `VITE_API_URL` | Backend API URL | `https://api.hrmoja.com/api` |

Optional secrets:
| Secret Name | Description |
|-------------|-------------|
| `DOCKER_USERNAME` | Docker Hub username (if pushing images) |
| `DOCKER_PASSWORD` | Docker Hub password or token |

## Server Setup

### 1. Initial Server Configuration

SSH into your server and run these commands:

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Log out and back in for group changes to take effect
```

### 2. Clone Repository on Server

```bash
# Create application directory
sudo mkdir -p /opt/hrmoja-portal
sudo chown $USER:$USER /opt/hrmoja-portal

# Clone repository
cd /opt/hrmoja-portal
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git .

# Configure git to store credentials (if using HTTPS)
git config credential.helper store
```

### 3. Create Environment File

Create a `.env` file in `/opt/hrmoja-portal`:

```bash
cat > /opt/hrmoja-portal/.env << EOF
# API Configuration
VITE_API_URL=http://YOUR_BACKEND_IP:8080/api

# Application Configuration
NODE_ENV=production
EOF
```

### 4. Configure Firewall (if applicable)

```bash
# Allow HTTP traffic
sudo ufw allow 80/tcp

# Allow HTTPS (if using SSL)
sudo ufw allow 443/tcp

# Check status
sudo ufw status
```

## Deployment Methods

### Method 1: Automatic Deployment (Recommended)

The CI/CD pipeline automatically deploys when you push to the `main` branch.

1. **Make changes** to your code
2. **Commit and push** to main:
   ```bash
   git add .
   git commit -m "Your commit message"
   git push origin main
   ```
3. **Monitor** the GitHub Actions workflow in your repository's Actions tab
4. **Verify** deployment by accessing your server URL

### Method 2: Manual Deployment via GitHub Actions

1. Go to your repository on GitHub
2. Click on the **Actions** tab
3. Select **Manual Deployment** workflow
4. Click **Run workflow**
5. Choose environment (production/staging)
6. Optionally skip build if already built
7. Click **Run workflow** button

### Method 3: Direct Server Deployment

SSH into your server and run:

```bash
cd /opt/hrmoja-portal
git pull origin main
docker-compose down
docker-compose up -d --build
```

## Docker Configuration

### docker-compose.yml

The application uses Docker Compose for container orchestration. Key features:

- **Multi-stage build** for optimized image size
- **Nginx** for serving static files
- **Health checks** for container monitoring
- **Automatic restart** policy

### Building Locally

To test the Docker build locally:

```bash
# Build the image
docker-compose build

# Run the container
docker-compose up -d

# View logs
docker-compose logs -f

# Stop the container
docker-compose down
```

## CI/CD Pipeline

### Automatic Pipeline (ci-cd.yml)

Triggers on:
- Push to `main` or `develop` branches
- Pull requests to `main` branch

Workflow stages:
1. **Build and Test**
   - Checkout code
   - Install dependencies
   - Run linter
   - Build application
   - Upload artifacts

2. **Docker Build**
   - Build Docker image
   - Cache layers for faster builds
   - (Optional) Push to Docker Hub

3. **Deploy to Production**
   - SSH into server
   - Pull latest code
   - Rebuild and restart containers
   - Verify health checks
   - Clean up old images

### Manual Pipeline (deploy-manual.yml)

Allows on-demand deployment with options:
- Choose environment (production/staging)
- Skip build step (for quick redeploys)

## Monitoring and Troubleshooting

### View Application Logs

```bash
# View real-time logs
docker logs -f hrmoja-frontend

# View last 100 lines
docker logs hrmoja-frontend --tail 100

# View logs with timestamps
docker logs hrmoja-frontend -t
```

### Check Container Status

```bash
# List running containers
docker ps

# Check container health
docker inspect hrmoja-frontend | grep -A 10 Health

# View resource usage
docker stats hrmoja-frontend
```

### Health Check Endpoint

Access the health endpoint:
```bash
curl http://localhost/health
```

Should return: `healthy`

### Common Issues

#### Issue: Container won't start
```bash
# Check logs
docker logs hrmoja-frontend

# Verify port availability
sudo netstat -tulpn | grep :80

# Check disk space
df -h
```

#### Issue: Build fails
```bash
# Clear Docker cache
docker system prune -a

# Rebuild from scratch
docker-compose build --no-cache
```

#### Issue: Application not accessible
```bash
# Check if nginx is running
docker exec hrmoja-frontend nginx -t

# Check firewall
sudo ufw status

# Verify network
docker network inspect hrmoja-network
```

## SSL/HTTPS Setup (Optional)

To enable HTTPS using Let's Encrypt:

### 1. Install Certbot

```bash
sudo apt install certbot python3-certbot-nginx
```

### 2. Update nginx.conf

Add SSL configuration to your nginx.conf file.

### 3. Obtain Certificate

```bash
sudo certbot --nginx -d your-domain.com
```

### 4. Auto-renewal

Certbot automatically sets up renewal. Test it:
```bash
sudo certbot renew --dry-run
```

## Rollback Procedure

If a deployment fails:

```bash
# SSH into server
ssh user@server

# Navigate to app directory
cd /opt/hrmoja-portal

# Check git log
git log --oneline -n 10

# Rollback to previous commit
git reset --hard COMMIT_HASH

# Rebuild and restart
docker-compose down
docker-compose up -d --build
```

## Performance Optimization

### 1. Enable Caching

The nginx.conf is already configured with caching headers for static assets.

### 2. Enable Gzip Compression

Gzip is enabled by default in the nginx configuration.

### 3. CDN Integration (Optional)

For better performance, consider using a CDN:
- Cloudflare
- AWS CloudFront
- Azure CDN

## Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `VITE_API_URL` | Backend API base URL | `http://localhost:8080/api` | Yes |
| `NODE_ENV` | Environment mode | `production` | No |

## Security Best Practices

1. **SSH Key Authentication**: Use SSH keys instead of passwords
2. **Firewall Configuration**: Only open necessary ports
3. **Regular Updates**: Keep Docker and system packages updated
4. **Environment Variables**: Never commit secrets to git
5. **HTTPS**: Use SSL certificates in production
6. **Security Headers**: Already configured in nginx.conf

## Backup Strategy

### Application Code
- Code is version-controlled in Git
- GitHub serves as primary backup

### Environment Configuration
Backup the `.env` file regularly:
```bash
cp /opt/hrmoja-portal/.env /opt/backups/frontend-env-$(date +%Y%m%d).bak
```

## Support and Maintenance

### Updating Dependencies

```bash
# Check for outdated packages
npm outdated

# Update packages
npm update

# Update specific package
npm install package-name@latest
```

### Regular Maintenance Tasks

1. **Weekly**: Check application logs
2. **Monthly**: Update dependencies
3. **Quarterly**: Review and update Docker images
4. **As needed**: Security patches

## Additional Resources

- [Docker Documentation](https://docs.docker.com/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Nginx Documentation](https://nginx.org/en/docs/)
- [Vite Documentation](https://vitejs.dev/)

## Contact

For issues or questions about deployment, contact your DevOps team or create an issue in the repository.
