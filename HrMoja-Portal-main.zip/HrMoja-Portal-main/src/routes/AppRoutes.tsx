import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import LandingPage from '../features/landing/LandingPage';
import Login from '../features/auth/Login';
import ForgotPassword from '../features/auth/ForgotPassword';
import ResetPassword from '../features/auth/ResetPassword';
import DashboardLayout from '../components/layout/DashboardLayout';
import PlatformAdminLayout from '../components/layout/PlatformAdminLayout';
import Dashboard from '../features/dashboard/Dashboard';
import SettingsPage from '../features/settings/SettingsPage';
import EmployeesPage from '../features/employees/EmployeesPage';
import EmployeeProfilePage from '../features/employees/EmployeeProfilePage';
import AddEmployeePage from '../features/employees/AddEmployeePage';
import PayrollComponentsPage from '../features/payroll/PayrollComponentsPage';
import PayrollProcessingPage from '../features/payroll/PayrollProcessingPage';
import PayrollPeriods from '../pages/PayrollPeriods';
import PayrollPeriodForm from '../pages/PayrollPeriodForm';
import PayrollPeriodDetails from '../pages/PayrollPeriodDetails';
import ProcessPayrollPage from '../pages/ProcessPayrollPage';
import EmployeeSalaryPage from '../features/salary/EmployeeSalaryPage';
import ReportsPage from '../features/reports/ReportsPage';
import OrganizationsPage from '../features/organizations/OrganizationsPage';
import OrganizationSettingsPage from '../features/organization/OrganizationSettingsPage';
import UsersManagementPage from '../features/users/UsersManagementPage';
import RolesManagementPage from '../features/users/RolesManagementPage';
import PlatformSettingsPage from '../features/platform-settings/PlatformSettingsPage';
import HRPayrollPreparation from '../features/hr-payroll/HRPayrollPreparation';
import HRPayrollEditPage from '../features/hr-payroll/HRPayrollEditPage';
import FinancePayrollReview from '../features/finance-payroll/FinancePayrollReview';
import FinancePayrollReviewDetail from '../features/finance-payroll/FinancePayrollReviewDetail';
import FinancePayrollPayment from '../features/finance-payroll/FinancePayrollPayment';
import PaymentManagementPage from '../features/finance-payroll/PaymentManagementPage';
import ExecutivePayrollApproval from '../features/executive-payroll/ExecutivePayrollApproval';
import ExecutivePayrollApprovalDetail from '../features/executive-payroll/ExecutivePayrollApprovalDetail';
import ExecutivePaymentAnalytics from '../features/executive-payroll/ExecutivePaymentAnalytics';

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuthStore();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

// Layout wrapper that selects the appropriate layout based on user role
const LayoutWrapper = () => {
  const { hasRole } = useAuthStore();
  const isPlatformAdmin = hasRole('PLATFORM_ADMIN') || hasRole('SUPER_ADMIN');

  // Platform Admins get their own layout
  if (isPlatformAdmin) {
    return <PlatformAdminLayout />;
  }

  // Organization users get the standard dashboard layout
  return <DashboardLayout />;
};

const AppRoutes = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* Protected Routes with Role-Based Layouts */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <LayoutWrapper />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
      </Route>
      
      {/* Organization-specific routes */}
      <Route path="/organization" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<OrganizationSettingsPage />} />
      </Route>
      
      <Route path="/employees" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<EmployeesPage />} />
        <Route path="new" element={<AddEmployeePage />} />
        <Route path=":id" element={<EmployeeProfilePage />} />
      </Route>
      
      <Route path="/payroll" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<Navigate to="/payroll/periods" replace />} />
        <Route path="periods" element={<PayrollPeriods />} />
        <Route path="periods/new" element={<PayrollPeriodForm />} />
        <Route path="periods/:id" element={<PayrollPeriodDetails />} />
        <Route path="periods/:id/edit" element={<PayrollPeriodForm />} />
        <Route path="periods/:id/process" element={<ProcessPayrollPage />} />
        <Route path="components" element={<PayrollComponentsPage />} />
        <Route path="processing" element={<PayrollProcessingPage />} />
        <Route path="salary" element={<EmployeeSalaryPage />} />
      </Route>
      
      {/* HR Payroll Preparation Module */}
      <Route path="/hr" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route path="payroll/prepare" element={<HRPayrollPreparation />} />
        <Route path="payroll/edit/:periodId" element={<HRPayrollEditPage />} />
      </Route>
      
      {/* Finance Payroll Review Module */}
      <Route path="/finance" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route path="payroll/review" element={<FinancePayrollReview />} />
        <Route path="payroll/review/:periodId" element={<FinancePayrollReviewDetail />} />
        <Route path="payroll/payment" element={<FinancePayrollPayment />} />
        <Route path="payroll/payment/manage/:periodId" element={<PaymentManagementPage />} />
      </Route>
      
      {/* Executive Payroll Approval Module */}
      <Route path="/executive" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route path="payroll/approval" element={<ExecutivePayrollApproval />} />
        <Route path="payroll/approval/:periodId" element={<ExecutivePayrollApprovalDetail />} />
        <Route path="payment/analytics" element={<ExecutivePaymentAnalytics />} />
      </Route>
      
      <Route path="/reports" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<ReportsPage />} />
      </Route>
      
      <Route path="/settings" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<SettingsPage />} />
      </Route>
      
      {/* Platform Admin specific routes */}
      <Route path="/organizations" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<OrganizationsPage />} />
      </Route>
      
      <Route path="/users" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<UsersManagementPage />} />
      </Route>
      
      <Route path="/roles" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<RolesManagementPage />} />
      </Route>
      
      <Route path="/platform-settings" element={<ProtectedRoute><LayoutWrapper /></ProtectedRoute>}>
        <Route index element={<PlatformSettingsPage />} />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
