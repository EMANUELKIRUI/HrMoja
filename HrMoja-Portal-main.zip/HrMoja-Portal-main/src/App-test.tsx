function AppTest() {
  return (
    <div style={{ padding: '20px', backgroundColor: 'red', color: 'white' }}>
      <h1>APP IS RENDERING!</h1>
      <p>If you see this, React is working</p>
    </div>
  );
}

export default AppTest;
