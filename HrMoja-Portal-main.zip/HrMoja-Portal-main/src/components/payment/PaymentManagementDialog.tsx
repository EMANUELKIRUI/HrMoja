import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Tabs,
  Tab,
  Stack,
  Card,
  CardContent,
  IconButton,
  Alert,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
} from '@mui/material';
import {
  Close as CloseIcon,
  CloudDownload as DownloadIcon,
  CloudUpload as UploadIcon,
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
  Payment as PaymentIcon,
  Receipt as ReceiptIcon,
  Description as FileIcon,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import axios from 'axios';

interface PaymentManagementDialogProps {
  open: boolean;
  onClose: () => void;
  period: any;
  paymentDetails: any;
  onRefresh: () => void;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`payment-tabpanel-${index}`}
      aria-labelledby={`payment-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

const PaymentManagementDialog: React.FC<PaymentManagementDialogProps> = ({
  open,
  onClose,
  period,
  paymentDetails,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [feedbackFiles, setFeedbackFiles] = useState<any[]>([]);
  const [discrepancyReport, setDiscrepancyReport] = useState<any>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  useEffect(() => {
    if (open && period) {
      loadFeedbackFiles();
      loadDiscrepancyReport();
    }
  }, [open, period]);

  const loadFeedbackFiles = async () => {
    try {
      const response = await axios.get(
        `/api/finance/payment-management/periods/${period.id}/feedback`
      );
      setFeedbackFiles(response.data);
    } catch (error: any) {
      console.error('Error loading feedback files:', error);
    }
  };

  const loadDiscrepancyReport = async () => {
    try {
      const response = await axios.get(
        `/api/finance/payment-management/periods/${period.id}/discrepancy-report`
      );
      setDiscrepancyReport(response.data);
    } catch (error: any) {
      console.error('Error loading discrepancy report:', error);
    }
  };

  const handleDownloadBankFile = async (format: 'CSV' | 'EXCEL') => {
    if (!paymentDetails?.paymentId) {
      toast.error('No payment record found. Please authorize payment first.');
      return;
    }

    try {
      setLoading(true);
      const response = await axios.get(
        `/api/finance/payment-management/payments/${paymentDetails.paymentId}/bank-file`,
        {
          params: { format },
          responseType: 'blob',
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute(
        'download',
        `bank_file_${period.periodCode}.${format === 'CSV' ? 'csv' : 'xlsx'}`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();

      toast.success(`${format} bank file downloaded successfully`);
      onRefresh();
    } catch (error: any) {
      toast.error('Failed to download bank file');
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
    }
  };

  const handleUploadFeedback = async () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    try {
      setLoading(true);
      const formData = new FormData();
      formData.append('file', selectedFile);

      const response = await axios.post(
        `/api/finance/payment-management/periods/${period.id}/feedback`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
        }
      );

      if (response.data.success) {
        toast.success('Bank feedback file uploaded successfully');
        if (response.data.hasDiscrepancies) {
          toast.warning(`Found ${response.data.discrepancyCount} discrepancies`);
        }
        setSelectedFile(null);
        loadFeedbackFiles();
        loadDiscrepancyReport();
        onRefresh();
      }
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to upload feedback file');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'success';
      case 'PROCESSING':
        return 'warning';
      case 'FAILED':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6">Payment Management - {period?.periodName}</Typography>
          <IconButton onClick={onClose} size="small">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>

      <DialogContent>
        {/* Summary Cards */}
        <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ mb: 3 }}>
          <Card variant="outlined" sx={{ flex: 1 }}>
              <CardContent>
                <Typography color="text.secondary" variant="caption">
                  Period Status
                </Typography>
                <Typography variant="h6">
                  <Chip label={period?.status} color="primary" size="small" />
                </Typography>
              </CardContent>
            </Card>
          <Card variant="outlined" sx={{ flex: 1 }}>
              <CardContent>
                <Typography color="text.secondary" variant="caption">
                  Payment Status
                </Typography>
                <Typography variant="h6">
                  {paymentDetails?.paymentStatus ? (
                    <Chip
                      label={paymentDetails.paymentStatus}
                      color={getStatusColor(paymentDetails.paymentStatus) as any}
                      size="small"
                    />
                  ) : (
                    'Not Started'
                  )}
                </Typography>
              </CardContent>
            </Card>
          <Card variant="outlined" sx={{ flex: 1 }}>
              <CardContent>
                <Typography color="text.secondary" variant="caption">
                  Total Amount
                </Typography>
                <Typography variant="h6">
                  {paymentDetails?.totalAmount
                    ? `UGX ${Number(paymentDetails.totalAmount).toLocaleString()}`
                    : '-'}
                </Typography>
              </CardContent>
            </Card>
          <Card variant="outlined" sx={{ flex: 1 }}>
              <CardContent>
                <Typography color="text.secondary" variant="caption">
                  Feedback Files
                </Typography>
                <Typography variant="h6">{feedbackFiles.length}</Typography>
              </CardContent>
            </Card>
        </Stack>

        {/* Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)}>
            <Tab label="Bank Files" icon={<FileIcon />} iconPosition="start" />
            <Tab label="Feedback & Analysis" icon={<UploadIcon />} iconPosition="start" />
            <Tab label="Payment Actions" icon={<PaymentIcon />} iconPosition="start" />
          </Tabs>
        </Box>

        {/* Tab 1: Bank Files */}
        <TabPanel value={activeTab} index={0}>
          <Box>
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">
              Download Bank Transfer File
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Generate and download the bank file for uploading to your bank's system.
              Files are locked after first generation to prevent tampering.
            </Typography>

            {paymentDetails?.bankFileGenerated && (
              <Alert severity="success" sx={{ mb: 2 }}>
                Bank file already generated and locked. Downloads will return the same file.
              </Alert>
            )}

            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
              <Button
                  variant="contained"
                  fullWidth
                  startIcon={<DownloadIcon />}
                  onClick={() => handleDownloadBankFile('CSV')}
                  disabled={loading || !paymentDetails?.paymentId}
                >
                  Download CSV Format
                </Button>
              <Button
                  variant="contained"
                  color="secondary"
                  fullWidth
                  startIcon={<DownloadIcon />}
                  onClick={() => handleDownloadBankFile('EXCEL')}
                  disabled={loading || !paymentDetails?.paymentId}
                >
                  Download Excel Format
                </Button>
            </Stack>

            {!paymentDetails?.paymentId && (
              <Alert severity="info" sx={{ mt: 2 }}>
                Please authorize payment first before downloading bank files.
              </Alert>
            )}
          </Box>
        </TabPanel>

        {/* Tab 2: Feedback & Analysis */}
        <TabPanel value={activeTab} index={1}>
          <Box>
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">
              Upload Bank Feedback File
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Upload the acknowledgement/feedback file from your bank. System will
              automatically analyze for discrepancies and fraud detection.
            </Typography>

            <Box sx={{ mb: 3 }}>
              <input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileSelect}
                style={{ display: 'none' }}
                id="feedback-file-input"
              />
              <label htmlFor="feedback-file-input">
                <Button variant="outlined" component="span" fullWidth sx={{ mb: 2 }}>
                  {selectedFile ? selectedFile.name : 'Choose File'}
                </Button>
              </label>
              {selectedFile && (
                <Button
                  variant="contained"
                  fullWidth
                  startIcon={<UploadIcon />}
                  onClick={handleUploadFeedback}
                  disabled={loading}
                >
                  Upload Feedback File
                </Button>
              )}
            </Box>

            <Divider sx={{ my: 3 }} />

            {/* Discrepancy Report */}
            {discrepancyReport && (
              <Box>
                <Typography variant="subtitle1" gutterBottom fontWeight="bold">
                  Discrepancy Analysis
                </Typography>

                {discrepancyReport.hasDiscrepancies ? (
                  <Alert severity="warning" sx={{ mb: 2 }}>
                    <Typography variant="body2" fontWeight="bold">
                      {discrepancyReport.totalDiscrepancies} Discrepancies Found
                    </Typography>
                    <Typography variant="caption">
                      Review discrepancies before confirming payment
                    </Typography>
                  </Alert>
                ) : discrepancyReport.totalFeedbackFiles > 0 ? (
                  <Alert severity="success" sx={{ mb: 2 }}>
                    No discrepancies found. All records match.
                  </Alert>
                ) : (
                  <Alert severity="info" sx={{ mb: 2 }}>
                    No feedback files uploaded yet.
                  </Alert>
                )}

                {feedbackFiles.length > 0 && (
                  <TableContainer component={Paper} variant="outlined">
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>File Name</TableCell>
                          <TableCell>Uploaded</TableCell>
                          <TableCell align="right">Records</TableCell>
                          <TableCell align="right">Amount</TableCell>
                          <TableCell align="right">Discrepancies</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {feedbackFiles.map((file) => (
                          <TableRow key={file.id}>
                            <TableCell>{file.fileName}</TableCell>
                            <TableCell>
                              {new Date(file.uploadedAt).toLocaleString()}
                            </TableCell>
                            <TableCell align="right">{file.totalRecords}</TableCell>
                            <TableCell align="right">
                              {Number(file.totalAmount).toLocaleString()}
                            </TableCell>
                            <TableCell align="right">
                              {file.discrepancyCount > 0 ? (
                                <Chip
                                  label={file.discrepancyCount}
                                  color="warning"
                                  size="small"
                                  icon={<WarningIcon />}
                                />
                              ) : (
                                <Chip
                                  label="0"
                                  color="success"
                                  size="small"
                                  icon={<CheckIcon />}
                                />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
              </Box>
            )}
          </Box>
        </TabPanel>

        {/* Tab 3: Payment Actions */}
        <TabPanel value={activeTab} index={2}>
          <Box>
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">
              Payment Workflow Actions
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
              Execute payment actions in sequence: Authorize → Download File → Upload to
              Bank → Upload Feedback → Confirm Payment
            </Typography>

            <List>
              <ListItem>
                <ListItemIcon>
                  <PaymentIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary="1. Authorize Payment"
                  secondary="Create payment record and prepare for processing"
                />
                <Chip
                  label={paymentDetails?.paymentId ? 'Done' : 'Pending'}
                  color={paymentDetails?.paymentId ? 'success' : 'default'}
                  size="small"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <DownloadIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary="2. Download Bank File"
                  secondary="Download CSV/Excel file for bank upload"
                />
                <Chip
                  label={paymentDetails?.bankFileGenerated ? 'Done' : 'Pending'}
                  color={paymentDetails?.bankFileGenerated ? 'success' : 'default'}
                  size="small"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <UploadIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary="3. Upload to Bank System"
                  secondary="Upload file to your bank's portal (external)"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <ReceiptIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary="4. Upload Bank Feedback"
                  secondary="Upload acknowledgement file from bank"
                />
                <Chip
                  label={feedbackFiles.length > 0 ? 'Done' : 'Pending'}
                  color={feedbackFiles.length > 0 ? 'success' : 'default'}
                  size="small"
                />
              </ListItem>
              <ListItem>
                <ListItemIcon>
                  <CheckIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary="5. Confirm Payment"
                  secondary="Final confirmation - marks period as PAID"
                />
                <Chip
                  label={paymentDetails?.paymentConfirmed ? 'Done' : 'Pending'}
                  color={paymentDetails?.paymentConfirmed ? 'success' : 'default'}
                  size="small"
                />
              </ListItem>
            </List>

            {discrepancyReport?.hasDiscrepancies && (
              <Alert severity="error" sx={{ mt: 2 }}>
                Cannot confirm payment: {discrepancyReport.totalDiscrepancies}{' '}
                discrepancies found. Please resolve before confirming.
              </Alert>
            )}
          </Box>
        </TabPanel>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onRefresh}>
          Refresh
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PaymentManagementDialog;
