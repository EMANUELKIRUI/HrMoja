import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Avatar,
  Menu,
  MenuItem,
  Badge,
  Chip,
  Stack,
  Breadcrumbs,
  Link,
  alpha,
  useTheme,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  Business as BusinessIcon,
  People as PeopleIcon,
  Payment as PaymentIcon,
  Assessment as AssessmentIcon,
  Settings as SettingsIcon,
  CalendarMonth as CalendarIcon,
  AttachMoney as SalaryIcon,
  // Autorenew as ProcessingIcon,
  ViewModule as ComponentsIcon,
  ManageAccounts as ManageAccountsIcon,
  Security as SecurityIcon,
  Assignment as AssignmentIcon,
  AccountBalance as AccountBalanceIcon,
  VerifiedUser as VerifiedUserIcon,
  Work as HRIcon,
  AccountBalanceWallet as FinanceIcon,
  AdminPanelSettings as ExecutiveIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Home as HomeIcon,
  NavigateNext as NavigateNextIcon,
  Logout,
  AccountCircle,
  Notifications as NotificationsIcon,
} from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';

const DRAWER_WIDTH = 280;

const DashboardLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const { user, logout } = useAuthStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [openMenus, setOpenMenus] = useState<{ [key: string]: boolean }>({});

  // Toggle specific menu by its text/key (accordion behavior - only one open at a time)
  const toggleMenu = (menuText: string) => {
    setOpenMenus(prev => {
      const isCurrentlyOpen = prev[menuText];
      // If closing current menu, just close it
      if (isCurrentlyOpen) {
        return { ...prev, [menuText]: false };
      }
      // If opening new menu, close all others and open this one
      return { [menuText]: true };
    });
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleProfileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleProfileMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  // Define all possible menu items with permission requirements (using permission CODES)
  const allMenuItems = [
    { text: 'Dashboard', icon: <DashboardIcon />, path: '/dashboard', permission: null }, // Always visible
    { text: 'Organization', icon: <BusinessIcon />, path: '/organization', permission: 'SETTINGS_READ' },
    { text: 'Users', icon: <ManageAccountsIcon />, path: '/users', permission: 'USER_MANAGE' },
    { text: 'Roles', icon: <SecurityIcon />, path: '/roles', permission: 'ROLE_MANAGE' },
    { text: 'Employees', icon: <PeopleIcon />, path: '/employees', permission: 'EMPLOYEE_READ' },
    
    // Payroll Management - Setup & Configuration
    { 
      text: 'Payroll Management', 
      icon: <PaymentIcon />, 
      permission: 'PAYROLL_READ',
      subItems: [
        { text: 'Periods', icon: <CalendarIcon />, path: '/payroll/periods', permission: 'PAYROLL_PERIOD' },
        { text: 'Components', icon: <ComponentsIcon />, path: '/payroll/components', permission: 'PAYROLL_COMPONENT' },
        { text: 'Salary', icon: <SalaryIcon />, path: '/payroll/salary', permission: 'PAYROLL_SALARY' },
        // { text: 'Run Processing', icon: <ProcessingIcon />, path: '/payroll/processing', permission: 'PAYROLL_PROCESS' },
      ]
    },
    
    // HR Operations Module
    { 
      text: 'HR Operations', 
      icon: <HRIcon />, 
      permission: 'PAYROLL_PROCESS',
      subItems: [
        { text: 'Payroll Preparation', icon: <AssignmentIcon />, path: '/hr/payroll/prepare', permission: 'PAYROLL_PROCESS' },
      ]
    },
    
    // Finance Module
    { 
      text: 'Finance', 
      icon: <FinanceIcon />, 
      permission: 'FINANCE_VIEW',
      subItems: [
        { text: 'Payroll Review', icon: <AccountBalanceIcon />, path: '/finance/payroll/review', permission: 'PAYROLL_REVIEW' },
        { text: 'Payment Processing', icon: <PaymentIcon />, path: '/finance/payroll/payment', permission: 'PAYROLL_PAY' },
      ]
    },
    
    // Executive Module
    { 
      text: 'Executive', 
      icon: <ExecutiveIcon />, 
      permission: 'PAYROLL_APPROVE',
      subItems: [
        { text: 'Payroll Approval', icon: <VerifiedUserIcon />, path: '/executive/payroll/approval', permission: 'PAYROLL_APPROVE' },
      ]
    },
    
    { text: 'Reports', icon: <AssessmentIcon />, path: '/reports', permission: 'REPORTS_READ' },
    { text: 'Settings', icon: <SettingsIcon />, path: '/settings', permission: 'SETTINGS_READ' },
  ];

  // Filter menu items based on user permissions
  const menuItems = allMenuItems.filter(item => {
    if (!item.permission) return true; // Always show items without permission requirement
    return user?.permissions?.includes(item.permission);
  });

  // Get current path for breadcrumbs
  const pathSegments = location.pathname.split('/').filter(Boolean);
  const breadcrumbs = pathSegments.map((segment, index) => ({
    label: segment.charAt(0).toUpperCase() + segment.slice(1),
    path: '/' + pathSegments.slice(0, index + 1).join('/'),
  }));

  const drawer = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Sidebar Header */}
      <Box
        sx={{
          p: 3,
          background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
          color: 'white',
        }}
      >
        <Typography variant="h5" fontWeight="bold" sx={{ mb: 0.5 }}>
          HRMoja
        </Typography>
        <Typography variant="caption" sx={{ opacity: 0.9 }}>
          HR & Payroll System
        </Typography>
      </Box>

      {/* User Profile Section */}
      <Box sx={{ p: 2.5, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Avatar
            sx={{
              width: 48,
              height: 48,
              background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
              fontWeight: 600,
            }}
          >
            {user?.fullName?.charAt(0)}
          </Avatar>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="subtitle2" fontWeight={600} noWrap>
              {user?.fullName}
            </Typography>
            <Typography variant="caption" color="text.secondary" noWrap>
              {user?.roles?.[0] || 'User'}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Navigation Menu */}
      <List sx={{ flex: 1, px: 1.5, py: 2 }}>
        {menuItems.map((item) => {
          // Check if item has submenu
          if (item.subItems) {
            const isPayrollActive = location.pathname.includes('/payroll');
            return (
              <Box key={item.text}>
                <ListItem disablePadding sx={{ mb: 0.5 }}>
                  <ListItemButton
                    onClick={() => toggleMenu(item.text)}
                    sx={{
                      borderRadius: 2,
                      py: 1.25,
                      backgroundColor: isPayrollActive ? alpha(theme.palette.primary.main, 0.08) : 'transparent',
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        color: isPayrollActive ? 'primary.main' : 'text.secondary',
                        minWidth: 40,
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={item.text}
                      primaryTypographyProps={{
                        fontWeight: isPayrollActive ? 600 : 500,
                        fontSize: '0.938rem',
                      }}
                    />
                    {openMenus[item.text] ? <ExpandLessIcon /> : <ExpandMoreIcon />}
                  </ListItemButton>
                </ListItem>
                
                {/* Submenu Items */}
                {openMenus[item.text] && (
                  <List component="div" disablePadding>
                    {item.subItems.map((subItem) => {
                      if (!subItem.permission || user?.permissions?.includes(subItem.permission)) {
                        const isSubActive = location.pathname === subItem.path;
                        return (
                          <ListItem key={subItem.text} disablePadding sx={{ mb: 0.5 }}>
                            <ListItemButton
                              onClick={() => navigate(subItem.path)}
                              selected={isSubActive}
                              sx={{
                                borderRadius: 2,
                                py: 1,
                                pl: 7,
                                '&.Mui-selected': {
                                  backgroundColor: alpha(theme.palette.primary.main, 0.12),
                                  '&:hover': {
                                    backgroundColor: alpha(theme.palette.primary.main, 0.16),
                                  },
                                },
                              }}
                            >
                              <ListItemIcon
                                sx={{
                                  color: isSubActive ? 'primary.main' : 'text.secondary',
                                  minWidth: 36,
                                }}
                              >
                                {subItem.icon}
                              </ListItemIcon>
                              <ListItemText
                                primary={subItem.text}
                                primaryTypographyProps={{
                                  fontWeight: isSubActive ? 600 : 500,
                                  fontSize: '0.875rem',
                                }}
                              />
                            </ListItemButton>
                          </ListItem>
                        );
                      }
                      return null;
                    })}
                  </List>
                )}
              </Box>
            );
          }
          
          // Regular menu item without submenu
          const isActive = Boolean(item.path && location.pathname.includes(item.path));
          return (
            <ListItem key={item.text} disablePadding sx={{ mb: 0.5 }}>
              <ListItemButton
                onClick={() => item.path && navigate(item.path)}
                selected={isActive}
                sx={{
                  borderRadius: 2,
                  py: 1.25,
                  '&.Mui-selected': {
                    backgroundColor: alpha(theme.palette.primary.main, 0.12),
                    '&:hover': {
                      backgroundColor: alpha(theme.palette.primary.main, 0.16),
                    },
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    color: isActive ? 'primary.main' : 'text.secondary',
                    minWidth: 40,
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                <ListItemText
                  primary={item.text}
                  primaryTypographyProps={{
                    fontWeight: isActive ? 600 : 500,
                    fontSize: '0.938rem',
                  }}
                />
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>

      {/* Sidebar Footer */}
      <Box sx={{ p: 2, borderTop: '1px solid', borderColor: 'divider' }}>
        <Chip
          label="v1.0.0"
          size="small"
          sx={{
            fontWeight: 500,
            backgroundColor: alpha(theme.palette.primary.main, 0.1),
            color: 'primary.main',
          }}
        />
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      {/* AppBar */}
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          width: { sm: `calc(100% - ${DRAWER_WIDTH}px)` },
          ml: { sm: `${DRAWER_WIDTH}px` },
          backgroundColor: 'background.paper',
          color: 'text.primary',
          borderBottom: '1px solid',
          borderColor: 'divider',
        }}
      >
        <Toolbar sx={{ py: 1 }}>
          <IconButton
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>

          {/* Breadcrumbs */}
          <Box sx={{ flexGrow: 1 }}>
            <Breadcrumbs
              separator={<NavigateNextIcon fontSize="small" />}
              aria-label="breadcrumb"
            >
              <Link
                component="button"
                onClick={() => navigate('/dashboard')}
                underline="hover"
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  color: 'text.secondary',
                  fontSize: '0.875rem',
                }}
              >
                <HomeIcon sx={{ fontSize: 18 }} />
                Home
              </Link>
              {breadcrumbs.map((crumb, index) => (
                <Typography
                  key={index}
                  color={index === breadcrumbs.length - 1 ? 'text.primary' : 'text.secondary'}
                  fontSize="0.875rem"
                  fontWeight={index === breadcrumbs.length - 1 ? 600 : 400}
                >
                  {crumb.label}
                </Typography>
              ))}
            </Breadcrumbs>
          </Box>

          {/* Right Side Actions */}
          <Stack direction="row" spacing={1} alignItems="center">
            <IconButton size="large">
              <Badge badgeContent={3} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>

            <Divider orientation="vertical" flexItem sx={{ mx: 1 }} />

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <Box sx={{ textAlign: 'right', display: { xs: 'none', sm: 'block' } }}>
                <Typography variant="body2" fontWeight={600}>
                  {user?.fullName}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {user?.roles?.[0] || 'User'}
                </Typography>
              </Box>
              <IconButton onClick={handleProfileMenuOpen} sx={{ p: 0.5 }}>
                <Avatar
                  sx={{
                    width: 40,
                    height: 40,
                    background: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
                    fontWeight: 600,
                  }}
                >
                  {user?.fullName?.charAt(0)}
                </Avatar>
              </IconButton>
            </Box>
          </Stack>
        </Toolbar>
      </AppBar>

      {/* User Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleProfileMenuClose}
        PaperProps={{
          elevation: 3,
          sx: {
            mt: 1.5,
            minWidth: 200,
            borderRadius: 2,
            '& .MuiMenuItem-root': {
              px: 2,
              py: 1.25,
              borderRadius: 1,
              mx: 1,
              my: 0.5,
            },
          },
        }}
      >
        <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="subtitle2" fontWeight={600}>
            {user?.fullName}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {user?.email}
          </Typography>
        </Box>
        <MenuItem onClick={handleProfileMenuClose}>
          <ListItemIcon>
            <AccountCircle fontSize="small" />
          </ListItemIcon>
          My Profile
        </MenuItem>
        <MenuItem onClick={handleProfileMenuClose}>
          <ListItemIcon>
            <SettingsIcon fontSize="small" />
          </ListItemIcon>
          Settings
        </MenuItem>
        <Divider sx={{ my: 1 }} />
        <MenuItem onClick={handleLogout} sx={{ color: 'error.main' }}>
          <ListItemIcon sx={{ color: 'error.main' }}>
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
        </MenuItem>
      </Menu>

      <Box
        component="nav"
        sx={{ width: { sm: DRAWER_WIDTH }, flexShrink: { sm: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: DRAWER_WIDTH },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: DRAWER_WIDTH },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          width: { sm: `calc(100% - ${DRAWER_WIDTH}px)` },
          minHeight: '100vh',
          bgcolor: 'background.default',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <Toolbar sx={{ py: 1 }} />
        <Box sx={{ flexGrow: 1, p: { xs: 2, sm: 3, md: 4 } }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
};

export default DashboardLayout;
