import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Chip,
  CircularProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  FormControlLabel,
  Checkbox,
  Grid,
  Alert,
} from '@mui/material';
import { ExpandMore as ExpandMoreIcon } from '@mui/icons-material';
import { roleManagementApi, type RoleDto } from '../../api/role-management.api';
import { permissionManagementApi, type PermissionDto } from '../../api/permission-management.api';

interface ManageRolePermissionsDialogProps {
  open: boolean;
  onClose: () => void;
  role: RoleDto | null;
}

const ManageRolePermissionsDialog = ({ open, onClose, role }: ManageRolePermissionsDialogProps) => {
  const queryClient = useQueryClient();
  const [selectedPermissions, setSelectedPermissions] = useState<Set<number>>(new Set());
  const [initialPermissions, setInitialPermissions] = useState<Set<number>>(new Set());

  // Fetch all permissions
  const { data: permissionsResponse, isLoading: permissionsLoading } = useQuery({
    queryKey: ['permissions'],
    queryFn: permissionManagementApi.getAllPermissions,
    enabled: open,
  });

  const permissions = permissionsResponse?.data || [];

  // Group permissions by module
  const groupedPermissions = permissions.reduce((acc, perm) => {
    if (!acc[perm.module]) {
      acc[perm.module] = [];
    }
    acc[perm.module].push(perm);
    return acc;
  }, {} as Record<string, PermissionDto[]>);

  // Initialize selected permissions
  useEffect(() => {
    if (role?.permissionIds) {
      const initialSet = new Set(role.permissionIds);
      setSelectedPermissions(initialSet);
      setInitialPermissions(initialSet);
    }
  }, [role, open]);

  // Add permissions mutation
  const addPermissionsMutation = useMutation({
    mutationFn: ({ roleId, permissionIds }: { roleId: number; permissionIds: number[] }) =>
      roleManagementApi.addPermissionsToRole(roleId, permissionIds),
  });

  // Remove permissions mutation
  const removePermissionsMutation = useMutation({
    mutationFn: ({ roleId, permissionIds }: { roleId: number; permissionIds: number[] }) =>
      roleManagementApi.removePermissionsFromRole(roleId, permissionIds),
  });

  const handlePermissionToggle = (permissionId: number) => {
    const newSelected = new Set(selectedPermissions);
    if (newSelected.has(permissionId)) {
      newSelected.delete(permissionId);
    } else {
      newSelected.add(permissionId);
    }
    setSelectedPermissions(newSelected);
  };

  const handleSelectAllInModule = (module: string) => {
    const modulePerms = groupedPermissions[module];
    const allSelected = modulePerms.every((p) => selectedPermissions.has(p.id!));

    const newSelected = new Set(selectedPermissions);
    modulePerms.forEach((p) => {
      if (allSelected) {
        newSelected.delete(p.id!);
      } else {
        newSelected.add(p.id!);
      }
    });
    setSelectedPermissions(newSelected);
  };

  const handleSave = async () => {
    if (!role?.id) return;

    try {
      // Calculate permissions to add and remove
      const toAdd = Array.from(selectedPermissions).filter((id) => !initialPermissions.has(id));
      const toRemove = Array.from(initialPermissions).filter((id) => !selectedPermissions.has(id));

      // Execute mutations
      if (toAdd.length > 0) {
        await addPermissionsMutation.mutateAsync({ roleId: role.id, permissionIds: toAdd });
      }
      if (toRemove.length > 0) {
        await removePermissionsMutation.mutateAsync({ roleId: role.id, permissionIds: toRemove });
      }

      // Invalidate queries to refresh the data
      await queryClient.invalidateQueries({ queryKey: ['roles'] });
      
      // Close dialog after successful update
      onClose();
    } catch (error: any) {
      console.error('Failed to update permissions:', error);
      alert('Failed to update permissions. Please try again.');
    }
  };

  const isLoading = addPermissionsMutation.isPending || removePermissionsMutation.isPending;
  const hasChanges = !areSetsEqual(selectedPermissions, initialPermissions);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box>
          <Typography variant="h6" fontWeight="bold">
            Manage Permissions
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {role?.name}
          </Typography>
        </Box>
      </DialogTitle>
      <DialogContent dividers>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="subtitle2" fontWeight="bold">
              Select permissions to assign to this role
            </Typography>
            <Chip
              label={`${selectedPermissions.size} / ${permissions.length} selected`}
              color="primary"
              size="small"
            />
          </Box>

          {permissionsLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : permissions.length === 0 ? (
            <Alert severity="info">No permissions available</Alert>
          ) : (
            <Box sx={{ maxHeight: 500, overflowY: 'auto' }}>
              {Object.entries(groupedPermissions).map(([module, perms]) => {
                const selectedCount = perms.filter((p) => selectedPermissions.has(p.id!)).length;
                const allSelected = selectedCount === perms.length;

                return (
                  <Accordion key={module} defaultExpanded>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={allSelected}
                              indeterminate={selectedCount > 0 && !allSelected}
                              onChange={() => handleSelectAllInModule(module)}
                              onClick={(e) => e.stopPropagation()}
                            />
                          }
                          label={
                            <Typography fontWeight="bold">
                              {module.toUpperCase()} ({selectedCount}/{perms.length})
                            </Typography>
                          }
                          onClick={(e) => e.stopPropagation()}
                        />
                      </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Grid container spacing={1}>
                        {perms.map((perm) => (
                          <Grid size={{ xs: 12, sm: 6 }} key={perm.id}>
                            <FormControlLabel
                              control={
                                <Checkbox
                                  checked={selectedPermissions.has(perm.id!)}
                                  onChange={() => handlePermissionToggle(perm.id!)}
                                  size="small"
                                />
                              }
                              label={
                                <Box>
                                  <Typography variant="body2" fontWeight={500}>
                                    {perm.name}
                                  </Typography>
                                  <Typography variant="caption" color="text.secondary">
                                    {perm.code}
                                  </Typography>
                                </Box>
                              }
                            />
                          </Grid>
                        ))}
                      </Grid>
                    </AccordionDetails>
                  </Accordion>
                );
              })}
            </Box>
          )}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={isLoading}>
          Cancel
        </Button>
        <Button onClick={handleSave} variant="contained" disabled={isLoading || !hasChanges}>
          {isLoading ? <CircularProgress size={24} /> : 'Save Changes'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// Helper function to compare sets
function areSetsEqual<T>(set1: Set<T>, set2: Set<T>): boolean {
  if (set1.size !== set2.size) return false;
  for (const item of set1) {
    if (!set2.has(item)) return false;
  }
  return true;
}

export default ManageRolePermissionsDialog;
