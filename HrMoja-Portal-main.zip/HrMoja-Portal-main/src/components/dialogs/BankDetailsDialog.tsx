import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  Alert,
  CircularProgress,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Typography,
  Autocomplete,
} from '@mui/material';
import { toast } from 'react-toastify';
import { employeeBankApi, type EmployeeBankDetails } from '../../api/employee-bank.api';
import { banksApi, type Bank, type BankBranch } from '../../api/banks.api';

interface BankDetailsDialogProps {
  open: boolean;
  onClose: () => void;
  employeeId: number;
  employeeName: string;
  onSuccess?: () => void;
}

const BankDetailsDialog: React.FC<BankDetailsDialogProps> = ({
  open,
  onClose,
  employeeId,
  employeeName,
  onSuccess,
}) => {
  const [loading, setLoading] = useState(false);
  const [loadingBanks, setLoadingBanks] = useState(false);
  const [banks, setBanks] = useState<Bank[]>([]);
  const [branches, setBranches] = useState<BankBranch[]>([]);
  const [existingDetails, setExistingDetails] = useState<EmployeeBankDetails | null>(null);
  
  const [formData, setFormData] = useState({
    bankId: '',
    bankBranchId: '',
    accountNumber: '',
    accountName: '',
    accountType: 'SAVINGS',
    primary: true,
  });

  useEffect(() => {
    if (open) {
      loadBanks();
      loadExistingBankDetails();
    }
  }, [open, employeeId]);

  useEffect(() => {
    if (formData.bankId) {
      loadBankBranches(Number(formData.bankId));
    }
  }, [formData.bankId]);

  const loadBanks = async () => {
    try {
      setLoadingBanks(true);
      const response = await banksApi.getActiveBanks();
      setBanks(response.data || []);
    } catch (error) {
      toast.error('Failed to load banks');
    } finally {
      setLoadingBanks(false);
    }
  };

  const loadBankBranches = async (bankId: number) => {
    try {
      const response = await banksApi.getBankBranches(bankId);
      setBranches(response.data || []);
    } catch (error) {
      toast.error('Failed to load bank branches');
      setBranches([]);
    }
  };

  const loadExistingBankDetails = async () => {
    try {
      const response = await employeeBankApi.getPrimaryBankDetails(employeeId);
      if (response.data) {
        setExistingDetails(response.data);
        setFormData({
          bankId: response.data.bankId?.toString() || '',
          bankBranchId: response.data.bankBranchId?.toString() || '',
          accountNumber: response.data.accountNumber || '',
          accountName: response.data.accountName || '',
          accountType: response.data.accountType || 'SAVINGS',
          primary: response.data.primary ?? true,
        });
      }
    } catch (error) {
      // No existing bank details, that's okay
      console.log('No existing bank details found');
    }
  };

  const handleSubmit = async () => {
    // Validation
    if (!formData.bankId || !formData.accountNumber || !formData.accountName) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      const bankDetailsData: EmployeeBankDetails = {
        employeeId: employeeId,
        bankId: Number(formData.bankId),
        bankBranchId: formData.bankBranchId ? Number(formData.bankBranchId) : undefined,
        accountNumber: formData.accountNumber,
        accountName: formData.accountName,
        accountType: formData.accountType,
        primary: formData.primary,
      };

      if (existingDetails?.id) {
        // Update existing
        await employeeBankApi.updateBankDetails(employeeId, existingDetails.id, bankDetailsData);
        toast.success('Bank details updated successfully');
      } else {
        // Create new
        await employeeBankApi.createBankDetails(bankDetailsData);
        toast.success('Bank details added successfully');
      }

      onSuccess?.();
      onClose();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to save bank details');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      onClose();
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        Update Bank Details - {employeeName}
      </DialogTitle>
      <DialogContent>
        <Alert severity="info" sx={{ mb: 3, mt: 1 }}>
          Bank details are required for payroll processing. Please provide accurate information.
        </Alert>

        {loadingBanks ? (
          <Box display="flex" justifyContent="center" py={3}>
            <CircularProgress />
          </Box>
        ) : (
          <Box display="flex" flexDirection="column" gap={2}>
            <Autocomplete
              fullWidth
              options={banks}
              getOptionLabel={(option) => option.name || ''}
              value={banks.find(b => b.id === Number(formData.bankId)) || null}
              onChange={(_, newValue) => {
                setFormData({ 
                  ...formData, 
                  bankId: newValue ? newValue.id.toString() : '', 
                  bankBranchId: '' 
                });
              }}
              disabled={loading}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Bank"
                  required
                  placeholder="Search for a bank..."
                />
              )}
              isOptionEqualToValue={(option, value) => option.id === value.id}
              noOptionsText="No banks found"
              ListboxProps={{
                style: { maxHeight: '250px' }
              }}
            />

            {branches.length > 0 && (
              <Autocomplete
                fullWidth
                options={branches}
                getOptionLabel={(option) => option.name || ''}
                value={branches.find(b => b.id === Number(formData.bankBranchId)) || null}
                onChange={(_, newValue) => {
                  setFormData({ 
                    ...formData, 
                    bankBranchId: newValue ? newValue.id.toString() : '' 
                  });
                }}
                disabled={loading}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Branch (Optional)"
                    placeholder="Search for a branch..."
                  />
                )}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                noOptionsText="No branches found"
                ListboxProps={{
                  style: { maxHeight: '200px' }
                }}
              />
            )}

            <TextField
              fullWidth
              label="Account Number"
              value={formData.accountNumber}
              onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
              required
              disabled={loading}
              placeholder="e.g., 1234567890"
            />

            <TextField
              fullWidth
              label="Account Name"
              value={formData.accountName}
              onChange={(e) => setFormData({ ...formData, accountName: e.target.value })}
              required
              disabled={loading}
              placeholder="Name as it appears on the account"
              helperText="Must match the name on your bank account"
            />

            <TextField
              select
              fullWidth
              label="Account Type"
              value={formData.accountType}
              onChange={(e) => setFormData({ ...formData, accountType: e.target.value })}
              disabled={loading}
            >
              <MenuItem value="SAVINGS">Savings Account</MenuItem>
              <MenuItem value="CURRENT">Current Account</MenuItem>
              <MenuItem value="CHECKING">Checking Account</MenuItem>
            </TextField>

            <FormControlLabel
              control={
                <Checkbox
                  checked={formData.primary}
                  onChange={(e) => setFormData({ ...formData, primary: e.target.checked })}
                  disabled={loading}
                />
              }
              label={
                <Typography variant="body2">
                  Set as primary account for payroll payments
                </Typography>
              }
            />
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} disabled={loading}>
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          color="primary"
          disabled={loading || loadingBanks}
        >
          {loading ? <CircularProgress size={24} /> : existingDetails ? 'Update' : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default BankDetailsDialog;
