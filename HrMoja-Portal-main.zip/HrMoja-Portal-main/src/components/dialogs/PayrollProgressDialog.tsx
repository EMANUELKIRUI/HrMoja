import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  Box,
  Typography,
  LinearProgress,
  Alert,
  CircularProgress,
  Button,
  DialogActions,
} from '@mui/material';
import {
  CheckCircle as SuccessIcon,
  Error as ErrorIcon,
  Timelapse as ProcessingIcon,
} from '@mui/icons-material';
import payrollApi, { type PayrollJobStatus } from '../../api/payrollApi';

interface PayrollProgressDialogProps {
  open: boolean;
  periodId: number;
  jobId: number;
  onClose: () => void;
  onComplete: () => void;
}

const PayrollProgressDialog: React.FC<PayrollProgressDialogProps> = ({
  open,
  periodId,
  jobId,
  onClose,
  onComplete,
}) => {
  const [jobStatus, setJobStatus] = useState<PayrollJobStatus | null>(null);
  const [polling, setPolling] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !periodId) {
      setPolling(false);
      return;
    }

    setPolling(true);
    setError(null);

    // Poll for status updates every 2 seconds
    const pollInterval = setInterval(async () => {
      try {
        const status = await payrollApi.getJobStatus(periodId);
        setJobStatus(status);

        // Stop polling if job is finished
        if (status.status === 'COMPLETED' || status.status === 'FAILED' || status.status === 'CANCELLED') {
          setPolling(false);
          clearInterval(pollInterval);
          
          // Auto-close and notify on success after 10 seconds
          if (status.status === 'COMPLETED') {
            setTimeout(() => {
              onComplete();
            }, 10000);
          }
        }
      } catch (err: any) {
        console.error('Error polling job status:', err);
        setError('Failed to get job status');
        setPolling(false);
        clearInterval(pollInterval);
      }
    }, 2000);

    // Initial fetch
    payrollApi.getJobStatus(periodId)
      .then(setJobStatus)
      .catch(err => {
        console.error('Error fetching initial job status:', err);
        setError('Failed to get job status');
      });

    return () => {
      clearInterval(pollInterval);
    };
  }, [open, periodId, onComplete]);

  const getStatusIcon = () => {
    if (!jobStatus) return <CircularProgress size={48} />;

    switch (jobStatus.status) {
      case 'COMPLETED':
        return <SuccessIcon sx={{ fontSize: 48, color: 'success.main' }} />;
      case 'FAILED':
        return <ErrorIcon sx={{ fontSize: 48, color: 'error.main' }} />;
      case 'PROCESSING':
      case 'QUEUED':
        return <ProcessingIcon sx={{ fontSize: 48, color: 'primary.main' }} />;
      default:
        return <CircularProgress size={48} />;
    }
  };

  const getStatusColor = () => {
    if (!jobStatus) return 'info';
    
    switch (jobStatus.status) {
      case 'COMPLETED':
        return 'success';
      case 'FAILED':
        return 'error';
      case 'PROCESSING':
        return 'primary';
      case 'QUEUED':
        return 'info';
      default:
        return 'info';
    }
  };

  const formatDuration = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  };

  const canClose = !polling || jobStatus?.status === 'COMPLETED' || jobStatus?.status === 'FAILED';

  return (
    <Dialog 
      open={open} 
      onClose={canClose ? onClose : undefined}
      maxWidth="sm" 
      fullWidth
      disableEscapeKeyDown={!canClose}
    >
      <DialogTitle>
        <Box display="flex" alignItems="center" gap={2}>
          {getStatusIcon()}
          <Box flex={1}>
            <Typography variant="h6">
              {jobStatus?.status === 'COMPLETED' ? 'Payroll Processing Complete' :
               jobStatus?.status === 'FAILED' ? 'Payroll Processing Failed' :
               jobStatus?.status === 'QUEUED' ? 'Queued for Processing' :
               'Processing Payroll'}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Period ID: {periodId} | Job ID: {jobId}
            </Typography>
          </Box>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {jobStatus && (
          <Box>
            {/* Progress Bar */}
            <Box mb={3}>
              <Box display="flex" justifyContent="space-between" mb={1}>
                <Typography variant="body2" color="text.secondary">
                  Progress
                </Typography>
                <Typography variant="body2" fontWeight="medium">
                  {jobStatus.progressPercentage}%
                </Typography>
              </Box>
              <LinearProgress 
                variant="determinate" 
                value={jobStatus.progressPercentage} 
                color={getStatusColor() as any}
                sx={{ height: 8, borderRadius: 1 }}
              />
            </Box>

            {/* Employee Count */}
            <Box mb={2}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Employees Processed
              </Typography>
              <Typography variant="h6">
                {jobStatus.processedEmployees} / {jobStatus.totalEmployees}
              </Typography>
              {jobStatus.failedEmployees > 0 && (
                <Typography variant="body2" color="error" sx={{ mt: 0.5 }}>
                  {jobStatus.failedEmployees} failed
                </Typography>
              )}
            </Box>

            {/* Status Message */}
            {jobStatus.statusMessage && (
              <Alert severity={getStatusColor() as any} sx={{ mb: 2 }}>
                {jobStatus.statusMessage}
              </Alert>
            )}

            {/* Error Message */}
            {jobStatus.errorMessage && (
              <Alert severity="error" sx={{ mb: 2 }}>
                <Typography variant="subtitle2" fontWeight="bold">
                  Error Details
                </Typography>
                <Typography variant="body2" sx={{ mt: 1 }}>
                  {jobStatus.errorMessage}
                </Typography>
              </Alert>
            )}

            {/* Timing Info */}
            {jobStatus.startedAt && (
              <Box mt={2} p={2} bgcolor="background.default" borderRadius={1}>
                <Typography variant="body2" color="text.secondary">
                  Started: {new Date(jobStatus.startedAt).toLocaleTimeString()}
                </Typography>
                {jobStatus.completedAt && (
                  <>
                    <Typography variant="body2" color="text.secondary">
                      Completed: {new Date(jobStatus.completedAt).toLocaleTimeString()}
                    </Typography>
                    {jobStatus.durationSeconds && (
                      <Typography variant="body2" color="text.secondary">
                        Duration: {formatDuration(jobStatus.durationSeconds)}
                      </Typography>
                    )}
                  </>
                )}
              </Box>
            )}
          </Box>
        )}

        {!jobStatus && !error && (
          <Box display="flex" justifyContent="center" alignItems="center" py={4}>
            <CircularProgress />
            <Typography variant="body2" color="text.secondary" ml={2}>
              Loading job status...
            </Typography>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        {canClose && (
          <Button onClick={onClose} variant="outlined">
            Close
          </Button>
        )}
        {jobStatus?.status === 'PROCESSING' && (
          <Typography variant="caption" color="text.secondary" sx={{ flex: 1, pl: 2 }}>
            Processing... Please wait
          </Typography>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default PayrollProgressDialog;
