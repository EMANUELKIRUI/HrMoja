import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  CircularProgress,
  Typography,
  Paper,
  Stack,
  Chip,
  Alert,
} from '@mui/material';
import {
  AccountBalance as BankIcon,
  CheckCircle as CheckIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';
import { employeeBankApi, type EmployeeBankDetails } from '../../api/employee-bank.api';

interface ViewBankDetailsDialogProps {
  open: boolean;
  onClose: () => void;
  employeeId: number;
  employeeName: string;
}

const ViewBankDetailsDialog: React.FC<ViewBankDetailsDialogProps> = ({
  open,
  onClose,
  employeeId,
  employeeName,
}) => {
  const [loading, setLoading] = useState(false);
  const [bankDetails, setBankDetails] = useState<EmployeeBankDetails | null>(null);

  useEffect(() => {
    if (open && employeeId) {
      loadBankDetails();
    }
  }, [open, employeeId]);

  const loadBankDetails = async () => {
    try {
      setLoading(true);
      const response = await employeeBankApi.getPrimaryBankDetails(employeeId);
      setBankDetails(response.data);
    } catch (error: any) {
      setBankDetails(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box display="flex" alignItems="center" gap={1}>
          <BankIcon color="primary" />
          <Typography variant="h6">
            Bank Details - {employeeName}
          </Typography>
        </Box>
      </DialogTitle>
      <DialogContent>
        {loading ? (
          <Box display="flex" justifyContent="center" py={4}>
            <CircularProgress />
          </Box>
        ) : bankDetails ? (
          <>
            <Alert severity="info" sx={{ mb: 3 }}>
              <Typography variant="body2">
                View-only mode. Bank details can only be updated by HR department.
              </Typography>
            </Alert>

            <Paper variant="outlined" sx={{ p: 3, bgcolor: 'grey.50' }}>
              <Stack spacing={2.5}>
                <Box>
                  <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                    Bank Name
                  </Typography>
                  <Typography variant="body1" fontWeight="medium">
                    {bankDetails.bankName || 'N/A'}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                    Branch
                  </Typography>
                  <Typography variant="body1" fontWeight="medium">
                    {bankDetails.bankBranchName || 'N/A'}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                    Account Number
                  </Typography>
                  <Typography variant="body1" fontWeight="medium" fontFamily="monospace">
                    {bankDetails.accountNumber}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                    Account Name
                  </Typography>
                  <Typography variant="body1" fontWeight="medium">
                    {bankDetails.accountName}
                  </Typography>
                </Box>

                <Box>
                  <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                    Account Type
                  </Typography>
                  <Chip 
                    label={bankDetails.accountType} 
                    size="small" 
                    color="primary" 
                    variant="outlined"
                  />
                </Box>

                {bankDetails.primary && (
                  <Box>
                    <Chip 
                      icon={<CheckIcon />}
                      label="Primary Account" 
                      size="small" 
                      color="success"
                    />
                  </Box>
                )}

                {bankDetails.swiftCode && (
                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                      SWIFT Code
                    </Typography>
                    <Typography variant="body1" fontWeight="medium" fontFamily="monospace">
                      {bankDetails.swiftCode}
                    </Typography>
                  </Box>
                )}

                {bankDetails.iban && (
                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
                      IBAN
                    </Typography>
                    <Typography variant="body1" fontWeight="medium" fontFamily="monospace">
                      {bankDetails.iban}
                    </Typography>
                  </Box>
                )}

                {bankDetails.active !== undefined && (
                  <Box>
                    <Chip 
                      icon={<CheckIcon />}
                      label={bankDetails.active ? "Active" : "Inactive"} 
                      size="small" 
                      color={bankDetails.active ? "success" : "default"}
                    />
                  </Box>
                )}
              </Stack>
            </Paper>
          </>
        ) : (
          <Alert severity="warning" icon={<WarningIcon />}>
            <Typography variant="body2">
              No bank details found for this employee. Bank details must be added by HR department.
            </Typography>
          </Alert>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant="contained">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ViewBankDetailsDialog;
