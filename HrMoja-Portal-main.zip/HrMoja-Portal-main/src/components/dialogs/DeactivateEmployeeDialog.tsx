import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  Typography,
  Alert,
  CircularProgress,
} from '@mui/material';
import { Warning as WarningIcon } from '@mui/icons-material';
import { employeesApi } from '../../api/employees.api';
import { toast } from 'react-toastify';

interface Employee {
  id?: number;
  employeeNumber?: string;
  firstName: string;
  lastName: string;
}

interface DeactivateEmployeeDialogProps {
  open: boolean;
  employee: Employee | null;
  onClose: () => void;
  onSuccess: () => void;
}

const DeactivateEmployeeDialog: React.FC<DeactivateEmployeeDialogProps> = ({
  open,
  employee,
  onClose,
  onSuccess,
}) => {
  const [reason, setReason] = useState('');
  const [deactivating, setDeactivating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleClose = () => {
    if (!deactivating) {
      setReason('');
      setError(null);
      onClose();
    }
  };

  const handleDeactivate = async () => {
    if (!employee) return;
    
    if (!reason.trim()) {
      setError('Please provide a reason for deactivation');
      return;
    }

    try {
      setDeactivating(true);
      setError(null);
      await employeesApi.deactivateEmployee(employee.id!, reason);
      toast.success('Employee deactivated successfully');
      setReason('');
      onClose();
      onSuccess();
    } catch (err: any) {
      const errorMessage = err.response?.data?.message || 'Failed to deactivate employee';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setDeactivating(false);
    }
  };

  if (!employee) return null;

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box display="flex" alignItems="center" gap={1}>
          <WarningIcon color="error" />
          <Typography variant="h6" component="span">
            Deactivate Employee
          </Typography>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Alert severity="warning" sx={{ mb: 2 }}>
          <Typography variant="subtitle2" fontWeight="bold">
            Warning: This action will deactivate the employee
          </Typography>
          <Typography variant="body2" sx={{ mt: 1 }}>
            Deactivating an employee will:
          </Typography>
          <ul style={{ margin: '8px 0 0 0', paddingLeft: '20px' }}>
            <li>Remove them from active payroll processing</li>
            <li>Mark their status as inactive</li>
            <li>Preserve their records for historical purposes</li>
          </ul>
        </Alert>

        <Box mb={2}>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Employee Details
          </Typography>
          <Typography variant="body1" fontWeight="medium">
            {employee.firstName} {employee.lastName}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Employee #: {employee.employeeNumber}
          </Typography>
        </Box>

        <TextField
          fullWidth
          label="Reason for Deactivation"
          multiline
          rows={4}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          error={!!error && !reason.trim()}
          helperText={error && !reason.trim() ? error : 'Please provide a detailed reason for deactivation'}
          required
          disabled={deactivating}
          placeholder="e.g., Resignation, Termination, End of Contract, etc."
        />

        {error && reason.trim() && (
          <Alert severity="error" sx={{ mt: 2 }}>
            {error}
          </Alert>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={handleClose} disabled={deactivating}>
          Cancel
        </Button>
        <Button
          variant="contained"
          color="error"
          onClick={handleDeactivate}
          disabled={deactivating || !reason.trim()}
          startIcon={deactivating ? <CircularProgress size={16} /> : null}
        >
          {deactivating ? 'Deactivating...' : 'Deactivate Employee'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeactivateEmployeeDialog;
