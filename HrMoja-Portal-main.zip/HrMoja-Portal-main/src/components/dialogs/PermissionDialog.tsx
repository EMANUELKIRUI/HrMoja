import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  Grid,
  CircularProgress,
  MenuItem,
} from '@mui/material';
import { permissionManagementApi, type PermissionDto, type PermissionCreateRequest } from '../../api/permission-management.api';

interface PermissionDialogProps {
  open: boolean;
  onClose: () => void;
  permission?: PermissionDto | null;
}

const MODULES = [
  'USER',
  'EMPLOYEE',
  'DEPARTMENT',
  'PAYROLL',
  'LEAVE',
  'ATTENDANCE',
  'ROLE',
  'REPORT',
  'FINANCE',
  'HR',
  'EXECUTIVE',
  'SYSTEM',
];

const PermissionDialog = ({ open, onClose, permission }: PermissionDialogProps) => {
  const queryClient = useQueryClient();
  const isEditMode = !!permission;

  const [formData, setFormData] = useState<PermissionCreateRequest>({
    name: '',
    code: '',
    description: '',
    module: '',
  });

  // Initialize form when editing
  useEffect(() => {
    if (permission) {
      setFormData({
        name: permission.name,
        code: permission.code,
        description: permission.description || '',
        module: permission.module,
      });
    } else {
      setFormData({
        name: '',
        code: '',
        description: '',
        module: '',
      });
    }
  }, [permission, open]);

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: PermissionCreateRequest) => permissionManagementApi.createPermission(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['permissions'] });
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      onClose();
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: (data: PermissionCreateRequest) => permissionManagementApi.updatePermission(permission!.id!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['permissions'] });
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      onClose();
    },
  });

  const handleSubmit = () => {
    if (isEditMode) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {isEditMode ? 'Edit Permission' : 'Create New Permission'}
      </DialogTitle>
      <DialogContent dividers>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, pt: 1 }}>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Permission Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                disabled={isLoading}
                helperText="Descriptive name (e.g., Manage Users)"
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Permission Code"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                required
                disabled={isLoading}
                helperText="Uppercase, underscore-separated (e.g., USER_MANAGE)"
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                select
                label="Module"
                value={formData.module}
                onChange={(e) => setFormData({ ...formData, module: e.target.value })}
                required
                disabled={isLoading}
                helperText="The module this permission belongs to"
              >
                <MenuItem value="">
                  <em>Select Module</em>
                </MenuItem>
                {MODULES.map((module) => (
                  <MenuItem key={module} value={module}>
                    {module}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                multiline
                rows={3}
                disabled={isLoading}
                helperText="Brief description of what this permission allows"
              />
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={isLoading}>
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          disabled={isLoading || !formData.name || !formData.code || !formData.module}
        >
          {isLoading ? <CircularProgress size={24} /> : isEditMode ? 'Update' : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PermissionDialog;
