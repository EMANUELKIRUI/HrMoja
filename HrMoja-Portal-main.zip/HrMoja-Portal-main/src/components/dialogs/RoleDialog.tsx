import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  Typography,
  FormControlLabel,
  Checkbox,
  Grid,
  Chip,
  Alert,
  CircularProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import { ExpandMore as ExpandMoreIcon } from '@mui/icons-material';
import { roleManagementApi, type RoleDto, type RoleCreateRequest } from '../../api/role-management.api';
import { permissionManagementApi, type PermissionDto } from '../../api/permission-management.api';

interface RoleDialogProps {
  open: boolean;
  onClose: () => void;
  role?: RoleDto | null;
}

const RoleDialog = ({ open, onClose, role }: RoleDialogProps) => {
  const queryClient = useQueryClient();
  const isEditMode = !!role;

  const [formData, setFormData] = useState<RoleCreateRequest>({
    name: '',
    code: '',
    description: '',
    level: 0,
    permissionIds: [],
  });

  const [selectedPermissions, setSelectedPermissions] = useState<Set<number>>(new Set());

  // Fetch all permissions
  const { data: permissionsResponse, isLoading: permissionsLoading } = useQuery({
    queryKey: ['permissions'],
    queryFn: permissionManagementApi.getAllPermissions,
    enabled: open,
  });

  const permissions = permissionsResponse?.data || [];

  // Group permissions by module
  const groupedPermissions = permissions.reduce((acc, perm) => {
    if (!acc[perm.module]) {
      acc[perm.module] = [];
    }
    acc[perm.module].push(perm);
    return acc;
  }, {} as Record<string, PermissionDto[]>);

  // Initialize form when editing
  useEffect(() => {
    if (role) {
      setFormData({
        name: role.name,
        code: role.code,
        description: role.description || '',
        level: role.level || 0,
        permissionIds: role.permissionIds || [],
      });
      setSelectedPermissions(new Set(role.permissionIds || []));
    } else {
      setFormData({
        name: '',
        code: '',
        description: '',
        level: 0,
        permissionIds: [],
      });
      setSelectedPermissions(new Set());
    }
  }, [role, open]);

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: RoleCreateRequest) => roleManagementApi.createRole(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      onClose();
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: (data: RoleCreateRequest) => roleManagementApi.updateRole(role!.id!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      onClose();
    },
  });

  const handlePermissionToggle = (permissionId: number) => {
    const newSelected = new Set(selectedPermissions);
    if (newSelected.has(permissionId)) {
      newSelected.delete(permissionId);
    } else {
      newSelected.add(permissionId);
    }
    setSelectedPermissions(newSelected);
  };

  const handleSelectAllInModule = (module: string) => {
    const modulePerms = groupedPermissions[module];
    const allSelected = modulePerms.every((p) => selectedPermissions.has(p.id!));
    
    const newSelected = new Set(selectedPermissions);
    modulePerms.forEach((p) => {
      if (allSelected) {
        newSelected.delete(p.id!);
      } else {
        newSelected.add(p.id!);
      }
    });
    setSelectedPermissions(newSelected);
  };

  const handleSubmit = () => {
    const submitData: RoleCreateRequest = {
      ...formData,
      permissionIds: Array.from(selectedPermissions),
    };

    if (isEditMode) {
      updateMutation.mutate(submitData);
    } else {
      createMutation.mutate(submitData);
    }
  };

  const isLoading = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {isEditMode ? 'Edit Role' : 'Create New Role'}
      </DialogTitle>
      <DialogContent dividers>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          {/* Basic Information */}
          <Box>
            <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
              Basic Information
            </Typography>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Role Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  disabled={isLoading}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Role Code"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  required
                  disabled={isLoading || (isEditMode && role?.isSystemRole)}
                  helperText="Uppercase, no spaces (e.g., HR_MANAGER)"
                />
              </Grid>
              <Grid size={{ xs: 12 }}>
                <TextField
                  fullWidth
                  label="Description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  multiline
                  rows={2}
                  disabled={isLoading}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  fullWidth
                  label="Level"
                  type="number"
                  value={formData.level}
                  onChange={(e) => setFormData({ ...formData, level: parseInt(e.target.value) || 0 })}
                  disabled={isLoading}
                  helperText="Higher level = more authority"
                />
              </Grid>
            </Grid>
          </Box>

          {/* Permissions */}
          <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" fontWeight="bold">
                Permissions ({selectedPermissions.size} selected)
              </Typography>
              <Chip
                label={`${selectedPermissions.size} / ${permissions.length}`}
                color="primary"
                size="small"
              />
            </Box>

            {permissionsLoading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
                <CircularProgress />
              </Box>
            ) : permissions.length === 0 ? (
              <Alert severity="info">No permissions available</Alert>
            ) : (
              <Box sx={{ maxHeight: 400, overflowY: 'auto' }}>
                {Object.entries(groupedPermissions).map(([module, perms]) => {
                  const selectedCount = perms.filter((p) => selectedPermissions.has(p.id!)).length;
                  const allSelected = selectedCount === perms.length;

                  return (
                    <Accordion key={module} defaultExpanded>
                      <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                          <FormControlLabel
                            control={
                              <Checkbox
                                checked={allSelected}
                                indeterminate={selectedCount > 0 && !allSelected}
                                onChange={() => handleSelectAllInModule(module)}
                                onClick={(e) => e.stopPropagation()}
                              />
                            }
                            label={
                              <Typography fontWeight="bold">
                                {module.toUpperCase()} ({selectedCount}/{perms.length})
                              </Typography>
                            }
                            onClick={(e) => e.stopPropagation()}
                          />
                        </Box>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Grid container spacing={1}>
                          {perms.map((perm) => (
                            <Grid size={{ xs: 12, sm: 6 }} key={perm.id}>
                              <FormControlLabel
                                control={
                                  <Checkbox
                                    checked={selectedPermissions.has(perm.id!)}
                                    onChange={() => handlePermissionToggle(perm.id!)}
                                    size="small"
                                  />
                                }
                                label={(
                                  <Box>
                                    <Typography variant="body2" fontWeight={500}>
                                      {perm.name}
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary">
                                      {perm.code}
                                    </Typography>
                                  </Box>
                                )}
                              />
                            </Grid>
                          ))}
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  );
                })}
              </Box>
            )}
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} disabled={isLoading}>
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          disabled={isLoading || !formData.name || !formData.code}
        >
          {isLoading ? <CircularProgress size={24} /> : isEditMode ? 'Update' : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default RoleDialog;
