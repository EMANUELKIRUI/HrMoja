import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  Chip,
  Stack,
  Divider,
} from '@mui/material';
import {
  CheckCircle as CheckIcon,
  Schedule as PendingIcon,
  Close as RejectIcon,
} from '@mui/icons-material';
import { format, parseISO } from 'date-fns';
import type { PayrollPeriod } from '../../api/payrollApi';

interface ApprovalWorkflowProps {
  period: PayrollPeriod;
  onApprovalAction: (action: 'prepare' | 'review' | 'final-approve' | 'reject', reason?: string) => Promise<void>;
  loading: boolean;
}

const ApprovalWorkflow: React.FC<ApprovalWorkflowProps> = ({
  period,
  onApprovalAction,
  loading,
}) => {
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  const getActiveStep = () => {
    if (period.finalApprovedBy) return 3;
    if (period.reviewedBy) return 2;
    if (period.preparedBy) return 1;
    return 0;
  };

  const canPrepare = period.status === 'PROCESSING';
  const canReview = period.status === 'PREPARED';
  const canFinalApprove = period.status === 'REVIEWED';
  const canReject = period.status === 'PREPARED' || period.status === 'REVIEWED';

  const handleReject = async () => {
    if (!rejectReason.trim()) {
      return;
    }
    await onApprovalAction('reject', rejectReason);
    setRejectDialogOpen(false);
    setRejectReason('');
  };

  const steps = [
    {
      label: 'Level 1: Prepared',
      description: 'Payroll Officer prepares and verifies calculations',
      user: period.preparedBy,
      timestamp: period.preparedAt,
      status: period.preparedBy ? 'completed' : period.status === 'PROCESSING' ? 'active' : 'pending',
    },
    {
      label: 'Level 2: Reviewed',
      description: 'Payroll Manager reviews and validates',
      user: period.reviewedBy,
      timestamp: period.reviewedAt,
      status: period.reviewedBy ? 'completed' : period.status === 'PREPARED' ? 'active' : 'pending',
    },
    {
      label: 'Level 3: Final Approval',
      description: 'Finance Director/CFO gives final approval',
      user: period.finalApprovedBy,
      timestamp: period.finalApprovedAt,
      status: period.finalApprovedBy ? 'completed' : period.status === 'REVIEWED' ? 'active' : 'pending',
    },
  ];

  return (
    <>
      <Card>
        <CardContent>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
            <Typography variant="h6" fontWeight="bold">
              Approval Workflow
            </Typography>
            <Chip
              label={period.approvalLevel || 'NONE'}
              color={period.approvalLevel === 'LEVEL_3_APPROVED' ? 'success' : 'warning'}
              size="small"
            />
          </Box>

          <Stepper activeStep={getActiveStep()} orientation="vertical">
            {steps.map((step, index) => (
              <Step key={step.label} completed={step.status === 'completed'}>
                <StepLabel
                  optional={
                    step.timestamp && (
                      <Typography variant="caption" color="text.secondary">
                        {format(parseISO(step.timestamp), 'dd MMM yyyy, HH:mm')}
                      </Typography>
                    )
                  }
                  StepIconComponent={() => (
                    step.status === 'completed' ? (
                      <CheckIcon color="success" />
                    ) : step.status === 'active' ? (
                      <PendingIcon color="primary" />
                    ) : (
                      <PendingIcon color="disabled" />
                    )
                  )}
                >
                  <Typography fontWeight={step.status === 'active' ? 'bold' : 'normal'}>
                    {step.label}
                  </Typography>
                </StepLabel>
                <StepContent>
                  <Typography variant="body2" color="text.secondary" mb={2}>
                    {step.description}
                  </Typography>

                  {step.user && (
                    <Alert severity="success" icon={<CheckIcon />} sx={{ mb: 2 }}>
                      <Typography variant="body2">
                        Approved by User ID: {step.user}
                      </Typography>
                    </Alert>
                  )}

                  {step.status === 'active' && (
                    <Stack direction="row" spacing={2}>
                      {index === 0 && canPrepare && (
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={() => onApprovalAction('prepare')}
                          disabled={loading}
                        >
                          Mark as Prepared
                        </Button>
                      )}
                      {index === 1 && canReview && (
                        <>
                          <Button
                            variant="contained"
                            color="primary"
                            onClick={() => onApprovalAction('review')}
                            disabled={loading}
                          >
                            Review & Approve
                          </Button>
                          {canReject && (
                            <Button
                              variant="outlined"
                              color="error"
                              startIcon={<RejectIcon />}
                              onClick={() => setRejectDialogOpen(true)}
                              disabled={loading}
                            >
                              Reject
                            </Button>
                          )}
                        </>
                      )}
                      {index === 2 && canFinalApprove && (
                        <>
                          <Button
                            variant="contained"
                            color="success"
                            onClick={() => onApprovalAction('final-approve')}
                            disabled={loading}
                          >
                            Give Final Approval
                          </Button>
                          {canReject && (
                            <Button
                              variant="outlined"
                              color="error"
                              startIcon={<RejectIcon />}
                              onClick={() => setRejectDialogOpen(true)}
                              disabled={loading}
                            >
                              Reject
                            </Button>
                          )}
                        </>
                      )}
                    </Stack>
                  )}
                </StepContent>
              </Step>
            ))}
          </Stepper>

          {period.status === 'APPROVED' && (
            <Box mt={3}>
              <Divider sx={{ mb: 2 }} />
              <Alert severity="success" icon={<CheckIcon />}>
                <Typography variant="body1" fontWeight="bold">
                  ✓ Payroll Fully Approved
                </Typography>
                <Typography variant="body2">
                  All approval levels completed. Ready for payment processing.
                </Typography>
              </Alert>
            </Box>
          )}

          {period.notes && (
            <Box mt={3}>
              <Divider sx={{ mb: 2 }} />
              <Typography variant="subtitle2" color="text.secondary" mb={1}>
                Notes & Comments
              </Typography>
              <Alert severity="info">
                <Typography variant="body2" style={{ whiteSpace: 'pre-wrap' }}>
                  {period.notes}
                </Typography>
              </Alert>
            </Box>
          )}
        </CardContent>
      </Card>

      {/* Rejection Dialog */}
      <Dialog open={rejectDialogOpen} onClose={() => setRejectDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Reject Payroll</DialogTitle>
        <DialogContent>
          <Alert severity="warning" sx={{ mb: 2 }}>
            Rejecting will reset the payroll to DRAFT status for corrections.
          </Alert>
          <TextField
            fullWidth
            multiline
            rows={4}
            label="Reason for Rejection"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            placeholder="Please provide a detailed reason for rejection..."
            required
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRejectDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleReject}
            color="error"
            variant="contained"
            disabled={!rejectReason.trim() || loading}
          >
            Reject Payroll
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ApprovalWorkflow;
