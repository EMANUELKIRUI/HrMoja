import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Checkbox,
  Button,
  Chip,
  LinearProgress,
  Stack,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  Tooltip,
} from '@mui/material';
import {
  CheckCircle as ApproveIcon,
  Cancel as RejectIcon,
  Close as CancelIcon,
  Restore as RestoreIcon,
  SelectAll as SelectAllIcon,
  CheckBox as CheckAllIcon,
  Edit as EditIcon,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import payrollApi from '../../api/payrollApi';
import type { EmployeePayrollRecord, ApprovalStats } from '../../api/payrollApi';

interface PartialApprovalPanelProps {
  periodId: number;
  records: EmployeePayrollRecord[];
  canEdit: boolean;
  onUpdate: () => void;
  onEditRecord?: (record: EmployeePayrollRecord) => void;
}

const PartialApprovalPanel: React.FC<PartialApprovalPanelProps> = ({
  periodId,
  records,
  canEdit,
  onUpdate,
  onEditRecord,
}) => {
  const [selectedRecords, setSelectedRecords] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [rejectingRecordId, setRejectingRecordId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [stats, setStats] = useState<ApprovalStats | null>(null);

  React.useEffect(() => {
    loadStats();
  }, [periodId, records]);

  const loadStats = async () => {
    try {
      const data = await payrollApi.getApprovalStats(periodId);
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const handleSelectAll = () => {
    const activeRecords = records.filter(r => !r.rejected);
    if (selectedRecords.length === activeRecords.length) {
      setSelectedRecords([]);
    } else {
      setSelectedRecords(activeRecords.map(r => r.id));
    }
  };

  const handleSelectRecord = (recordId: number) => {
    if (selectedRecords.includes(recordId)) {
      setSelectedRecords(selectedRecords.filter(id => id !== recordId));
    } else {
      setSelectedRecords([...selectedRecords, recordId]);
    }
  };

  const handleApproveSelected = async () => {
    if (selectedRecords.length === 0) {
      toast.warning('Please select records to approve');
      return;
    }

    try {
      setLoading(true);
      const approved = await payrollApi.bulkApproveLevel1(selectedRecords);
      toast.success(`${approved} record(s) approved at Level 1`);
      setSelectedRecords([]);
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve records');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveAll = async () => {
    try {
      setLoading(true);
      const approved = await payrollApi.approveAllLevel1(periodId);
      toast.success(`${approved} record(s) approved at Level 1`);
      setSelectedRecords([]);
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve all');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveOne = async (recordId: number) => {
    try {
      setLoading(true);
      await payrollApi.approveRecordLevel1(recordId);
      toast.success('Record approved at Level 1');
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve');
    } finally {
      setLoading(false);
    }
  };

  const handleUnapprove = async (recordId: number) => {
    try {
      setLoading(true);
      await payrollApi.unapproveRecordLevel1(recordId);
      toast.success('Approval removed');
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to unapprove');
    } finally {
      setLoading(false);
    }
  };

  const handleRejectClick = (recordId: number) => {
    setRejectingRecordId(recordId);
    setRejectDialogOpen(true);
  };

  const handleRejectConfirm = async () => {
    if (!rejectingRecordId || !rejectReason.trim()) {
      toast.warning('Please provide a rejection reason');
      return;
    }

    try {
      setLoading(true);
      await payrollApi.rejectRecord(rejectingRecordId, rejectReason);
      toast.warning('Record rejected/excluded from payroll');
      setRejectDialogOpen(false);
      setRejectingRecordId(null);
      setRejectReason('');
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to reject');
    } finally {
      setLoading(false);
    }
  };

  const handleRestore = async (recordId: number) => {
    try {
      setLoading(true);
      await payrollApi.restoreRecord(recordId);
      toast.success('Record restored');
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to restore');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const activeRecords = records.filter(r => !r.rejected);
  const rejectedRecords = records.filter(r => r.rejected);

  return (
    <Card>
      <CardContent>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h6" fontWeight="bold">
            Level 1 Approval - Individual Records
          </Typography>
          {canEdit && (
            <Stack direction="row" spacing={1}>
              <Button
                variant="outlined"
                size="small"
                startIcon={<SelectAllIcon />}
                onClick={handleSelectAll}
                disabled={loading || activeRecords.length === 0}
              >
                {selectedRecords.length === activeRecords.length ? 'Deselect All' : 'Select All'}
              </Button>
              <Button
                variant="contained"
                size="small"
                startIcon={<ApproveIcon />}
                onClick={handleApproveSelected}
                disabled={loading || selectedRecords.length === 0}
              >
                Approve Selected ({selectedRecords.length})
              </Button>
              <Button
                variant="contained"
                color="success"
                size="small"
                startIcon={<CheckAllIcon />}
                onClick={handleApproveAll}
                disabled={loading}
              >
                Approve All
              </Button>
            </Stack>
          )}
        </Box>

        {/* Approval Progress */}
        {stats && (
          <Box mb={3}>
            <Box display="flex" justifyContent="space-between" mb={1}>
              <Typography variant="body2" color="text.secondary">
                Approval Progress: {stats.approvedCount} of {stats.totalRecords - stats.rejectedCount} approved
              </Typography>
              <Typography variant="body2" fontWeight="bold">
                {stats.approvalPercentage.toFixed(1)}%
              </Typography>
            </Box>
            <LinearProgress 
              variant="determinate" 
              value={stats.approvalPercentage} 
              color={stats.approvalPercentage === 100 ? 'success' : 'primary'}
              sx={{ height: 8, borderRadius: 1 }}
            />
            <Box display="flex" gap={2} mt={1}>
              <Chip label={`${stats.approvedCount} Approved`} color="success" size="small" />
              <Chip label={`${stats.pendingCount} Pending`} color="warning" size="small" />
              {stats.rejectedCount > 0 && (
                <Chip label={`${stats.rejectedCount} Rejected`} color="error" size="small" />
              )}
            </Box>
          </Box>
        )}

        {/* Active Records Table */}
        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                {canEdit && <TableCell padding="checkbox"></TableCell>}
                <TableCell>Employee</TableCell>
                <TableCell>Employee #</TableCell>
                <TableCell align="right">Gross Pay</TableCell>
                <TableCell align="right">Net Pay</TableCell>
                <TableCell align="center">Status</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {activeRecords.map((record) => (
                <TableRow 
                  key={record.id}
                  selected={selectedRecords.includes(record.id)}
                  sx={{ 
                    backgroundColor: record.approvedLevel1 ? 'success.50' : 'inherit',
                  }}
                >
                  {canEdit && (
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedRecords.includes(record.id)}
                        onChange={() => handleSelectRecord(record.id)}
                        disabled={loading || record.rejected}
                      />
                    </TableCell>
                  )}
                  <TableCell>
                    <Typography variant="body2" fontWeight="medium">
                      {record.employeeName}
                    </Typography>
                  </TableCell>
                  <TableCell>{record.employeeNumber}</TableCell>
                  <TableCell align="right">{formatCurrency(record.grossSalary)}</TableCell>
                  <TableCell align="right">{formatCurrency(record.netSalary)}</TableCell>
                  <TableCell align="center">
                    {record.approvedLevel1 ? (
                      <Chip label="✓ Approved L1" color="success" size="small" />
                    ) : (
                      <Chip label="Pending" color="warning" size="small" />
                    )}
                  </TableCell>
                  <TableCell align="center">
                    <Stack direction="row" spacing={0.5} justifyContent="center">
                      {canEdit && onEditRecord && (
                        <Tooltip title="Edit Line Items">
                          <IconButton
                            size="small"
                            onClick={() => onEditRecord(record)}
                            disabled={loading}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {canEdit && !record.approvedLevel1 && (
                        <Tooltip title="Approve">
                          <IconButton
                            size="small"
                            color="success"
                            onClick={() => handleApproveOne(record.id)}
                            disabled={loading}
                          >
                            <ApproveIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {canEdit && record.approvedLevel1 && (
                        <Tooltip title="Unapprove">
                          <IconButton
                            size="small"
                            onClick={() => handleUnapprove(record.id)}
                            disabled={loading}
                          >
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                      {canEdit && (
                        <Tooltip title="Reject/Exclude">
                          <IconButton
                            size="small"
                            color="error"
                            onClick={() => handleRejectClick(record.id)}
                            disabled={loading}
                          >
                            <RejectIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Rejected Records */}
        {rejectedRecords.length > 0 && (
          <Box mt={3}>
            <Typography variant="subtitle2" color="error" mb={1}>
              Rejected/Excluded Records ({rejectedRecords.length})
            </Typography>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Employee</TableCell>
                    <TableCell>Reason</TableCell>
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rejectedRecords.map((record) => (
                    <TableRow key={record.id} sx={{ backgroundColor: 'error.50' }}>
                      <TableCell>
                        <Typography variant="body2" fontWeight="medium">
                          {record.employeeName} ({record.employeeNumber})
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="text.secondary">
                          {record.rejectionReason}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        {canEdit && (
                          <Tooltip title="Restore Record">
                            <IconButton
                              size="small"
                              color="primary"
                              onClick={() => handleRestore(record.id)}
                              disabled={loading}
                            >
                              <RestoreIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}
      </CardContent>

      {/* Reject Dialog */}
      <Dialog open={rejectDialogOpen} onClose={() => setRejectDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Reject/Exclude Employee Record</DialogTitle>
        <DialogContent>
          <Alert severity="warning" sx={{ mb: 2 }}>
            This will exclude the employee from this payroll period. The record will be soft-deleted but can be restored.
          </Alert>
          <TextField
            fullWidth
            multiline
            rows={4}
            label="Rejection Reason"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            placeholder="e.g., Employee on unpaid leave, calculation error needs investigation..."
            required
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRejectDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleRejectConfirm}
            color="error"
            variant="contained"
            disabled={!rejectReason.trim() || loading}
          >
            Reject/Exclude
          </Button>
        </DialogActions>
      </Dialog>
    </Card>
  );
};

export default PartialApprovalPanel;
