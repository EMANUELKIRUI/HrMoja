import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  IconButton,
  Typography,
  Alert,
  Box,
  Chip,
  Paper,
  Stack,
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  Add as AddIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import payrollApi from '../../api/payrollApi';
import type { EmployeePayrollRecord, PayrollLineItem } from '../../api/payrollApi';

interface EmployeeLineItemEditorProps {
  open: boolean;
  onClose: () => void;
  record: EmployeePayrollRecord;
  onUpdate: () => void;
}

const EmployeeLineItemEditor: React.FC<EmployeeLineItemEditorProps> = ({
  open,
  onClose,
  record,
  onUpdate,
}) => {
  const [lineItems, setLineItems] = useState<PayrollLineItem[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<PayrollLineItem | null>(null);
  const [newItem, setNewItem] = useState({
    componentName: '',
    componentCode: '',
    category: 'EARNING',
    amount: '',
  });

  useEffect(() => {
    if (open && record) {
      loadLineItems();
    }
  }, [open, record]);

  const loadLineItems = async () => {
    try {
      setLoading(true);
      const items = await payrollApi.getLineItems(record.id);
      setLineItems(items);
    } catch (error: any) {
      toast.error('Failed to load line items');
    } finally {
      setLoading(false);
    }
  };

  const handleEditClick = (item: PayrollLineItem) => {
    setEditingId(item.id);
    setEditAmount(item.amount.toString());
  };

  const handleSaveEdit = async (lineItemId: number) => {
    try {
      setLoading(true);
      const amount = parseFloat(editAmount);
      if (isNaN(amount)) {
        toast.error('Invalid amount');
        return;
      }
      await payrollApi.updateLineItem(lineItemId, amount);
      toast.success('Line item updated');
      setEditingId(null);
      loadLineItems();
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to update line item');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteClick = (item: PayrollLineItem) => {
    if (item.isStatutory) {
      toast.error('Cannot delete statutory items (NSSF, PAYE, LST)');
      return;
    }
    setItemToDelete(item);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;

    try {
      setLoading(true);
      await payrollApi.deleteLineItem(itemToDelete.id);
      toast.success('Line item deleted successfully');
      setDeleteDialogOpen(false);
      setItemToDelete(null);
      loadLineItems();
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to delete line item');
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = async () => {
    try {
      setLoading(true);
      const amount = parseFloat(newItem.amount);
      if (!newItem.componentName || !newItem.componentCode || isNaN(amount)) {
        toast.error('Please fill all fields with valid data');
        return;
      }

      await payrollApi.addLineItem(
        record.id,
        newItem.componentName,
        newItem.componentCode,
        newItem.category,
        amount
      );
      
      toast.success('Line item added');
      setAddDialogOpen(false);
      setNewItem({ componentName: '', componentCode: '', category: 'EARNING', amount: '' });
      loadLineItems();
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to add line item');
    } finally {
      setLoading(false);
    }
  };

  const handleRecalculate = async () => {
    try {
      setLoading(true);
      await payrollApi.recalculateEmployeeRecord(record.id);
      toast.success('Employee record recalculated');
      loadLineItems();
      onUpdate();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to recalculate');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'EARNING':
        return 'success';
      case 'DEDUCTION':
        return 'error';
      case 'STATUTORY':
        return 'warning';
      case 'TAX':
        return 'secondary';
      default:
        return 'default';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <>
      <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="h6">
              Edit Line Items - {record.employeeName}
            </Typography>
            <Stack direction="row" spacing={1}>
              <Button
                variant="outlined"
                size="small"
                startIcon={<AddIcon />}
                onClick={() => setAddDialogOpen(true)}
                disabled={loading}
              >
                Add Item
              </Button>
              <Button
                variant="outlined"
                size="small"
                startIcon={<RefreshIcon />}
                onClick={handleRecalculate}
                disabled={loading}
              >
                Recalculate
              </Button>
            </Stack>
          </Box>
        </DialogTitle>

        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            You can edit line item amounts, add custom items, or delete non-statutory items at Level 1 (PREPARED stage).
          </Alert>

          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Component</TableCell>
                  <TableCell>Code</TableCell>
                  <TableCell>Category</TableCell>
                  <TableCell align="right">Amount</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {lineItems.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Typography variant="body2" fontWeight="medium">
                        {item.componentName}
                      </Typography>
                    </TableCell>
                    <TableCell>{item.componentCode}</TableCell>
                    <TableCell>
                      <Chip
                        label={item.componentCategory}
                        color={getCategoryColor(item.componentCategory) as any}
                        size="small"
                      />
                    </TableCell>
                    <TableCell align="right">
                      {editingId === item.id ? (
                        <TextField
                          size="small"
                          type="number"
                          value={editAmount}
                          onChange={(e) => setEditAmount(e.target.value)}
                          sx={{ width: 120 }}
                        />
                      ) : (
                        <Typography variant="body2">
                          {formatCurrency(item.amount)}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {editingId === item.id ? (
                        <>
                          <IconButton
                            size="small"
                            color="primary"
                            onClick={() => handleSaveEdit(item.id)}
                            disabled={loading}
                          >
                            <SaveIcon fontSize="small" />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => setEditingId(null)}
                            disabled={loading}
                          >
                            <CancelIcon fontSize="small" />
                          </IconButton>
                        </>
                      ) : (
                        <>
                          <IconButton
                            size="small"
                            onClick={() => handleEditClick(item)}
                            disabled={loading}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                          <IconButton
                            size="small"
                            color="error"
                            onClick={() => handleDeleteClick(item)}
                            disabled={loading || item.isStatutory}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Box mt={3}>
            <Typography variant="subtitle2" color="text.secondary" mb={1}>
              Summary
            </Typography>
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Stack spacing={1}>
                <Box display="flex" justifyContent="space-between">
                  <Typography variant="body2">Gross Salary:</Typography>
                  <Typography variant="body2" fontWeight="bold">
                    {formatCurrency(record.grossSalary)}
                  </Typography>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Typography variant="body2">Total Deductions:</Typography>
                  <Typography variant="body2" color="error.main">
                    {formatCurrency(record.totalDeductions)}
                  </Typography>
                </Box>
                <Box display="flex" justifyContent="space-between">
                  <Typography variant="body1" fontWeight="bold">Net Salary:</Typography>
                  <Typography variant="body1" fontWeight="bold" color="success.main">
                    {formatCurrency(record.netSalary)}
                  </Typography>
                </Box>
              </Stack>
            </Paper>
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={onClose}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog 
        open={deleteDialogOpen} 
        onClose={() => setDeleteDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ color: 'error.main' }}>
          <Box display="flex" alignItems="center" gap={1}>
            <DeleteIcon />
            Confirm Delete Line Item
          </Box>
        </DialogTitle>
        <DialogContent>
          {itemToDelete && (
            <>
              <Alert severity="warning" sx={{ mb: 2 }}>
                Are you sure you want to delete this line item? This action cannot be undone.
              </Alert>
              <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
                <Stack spacing={1}>
                  <Box display="flex" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">Component Name:</Typography>
                    <Typography variant="body2" fontWeight="medium">{itemToDelete.componentName}</Typography>
                  </Box>
                  <Box display="flex" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">Component Code:</Typography>
                    <Typography variant="body2" fontWeight="medium">{itemToDelete.componentCode}</Typography>
                  </Box>
                  <Box display="flex" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">Category:</Typography>
                    <Chip 
                      label={itemToDelete.componentCategory} 
                      color={getCategoryColor(itemToDelete.componentCategory) as any}
                      size="small"
                    />
                  </Box>
                  <Box display="flex" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">Amount:</Typography>
                    <Typography variant="body2" fontWeight="bold" color="error.main">
                      {formatCurrency(itemToDelete.amount)}
                    </Typography>
                  </Box>
                </Stack>
              </Paper>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)} disabled={loading}>
            Cancel
          </Button>
          <Button 
            onClick={handleDeleteConfirm} 
            color="error" 
            variant="contained"
            disabled={loading}
            startIcon={<DeleteIcon />}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Item Dialog */}
      <Dialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Line Item</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              fullWidth
              label="Component Name"
              value={newItem.componentName}
              onChange={(e) => setNewItem({ ...newItem, componentName: e.target.value })}
            />
            <TextField
              fullWidth
              label="Component Code"
              value={newItem.componentCode}
              onChange={(e) => setNewItem({ ...newItem, componentCode: e.target.value })}
            />
            <TextField
              fullWidth
              select
              label="Category"
              value={newItem.category}
              onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
              SelectProps={{ native: true }}
            >
              <option value="EARNING">EARNING</option>
              <option value="DEDUCTION">DEDUCTION</option>
            </TextField>
            <TextField
              fullWidth
              label="Amount"
              type="number"
              value={newItem.amount}
              onChange={(e) => setNewItem({ ...newItem, amount: e.target.value })}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAddDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleAddItem} variant="contained" disabled={loading}>
            Add
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default EmployeeLineItemEditor;
