import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Alert,
  Chip,
  Stack,
} from '@mui/material';
import {
  People as PeopleIcon,
  CheckCircle as CheckIcon,
} from '@mui/icons-material';
import { employeesApi } from '../../api/employees.api';
import { employeeSalaryApi } from '../../api/employee-salary.api';
import { useAuthStore } from '../../store/authStore';

interface EmployeeWithSalary {
  id: number;
  employeeNumber: string;
  firstName: string;
  lastName: string;
  jobTitle: string;
  basicSalary: number;
  status: string;
}

interface ProcessPayrollPreviewProps {
  open: boolean;
  periodId: number;
  periodName: string;
  onClose: () => void;
  onConfirm: () => void;
  loading?: boolean;
}

const ProcessPayrollPreview: React.FC<ProcessPayrollPreviewProps> = ({
  open,
  periodId,
  periodName,
  onClose,
  onConfirm,
  loading = false,
}) => {
  const [employees, setEmployees] = useState<EmployeeWithSalary[]>([]);
  const [loadingEmployees, setLoadingEmployees] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;

  useEffect(() => {
    if (open) {
      loadActiveEmployees();
    }
  }, [open, periodId]);

  const loadActiveEmployees = async () => {
    try {
      setLoadingEmployees(true);
      setError(null);
      
      // Fetch all active employees
      const employeesResponse = await employeesApi.searchEmployeesWithFilters(
        organizationId,
        { isActive: true, status: 'ACTIVE' },
        0,
        1000 // Get all active employees
      );
      
      if (employeesResponse.success && employeesResponse.data) {
        const activeEmps = employeesResponse.data.content || [];
        
        // Fetch salary information for each employee
        const employeesWithSalary = await Promise.all(
          activeEmps.map(async (emp) => {
            try {
              const salaryResponse = await employeeSalaryApi.getCurrentSalary(emp.id!);
              const basicSalary = salaryResponse.success && salaryResponse.data 
                ? salaryResponse.data.basicSalary 
                : 0;
              
              return {
                id: emp.id!,
                employeeNumber: emp.employeeNumber || 'N/A',
                firstName: emp.firstName,
                lastName: emp.lastName,
                jobTitle: emp.jobTitleName || 'N/A',
                basicSalary: basicSalary,
                status: emp.employmentStatus || 'ACTIVE',
              };
            } catch (err) {
              // If salary fetch fails, include employee with 0 salary
              return {
                id: emp.id!,
                employeeNumber: emp.employeeNumber || 'N/A',
                firstName: emp.firstName,
                lastName: emp.lastName,
                jobTitle: emp.jobTitleName || 'N/A',
                basicSalary: 0,
                status: emp.employmentStatus || 'ACTIVE',
              };
            }
          })
        );
        
        setEmployees(employeesWithSalary);
      } else {
        setEmployees([]);
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to load employees');
      setEmployees([]);
    } finally {
      setLoadingEmployees(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const totalBasicSalary = employees.reduce((sum, emp) => sum + (emp.basicSalary || 0), 0);
  const activeEmployees = employees.filter(emp => emp.status === 'ACTIVE');

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle>
        <Box display="flex" alignItems="center" gap={1}>
          <PeopleIcon />
          <Typography variant="h6" component="span">
            Process Payroll Preview
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {periodName}
        </Typography>
      </DialogTitle>

      <DialogContent>
        {loadingEmployees ? (
          <Box display="flex" justifyContent="center" alignItems="center" py={4}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Alert severity="error">{error}</Alert>
        ) : (
          <>
            {/* Summary Cards */}
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} mb={3}>
              <Paper sx={{ p: 2, bgcolor: 'primary.50', flex: 1 }}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Total Employees
                  </Typography>
                  <Typography variant="h4" fontWeight="bold" color="primary.main">
                    {activeEmployees.length}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Active employees to be processed
                  </Typography>
                </Paper>
              <Paper sx={{ p: 2, bgcolor: 'success.50', flex: 1 }}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Estimated Gross Pay
                  </Typography>
                  <Typography variant="h5" fontWeight="bold" color="success.main">
                    {formatCurrency(totalBasicSalary)}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Basic salary before deductions
                  </Typography>
                </Paper>
              <Paper sx={{ p: 2, bgcolor: 'info.50', flex: 1 }}>
                  <Typography variant="subtitle2" color="text.secondary">
                    Processing Status
                  </Typography>
                  <Box display="flex" alignItems="center" gap={1} mt={1}>
                    <CheckIcon color="success" />
                    <Typography variant="body2" fontWeight="medium">
                      Ready to Process
                    </Typography>
                  </Box>
                  <Typography variant="caption" color="text.secondary">
                    All validations passed
                  </Typography>
                </Paper>
            </Stack>

            {activeEmployees.length === 0 ? (
              <Alert severity="info" icon={<PeopleIcon />}>
                <strong>Ready to Process Payroll</strong>
                <Typography variant="body2" sx={{ mt: 1 }}>
                  The system will automatically process payroll for all employees with active salary structures.
                  This includes calculating gross pay, tax deductions (PAYE), statutory contributions (NSSF), and net pay.
                </Typography>
              </Alert>
            ) : (
              <>
                <Alert severity="info" sx={{ mb: 2 }}>
                  <Typography variant="body2">
                    <strong>What will happen:</strong>
                  </Typography>
                  <ul style={{ margin: '8px 0 0 0', paddingLeft: '20px' }}>
                    <li>Calculate gross pay based on salary structures</li>
                    <li>Apply tax deductions (PAYE) based on country tax rules</li>
                    <li>Deduct statutory contributions (NSSF, etc.)</li>
                    <li>Calculate net pay for each employee</li>
                    <li>Generate payroll records for approval workflow</li>
                  </ul>
                </Alert>

                <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                  Employees to be Processed ({activeEmployees.length})
                </Typography>

                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ bgcolor: 'grey.50' }}>
                        <TableCell>Employee #</TableCell>
                        <TableCell>Name</TableCell>
                        <TableCell>Job Title</TableCell>
                        <TableCell align="right">Basic Salary</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {activeEmployees.map((employee) => (
                        <TableRow key={employee.id} hover>
                          <TableCell>
                            <Typography variant="body2" fontWeight="medium">
                              {employee.employeeNumber}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            {employee.firstName} {employee.lastName}
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {employee.jobTitle}
                            </Typography>
                          </TableCell>
                          <TableCell align="right">
                            <Typography variant="body2" fontWeight="medium">
                              {formatCurrency(employee.basicSalary)}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={employee.status}
                              color="success"
                              size="small"
                              variant="outlined"
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>

                {employees.length > activeEmployees.length && (
                  <Alert severity="info" sx={{ mt: 2 }}>
                    {employees.length - activeEmployees.length} inactive employee(s) will be excluded from processing.
                  </Alert>
                )}
              </>
            )}
          </>
        )}
      </DialogContent>

      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} disabled={loading}>
          Cancel
        </Button>
        <Button
          onClick={onConfirm}
          variant="contained"
          disabled={loading || loadingEmployees}
          startIcon={loading ? <CircularProgress size={16} /> : null}
        >
          {loading ? 'Processing...' : 'Process Payroll'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ProcessPayrollPreview;
