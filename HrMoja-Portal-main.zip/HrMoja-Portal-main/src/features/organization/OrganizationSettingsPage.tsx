import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  TextField,
  Button,
  Alert,
  CircularProgress,
  Chip,
} from '@mui/material';
import {
  Business as BusinessIcon,
  Save as SaveIcon,
} from '@mui/icons-material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { organizationsApi } from '../../api/organizations.api';
import { useAuthStore } from '../../store/authStore';

const orgSchema = z.object({
  name: z.string().min(1, 'Organization name is required'),
  addressLine1: z.string().optional(),
  addressLine2: z.string().optional(),
  city: z.string().optional(),
  stateProvince: z.string().optional(),
  postalCode: z.string().optional(),
  phoneNumber: z.string().optional(),
  email: z.string().email('Invalid email').optional(),
  website: z.string().optional(),
  taxIdentificationNumber: z.string().optional(),
  registrationNumber: z.string().optional(),
});

type OrgFormData = z.infer<typeof orgSchema>;

const OrganizationSettingsPage = () => {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Fetch current user's organization
  const { data: orgResponse, isLoading } = useQuery({
    queryKey: ['organization', user?.organizationId],
    queryFn: () => organizationsApi.getOrganizationById(user?.organizationId!),
    enabled: !!user?.organizationId,
  });

  const organization = orgResponse?.data;

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isDirty },
  } = useForm<OrgFormData>({
    resolver: zodResolver(orgSchema),
    defaultValues: {
      name: '',
      addressLine1: '',
      addressLine2: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      phoneNumber: '',
      email: '',
      website: '',
      taxIdentificationNumber: '',
      registrationNumber: '',
    },
  });

  // Update form when organization data loads
  useEffect(() => {
    if (organization) {
      reset({
        name: organization.name || '',
        addressLine1: organization.addressLine1 || '',
        addressLine2: organization.addressLine2 || '',
        city: organization.city || '',
        stateProvince: organization.stateProvince || '',
        postalCode: organization.postalCode || '',
        phoneNumber: organization.phoneNumber || '',
        email: organization.email || '',
        website: organization.website || '',
        taxIdentificationNumber: organization.taxIdentificationNumber || '',
        registrationNumber: organization.registrationNumber || '',
      });
    }
  }, [organization, reset]);

  const updateMutation = useMutation({
    mutationFn: (data: OrgFormData) => {
      if (!user?.organizationId) throw new Error('No organization ID');
      // Map form data to API format, preserving fields not in the form
      const updateData = {
        ...data,
        countryId: organization?.countryId || 1, // Keep existing countryId
        active: organization?.active, // Preserve active status
        legalName: organization?.legalName, // Preserve other fields
        logoUrl: organization?.logoUrl,
      };
      return organizationsApi.updateOrganization(user.organizationId, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organization', user?.organizationId] });
      setSuccess('Organization updated successfully');
      setError(null);
      setTimeout(() => setSuccess(null), 3000);
    },
    onError: (err: any) => {
      setError(err.response?.data?.message || 'Failed to update organization');
      setSuccess(null);
    },
  });

  const onSubmit = (data: OrgFormData) => {
    setError(null);
    setSuccess(null);
    updateMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!user?.organizationId || !organization) {
    return (
      <Box>
        <Alert severity="warning">
          No organization assigned to your account. Please contact support.
        </Alert>
      </Box>
    );
  }

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Organization Settings
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage your organization information
          </Typography>
        </Box>
        <Chip
          label={organization.active ? 'Active' : 'Inactive'}
          color={organization.active ? 'success' : 'default'}
        />
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 3 }}>
          {success}
        </Alert>
      )}

      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={3}>
          {/* Organization Info Card */}
          <Grid size={12}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                  <BusinessIcon sx={{ fontSize: 40, color: 'primary.main' }} />
                  <Box>
                    <Typography variant="h6" fontWeight="bold">
                      Organization Information
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Basic details about your organization
                    </Typography>
                  </Box>
                </Box>

                <Grid container spacing={3}>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="name"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Organization Name"
                          fullWidth
                          required
                          error={!!errors.name}
                          helperText={errors.name?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="email"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Email Address"
                          type="email"
                          fullWidth
                          error={!!errors.email}
                          helperText={errors.email?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="phoneNumber"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Phone Number"
                          fullWidth
                          error={!!errors.phoneNumber}
                          helperText={errors.phoneNumber?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="website"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Website"
                          fullWidth
                          error={!!errors.website}
                          helperText={errors.website?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="addressLine1"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Address Line 1"
                          fullWidth
                          error={!!errors.addressLine1}
                          helperText={errors.addressLine1?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="addressLine2"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Address Line 2"
                          fullWidth
                          error={!!errors.addressLine2}
                          helperText={errors.addressLine2?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 4 }}>
                    <Controller
                      name="city"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="City"
                          fullWidth
                          error={!!errors.city}
                          helperText={errors.city?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 4 }}>
                    <Controller
                      name="stateProvince"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="State/Province"
                          fullWidth
                          error={!!errors.stateProvince}
                          helperText={errors.stateProvince?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 4 }}>
                    <Controller
                      name="postalCode"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Postal Code"
                          fullWidth
                          error={!!errors.postalCode}
                          helperText={errors.postalCode?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="taxIdentificationNumber"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Tax ID / TIN"
                          fullWidth
                          error={!!errors.taxIdentificationNumber}
                          helperText={errors.taxIdentificationNumber?.message}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="registrationNumber"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Registration Number"
                          fullWidth
                          error={!!errors.registrationNumber}
                          helperText={errors.registrationNumber?.message}
                        />
                      )}
                    />
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>

          {/* Action Buttons */}
          <Grid size={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
              <Button
                variant="outlined"
                onClick={() => reset()}
                disabled={!isDirty || updateMutation.isPending}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                startIcon={<SaveIcon />}
                disabled={!isDirty || updateMutation.isPending}
              >
                {updateMutation.isPending ? 'Saving...' : 'Save Changes'}
              </Button>
            </Box>
          </Grid>
        </Grid>
      </form>
    </Box>
  );
};

export default OrganizationSettingsPage;
