import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  TablePagination,
  TextField,
  InputAdornment,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Search as SearchIcon,
  ManageAccounts as ManageIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { hrPayrollApi } from '../../api/hrPayrollApi';
import { toast } from 'react-toastify';

interface PayrollPeriod {
  id: number;
  periodName: string;
  periodCode: string;
  status: string;
  totalEmployees: number;
  totalApprovedLevel1: number;
  totalGrossPay: number;
  totalNetPay: number;
}

const HRPayrollPreparation: React.FC = () => {
  const navigate = useNavigate();
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPeriod] = useState<PayrollPeriod | null>(null);
  const [submitDialog, setSubmitDialog] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalElements, setTotalElements] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadPeriods();
  }, [page, rowsPerPage, searchTerm]);

  const loadPeriods = async () => {
    try {
      setLoading(true);
      const response = await hrPayrollApi.getPeriodsForPreparation(
        undefined, 
        searchTerm || undefined, 
        page, 
        rowsPerPage
      );
      const data = response.data.data;
      setPeriods(data.content || []);
      setTotalElements(data.totalElements || 0);
    } catch (error: any) {
      toast.error('Failed to load periods');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitForReview = async () => {
    if (!selectedPeriod) return;

    try {
      await hrPayrollApi.submitForReview(selectedPeriod.id);
      toast.success('Period submitted for Finance review');
      setSubmitDialog(false);
      loadPeriods();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to submit');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PROCESSING':
        return 'info';
      case 'DRAFT':
        return 'warning';
      case 'PREPARED':
        return 'success';
      default:
        return 'default';
    }
  };

  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" fontWeight="bold">
          HR Payroll Preparation
        </Typography>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={loadPeriods}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      <Alert severity="info" sx={{ mb: 3 }}>
        Review and approve employee payroll records before submitting to Finance for review
      </Alert>

      <Box mb={3}>
        <TextField
          fullWidth
          placeholder="Search by period name or code..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setPage(0);
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Period</TableCell>
              <TableCell>Code</TableCell>
              <TableCell>Status</TableCell>
              <TableCell align="right">Employees</TableCell>
              <TableCell align="right">Approved (L1)</TableCell>
              <TableCell align="right">Gross Pay</TableCell>
              <TableCell align="right">Net Pay</TableCell>
              <TableCell align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {periods.map((period) => (
              <TableRow key={period.id} hover>
                <TableCell>{period.periodName}</TableCell>
                <TableCell>{period.periodCode}</TableCell>
                <TableCell>
                  <Chip
                    label={period.status}
                    color={getStatusColor(period.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell align="right">{period.totalEmployees}</TableCell>
                <TableCell align="right">
                  {period.totalApprovedLevel1} / {period.totalEmployees}
                </TableCell>
                <TableCell align="right">
                  {period.totalGrossPay?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="right">
                  {period.totalNetPay?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="center">
                  <Button
                    variant="contained"
                    size="small"
                    startIcon={<ManageIcon />}
                    onClick={() => navigate(`/hr/payroll/edit/${period.id}`)}
                  >
                    Manage
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {periods.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <Typography color="text.secondary" py={3}>
                    No periods available for preparation
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25, 50]}
        component="div"
        count={totalElements}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={(_, newPage) => setPage(newPage)}
        onRowsPerPageChange={(e) => {
          setRowsPerPage(parseInt(e.target.value, 10));
          setPage(0);
        }}
      />

      {/* Submit for Review Dialog */}
      <Dialog open={submitDialog} onClose={() => setSubmitDialog(false)}>
        <DialogTitle>Submit for Finance Review</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to submit <strong>{selectedPeriod?.periodName}</strong> for Finance review?
          </Typography>
          <Alert severity="warning" sx={{ mt: 2 }}>
            Ensure all employee records are approved at Level 1 before submitting.
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSubmitDialog(false)}>Cancel</Button>
          <Button onClick={handleSubmitForReview} variant="contained" color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default HRPayrollPreparation;
