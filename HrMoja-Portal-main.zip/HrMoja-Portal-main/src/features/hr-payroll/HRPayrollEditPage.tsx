import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  TablePagination,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Tooltip,
  Checkbox,
  LinearProgress,
  Stack,
  Menu,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
  Edit as EditIcon,
  CheckCircle as ApproveIcon,
  Cancel as RejectIcon,
  Send as SubmitIcon,
  Refresh as RefreshIcon,
  Search as SearchIcon,
  SelectAll as SelectAllIcon,
  CheckBox as CheckAllIcon,
  AccountBalance as BankIcon,
  CheckCircleOutline as BankReadyIcon,
  ArrowDropDown as ArrowDropDownIcon,
} from '@mui/icons-material';
import { hrPayrollApi } from '../../api/hrPayrollApi';
import { toast } from 'react-toastify';
import EmployeeLineItemEditor from '../../components/payroll/EmployeeLineItemEditor';
import BankDetailsDialog from '../../components/dialogs/BankDetailsDialog';

interface PayrollPeriod {
  id: number;
  periodName: string;
  periodCode: string;
  status: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
  totalEmployees: number;
  totalGrossPay: number;
  totalNetPay: number;
}

interface EmployeeRecord {
  id: number;
  employeeId: number;
  payrollPeriodId: number;
  employee: {
    id: number;
    employeeNumber: string;
    firstName: string;
    lastName: string;
    department: {
      name: string;
    };
  };
  employeeName: string;
  employeeNumber: string;
  departmentName: string;
  basicSalary: number;
  grossSalary: number;
  totalEarnings: number;
  totalDeductions: number;
  totalStatutory: number;
  totalTaxes: number;
  netSalary: number;
  taxableIncome: number;
  pensionableIncome: number;
  status: string;
  approvedLevel1: boolean;
  level1ApprovedBy: number;
  level1ApprovedAt: string;
  rejected: boolean;
  rejectionReason: string;
  isPaid: boolean;
  hasBankDetails: boolean;
}

interface ApprovalStats {
  totalRecords: number;
  approvedCount: number;
  rejectedCount: number;
  pendingCount: number;
  approvalPercentage: number;
}

const HRPayrollEditPage: React.FC = () => {
  const { periodId } = useParams<{ periodId: string }>();
  const navigate = useNavigate();
  
  const [period, setPeriod] = useState<PayrollPeriod | null>(null);
  const [records, setRecords] = useState<EmployeeRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<EmployeeRecord | null>(null);
  
  // Pagination
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [totalElements, setTotalElements] = useState(0);
  
  // Search and Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [approvalLevelFilter, setApprovalLevelFilter] = useState<number | ''>('');
  
  // Selection for bulk actions
  const [selectedRecords, setSelectedRecords] = useState<number[]>([]);
  const [approvalStats, setApprovalStats] = useState<ApprovalStats | null>(null);
  
  // Dialogs
  const [lineItemEditorOpen, setLineItemEditorOpen] = useState(false);
  const [bankDetailsDialog, setBankDetailsDialog] = useState(false);
  const [approveDialog, setApproveDialog] = useState(false);
  const [rejectDialog, setRejectDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [submitDialog, setSubmitDialog] = useState(false);
  const [submissionComment, setSubmissionComment] = useState('');
  
  // Actions menu
  const [actionsMenuAnchor, setActionsMenuAnchor] = useState<null | HTMLElement>(null);

  useEffect(() => {
    if (periodId) {
      loadPeriodData();
    }
  }, [periodId, page, rowsPerPage, searchTerm, departmentFilter, statusFilter, approvalLevelFilter]);

  const loadPeriodData = async () => {
    try {
      setLoading(true);
      const [periodRes, recordsRes] = await Promise.all([
        hrPayrollApi.getPeriodDetails(Number(periodId)),
        hrPayrollApi.getEmployeeRecords(
          Number(periodId),
          searchTerm || undefined,
          departmentFilter || undefined,
          statusFilter || undefined,
          approvalLevelFilter !== '' ? Number(approvalLevelFilter) : undefined,
          page,
          rowsPerPage
        ),
      ]);
      setPeriod(periodRes.data.data);
      const data = recordsRes.data.data;
      setRecords(data.content || []);
      setTotalElements(data.totalElements || 0);
      calculateApprovalStats(data.content || []);
    } catch (error: any) {
      toast.error('Failed to load payroll data');
    } finally {
      setLoading(false);
    }
  };

  const calculateApprovalStats = (allRecords: EmployeeRecord[]) => {
    const totalRecords = allRecords.length;
    const approvedCount = allRecords.filter(r => r.approvedLevel1).length;
    const rejectedCount = allRecords.filter(r => r.rejected).length;
    const pendingCount = totalRecords - approvedCount - rejectedCount;
    const approvalPercentage = totalRecords > 0 ? (approvedCount / (totalRecords - rejectedCount)) * 100 : 0;
    
    setApprovalStats({
      totalRecords,
      approvedCount,
      rejectedCount,
      pendingCount,
      approvalPercentage,
    });
  };

  const handleSelectAll = () => {
    const activeRecords = records.filter(r => !r.rejected);
    if (selectedRecords.length === activeRecords.length) {
      setSelectedRecords([]);
    } else {
      setSelectedRecords(activeRecords.map(r => r.id));
    }
  };

  const handleSelectRecord = (recordId: number) => {
    if (selectedRecords.includes(recordId)) {
      setSelectedRecords(selectedRecords.filter(id => id !== recordId));
    } else {
      setSelectedRecords([...selectedRecords, recordId]);
    }
  };

  const handleApproveSelected = async () => {
    if (selectedRecords.length === 0) {
      toast.warning('Please select records to approve');
      return;
    }
    try {
      setLoading(true);
      await Promise.all(selectedRecords.map(id => hrPayrollApi.approveRecord(id)));
      toast.success(`${selectedRecords.length} record(s) approved`);
      setSelectedRecords([]);
      loadPeriodData();
    } catch (error: any) {
      toast.error('Failed to approve selected records');
    } finally {
      setLoading(false);
    }
  };

  const handleEditRecord = (record: EmployeeRecord) => {
    setSelectedRecord(record);
    setLineItemEditorOpen(true);
  };

  const handleUpdateBankDetails = (record: EmployeeRecord) => {
    setSelectedRecord(record);
    setBankDetailsDialog(true);
  };

  const handleBankDetailsSuccess = () => {
    setBankDetailsDialog(false);
    setSelectedRecord(null);
    loadPeriodData();
  };

  const handleOpenActionsMenu = (event: React.MouseEvent<HTMLElement>, record: EmployeeRecord) => {
    setActionsMenuAnchor(event.currentTarget);
    setSelectedRecord(record);
  };

  const handleCloseActionsMenu = () => {
    setActionsMenuAnchor(null);
  };

  const handleApproveRecord = async () => {
    if (!selectedRecord) return;

    try {
      await hrPayrollApi.approveRecord(selectedRecord.id);
      toast.success('Record approved (Level 1)');
      setApproveDialog(false);
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve record');
    }
  };

  const handleRejectRecord = async () => {
    if (!selectedRecord || !rejectReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    try {
      await hrPayrollApi.rejectRecord(selectedRecord.id, rejectReason);
      toast.success('Record rejected');
      setRejectDialog(false);
      setRejectReason('');
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to reject record');
    }
  };

  const handleApproveAll = async () => {
    if (!periodId) return;

    try {
      await hrPayrollApi.approveAllRecords(Number(periodId));
      toast.success('All records approved');
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve all records');
    }
  };

  const handleSubmitForReview = async () => {
    if (!periodId) return;

    // Validate all active records are either approved or rejected (no pending)
    if (approvalStats && approvalStats.pendingCount > 0) {
      toast.error(
        `Cannot submit: ${approvalStats.pendingCount} record(s) are still pending approval. ` +
        'Please approve or reject all records before submitting for Finance review.'
      );
      return;
    }

    // Ensure at least one record is approved
    if (approvalStats && approvalStats.approvedCount === 0) {
      toast.error('Cannot submit: No approved records found. All records have been rejected.');
      return;
    }

    // Check for missing bank details in APPROVED records only
    const approvedRecordsWithoutBank = records.filter(r => r.approvedLevel1 && !r.hasBankDetails).length;
    if (approvedRecordsWithoutBank > 0) {
      toast.error(
        `Cannot submit: ${approvedRecordsWithoutBank} approved employee(s) are missing bank details. ` +
        'Please update bank details for approved employees before submitting.'
      );
      return;
    }

    // Validate submission comment is provided (mandatory for audit trail)
    if (!submissionComment || submissionComment.trim() === '') {
      toast.error('Submission notes/remarks are mandatory for audit purposes. Please provide a comment.');
      return;
    }

    try {
      await hrPayrollApi.submitForReview(Number(periodId), submissionComment);
      toast.success('Period submitted for Finance review');
      setSubmitDialog(false);
      setSubmissionComment('');
      navigate('/hr/payroll/prepare');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to submit');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'success';
      case 'REJECTED':
        return 'error';
      case 'PENDING':
        return 'warning';
      default:
        return 'default';
    }
  };

  if (loading && !period) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center" gap={2}>
          <IconButton onClick={() => navigate('/hr/payroll/prepare')}>
            <BackIcon />
          </IconButton>
          <Box>
            <Typography variant="h4" fontWeight="bold">
              Edit Payroll - {period?.periodName}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {period?.periodCode} | Status: {period?.status}
            </Typography>
          </Box>
        </Box>
        <Box display="flex" gap={2}>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={loadPeriodData}
            disabled={loading}
          >
            Refresh
          </Button>
          <Button
            variant="contained"
            color="success"
            startIcon={<ApproveIcon />}
            onClick={handleApproveAll}
            disabled={loading || period?.status !== 'PROCESSING'}
          >
            Approve All
          </Button>
          <Button
            variant="contained"
            color="primary"
            startIcon={<SubmitIcon />}
            onClick={() => setSubmitDialog(true)}
            disabled={
              loading || 
              period?.status !== 'PROCESSING' || 
              (approvalStats ? approvalStats.pendingCount > 0 : false) ||
              (approvalStats ? approvalStats.approvedCount === 0 : false)
            }
          >
            Submit for Review
          </Button>
        </Box>
      </Box>

      {/* Summary Cards */}
      <Box display="flex" gap={3} mb={3} flexWrap="wrap">
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Employees
              </Typography>
              <Typography variant="h4" fontWeight="bold">
                {period?.totalEmployees || 0}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Approved Records
              </Typography>
              <Typography variant="h4" fontWeight="bold" color="success.main">
                {records.filter(r => r.approvedLevel1).length}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Gross Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {period?.totalGrossPay?.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Net Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {period?.totalNetPay?.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
      </Box>

      <Alert severity="info" sx={{ mb: 3 }}>
        Review and edit employee records. Approve records individually or in bulk before submitting to Finance.
      </Alert>

      {/* Approval Progress Bar */}
      {approvalStats && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6" fontWeight="bold">
                Level 1 Approval Progress
              </Typography>
              <Stack direction="row" spacing={1}>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<SelectAllIcon />}
                  onClick={handleSelectAll}
                  disabled={loading || records.length === 0}
                >
                  {selectedRecords.length === records.filter(r => !r.rejected).length ? 'Deselect All' : 'Select All'}
                </Button>
                <Button
                  variant="contained"
                  size="small"
                  startIcon={<ApproveIcon />}
                  onClick={handleApproveSelected}
                  disabled={loading || selectedRecords.length === 0}
                >
                  Approve Selected ({selectedRecords.length})
                </Button>
                <Button
                  variant="contained"
                  color="success"
                  size="small"
                  startIcon={<CheckAllIcon />}
                  onClick={handleApproveAll}
                  disabled={loading}
                >
                  Approve All
                </Button>
              </Stack>
            </Box>
            <Box display="flex" justifyContent="space-between" mb={1}>
              <Typography variant="body2" color="text.secondary">
                Approval Progress: {approvalStats.approvedCount} of {approvalStats.totalRecords - approvalStats.rejectedCount} approved
              </Typography>
              <Typography variant="body2" fontWeight="bold">
                {approvalStats.approvalPercentage.toFixed(1)}%
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={approvalStats.approvalPercentage}
              color={approvalStats.approvalPercentage === 100 ? 'success' : 'primary'}
              sx={{ height: 8, borderRadius: 1 }}
            />
            <Box display="flex" gap={2} mt={1}>
              <Chip label={`${approvalStats.approvedCount} Approved`} color="success" size="small" />
              <Chip label={`${approvalStats.pendingCount} Pending`} color="warning" size="small" />
              {approvalStats.rejectedCount > 0 && (
                <Chip label={`${approvalStats.rejectedCount} Rejected`} color="error" size="small" />
              )}
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Search and Filters */}
      <Box mb={3} display="flex" gap={2} flexWrap="wrap">
        <TextField
          placeholder="Search by name or employee number..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setPage(0);
          }}
          sx={{ flex: '1 1 300px' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
        <FormControl sx={{ minWidth: 150 }}>
          <InputLabel>Department</InputLabel>
          <Select
            value={departmentFilter}
            onChange={(e) => {
              setDepartmentFilter(e.target.value);
              setPage(0);
            }}
            label="Department"
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="IT">IT</MenuItem>
            <MenuItem value="HR">HR</MenuItem>
            <MenuItem value="Finance">Finance</MenuItem>
            <MenuItem value="Operations">Operations</MenuItem>
          </Select>
        </FormControl>
        <FormControl sx={{ minWidth: 150 }}>
          <InputLabel>Status</InputLabel>
          <Select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setPage(0);
            }}
            label="Status"
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="PENDING">Pending</MenuItem>
            <MenuItem value="APPROVED">Approved</MenuItem>
            <MenuItem value="REJECTED">Rejected</MenuItem>
          </Select>
        </FormControl>
        <FormControl sx={{ minWidth: 180 }}>
          <InputLabel>Approval Level</InputLabel>
          <Select
            value={approvalLevelFilter}
            onChange={(e) => {
              setApprovalLevelFilter(e.target.value as number | '');
              setPage(0);
            }}
            label="Approval Level"
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value={0}>Not Approved</MenuItem>
            <MenuItem value={1}>Level 1+</MenuItem>
            <MenuItem value={2}>Level 2+</MenuItem>
          </Select>
        </FormControl>
        <Tooltip title="Clear Filters">
          <Button
            variant="outlined"
            onClick={() => {
              setSearchTerm('');
              setDepartmentFilter('');
              setStatusFilter('');
              setApprovalLevelFilter('');
              setPage(0);
            }}
          >
            Clear
          </Button>
        </Tooltip>
      </Box>

      {/* Employee Records Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell padding="checkbox"></TableCell>
              <TableCell>Employee Code</TableCell>
              <TableCell>Employee Name</TableCell>
              <TableCell>Department</TableCell>
              <TableCell align="right">Basic Salary</TableCell>
              <TableCell align="right">Gross Pay</TableCell>
              <TableCell align="right">Deductions</TableCell>
              <TableCell align="right">Net Pay</TableCell>
              <TableCell>Status</TableCell>
              <TableCell align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {records.map((record) => (
              <TableRow 
                key={record.id} 
                hover
                selected={selectedRecords.includes(record.id)}
                sx={{ backgroundColor: record.approvedLevel1 ? 'success.50' : 'inherit' }}
              >
                <TableCell padding="checkbox">
                  <Checkbox
                    checked={selectedRecords.includes(record.id)}
                    onChange={() => handleSelectRecord(record.id)}
                    disabled={loading || record.rejected}
                  />
                </TableCell>
                <TableCell>{record.employee?.employeeNumber || record.employeeNumber}</TableCell>
                <TableCell>
                  {record.employee ? `${record.employee.firstName} ${record.employee.lastName}` : record.employeeName}
                </TableCell>
                <TableCell>{record.employee?.department?.name || record.departmentName}</TableCell>
                <TableCell align="right">
                  {record.basicSalary?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="right">
                  {record.grossSalary?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="right">
                  {record.totalDeductions?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="right">
                  {record.netSalary?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell>
                  <Chip
                    label={`${record.status} (L${record.approvedLevel1 ? '1' : '0'})`}
                    color={getStatusColor(record.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell align="center">
                  {!record.hasBankDetails ? (
                    <Button
                      variant="outlined"
                      color="warning"
                      size="small"
                      startIcon={<BankIcon />}
                      onClick={() => handleUpdateBankDetails(record)}
                    >
                      Update Bank Details
                    </Button>
                  ) : (
                    <Box display="flex" alignItems="center" gap={1}>
                      <Chip
                        icon={<BankReadyIcon />}
                        label="Bank Ready"
                        color="success"
                        size="small"
                        variant="outlined"
                      />
                      <Button
                        variant="outlined"
                        size="small"
                        endIcon={<ArrowDropDownIcon />}
                        onClick={(e) => handleOpenActionsMenu(e, record)}
                      >
                        Actions
                      </Button>
                    </Box>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {records.length === 0 && (
              <TableRow>
                <TableCell colSpan={9} align="center">
                  <Typography color="text.secondary" py={3}>
                    No employee records found
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 20, 50, 100]}
        component="div"
        count={totalElements}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={(_, newPage) => setPage(newPage)}
        onRowsPerPageChange={(e) => {
          setRowsPerPage(parseInt(e.target.value, 10));
          setPage(0);
        }}
      />

      {/* Employee Line Item Editor */}
      {selectedRecord && lineItemEditorOpen && (
        <EmployeeLineItemEditor
          open={lineItemEditorOpen}
          onClose={() => {
            setLineItemEditorOpen(false);
            setSelectedRecord(null);
          }}
          record={selectedRecord}
          onUpdate={loadPeriodData}
        />
      )}

      {/* Bank Details Dialog */}
      {selectedRecord && (
        <BankDetailsDialog
          open={bankDetailsDialog}
          onClose={() => {
            setBankDetailsDialog(false);
            setSelectedRecord(null);
          }}
          employeeId={selectedRecord.employeeId}
          employeeName={selectedRecord.employeeName}
          onSuccess={handleBankDetailsSuccess}
        />
      )}

      {/* Actions Menu */}
      <Menu
        anchorEl={actionsMenuAnchor}
        open={Boolean(actionsMenuAnchor)}
        onClose={handleCloseActionsMenu}
      >
        <MenuItem
          onClick={() => {
            handleCloseActionsMenu();
            if (selectedRecord) handleUpdateBankDetails(selectedRecord);
          }}
        >
          <ListItemIcon>
            <BankIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Update Bank Details</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleCloseActionsMenu();
            if (selectedRecord) handleEditRecord(selectedRecord);
          }}
        >
          <ListItemIcon>
            <EditIcon fontSize="small" color="primary" />
          </ListItemIcon>
          <ListItemText>Edit Line Items</ListItemText>
        </MenuItem>
        {selectedRecord && !selectedRecord.approvedLevel1 && (
          <>
            <MenuItem
              onClick={() => {
                handleCloseActionsMenu();
                setApproveDialog(true);
              }}
            >
              <ListItemIcon>
                <ApproveIcon fontSize="small" color="success" />
              </ListItemIcon>
              <ListItemText>Approve Record</ListItemText>
            </MenuItem>
            <MenuItem
              onClick={() => {
                handleCloseActionsMenu();
                setRejectDialog(true);
              }}
            >
              <ListItemIcon>
                <RejectIcon fontSize="small" color="error" />
              </ListItemIcon>
              <ListItemText>Reject Record</ListItemText>
            </MenuItem>
          </>
        )}
      </Menu>

      {/* Approve Record Dialog */}
      <Dialog open={approveDialog} onClose={() => setApproveDialog(false)}>
        <DialogTitle>Approve Record</DialogTitle>
        <DialogContent>
          <Typography>
            Approve payroll record for <strong>{selectedRecord?.employee ? `${selectedRecord.employee.firstName} ${selectedRecord.employee.lastName}` : selectedRecord?.employeeName}</strong>?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setApproveDialog(false)}>Cancel</Button>
          <Button onClick={handleApproveRecord} variant="contained" color="success">
            Approve
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reject Record Dialog */}
      <Dialog open={rejectDialog} onClose={() => setRejectDialog(false)}>
        <DialogTitle>Reject Record</DialogTitle>
        <DialogContent>
          <Typography mb={2}>
            Reject payroll record for <strong>{selectedRecord?.employee ? `${selectedRecord.employee.firstName} ${selectedRecord.employee.lastName}` : selectedRecord?.employeeName}</strong>?
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Rejection Reason"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            required
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRejectDialog(false)}>Cancel</Button>
          <Button onClick={handleRejectRecord} variant="contained" color="error">
            Reject
          </Button>
        </DialogActions>
      </Dialog>

      {/* Submit for Review Dialog */}
      <Dialog open={submitDialog} onClose={() => setSubmitDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Submit for Finance Review</DialogTitle>
        <DialogContent>
          {approvalStats && approvalStats.pendingCount > 0 ? (
            <Alert severity="error" sx={{ mb: 2 }}>
              Cannot submit: {approvalStats.pendingCount} record(s) are still pending approval.
              <br />
              Please approve or reject all records before submitting for Finance review.
            </Alert>
          ) : approvalStats && approvalStats.approvedCount === 0 ? (
            <Alert severity="error" sx={{ mb: 2 }}>
              Cannot submit: No approved records found. All records have been rejected.
            </Alert>
          ) : (
            <>
              <Alert severity="info" sx={{ mb: 2 }}>
                Submit {period?.periodName} for Finance review?
                <br />
                {approvalStats?.approvedCount} record(s) approved, {approvalStats?.rejectedCount} rejected.
                <br />
                This will move the payroll to Finance review (Level 2).
              </Alert>
              <TextField
                label="Submission Notes/Remarks"
                multiline
                rows={4}
                fullWidth
                required
                value={submissionComment}
                onChange={(e) => setSubmissionComment(e.target.value)}
                placeholder="Add notes or remarks for the Finance team... (Required for audit trail)"
                helperText="Required: Provide context, issues resolved, or important notes for Finance review"
                sx={{ mt: 2 }}
                error={submissionComment.trim() === ''}
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSubmitDialog(false)}>Cancel</Button>
          <Button 
            onClick={handleSubmitForReview} 
            variant="contained" 
            color="primary"
            disabled={
              (approvalStats ? approvalStats.pendingCount > 0 : false) ||
              (approvalStats ? approvalStats.approvedCount === 0 : false)
            }
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default HRPayrollEditPage;
