import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Paper,
  Button,
  Alert,
  Card,
  CardContent,
  CircularProgress,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  Refresh as RefreshIcon,
  TrendingUp as TrendingIcon,
} from '@mui/icons-material';
import { financePayrollApi } from '../../api/financePayrollApi';
import { toast } from 'react-toastify';

interface PayrollPeriod {
  id: number;
  periodName: string;
  periodCode: string;
  status: string;
  totalEmployees: number;
  totalGrossPay: number;
  totalDeductions: number;
  totalNetPay: number;
  preparedAt: string;
  preparedBy: number;
}

const FinancePayrollReview: React.FC = () => {
  const navigate = useNavigate();
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadPeriods();
  }, []);

  const loadPeriods = async () => {
    try {
      setLoading(true);
      const response = await financePayrollApi.getPeriodsForReview();
      setPeriods(response.data.data || []);
    } catch (error: any) {
      toast.error('Failed to load periods');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PREPARED':
        return 'primary';
      case 'REVIEWED':
        return 'success';
      case 'REJECTED':
        return 'error';
      default:
        return 'default';
    }
  };

  const totalEmployees = periods.reduce((sum, p) => sum + (p.totalEmployees || 0), 0);
  const totalGrossPay = periods.reduce((sum, p) => sum + (p.totalGrossPay || 0), 0);
  const totalNetPay = periods.reduce((sum, p) => sum + (p.totalNetPay || 0), 0);

  if (loading && periods.length === 0) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold">
            Finance Payroll Review
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Review and validate payroll periods submitted by HR
          </Typography>
        </Box>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={loadPeriods}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      {/* Summary Cards */}
      <Box display="flex" gap={3} mb={3} flexWrap="wrap">
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Periods Pending Review
              </Typography>
              <Typography variant="h4" fontWeight="bold">
                {periods.length}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Employees
              </Typography>
              <Typography variant="h4" fontWeight="bold" color="primary.main">
                {totalEmployees}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Gross Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {totalGrossPay.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Net Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {totalNetPay.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
      </Box>

      <Alert severity="info" sx={{ mb: 3 }}>
        <strong>Finance Review Process:</strong> Review payroll data submitted by HR, perform financial
        validation, and approve/reject periods. Click on a period to view detailed employee records and
        validation reports.
      </Alert>

      {/* Periods Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Period</TableCell>
              <TableCell>Code</TableCell>
              <TableCell>Status</TableCell>
              <TableCell align="right">Employees</TableCell>
              <TableCell align="right">Gross Pay</TableCell>
              <TableCell align="right">Deductions</TableCell>
              <TableCell align="right">Net Pay</TableCell>
              <TableCell align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {periods.map((period) => (
              <TableRow key={period.id} hover>
                <TableCell>
                  <Typography fontWeight="medium">{period.periodName}</Typography>
                </TableCell>
                <TableCell>{period.periodCode}</TableCell>
                <TableCell>
                  <Chip
                    label={period.status}
                    color={getStatusColor(period.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell align="right">{period.totalEmployees}</TableCell>
                <TableCell align="right">
                  {period.totalGrossPay?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="right">
                  {period.totalDeductions?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="right">
                  {period.totalNetPay?.toLocaleString('en-UG', {
                    style: 'currency',
                    currency: 'UGX',
                  })}
                </TableCell>
                <TableCell align="center">
                  <Button
                    variant="contained"
                    size="small"
                    startIcon={<ViewIcon />}
                    onClick={() => navigate(`/finance/payroll/review/${period.id}`)}
                  >
                    Review
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {periods.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <Box py={6}>
                    <TrendingIcon sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary">
                      No periods pending Finance review
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mt={1}>
                      Periods will appear here once HR submits them for review
                    </Typography>
                  </Box>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default FinancePayrollReview;
