import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  List,
  ListItem,
  ListItemText,
  Stack,
  Tabs,
  Tab,
  TablePagination,
  InputAdornment,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Menu,
  ListItemIcon,
  Checkbox,
  Tooltip,
  LinearProgress,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
  CheckCircle as ApproveIcon,
  Cancel as RejectIcon,
  Refresh as RefreshIcon,
  ExpandMore as ExpandMoreIcon,
  Assessment as ReportIcon,
  AccountBalance as BankIcon,
  Warning as WarningIcon,
  Search as SearchIcon,
  PieChart as PieChartIcon,
  AttachMoney as MoneyIcon,
  People as PeopleIcon,
  Edit as EditIcon,
  Visibility as ViewIcon,
  MoreVert as MoreVertIcon,
} from '@mui/icons-material';
import { financePayrollApi } from '../../api/financePayrollApi';
import { toast } from 'react-toastify';
import EmployeeLineItemEditor from '../../components/payroll/EmployeeLineItemEditor';
import ViewBankDetailsDialog from '../../components/dialogs/ViewBankDetailsDialog';

interface PayrollPeriod {
  id: number;
  periodName: string;
  periodCode: string;
  status: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
  totalEmployees: number;
  totalGrossPay: number;
  totalNetPay: number;
  totalDeductions: number;
  totalStatutory: number;
  totalTaxes: number;
}

// Unused - keeping for future reference
// interface EmployeeRecord {
//   id: number;
//   employeeId: number;
//   payrollPeriodId: number;
//   employee: {
//     id: number;
//     employeeNumber: string;
//     firstName: string;
//     lastName: string;
//     department: {
//       name: string;
//     };
//   };
//   employeeName: string;
//   employeeNumber: string;
//   departmentName: string;
//   basicSalary: number;
//   grossSalary: number;
//   totalEarnings: number;
//   totalDeductions: number;
//   totalStatutory: number;
//   totalTaxes: number;
//   netSalary: number;
//   taxableIncome: number;
//   pensionableIncome: number;
//   status: string;
//   approvedLevel1: boolean;
//   reviewedLevel2: boolean;
//   level1ApprovedBy: number;
//   level1ApprovedAt: string;
//   level2ReviewedBy: number;
//   level2ReviewedAt: string;
//   rejected: boolean;
//   rejectionReason: string;
//   isPaid: boolean;
//   hasBankDetails: boolean;
// }

// Unused - keeping for future reference
// interface FinancialSummary {
//   totalGrossPay: number;
//   totalNetPay: number;
//   totalDeductions: number;
//   totalStatutoryDeductions: number;
//   totalTaxes: number;
//   totalBankTransfers: number;
//   totalEmployees: number;
//   approvedEmployees: number;
//   departmentBreakdown: Array<{
//     department: string;
//     employeeCount: number;
//     totalGross: number;
//     totalNet: number;
//   }>;
// }

// Unused - keeping for future reference
// interface ValidationReport {
//   passed: boolean;
//   errors: string[];
//   warnings: string[];
//   summary: {
//     totalRecords: number;
//     validRecords: number;
//     invalidRecords: number;
//     // missingBankDetails: number;
//   };
// }

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

const FinancePayrollReviewDetail: React.FC = () => {
  const { periodId } = useParams<{ periodId: string }>();
  const navigate = useNavigate();

  const [period, setPeriod] = useState<PayrollPeriod | null>(null);
  const [records, setRecords] = useState<any>(null);
  const [financialSummary, setFinancialSummary] = useState<any | null>(null);
  const [validationReport, setValidationReport] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  
  // Pagination and filtering
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [reviewStatusFilter, setReviewStatusFilter] = useState('');
  const [departments, setDepartments] = useState<string[]>([]);
  
  // Multi-select for bulk review
  const [selectedRecords, setSelectedRecords] = useState<number[]>([]);
  
  // Review completion tracking
  const [reviewStats, setReviewStats] = useState<{
    totalEligible: number;
    reviewedCount: number;
    notReviewedCount: number;
    allReviewed: boolean;
  }>({ totalEligible: 0, reviewedCount: 0, notReviewedCount: 0, allReviewed: false });

  // Dialogs
  const [reviewDialog, setReviewDialog] = useState(false);
  const [rejectDialog, setRejectDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [lineItemEditorOpen, setLineItemEditorOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [bankDetailsDialogOpen, setBankDetailsDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<{ id: number; name: string } | null>(null);
  const [actionsMenuAnchor, setActionsMenuAnchor] = useState<null | HTMLElement>(null);
  const [recordRejectDialog, setRecordRejectDialog] = useState(false);
  const [recordRejectReason, setRecordRejectReason] = useState('');
  const [reviewRecordDialog, setReviewRecordDialog] = useState(false);
  const [reviewRemarks, setReviewRemarks] = useState('');
  const [isBulkReview, setIsBulkReview] = useState(false);

  useEffect(() => {
    if (periodId) {
      loadPeriodData();
    }
  }, [periodId, page, rowsPerPage, searchTerm, departmentFilter]);

  const loadPeriodData = async () => {
    try {
      setLoading(true);
      const [periodRes, recordsRes, summaryRes, validationRes] = await Promise.all([
        financePayrollApi.getPeriodDetails(Number(periodId)),
        financePayrollApi.getEmployeeRecords(Number(periodId), searchTerm, departmentFilter, page, rowsPerPage),
        financePayrollApi.getFinancialSummary(Number(periodId)),
        financePayrollApi.getValidationReport(Number(periodId)),
      ]);
      
      setPeriod(periodRes.data.data || null);
      
      // Log the records response structure for debugging
      console.log('Records Response:', recordsRes.data);
      console.log('Records Data:', recordsRes.data.data);
      
      const recordsData = recordsRes.data.data;
      console.log('Setting records state:', recordsData);
      console.log('Records content:', recordsData?.content);
      console.log('Records totalElements:', recordsData?.totalElements);
      
      setRecords(recordsData || null);
      setFinancialSummary(summaryRes.data.data || null);
      
      // Extract unique departments for filter
      if (summaryRes.data.data?.departmentBreakdown) {
        const depts = summaryRes.data.data.departmentBreakdown.map((d: any) => d.department);
        setDepartments(depts);
      }
      
      // Set validation report directly from backend
      setValidationReport(validationRes.data.data || null);
      
      // Calculate review statistics
      if (recordsData?.content) {
        const eligibleRecords = recordsData.content.filter((r: any) => 
          !r.rejected && r.approvedLevel1
        );
        const reviewedRecords = eligibleRecords.filter((r: any) => r.reviewedLevel2);
        const totalEligible = eligibleRecords.length;
        const reviewedCount = reviewedRecords.length;
        const notReviewedCount = totalEligible - reviewedCount;
        const allReviewed = totalEligible > 0 && notReviewedCount === 0;
        
        setReviewStats({
          totalEligible,
          reviewedCount,
          notReviewedCount,
          allReviewed
        });
      }
    } catch (error: any) {
      console.error('Error loading period data:', error);
      toast.error(error.response?.data?.message || 'Failed to load period data');
    } finally {
      setLoading(false);
    }
  };

  const handleReviewAndApprove = async () => {
    if (!periodId) return;

    // Validate review comment is provided (mandatory for audit trail)
    if (!reviewComment || reviewComment.trim() === '') {
      toast.error('Review notes/remarks are mandatory for audit purposes. Please provide a comment.');
      return;
    }

    try {
      await financePayrollApi.reviewPeriod(Number(periodId), reviewComment);
      toast.success('Period reviewed successfully (Level 2)');
      setReviewDialog(false);
      setReviewComment('');
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to review period');
    }
  };

  const handleSubmitForFinalApproval = async () => {
    if (!periodId) return;

    try {
      await financePayrollApi.submitForFinalApproval(Number(periodId));
      toast.success('Period submitted for Executive final approval');
      navigate('/finance/payroll/review');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to submit for approval');
    }
  };

  const handleReject = async () => {
    if (!periodId || !rejectReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    try {
      await financePayrollApi.rejectPeriod(Number(periodId), rejectReason);
      toast.success('Period rejected and returned to HR');
      setRejectDialog(false);
      setRejectReason('');
      navigate('/finance/payroll/review');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to reject period');
    }
  };

  const handleEditLineItems = (record: any) => {
    setSelectedRecord(record);
    setLineItemEditorOpen(true);
  };

  const handleLineItemUpdate = () => {
    loadPeriodData();
  };

  const handleViewBankDetails = (record: any) => {
    const employeeName = record.employee 
      ? `${record.employee.firstName} ${record.employee.lastName}` 
      : record.employeeName;
    setSelectedEmployee({
      id: record.employee?.id || record.employeeId,
      name: employeeName
    });
    setBankDetailsDialogOpen(true);
  };

  const handleOpenActionsMenu = (event: React.MouseEvent<HTMLElement>, record: any) => {
    setActionsMenuAnchor(event.currentTarget);
    setSelectedRecord(record);
  };

  const handleCloseActionsMenu = () => {
    setActionsMenuAnchor(null);
  };

  // Unused - keeping for future reference
  // const handleApproveRecord = async () => {
  //   if (!selectedRecord) return;
  //
  //   try {
  //     await financePayrollApi.approveRecord(selectedRecord.id);
  //     toast.success('Record approved successfully');
  //     handleCloseActionsMenu();
  //     loadPeriodData();
  //   } catch (error: any) {
  //     toast.error(error.response?.data?.message || 'Failed to approve record');
  //   }
  // };
  //
  // const handleRejectRecordClick = () => {
  //   handleCloseActionsMenu();
  //   setRecordRejectDialog(true);
  // };

  const handleSelectAll = () => {
    const eligibleRecords = records?.content?.filter((r: any) => 
      !r.rejected && r.approvedLevel1 && !r.reviewedLevel2
    ) || [];
    
    if (selectedRecords.length === eligibleRecords.length) {
      setSelectedRecords([]);
    } else {
      setSelectedRecords(eligibleRecords.map((r: any) => r.id));
    }
  };

  const handleSelectRecord = (recordId: number) => {
    if (selectedRecords.includes(recordId)) {
      setSelectedRecords(selectedRecords.filter(id => id !== recordId));
    } else {
      setSelectedRecords([...selectedRecords, recordId]);
    }
  };

  const handleOpenReviewDialog = (record?: any) => {
    if (record) {
      // Single record review
      setSelectedRecord(record);
      setIsBulkReview(false);
    } else {
      // Bulk review
      setIsBulkReview(true);
    }
    setReviewRemarks('');
    setReviewRecordDialog(true);
  };

  const handleConfirmReview = async () => {
    if (!reviewRemarks.trim()) {
      toast.error('Please provide review remarks for audit purposes');
      return;
    }

    try {
      if (isBulkReview) {
        // Bulk review
        if (selectedRecords.length === 0) {
          toast.error('No records selected');
          return;
        }
        await financePayrollApi.reviewBulkRecords(selectedRecords, reviewRemarks);
        toast.success(`${selectedRecords.length} record(s) reviewed successfully`);
        setSelectedRecords([]);
      } else {
        // Single record review
        if (!selectedRecord) return;
        await financePayrollApi.reviewRecord(selectedRecord.id, reviewRemarks);
        toast.success(`Record reviewed successfully for ${selectedRecord.employeeName || selectedRecord.employee?.firstName}`);
      }
      setReviewRecordDialog(false);
      setReviewRemarks('');
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to review record(s)');
    }
  };

  const handleRejectRecordConfirm = async () => {
    if (!selectedRecord || !recordRejectReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    try {
      await financePayrollApi.rejectRecord(selectedRecord.id, recordRejectReason);
      toast.success('Record rejected successfully');
      setRecordRejectDialog(false);
      setRecordRejectReason('');
      setSelectedRecord(null);
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to reject record');
    }
  };

  // Unused - keeping for future reference
  // const handleApproveAll = async () => {
  //   if (!periodId) return;
  //
  //   try {
  //     await financePayrollApi.approveAllRecords(Number(periodId));
  //     toast.success('All records approved successfully');
  //     loadPeriodData();
  //   } catch (error: any) {
  //     toast.error(error.response?.data?.message || 'Failed to approve all records');
  //   }
  // };
  //
  // const getStatusColor = (status: string) => {
  //   switch (status) {
  //     case 'APPROVED':
  //       return 'success';
  //     case 'REJECTED':
  //       return 'error';
  //     case 'PENDING':
  //       return 'warning';
  //     default:
  //       return 'default';
  //   }
  // };

  if (loading && !period) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center" gap={2}>
          <IconButton onClick={() => navigate('/finance/payroll/review')}>
            <BackIcon />
          </IconButton>
          <Box>
            <Typography variant="h4" fontWeight="bold">
              Finance Review - {period?.periodName}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {period?.periodCode} | Status: {period?.status}
            </Typography>
          </Box>
        </Box>
        <Box display="flex" gap={2}>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={loadPeriodData}
            disabled={loading}
          >
            Refresh
          </Button>
          <Button
            variant="outlined"
            color="error"
            startIcon={<RejectIcon />}
            onClick={() => setRejectDialog(true)}
            disabled={loading || period?.status !== 'PREPARED'}
          >
            Reject
          </Button>
          {/* Temporarily disabled pending client confirmation */}
          {/* <Button
            variant="outlined"
            color="success"
            startIcon={<ApproveIcon />}
            onClick={handleApproveAll}
            disabled={loading || period?.status !== 'PREPARED'}
          >
            Approve All
          </Button> */}
          <Tooltip 
            title={
              !reviewStats.allReviewed 
                ? `Please review all records first (${reviewStats.notReviewedCount} remaining)` 
                : 'Mark period as reviewed and approved by Finance'
            }
          >
            <span>
              <Button
                variant="contained"
                color="success"
                startIcon={<ApproveIcon />}
                onClick={() => setReviewDialog(true)}
                disabled={loading || period?.status !== 'PREPARED' || !reviewStats.allReviewed}
              >
                Review & Approve
              </Button>
            </span>
          </Tooltip>
        </Box>
      </Box>

      {/* Review Progress Alert */}
      {!reviewStats.allReviewed && reviewStats.totalEligible > 0 && (
        <Alert severity="warning" sx={{ mb: 3 }}>
          <Box>
            <Typography variant="body1" fontWeight="bold" gutterBottom>
              ⚠️ Review Required: {reviewStats.notReviewedCount} of {reviewStats.totalEligible} records pending review
            </Typography>
            <LinearProgress 
              variant="determinate" 
              value={(reviewStats.reviewedCount / reviewStats.totalEligible) * 100}
              sx={{ height: 8, borderRadius: 1, mb: 1 }}
            />
            <Typography variant="body2">
              Progress: {reviewStats.reviewedCount} reviewed ({Math.round((reviewStats.reviewedCount / reviewStats.totalEligible) * 100)}%)
              • You must review all records before submitting for Executive approval
            </Typography>
          </Box>
        </Alert>
      )}

      {reviewStats.allReviewed && reviewStats.totalEligible > 0 && (
        <Alert severity="success" sx={{ mb: 3 }}>
          <Typography variant="body1" fontWeight="bold">
            ✓ All {reviewStats.totalEligible} records have been reviewed! You can now proceed with final approval.
          </Typography>
        </Alert>
      )}

      {/* Summary Cards */}
      <Box display="flex" gap={3} mb={3} flexWrap="wrap">
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Employees
              </Typography>
              <Typography variant="h4" fontWeight="bold">
                {period?.totalEmployees || 0}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card sx={{ bgcolor: reviewStats.allReviewed ? 'success.50' : 'warning.50' }}>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Review Progress
              </Typography>
              <Typography variant="h4" fontWeight="bold" color={reviewStats.allReviewed ? 'success.main' : 'warning.main'}>
                {reviewStats.reviewedCount}/{reviewStats.totalEligible}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {reviewStats.allReviewed ? 'Complete' : `${reviewStats.notReviewedCount} remaining`}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Gross Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {period?.totalGrossPay?.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Deductions
              </Typography>
              <Typography variant="h5" fontWeight="bold" color="warning.main">
                {period?.totalDeductions?.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
        <Box flex="1 1 200px">
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Net Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold" color="success.main">
                {period?.totalNetPay?.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </Typography>
            </CardContent>
          </Card>
        </Box>
      </Box>

      {/* Validation Report Alert */}
      {validationReport && !validationReport.passed && validationReport.errors && validationReport.errors.length > 0 && (
        <Alert severity="error" sx={{ mb: 3 }}>
          <Typography fontWeight="bold">Validation Failed</Typography>
          {validationReport.errors.map((error: string, idx: number) => (
            <Typography key={idx} variant="body2">• {error}</Typography>
          ))}
        </Alert>
      )}

      {validationReport && validationReport.warnings && validationReport.warnings.length > 0 && (
        <Alert severity="warning" sx={{ mb: 3 }}>
          <Typography fontWeight="bold">Validation Warnings</Typography>
          {validationReport.warnings.map((warning: string, idx: number) => (
            <Typography key={idx} variant="body2">• {warning}</Typography>
          ))}
        </Alert>
      )}

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs value={activeTab} onChange={(_, newValue) => setActiveTab(newValue)}>
          <Tab label="Employee Records" />
          <Tab label="Financial Summary" />
          <Tab label="Validation Report" />
        </Tabs>
      </Box>

      {/* Tab Panels */}
      <TabPanel value={activeTab} index={0}>
        {/* Bulk Actions */}
        {selectedRecords.length > 0 && (
          <Alert severity="info" sx={{ mb: 2 }}>
            <Box display="flex" alignItems="center" gap={2}>
              <Typography variant="body2">
                {selectedRecords.length} record(s) selected
              </Typography>
              <Button
                variant="contained"
                size="small"
                onClick={() => handleOpenReviewDialog()}
                startIcon={<ApproveIcon />}
                sx={{ textTransform: 'none' }}
              >
                Review Selected
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={() => setSelectedRecords([])}
                sx={{ textTransform: 'none' }}
              >
                Deselect All
              </Button>
            </Box>
          </Alert>
        )}

        {/* Search and Filters */}
        <Box display="flex" gap={2} mb={3}>
          <TextField
            placeholder="Search by name or employee number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            size="small"
            sx={{ flex: 1 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel>Department</InputLabel>
            <Select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              label="Department"
            >
              <MenuItem value="">All Departments</MenuItem>
              {departments.map((dept) => (
                <MenuItem key={dept} value={dept}>{dept}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 200 }}>
            <InputLabel>Review Status</InputLabel>
            <Select
              value={reviewStatusFilter}
              onChange={(e) => setReviewStatusFilter(e.target.value)}
              label="Review Status"
            >
              <MenuItem value="">All Records</MenuItem>
              <MenuItem value="reviewed">Reviewed</MenuItem>
              <MenuItem value="not-reviewed">Not Reviewed</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="outlined"
            onClick={() => {
              setSearchTerm('');
              setDepartmentFilter('');
              setReviewStatusFilter('');
            }}
          >
            Clear Filters
          </Button>
        </Box>

        {/* Employee Records Table */}
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    checked={selectedRecords.length > 0 && selectedRecords.length === records?.content?.filter((r: any) => !r.rejected && r.approvedLevel1 && !r.reviewedLevel2).length}
                    indeterminate={selectedRecords.length > 0 && selectedRecords.length < (records?.content?.filter((r: any) => !r.rejected && r.approvedLevel1 && !r.reviewedLevel2).length || 0)}
                    onChange={handleSelectAll}
                  />
                </TableCell>
                <TableCell>Employee Code</TableCell>
                <TableCell>Employee Name</TableCell>
                <TableCell>Department</TableCell>
                <TableCell align="right">Basic Salary</TableCell>
                <TableCell align="right">Gross Pay</TableCell>
                <TableCell align="right">Deductions</TableCell>
                <TableCell align="right">Net Pay</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="center">Bank</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={10} align="center">
                    <CircularProgress size={24} sx={{ my: 2 }} />
                  </TableCell>
                </TableRow>
              ) : records?.content && records.content.length > 0 ? (
                records.content
                  .filter((record: any) => {
                    if (!reviewStatusFilter) return true;
                    if (reviewStatusFilter === 'reviewed') return record.reviewedLevel2;
                    if (reviewStatusFilter === 'not-reviewed') return !record.reviewedLevel2;
                    return true;
                  })
                  .map((record: any) => (
                <TableRow
                  key={record.id}
                  hover
                  sx={{ backgroundColor: record.reviewedLevel2 ? '#e8f5e9' : 'inherit' }}
                >
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedRecords.includes(record.id)}
                      onChange={() => handleSelectRecord(record.id)}
                      disabled={record.rejected || !record.approvedLevel1 || record.reviewedLevel2}
                    />
                  </TableCell>
                  <TableCell>{record.employee?.employeeNumber || record.employeeNumber}</TableCell>
                  <TableCell>
                    {record.employee
                      ? `${record.employee.firstName} ${record.employee.lastName}`
                      : record.employeeName}
                  </TableCell>
                  <TableCell>
                    {record.employee?.department?.name || record.departmentName}
                  </TableCell>
                  <TableCell align="right">
                    {record.basicSalary?.toLocaleString('en-UG', {
                      style: 'currency',
                      currency: 'UGX',
                    })}
                  </TableCell>
                  <TableCell align="right">
                    {record.grossSalary?.toLocaleString('en-UG', {
                      style: 'currency',
                      currency: 'UGX',
                    })}
                  </TableCell>
                  <TableCell align="right">
                    {record.totalDeductions?.toLocaleString('en-UG', {
                      style: 'currency',
                      currency: 'UGX',
                    })}
                  </TableCell>
                  <TableCell align="right">
                    {record.netSalary?.toLocaleString('en-UG', {
                      style: 'currency',
                      currency: 'UGX',
                    })}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={record.reviewedLevel2 ? 'Reviewed' : 'Not Reviewed'}
                      color={record.reviewedLevel2 ? 'success' : 'default'}
                      size="small"
                      sx={{
                        fontWeight: record.reviewedLevel2 ? 'bold' : 'normal',
                        bgcolor: record.reviewedLevel2 ? 'success.main' : 'grey.300',
                        color: record.reviewedLevel2 ? 'white' : 'text.secondary'
                      }}
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Box display="flex" alignItems="center" justifyContent="center" gap={0.5}>
                      {record.hasBankDetails ? (
                        <Chip 
                          icon={<BankIcon />} 
                          label="Ready" 
                          color="success" 
                          size="small"
                          onClick={() => handleViewBankDetails(record)}
                          sx={{ cursor: 'pointer' }}
                        />
                      ) : (
                        <Chip
                          icon={<WarningIcon />}
                          label="Missing"
                          color="error"
                          size="small"
                        />
                      )}
                      {record.hasBankDetails && (
                        <IconButton
                          size="small"
                          onClick={() => handleViewBankDetails(record)}
                          title="View Bank Details"
                        >
                          <ViewIcon fontSize="small" />
                        </IconButton>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell align="center">
                    <Button
                      variant="outlined"
                      size="small"
                      endIcon={<MoreVertIcon />}
                      onClick={(e) => handleOpenActionsMenu(e, record)}
                    >
                      Actions
                    </Button>
                  </TableCell>
                  <TableCell align="center">
                    {!record.reviewedLevel2 ? (
                      <Button
                        variant="contained"
                        size="small"
                        color="primary"
                        onClick={() => handleOpenReviewDialog(record)}
                        sx={{ textTransform: 'none', minWidth: '90px' }}
                      >
                        Review
                      </Button>
                    ) : (
                      <Button
                        variant="outlined"
                        size="small"
                        disabled
                        sx={{ textTransform: 'none', minWidth: '90px' }}
                      >
                        Reviewed
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
                ))
              ) : null}
              {!loading && (!records?.content || records.content.length === 0) && (
                <TableRow>
                  <TableCell colSpan={10} align="center">
                    <Typography color="text.secondary" py={3}>
                      No employee records found
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {/* Pagination */}
        {records && (
          <TablePagination
            component="div"
            count={records.totalElements || 0}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
            rowsPerPageOptions={[10, 20, 50, 100]}
          />
        )}
      </TabPanel>

      <TabPanel value={activeTab} index={1}>
        {/* Financial Summary */}
        {financialSummary && (
          <Stack spacing={3}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={3}>
            {/* Employee Counts Summary */}
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={2}>
                    <PeopleIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6" fontWeight="bold">
                      Employee Counts
                    </Typography>
                  </Box>
                  <List dense>
                    <ListItem>
                      <ListItemText primary="Total Records" />
                      <Typography variant="h6" fontWeight="bold">
                        {financialSummary.employeeCounts?.total || 0}
                      </Typography>
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="Active (Non-Rejected)" />
                      <Typography variant="h6" color="success.main" fontWeight="bold">
                        {financialSummary.employeeCounts?.active || 0}
                      </Typography>
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="Rejected" />
                      <Typography variant="h6" color="error.main">
                        {financialSummary.employeeCounts?.rejected || 0}
                      </Typography>
                    </ListItem>
                    <Divider sx={{ my: 1 }} />
                    <ListItem>
                      <ListItemText primary="With Bank Details" />
                      <Chip label={financialSummary.employeeCounts?.withBankDetails || 0} color="success" size="small" />
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="Missing Bank Details" />
                      <Chip label={financialSummary.employeeCounts?.missingBankDetails || 0} color="error" size="small" />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>

            {/* Financial Totals */}
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={2}>
                    <MoneyIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6" fontWeight="bold">
                      Financial Overview
                    </Typography>
                  </Box>
                  <Stack spacing={2}>
                    <Stack direction="row" spacing={2}>
                      <Box p={2} bgcolor="primary.50" borderRadius={2} flex={1}>
                        <Typography variant="caption" color="text.secondary">Total Gross Pay</Typography>
                        <Typography variant="h5" fontWeight="bold">
                          {(financialSummary.totalGrossPay || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                        </Typography>
                      </Box>
                      <Box p={2} bgcolor="success.50" borderRadius={2} flex={1}>
                        <Typography variant="caption" color="text.secondary">Total Net Pay</Typography>
                        <Typography variant="h5" fontWeight="bold" color="success.main">
                          {(financialSummary.totalNetPay || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                        </Typography>
                      </Box>
                    </Stack>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Total Deductions</Typography>
                      <Typography variant="h6" fontWeight="bold">
                        {(financialSummary.totalDeductions || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Total Taxes (PAYE)</Typography>
                      <Typography variant="h6" fontWeight="bold">
                        {(financialSummary.totalTaxes || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Statutory Deductions</Typography>
                      <Typography variant="h6" fontWeight="bold">
                        {(financialSummary.totalStatutoryDeductions || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                      </Box>
                    </Stack>
                  </Stack>
                </CardContent>
              </Card>
            </Stack>

            {/* Averages */}
              <Card>
                <CardContent>
                  <Typography variant="h6" fontWeight="bold" gutterBottom>Average Per Employee</Typography>
                  <Stack direction="row" spacing={2}>
                    <Box flex={1}>
                      <Typography variant="caption" color="text.secondary">Avg Gross Pay</Typography>
                      <Typography variant="h6">
                        {(financialSummary.averageGrossPay || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                    </Box>
                    <Box flex={1}>
                      <Typography variant="caption" color="text.secondary">Avg Net Pay</Typography>
                      <Typography variant="h6">
                        {(financialSummary.averageNetPay || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                    </Box>
                    <Box flex={1}>
                      <Typography variant="caption" color="text.secondary">Avg Tax</Typography>
                      <Typography variant="h6">
                        {(financialSummary.averageTax || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>

            <Stack direction={{ xs: 'column', md: 'row' }} spacing={3}>
            {/* Department Breakdown */}
              <Card>
                <CardContent>
                  <Typography variant="h6" fontWeight="bold" gutterBottom>
                    Department Breakdown
                  </Typography>
                  <Divider sx={{ my: 2 }} />
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>Department</TableCell>
                          <TableCell align="right">Employees</TableCell>
                          <TableCell align="right">Gross Pay</TableCell>
                          <TableCell align="right">Net Pay</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {financialSummary?.departmentBreakdown?.map((dept: any, idx: number) => (
                          <TableRow key={idx}>
                            <TableCell>{dept.department}</TableCell>
                            <TableCell align="right">{dept.employeeCount}</TableCell>
                            <TableCell align="right">
                              {(dept.totalGross || 0).toLocaleString('en-UG', {
                                style: 'currency',
                                currency: 'UGX',
                              })}
                            </TableCell>
                            <TableCell align="right">
                              {(dept.totalNet || 0).toLocaleString('en-UG', {
                                style: 'currency',
                                currency: 'UGX',
                              })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </CardContent>
              </Card>

            {/* Statutory Analysis */}
              <Card>
                <CardContent>
                  <Box display="flex" alignItems="center" mb={2}>
                    <PieChartIcon color="primary" sx={{ mr: 1 }} />
                    <Typography variant="h6" fontWeight="bold">
                      Statutory Contributions
                    </Typography>
                  </Box>
                  <List>
                    <ListItem>
                      <ListItemText primary="NSSF (Employee + Employer)" />
                      <Typography variant="h6" fontWeight="bold">
                        {(financialSummary.statutoryAnalysis?.totalNSSF || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="LST (Local Service Tax)" />
                      <Typography variant="h6" fontWeight="bold">
                        {(financialSummary.statutoryAnalysis?.totalLST || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                    </ListItem>
                    <ListItem>
                      <ListItemText primary="PAYE (Pay As You Earn)" />
                      <Typography variant="h6" fontWeight="bold">
                        {(financialSummary.statutoryAnalysis?.totalPAYE || 0).toLocaleString('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 })}
                      </Typography>
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
            </Stack>

            {/* Salary Distribution */}
              <Card>
                <CardContent>
                  <Typography variant="h6" fontWeight="bold" gutterBottom>
                    Salary Range Distribution
                  </Typography>
                  <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} mt={1}>
                    <Box p={2} bgcolor="grey.100" borderRadius={2} textAlign="center" flex={1}>
                        <Typography variant="caption" color="text.secondary">Below UGX 500K</Typography>
                        <Typography variant="h4" fontWeight="bold">
                          {financialSummary.salaryDistribution?.below500k || 0}
                        </Typography>
                      </Box>
                    <Box p={2} bgcolor="grey.100" borderRadius={2} textAlign="center" flex={1}>
                        <Typography variant="caption" color="text.secondary">UGX 500K - 1M</Typography>
                        <Typography variant="h4" fontWeight="bold">
                          {financialSummary.salaryDistribution?.['500kTo1M'] || 0}
                        </Typography>
                      </Box>
                    <Box p={2} bgcolor="grey.100" borderRadius={2} textAlign="center" flex={1}>
                        <Typography variant="caption" color="text.secondary">UGX 1M - 2M</Typography>
                        <Typography variant="h4" fontWeight="bold">
                          {financialSummary.salaryDistribution?.['1MTo2M'] || 0}
                        </Typography>
                      </Box>
                    <Box p={2} bgcolor="grey.100" borderRadius={2} textAlign="center" flex={1}>
                        <Typography variant="caption" color="text.secondary">Above UGX 2M</Typography>
                        <Typography variant="h4" fontWeight="bold">
                          {financialSummary.salaryDistribution?.above2M || 0}
                        </Typography>
                      </Box>
                  </Stack>
                </CardContent>
              </Card>
          </Stack>
        )}
      </TabPanel>

      <TabPanel value={activeTab} index={2}>
        {/* Validation Report */}
        {validationReport && (
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                <ReportIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Validation Report
              </Typography>
              <Divider sx={{ my: 2 }} />

              <Box display="flex" gap={3} mb={3} flexWrap="wrap">
                <Box flex="1 1 200px">
                  <Card variant="outlined">
                    <CardContent>
                      <Typography color="text.secondary" variant="body2">
                        Total Records
                      </Typography>
                      <Typography variant="h4" fontWeight="bold">
                        {validationReport?.summary?.totalRecords || 0}
                      </Typography>
                    </CardContent>
                  </Card>
                </Box>
                <Box flex="1 1 200px">
                  <Card variant="outlined">
                    <CardContent>
                      <Typography color="text.secondary" variant="body2">
                        Valid Records
                      </Typography>
                      <Typography variant="h4" fontWeight="bold" color="success.main">
                        {validationReport?.summary?.validRecords || 0}
                      </Typography>
                    </CardContent>
                  </Card>
                </Box>
                <Box flex="1 1 200px">
                  <Card variant="outlined">
                    <CardContent>
                      <Typography color="text.secondary" variant="body2">
                        Invalid Records
                      </Typography>
                      <Typography variant="h4" fontWeight="bold" color="error.main">
                        {validationReport?.summary?.invalidRecords + validationReport?.summary?.rejectedRecords || 0}
                      </Typography>
                    </CardContent>
                  </Card>
                </Box>
                <Box flex="1 1 200px">
                  <Card variant="outlined">
                    <CardContent>
                      <Typography color="text.secondary" variant="body2">
                        Missing Bank Details
                      </Typography>
                      <Typography variant="h4" fontWeight="bold" color="warning.main">
                        {validationReport?.summary?.missingBankDetails || 0}
                      </Typography>
                    </CardContent>
                  </Card>
                </Box>
              </Box>

              {validationReport?.errors && validationReport.errors.length > 0 && (
                <Accordion defaultExpanded>
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                    <Typography fontWeight="bold" color="error">
                      Errors ({validationReport.errors.length})
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <List>
                      {validationReport.errors.map((error: string, idx: number) => (
                        <ListItem key={idx}>
                          <ListItemText primary={error} />
                        </ListItem>
                      ))}
                    </List>
                  </AccordionDetails>
                </Accordion>
              )}

              {validationReport?.warnings && validationReport.warnings.length > 0 && (
                <Accordion>
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                    <Typography fontWeight="bold" color="warning.main">
                      Warnings ({validationReport.warnings.length})
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <List>
                      {validationReport.warnings.map((warning: string, idx: number) => (
                        <ListItem key={idx}>
                          <ListItemText primary={warning} />
                        </ListItem>
                      ))}
                    </List>
                  </AccordionDetails>
                </Accordion>
              )}

              {validationReport?.passed && (
                <Alert severity="success" sx={{ mt: 2 }}>
                  <Typography fontWeight="bold">
                    All validation checks passed successfully
                  </Typography>
                  <Typography variant="body2">
                    This payroll period is ready for Finance review and approval.
                  </Typography>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </TabPanel>

      {/* Review & Approve Dialog */}
      <Dialog open={reviewDialog} onClose={() => setReviewDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Review & Approve Payroll</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>
            Period: <strong>{period?.periodName}</strong>
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={4}
            required
            label="Review Notes/Remarks"
            value={reviewComment}
            onChange={(e) => setReviewComment(e.target.value)}
            placeholder="Add review notes, validation results, or important observations... (Required for audit trail)"
            helperText="Required: Provide validation results, issues found, or approval justification"
            sx={{ mt: 2, mb: 2 }}
            error={reviewComment.trim() === ''}
          />
          <Alert severity="info">
            This will mark the period as REVIEWED (Level 2) by Finance. After reviewing, you can
            submit it for Executive final approval.
          </Alert>
          <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
            <Button
              variant="outlined"
              fullWidth
              onClick={() => {
                handleReviewAndApprove();
              }}
            >
              Review Only
            </Button>
            <Button
              variant="contained"
              color="success"
              fullWidth
              onClick={async () => {
                await handleReviewAndApprove();
                await handleSubmitForFinalApproval();
              }}
            >
              Review & Submit to Executive
            </Button>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setReviewDialog(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={rejectDialog} onClose={() => setRejectDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Reject Payroll Period</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>
            Period: <strong>{period?.periodName}</strong>
          </Typography>
          <TextField
            fullWidth
            required
            multiline
            rows={4}
            label="Rejection Reason"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            sx={{ mt: 2 }}
            error={!rejectReason.trim()}
            helperText={
              !rejectReason.trim() ? 'Please provide a detailed reason for rejection' : ''
            }
          />
          <Alert severity="warning" sx={{ mt: 2 }}>
            This will return the period to HR for corrections. HR will be notified of the rejection
            reason.
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRejectDialog(false)}>Cancel</Button>
          <Button
            onClick={handleReject}
            variant="contained"
            color="error"
            disabled={!rejectReason.trim()}
          >
            Reject & Return to HR
          </Button>
        </DialogActions>
      </Dialog>

      {/* Line Item Editor Dialog */}
      {selectedRecord && (
        <EmployeeLineItemEditor
          open={lineItemEditorOpen}
          onClose={() => {
            setLineItemEditorOpen(false);
            setSelectedRecord(null);
          }}
          record={selectedRecord}
          onUpdate={handleLineItemUpdate}
        />
      )}

      {/* View Bank Details Dialog */}
      {selectedEmployee && (
        <ViewBankDetailsDialog
          open={bankDetailsDialogOpen}
          onClose={() => {
            setBankDetailsDialogOpen(false);
            setSelectedEmployee(null);
          }}
          employeeId={selectedEmployee.id}
          employeeName={selectedEmployee.name}
        />
      )}

      {/* Actions Menu */}
      <Menu
        anchorEl={actionsMenuAnchor}
        open={Boolean(actionsMenuAnchor)}
        onClose={handleCloseActionsMenu}
      >
        <MenuItem
          onClick={() => {
            handleCloseActionsMenu();
            if (selectedRecord) handleEditLineItems(selectedRecord);
          }}
        >
          <ListItemIcon>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Edit Line Items</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleCloseActionsMenu();
            if (selectedRecord) handleViewBankDetails(selectedRecord);
          }}
        >
          <ListItemIcon>
            <ViewIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>View Bank Details</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            handleCloseActionsMenu();
            setRecordRejectDialog(true);
          }}
        >
          <ListItemIcon>
            <RejectIcon fontSize="small" color="error" />
          </ListItemIcon>
          <ListItemText>Disapprove Record</ListItemText>
        </MenuItem>
      </Menu>

      {/* Record Reject Dialog */}
      <Dialog open={recordRejectDialog} onClose={() => setRecordRejectDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Disapprove Employee Record</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>
            Disapprove payroll record for{' '}
            <strong>
              {selectedRecord?.employee
                ? `${selectedRecord.employee.firstName} ${selectedRecord.employee.lastName}`
                : selectedRecord?.employeeName}
            </strong>
            ?
          </Typography>
          <TextField
            fullWidth
            required
            multiline
            rows={4}
            label="Disapproval Reason"
            value={recordRejectReason}
            onChange={(e) => setRecordRejectReason(e.target.value)}
            sx={{ mt: 2 }}
            error={!recordRejectReason.trim()}
            helperText={!recordRejectReason.trim() ? 'Please provide a detailed reason for disapproval' : ''}
          />
          <Alert severity="warning" sx={{ mt: 2 }}>
            This record will be excluded from the payroll period and returned to HR for corrections.
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRecordRejectDialog(false)}>Cancel</Button>
          <Button
            onClick={handleRejectRecordConfirm}
            variant="contained"
            color="error"
            disabled={!recordRejectReason.trim()}
          >
            Disapprove Record
          </Button>
        </DialogActions>
      </Dialog>

      {/* Review Record Dialog */}
      <Dialog open={reviewRecordDialog} onClose={() => setReviewRecordDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>
          {isBulkReview ? `Review ${selectedRecords.length} Selected Records` : 'Finance Review - Payroll Record'}
        </DialogTitle>
        <DialogContent>
          {!isBulkReview && selectedRecord && (
            <Box mb={3}>
              {/* Employee Information */}
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent>
                  <Typography variant="subtitle2" color="primary" gutterBottom>
                    EMPLOYEE INFORMATION
                  </Typography>
                  <Divider sx={{ mb: 1.5 }} />
                  <Stack spacing={2}>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Full Name</Typography>
                      <Typography variant="body1" fontWeight="medium">
                        {selectedRecord.employee
                          ? `${selectedRecord.employee.firstName} ${selectedRecord.employee.lastName}`
                          : selectedRecord.employeeName}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Employee Number</Typography>
                      <Typography variant="body1" fontWeight="medium">
                        {selectedRecord.employee?.employeeNumber || selectedRecord.employeeNumber}
                      </Typography>
                      </Box>
                    </Stack>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Department</Typography>
                      <Typography variant="body1">
                        {selectedRecord.employee?.department?.name || selectedRecord.departmentName}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Position</Typography>
                      <Typography variant="body1">
                        {selectedRecord.positionTitle || 'N/A'}
                      </Typography>
                      </Box>
                    </Stack>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Bank Details</Typography>
                      <Box display="flex" alignItems="center" gap={0.5}>
                        {selectedRecord.hasBankDetails ? (
                          <Chip icon={<BankIcon />} label="Ready" color="success" size="small" />
                        ) : (
                          <Chip icon={<WarningIcon />} label="Missing" color="warning" size="small" />
                        )}
                      </Box>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Approval Status</Typography>
                      <Box>
                        {selectedRecord.approvedLevel1 ? (
                          <Chip label="HR Approved" color="success" size="small" />
                        ) : (
                          <Chip label="Pending HR" color="default" size="small" />
                        )}
                      </Box>
                      </Box>
                    </Stack>
                  </Stack>
                </CardContent>
              </Card>

              {/* Salary Breakdown */}
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent>
                  <Typography variant="subtitle2" color="primary" gutterBottom>
                    SALARY BREAKDOWN
                  </Typography>
                  <Divider sx={{ mb: 1.5 }} />
                  <Stack spacing={2}>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Basic Salary</Typography>
                      <Typography variant="h6">
                        {selectedRecord.basicSalary?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Total Earnings</Typography>
                      <Typography variant="h6" color="info.main">
                        {selectedRecord.totalEarnings?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                      </Box>
                    </Stack>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Gross Salary</Typography>
                      <Typography variant="h6" fontWeight="bold">
                        {selectedRecord.grossSalary?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">Taxable Income</Typography>
                      <Typography variant="body1">
                        {selectedRecord.taxableIncome?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                      </Box>
                    </Stack>
                  </Stack>
                </CardContent>
              </Card>

              {/* Deductions & Taxes */}
              <Card variant="outlined" sx={{ mb: 2 }}>
                <CardContent>
                  <Typography variant="subtitle2" color="primary" gutterBottom>
                    DEDUCTIONS & TAXES
                  </Typography>
                  <Divider sx={{ mb: 1.5 }} />
                  <Stack spacing={2}>
                    <Stack direction="row" spacing={2}>
                      <Box flex={1}>
                      <Typography variant="caption" color="text.secondary">Statutory Deductions</Typography>
                      <Typography variant="body1" color="warning.main">
                        {selectedRecord.totalStatutory?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                      </Box>
                      <Box flex={1}>
                        <Typography variant="caption" color="text.secondary">PAYE Tax</Typography>
                      <Typography variant="body1" color="warning.main">
                        {selectedRecord.totalTaxes?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                      </Box>
                    </Stack>
                    <Box>
                      <Typography variant="caption" color="text.secondary">Total Deductions</Typography>
                      <Typography variant="h6" color="error.main" fontWeight="bold">
                        {selectedRecord.totalDeductions?.toLocaleString('en-UG', {
                          style: 'currency',
                          currency: 'UGX',
                        })}
                      </Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>

              {/* Net Pay - Highlighted */}
              <Card sx={{ bgcolor: 'success.50', border: '2px solid', borderColor: 'success.main' }}>
                <CardContent>
                  <Typography variant="subtitle2" color="success.dark" gutterBottom>
                    NET SALARY (PAYABLE AMOUNT)
                  </Typography>
                  <Typography variant="h4" color="success.main" fontWeight="bold">
                    {selectedRecord.netSalary?.toLocaleString('en-UG', {
                      style: 'currency',
                      currency: 'UGX',
                    })}
                  </Typography>
                  <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
                    Gross Salary - Total Deductions
                  </Typography>
                </CardContent>
              </Card>
            </Box>
          )}
          
          {isBulkReview && (
            <Box mb={3}>
              <Alert severity="info" sx={{ mb: 2 }}>
                You are about to review {selectedRecords.length} employee records.
              </Alert>
              
              {records?.content && (
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="subtitle2" color="primary" gutterBottom>
                      BULK REVIEW SUMMARY
                    </Typography>
                    <Divider sx={{ mb: 2 }} />
                    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
                      <Box textAlign="center" p={2} bgcolor="grey.100" borderRadius={1} flex={1}>
                          <Typography variant="h4" fontWeight="bold">
                            {selectedRecords.length}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Records Selected
                          </Typography>
                        </Box>
                      <Box textAlign="center" p={2} bgcolor="info.50" borderRadius={1} flex={1}>
                          <Typography variant="h5" fontWeight="bold" color="info.main">
                            {records.content
                              .filter((r: any) => selectedRecords.includes(r.id))
                              .reduce((sum: number, r: any) => sum + (r.grossSalary || 0), 0)
                              .toLocaleString('en-UG', { style: 'currency', currency: 'UGX', maximumFractionDigits: 0 })}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Total Gross
                          </Typography>
                        </Box>
                      <Box textAlign="center" p={2} bgcolor="success.50" borderRadius={1} flex={1}>
                          <Typography variant="h5" fontWeight="bold" color="success.main">
                            {records.content
                              .filter((r: any) => selectedRecords.includes(r.id))
                              .reduce((sum: number, r: any) => sum + (r.netSalary || 0), 0)
                              .toLocaleString('en-UG', { style: 'currency', currency: 'UGX', maximumFractionDigits: 0 })}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Total Net Pay
                          </Typography>
                        </Box>
                    </Stack>
                  </CardContent>
                </Card>
              )}
            </Box>
          )}

          <TextField
            fullWidth
            required
            multiline
            rows={4}
            label="Review Remarks"
            value={reviewRemarks}
            onChange={(e) => setReviewRemarks(e.target.value)}
            placeholder="Provide detailed review notes, validation findings, or any observations..."
            helperText="Required for audit trail: Document what you verified and any issues found"
            error={!reviewRemarks.trim()}
            sx={{ mt: 1 }}
          />
          
          <Alert severity="info" sx={{ mt: 2 }}>
            <Typography variant="body2" fontWeight="bold" gutterBottom>
              By reviewing this record, you confirm:
            </Typography>
            <Typography variant="body2" component="ul" sx={{ pl: 2, mb: 0 }}>
              <li>Payroll calculations are accurate</li>
              <li>Deductions and taxes are correctly applied</li>
              <li>Employee details are verified</li>
              <li>No irregularities detected</li>
            </Typography>
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setReviewRecordDialog(false)}>Cancel</Button>
          <Button
            onClick={handleConfirmReview}
            variant="contained"
            color="success"
            disabled={!reviewRemarks.trim()}
            startIcon={<ApproveIcon />}
          >
            {isBulkReview ? 'Review All Selected' : 'Confirm Review'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default FinancePayrollReviewDetail;
