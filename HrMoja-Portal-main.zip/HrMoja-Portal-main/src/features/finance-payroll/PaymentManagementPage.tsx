import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Tabs,
  Tab,
  Stack,
  Card,
  CardContent,
  Button,
  Alert,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Divider,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  IconButton,
} from '@mui/material';
import {
  CloudDownload as DownloadIcon,
  CloudUpload as UploadIcon,
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
  Payment as PaymentIcon,
  Receipt as ReceiptIcon,
  Description as FileIcon,
  ArrowBack as BackIcon,
  Close as CloseIcon,
  PlayArrow as ExecuteIcon,
  Done as ConfirmIcon,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import { apiClient } from '../../api/axios.config';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`payment-tabpanel-${index}`}
      aria-labelledby={`payment-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
}

const PaymentManagementPage: React.FC = () => {
  const { periodId } = useParams<{ periodId: string }>();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState(2); // Start on Payment Actions tab
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<any>(null);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);
  const [feedbackFiles, setFeedbackFiles] = useState<any[]>([]);
  const [discrepancyReport, setDiscrepancyReport] = useState<any>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  // Dialog states
  const [authorizeDialog, setAuthorizeDialog] = useState(false);
  const [executeDialog, setExecuteDialog] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState(false);
  
  // Form states
  const [paymentMethod, setPaymentMethod] = useState('BANK_TRANSFER');
  const [paymentReference, setPaymentReference] = useState('');
  const [authNotes, setAuthNotes] = useState('');
  const [transactionReference, setTransactionReference] = useState('');
  const [confirmNotes, setConfirmNotes] = useState('');

  useEffect(() => {
    if (periodId) {
      loadData();
    }
  }, [periodId]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [periodRes, paymentRes, feedbackRes, discrepancyRes] = await Promise.all([
        apiClient.get(`/finance/payment-management/periods/${periodId}`),
        apiClient.get(`/finance/payment-management/periods/${periodId}/payment-details`),
        apiClient.get(`/finance/payment-management/periods/${periodId}/feedback`),
        apiClient.get(`/finance/payment-management/periods/${periodId}/discrepancy-report`),
      ]);

      setPeriod(periodRes.data);
      setPaymentDetails(paymentRes.data);
      setFeedbackFiles(Array.isArray(feedbackRes.data) ? feedbackRes.data : []);
      setDiscrepancyReport(discrepancyRes.data);
    } catch (error: any) {
      toast.error('Failed to load payment management data');
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadBankFile = async (format: 'CSV' | 'EXCEL') => {
    if (!paymentDetails?.paymentId) {
      toast.error('No payment record found. Please authorize payment first.');
      return;
    }

    try {
      setLoading(true);
      const response = await apiClient.get(
        `/finance/payment-management/payments/${paymentDetails.paymentId}/bank-file`,
        {
          params: { format },
          responseType: 'blob',
        }
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute(
        'download',
        `bank_file_${period?.periodCode}.${format === 'CSV' ? 'csv' : 'xlsx'}`
      );
      document.body.appendChild(link);
      link.click();
      link.remove();

      toast.success(`${format} bank file downloaded successfully`);
      loadData();
    } catch (error: any) {
      toast.error('Failed to download bank file');
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
    }
  };

  const handleUploadFeedback = async () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    try {
      setLoading(true);
      const formData = new FormData();
      formData.append('file', selectedFile);

      const response = await apiClient.post(
        `/finance/payment-management/periods/${periodId}/feedback`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
        }
      );

      if (response.data.success) {
        toast.success('Bank feedback file uploaded successfully');
        if (response.data.hasDiscrepancies) {
          toast.warning(`Found ${response.data.discrepancyCount} discrepancies`);
        }
        setSelectedFile(null);
        loadData();
      }
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to upload feedback file');
    } finally {
      setLoading(false);
    }
  };

  const handleAuthorizePayment = async () => {
    try {
      setLoading(true);
      const response = await apiClient.post(
        `/finance/payment-management/periods/${periodId}/authorize`,
        {
          paymentMethod,
          paymentReference,
          notes: authNotes,
        }
      );

      if (response.data.success) {
        toast.success('Payment authorized successfully');
        setAuthorizeDialog(false);
        setPaymentMethod('BANK_TRANSFER');
        setPaymentReference('');
        setAuthNotes('');
        loadData();
      }
    } catch (error: any) {
      const errorMsg = error.response?.data?.error || error.response?.data?.message || 'Failed to authorize payment';
      
      // If payment already authorized, reload data to show current state
      if (errorMsg.includes('already authorized')) {
        toast.warning('Payment is already authorized for this period');
        setAuthorizeDialog(false);
        loadData(); // Refresh to show authorized payment
      } else {
        toast.error(errorMsg);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleExecutePayment = async () => {
    if (!paymentDetails?.paymentId) {
      toast.error('Payment must be authorized first');
      return;
    }

    try {
      setLoading(true);
      const response = await apiClient.post(
        `/finance/payment-management/payments/${paymentDetails.paymentId}/execute`,
        {
          transactionReference,
        }
      );

      if (response.data.success) {
        toast.success('Payment marked as executed');
        setExecuteDialog(false);
        setTransactionReference('');
        loadData();
      }
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to execute payment');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmPayment = async () => {
    if (!paymentDetails?.paymentId) {
      toast.error('Payment must be authorized first');
      return;
    }

    if (discrepancyReport?.hasDiscrepancies) {
      toast.error('Cannot confirm payment with unresolved discrepancies');
      return;
    }

    try {
      setLoading(true);
      const response = await apiClient.post(
        `/finance/payment-management/payments/${paymentDetails.paymentId}/confirm`,
        {
          confirmationNotes: confirmNotes,
        }
      );

      if (response.data.success) {
        toast.success('Payment confirmed - Period marked as PAID');
        setConfirmDialog(false);
        setConfirmNotes('');
        loadData();
      }
    } catch (error: any) {
      toast.error(error.response?.data?.error || 'Failed to confirm payment');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
      case 'AUTHORIZED':
        return 'success';
      case 'PROCESSING':
        return 'warning';
      case 'FAILED':
        return 'error';
      default:
        return 'default';
    }
  };

  if (loading && !period) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" alignItems="center" mb={3}>
        <Button
          startIcon={<BackIcon />}
          onClick={() => navigate('/finance/payroll/payment')}
          sx={{ mr: 2 }}
        >
          Back
        </Button>
        <Box flexGrow={1}>
          <Typography variant="h4">Payment Management</Typography>
          <Typography variant="body2" color="text.secondary">
            {period?.periodName} - {period?.periodCode}
          </Typography>
        </Box>
        <Button variant="outlined" onClick={loadData} disabled={loading}>
          Refresh
        </Button>
      </Box>

      {/* Summary Cards */}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ mb: 3 }}>
        <Card variant="outlined" sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="caption">
                Period Status
              </Typography>
              <Typography variant="h6">
                <Chip label={period?.status} color="primary" size="small" />
              </Typography>
            </CardContent>
          </Card>
        <Card variant="outlined" sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="caption">
                Payment Status
              </Typography>
              <Typography variant="h6">
                {paymentDetails?.paymentStatus ? (
                  <Chip
                    label={paymentDetails.paymentStatus}
                    color={getStatusColor(paymentDetails.paymentStatus) as any}
                    size="small"
                  />
                ) : (
                  'Not Started'
                )}
              </Typography>
            </CardContent>
          </Card>
        <Card variant="outlined" sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="caption">
                Total Amount
              </Typography>
              <Typography variant="h6">
                {paymentDetails?.totalAmount
                  ? `UGX ${Number(paymentDetails.totalAmount).toLocaleString()}`
                  : '-'}
              </Typography>
            </CardContent>
          </Card>
        <Card variant="outlined" sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="caption">
                Feedback Files
              </Typography>
              <Typography variant="h6">{feedbackFiles.length}</Typography>
            </CardContent>
          </Card>
      </Stack>

      {/* Tabs */}
      <Card>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)}>
            <Tab label="Bank Files" icon={<FileIcon />} iconPosition="start" />
            <Tab label="Feedback & Analysis" icon={<UploadIcon />} iconPosition="start" />
            <Tab label="Payment Actions" icon={<PaymentIcon />} iconPosition="start" />
          </Tabs>
        </Box>

        <CardContent>
          {/* Tab 1: Bank Files */}
          <TabPanel value={activeTab} index={0}>
            <Box>
              <Typography variant="h6" gutterBottom>
                Download Bank Transfer File
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Generate and download the bank file for uploading to your bank's system.
                Files are locked after first generation to prevent tampering.
              </Typography>

              {paymentDetails?.bankFileGenerated && (
                <Alert severity="success" sx={{ mb: 3 }}>
                  Bank file already generated and locked. Downloads will return the same file.
                </Alert>
              )}

              <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
                <Button
                    variant="contained"
                    fullWidth
                    size="large"
                    startIcon={<DownloadIcon />}
                    onClick={() => handleDownloadBankFile('CSV')}
                    disabled={loading || !paymentDetails?.paymentId}
                  >
                    Download CSV Format
                  </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    fullWidth
                    size="large"
                    startIcon={<DownloadIcon />}
                    onClick={() => handleDownloadBankFile('EXCEL')}
                    disabled={loading || !paymentDetails?.paymentId}
                  >
                    Download Excel Format
                  </Button>
              </Stack>

              {!paymentDetails?.paymentId && (
                <Alert severity="info" sx={{ mt: 3 }}>
                  Please authorize payment first before downloading bank files.
                </Alert>
              )}
            </Box>
          </TabPanel>

          {/* Tab 2: Feedback & Analysis */}
          <TabPanel value={activeTab} index={1}>
            <Box>
              <Typography variant="h6" gutterBottom>
                Upload Bank Feedback File
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Upload the acknowledgement/feedback file from your bank. System will
                automatically analyze for discrepancies and fraud detection.
              </Typography>

              {!paymentDetails?.bankFileGenerated ? (
                <Alert severity="warning" sx={{ mb: 4 }}>
                  Please download the bank file first before uploading feedback.
                </Alert>
              ) : (
                <Box sx={{ mb: 4 }}>
                  <input
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileSelect}
                    style={{ display: 'none' }}
                    id="feedback-file-input"
                  />
                  <label htmlFor="feedback-file-input">
                    <Button variant="outlined" component="span" fullWidth sx={{ mb: 2 }}>
                      {selectedFile ? selectedFile.name : 'Choose File'}
                    </Button>
                  </label>
                  {selectedFile && (
                    <Button
                      variant="contained"
                      fullWidth
                      size="large"
                      startIcon={<UploadIcon />}
                      onClick={handleUploadFeedback}
                      disabled={loading}
                    >
                      Upload Feedback File
                    </Button>
                  )}
                </Box>
              )}

              <Divider sx={{ my: 4 }} />

              {/* Discrepancy Report */}
              {discrepancyReport && (
                <Box>
                  <Typography variant="h6" gutterBottom>
                    Discrepancy Analysis
                  </Typography>

                  {discrepancyReport.hasDiscrepancies ? (
                    <Alert severity="warning" sx={{ mb: 3 }}>
                      <Typography variant="body2" fontWeight="bold">
                        {discrepancyReport.totalDiscrepancies} Discrepancies Found
                      </Typography>
                      <Typography variant="caption">
                        Review discrepancies before confirming payment
                      </Typography>
                    </Alert>
                  ) : discrepancyReport.totalFeedbackFiles > 0 ? (
                    <Alert severity="success" sx={{ mb: 3 }}>
                      No discrepancies found. All records match.
                    </Alert>
                  ) : (
                    <Alert severity="info" sx={{ mb: 3 }}>
                      No feedback files uploaded yet.
                    </Alert>
                  )}

                  {feedbackFiles.length > 0 && (
                    <TableContainer component={Paper} variant="outlined">
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell>File Name</TableCell>
                            <TableCell>Uploaded</TableCell>
                            <TableCell align="right">Records</TableCell>
                            <TableCell align="right">Amount</TableCell>
                            <TableCell align="right">Discrepancies</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {feedbackFiles.map((file) => (
                            <TableRow key={file.id}>
                              <TableCell>{file.fileName}</TableCell>
                              <TableCell>
                                {new Date(file.uploadedAt).toLocaleString()}
                              </TableCell>
                              <TableCell align="right">{file.totalRecords}</TableCell>
                              <TableCell align="right">
                                {Number(file.totalAmount).toLocaleString()}
                              </TableCell>
                              <TableCell align="right">
                                {file.discrepancyCount > 0 ? (
                                  <Chip
                                    label={file.discrepancyCount}
                                    color="warning"
                                    size="small"
                                    icon={<WarningIcon />}
                                  />
                                ) : (
                                  <Chip
                                    label="0"
                                    color="success"
                                    size="small"
                                    icon={<CheckIcon />}
                                  />
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  )}
                </Box>
              )}
            </Box>
          </TabPanel>

          {/* Tab 3: Payment Actions */}
          <TabPanel value={activeTab} index={2}>
            <Box>
              <Typography variant="h6" gutterBottom>
                Payment Workflow Actions
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 4 }}>
                Execute payment actions in sequence: Authorize → Download File → Upload to
                Bank → Upload Feedback → Confirm Payment
              </Typography>

              {/* Step 1: Authorize Payment */}
              <Card sx={{ mb: 3 }} variant="outlined">
                <CardContent>
                  <Stack direction="row" alignItems="center" spacing={2} mb={2}>
                    <PaymentIcon color="primary" fontSize="large" />
                    <Box flexGrow={1}>
                      <Typography variant="h6">1. Authorize Payment</Typography>
                      <Typography variant="body2" color="text.secondary">
                        Create payment record and authorize for processing
                      </Typography>
                    </Box>
                    <Chip
                      label={paymentDetails?.paymentId ? 'Authorized' : 'Pending'}
                      color={paymentDetails?.paymentId ? 'success' : 'default'}
                    />
                  </Stack>
                  {!paymentDetails?.paymentId ? (
                    <Button
                      variant="contained"
                      color="primary"
                      size="large"
                      startIcon={<PaymentIcon />}
                      onClick={() => setAuthorizeDialog(true)}
                      disabled={loading}
                      sx={{ fontSize: '1.1rem', py: 1.5 }}
                    >
                      Authorize Payment
                    </Button>
                  ) : (
                    <Alert severity="success">
                      Payment authorized on{' '}
                      {new Date(paymentDetails.authorizedAt).toLocaleString()}
                    </Alert>
                  )}
                </CardContent>
              </Card>

              {/* Step 2: Download Bank File */}
              <Card sx={{ mb: 3 }} variant="outlined">
                <CardContent>
                  <Stack direction="row" alignItems="center" spacing={2} mb={2}>
                    <DownloadIcon color="primary" fontSize="large" />
                    <Box flexGrow={1}>
                      <Typography variant="h6">2. Download Bank File</Typography>
                      <Typography variant="body2" color="text.secondary">
                        Download CSV/Excel file for bank upload
                      </Typography>
                    </Box>
                    <Chip
                      label={paymentDetails?.bankFileGenerated ? 'Generated' : 'Pending'}
                      color={paymentDetails?.bankFileGenerated ? 'success' : 'default'}
                    />
                  </Stack>
                  <Stack direction="row" spacing={2}>
                    <Button
                      variant="contained"
                      size="large"
                      startIcon={<DownloadIcon />}
                      onClick={() => handleDownloadBankFile('CSV')}
                      disabled={loading || !paymentDetails?.paymentId}
                      sx={{ fontSize: '1rem', py: 1.5 }}
                    >
                      Download CSV
                    </Button>
                    <Button
                      variant="contained"
                      color="secondary"
                      size="large"
                      startIcon={<DownloadIcon />}
                      onClick={() => handleDownloadBankFile('EXCEL')}
                      disabled={loading || !paymentDetails?.paymentId}
                      sx={{ fontSize: '1rem', py: 1.5 }}
                    >
                      Download Excel
                    </Button>
                  </Stack>
                </CardContent>
              </Card>

              {/* Step 3: Execute Payment */}
              <Card sx={{ mb: 3 }} variant="outlined">
                <CardContent>
                  <Stack direction="row" alignItems="center" spacing={2} mb={2}>
                    <ExecuteIcon color="primary" fontSize="large" />
                    <Box flexGrow={1}>
                      <Typography variant="h6">3. Execute Payment</Typography>
                      <Typography variant="body2" color="text.secondary">
                        Mark as executed after uploading file to bank
                      </Typography>
                    </Box>
                    <Chip
                      label={
                        paymentDetails?.paymentStatus === 'PROCESSING' ||
                        paymentDetails?.paymentStatus === 'COMPLETED'
                          ? 'Executed'
                          : 'Pending'
                      }
                      color={
                        paymentDetails?.paymentStatus === 'PROCESSING' ||
                        paymentDetails?.paymentStatus === 'COMPLETED'
                          ? 'success'
                          : 'default'
                      }
                    />
                  </Stack>
                  {paymentDetails?.paymentStatus === 'AUTHORIZED' ? (
                    <Button
                      variant="contained"
                      color="warning"
                      size="large"
                      startIcon={<ExecuteIcon />}
                      onClick={() => setExecuteDialog(true)}
                      disabled={loading}
                      sx={{ fontSize: '1.1rem', py: 1.5 }}
                    >
                      Mark as Executed
                    </Button>
                  ) : paymentDetails?.paymentStatus === 'PROCESSING' ||
                    paymentDetails?.paymentStatus === 'COMPLETED' ? (
                    <Alert severity="success">Payment executed successfully</Alert>
                  ) : (
                    <Alert severity="info">Authorize payment first</Alert>
                  )}
                </CardContent>
              </Card>

              {/* Step 4: Upload Feedback */}
              <Card sx={{ mb: 3 }} variant="outlined">
                <CardContent>
                  <Stack direction="row" alignItems="center" spacing={2} mb={2}>
                    <ReceiptIcon color="primary" fontSize="large" />
                    <Box flexGrow={1}>
                      <Typography variant="h6">4. Upload Bank Feedback</Typography>
                      <Typography variant="body2" color="text.secondary">
                        Upload acknowledgement file from bank
                      </Typography>
                    </Box>
                    <Chip
                      label={feedbackFiles.length > 0 ? `${feedbackFiles.length} Files` : 'Pending'}
                      color={feedbackFiles.length > 0 ? 'success' : 'default'}
                    />
                  </Stack>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Upload feedback files in the "Feedback & Analysis" tab
                  </Alert>
                </CardContent>
              </Card>

              {/* Step 5: Confirm Payment */}
              <Card variant="outlined">
                <CardContent>
                  <Stack direction="row" alignItems="center" spacing={2} mb={2}>
                    <ConfirmIcon color="primary" fontSize="large" />
                    <Box flexGrow={1}>
                      <Typography variant="h6">5. Confirm Payment</Typography>
                      <Typography variant="body2" color="text.secondary">
                        Final confirmation - marks period as PAID
                      </Typography>
                    </Box>
                    <Chip
                      label={paymentDetails?.paymentConfirmed ? 'Confirmed' : 'Pending'}
                      color={paymentDetails?.paymentConfirmed ? 'success' : 'default'}
                    />
                  </Stack>

                  {discrepancyReport?.hasDiscrepancies && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                      Cannot confirm: {discrepancyReport.totalDiscrepancies} discrepancies found.
                      Resolve issues first.
                    </Alert>
                  )}

                  {!paymentDetails?.paymentConfirmed ? (
                    <Button
                      variant="contained"
                      color="success"
                      size="large"
                      startIcon={<ConfirmIcon />}
                      onClick={() => setConfirmDialog(true)}
                      disabled={
                        loading ||
                        !paymentDetails?.paymentId ||
                        discrepancyReport?.hasDiscrepancies
                      }
                      sx={{ fontSize: '1.1rem', py: 1.5 }}
                    >
                      Confirm Payment
                    </Button>
                  ) : (
                    <Alert severity="success">
                      Payment confirmed - Period marked as PAID
                    </Alert>
                  )}
                </CardContent>
              </Card>
            </Box>
          </TabPanel>
        </CardContent>
      </Card>

      {/* Authorize Payment Dialog */}
      <Dialog open={authorizeDialog} onClose={() => setAuthorizeDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="h6">Authorize Payment</Typography>
            <IconButton onClick={() => setAuthorizeDialog(false)} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Create payment record and authorize for processing. This will prepare the payroll for
            payment execution.
          </Typography>

          <TextField
            fullWidth
            select
            label="Payment Method"
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            sx={{ mb: 2 }}
          >
            <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
            <MenuItem value="CHECK">Check</MenuItem>
            <MenuItem value="CASH">Cash</MenuItem>
            <MenuItem value="MOBILE_MONEY">Mobile Money</MenuItem>
          </TextField>

          <TextField
            fullWidth
            label="Payment Reference (Optional)"
            value={paymentReference}
            onChange={(e) => setPaymentReference(e.target.value)}
            placeholder="e.g., PAY-2024-001"
            sx={{ mb: 2 }}
          />

          <TextField
            fullWidth
            multiline
            rows={3}
            label="Notes (Optional)"
            value={authNotes}
            onChange={(e) => setAuthNotes(e.target.value)}
            placeholder="Add any additional notes..."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAuthorizeDialog(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleAuthorizePayment}
            disabled={loading}
          >
            Authorize Payment
          </Button>
        </DialogActions>
      </Dialog>

      {/* Execute Payment Dialog */}
      <Dialog open={executeDialog} onClose={() => setExecuteDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="h6">Execute Payment</Typography>
            <IconButton onClick={() => setExecuteDialog(false)} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Mark this payment as executed after uploading the bank file to your bank's system.
          </Typography>

          <Alert severity="info" sx={{ mb: 3 }}>
            Make sure you have uploaded the bank file to your bank's portal before marking as
            executed.
          </Alert>

          <TextField
            fullWidth
            label="Transaction Reference (Optional)"
            value={transactionReference}
            onChange={(e) => setTransactionReference(e.target.value)}
            placeholder="e.g., TXN-123456"
            helperText="Bank transaction or batch reference number"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setExecuteDialog(false)}>Cancel</Button>
          <Button
            variant="contained"
            color="warning"
            onClick={handleExecutePayment}
            disabled={loading}
          >
            Mark as Executed
          </Button>
        </DialogActions>
      </Dialog>

      {/* Confirm Payment Dialog */}
      <Dialog open={confirmDialog} onClose={() => setConfirmDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="h6">Confirm Payment Completion</Typography>
            <IconButton onClick={() => setConfirmDialog(false)} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            This is the final step. Confirming will mark the payroll period as PAID and complete
            the payment process.
          </Typography>

          <Alert severity="warning" sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight="bold">
              Warning: This action cannot be undone
            </Typography>
            <Typography variant="caption">
              Ensure all bank feedbacks are uploaded and validated before confirming.
            </Typography>
          </Alert>

          {paymentDetails && (
            <Box sx={{ mb: 3, p: 2, bgcolor: 'background.paper', borderRadius: 1, border: '1px solid #ddd' }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Payment Summary
              </Typography>
              <Typography variant="body2">
                <strong>Period:</strong> {period?.periodName}
              </Typography>
              <Typography variant="body2">
                <strong>Total Amount:</strong> UGX{' '}
                {Number(paymentDetails.totalAmount).toLocaleString()}
              </Typography>
              <Typography variant="body2">
                <strong>Employees:</strong> {paymentDetails.totalEmployees}
              </Typography>
              <Typography variant="body2">
                <strong>Feedback Files:</strong> {feedbackFiles.length}
              </Typography>
            </Box>
          )}

          <TextField
            fullWidth
            multiline
            rows={3}
            label="Confirmation Notes (Optional)"
            value={confirmNotes}
            onChange={(e) => setConfirmNotes(e.target.value)}
            placeholder="Add final confirmation notes..."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialog(false)}>Cancel</Button>
          <Button
            variant="contained"
            color="success"
            onClick={handleConfirmPayment}
            disabled={loading}
          >
            Confirm Payment
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PaymentManagementPage;
