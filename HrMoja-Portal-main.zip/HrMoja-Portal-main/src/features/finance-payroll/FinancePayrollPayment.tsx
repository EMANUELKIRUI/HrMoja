import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  CircularProgress,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Alert,
  Stack,
} from '@mui/material';
import {
  Download as DownloadIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import { financePayrollApi } from '../../api/financePayrollApi';

const FinancePayrollPayment: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [periods, setPeriods] = useState<any[]>([]);
  const [selectedPeriod] = useState<any>(null);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);

  // Dialogs
  const [authorizeDialog, setAuthorizeDialog] = useState(false);
  const [executeDialog, setExecuteDialog] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState(false);
  const [bankFileDialog, setBankFileDialog] = useState(false);

  // Form states
  const [paymentMethod, setPaymentMethod] = useState('BANK_TRANSFER');
  const [paymentReference, setPaymentReference] = useState('');
  const [notes, setNotes] = useState('');
  const [transactionReference, setTransactionReference] = useState('');
  const [confirmationNotes, setConfirmationNotes] = useState('');
  

  useEffect(() => {
    loadPeriods();
  }, []);

  const loadPeriods = async () => {
    setLoading(true);
    try {
      // Load APPROVED periods ready for payment
      const response = await financePayrollApi.getPeriodsForReview('APPROVED');
      setPeriods(response.data.data || []);
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to load periods');
    } finally {
      setLoading(false);
    }
  };

  const loadPaymentDetails = async (periodId: number) => {
    try {
      const response = await financePayrollApi.getPaymentDetails(periodId);
      setPaymentDetails(response.data.data);
      return response.data.data;
    } catch (error: any) {
      toast.error('Failed to load payment details');
      return null;
    }
  };

  const handleAuthorizePayment = async () => {
    if (!selectedPeriod) return;

    try {
      await financePayrollApi.authorizePayment(selectedPeriod.id, {
        paymentMethod,
        paymentReference,
        notes,
      });
      toast.success('Payment authorized successfully');
      setAuthorizeDialog(false);
      resetForm();
      loadPeriods();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to authorize payment');
    }
  };

  const handleExecutePayment = async () => {
    if (!paymentDetails?.paymentId) return;

    try {
      await financePayrollApi.executePayment(paymentDetails.paymentId, {
        transactionReference,
      });
      toast.success('Payment marked as executed');
      setExecuteDialog(false);
      setTransactionReference('');
      await loadPaymentDetails(selectedPeriod.id);
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to execute payment');
    }
  };

  const handleConfirmPayment = async () => {
    if (!paymentDetails?.paymentId) return;

    try {
      await financePayrollApi.confirmPayment(paymentDetails.paymentId, {
        notes: confirmationNotes,
      });
      toast.success('Payment confirmed - Period marked as PAID');
      setConfirmDialog(false);
      setConfirmationNotes('');
      loadPeriods();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to confirm payment');
    }
  };

  const handleDownloadBankFile = async (format: 'CSV' | 'EXCEL') => {
    if (!paymentDetails?.paymentId) return;

    try {
      const response = await financePayrollApi.downloadBankFile(paymentDetails.paymentId, format);
      
      // Create blob and download
      const blob = new Blob([response.data], {
        type: format === 'EXCEL' 
          ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          : 'text/csv',
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `PAYROLL_BANK_FILE_${paymentDetails.paymentId}.${format === 'EXCEL' ? 'xlsx' : 'csv'}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success(`Bank file downloaded (${format})`);
      setBankFileDialog(false);
    } catch (error: any) {
      toast.error('Failed to download bank file');
    }
  };

  // Unused - keeping for future reference
  // const openAuthorizeDialog = async (period: any) => {
  //   setSelectedPeriod(period);
  //   
  //   // Check if already authorized
  //   const details = await loadPaymentDetails(period.id);
  //   if (details?.paymentId) {
  //     toast.info('Payment already authorized for this period');
  //     return;
  //   }
  //   
  //   setAuthorizeDialog(true);
  // };
  //
  // const openBankFileDialog = async (period: any) => {
  //   setSelectedPeriod(period);
  //   const details = await loadPaymentDetails(period.id);
  //   
  //   if (!details?.paymentId) {
  //     toast.error('Please authorize payment first');
  //     return;
  //   }
  //   
  //   setPaymentDetails(details);
  //   setBankFileDialog(true);
  // };
  //
  // const openExecuteDialog = async (period: any) => {
  //   setSelectedPeriod(period);
  //   const details = await loadPaymentDetails(period.id);
  //   
  //   if (!details?.paymentId) {
  //     toast.error('Please authorize payment first');
  //     return;
  //   }
  //   
  //   if (details.paymentStatus === 'COMPLETED') {
  //     toast.info('Payment already completed');
  //     return;
  //   }
  //   
  //   setPaymentDetails(details);
  //   setExecuteDialog(true);
  // };
  //
  // const openConfirmDialog = async (period: any) => {
  //   setSelectedPeriod(period);
  //   const details = await loadPaymentDetails(period.id);
  //   
  //   if (!details?.paymentId) {
  //     toast.error('Please authorize payment first');
  //     return;
  //   }
  //   
  //   if (details.paymentConfirmed) {
  //     toast.info('Payment already confirmed');
  //     return;
  //   }
  //   
  //   setPaymentDetails(details);
  //   setConfirmDialog(true);
  // };

  const resetForm = () => {
    setPaymentMethod('BANK_TRANSFER');
    setPaymentReference('');
    setNotes('');
  };

  const handleOpenManagement = (period: any) => {
    // Navigate to the payment management page
    navigate(`/finance/payroll/payment/manage/${period.id}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'success';
      case 'PAID':
        return 'info';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold">
            Payroll Payment Processing
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Authorize and process payments for approved payroll periods
          </Typography>
        </Box>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={loadPeriods}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      {/* Summary Cards */}
      <Box display="flex" gap={2} mb={3}>
        <Card sx={{ flex: 1 }}>
          <CardContent>
            <Typography color="text.secondary" variant="body2">
              Periods Ready for Payment
            </Typography>
            <Typography variant="h4" fontWeight="bold">
              {periods.length}
            </Typography>
          </CardContent>
        </Card>
        <Card sx={{ flex: 1 }}>
          <CardContent>
            <Typography color="text.secondary" variant="body2">
              Total Amount
            </Typography>
            <Typography variant="h4" fontWeight="bold">
              {periods.reduce((sum, p) => sum + (p.totalNetPay || 0), 0).toLocaleString('en-UG', {
                style: 'currency',
                currency: 'UGX',
              })}
            </Typography>
          </CardContent>
        </Card>
      </Box>

      {/* Instructions */}
      <Alert severity="info" sx={{ mb: 3 }}>
        <Typography variant="body2" fontWeight="bold" gutterBottom>
          Payment Processing Steps:
        </Typography>
        <Typography variant="body2">
          1. <strong>Authorize Payment</strong> - Create payment record<br />
          2. <strong>Download Bank File</strong> - Generate CSV/Excel for bank upload<br />
          3. <strong>Execute Payment</strong> - Mark as executed after bank upload<br />
          4. <strong>Confirm Payment</strong> - Final confirmation to mark period as PAID
        </Typography>
      </Alert>

      {/* Periods Table */}
      {periods.length === 0 ? (
        <Card>
          <CardContent>
            <Typography variant="body1" color="text.secondary" align="center">
              No approved periods ready for payment
            </Typography>
          </CardContent>
        </Card>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Period</TableCell>
                <TableCell>Date Range</TableCell>
                <TableCell>Employees</TableCell>
                <TableCell align="right">Total Amount</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {periods.map((period) => (
                <TableRow key={period.id} hover>
                  <TableCell>
                    <Typography variant="body2" fontWeight="bold">
                      {period.periodName}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {period.periodCode}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">
                      {new Date(period.startDate).toLocaleDateString()} - {new Date(period.endDate).toLocaleDateString()}
                    </Typography>
                  </TableCell>
                  <TableCell>{period.totalEmployees}</TableCell>
                  <TableCell align="right">
                    <Typography variant="body2" fontWeight="bold">
                      {period.totalNetPay?.toLocaleString('en-UG', {
                        style: 'currency',
                        currency: 'UGX',
                      })}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={period.status}
                      color={getStatusColor(period.status) as any}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Button
                      variant="contained"
                      size="small"
                      color="primary"
                      onClick={() => handleOpenManagement(period)}
                    >
                      Manage
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Authorize Payment Dialog */}
      <Dialog open={authorizeDialog} onClose={() => setAuthorizeDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Authorize Payment</DialogTitle>
        <DialogContent>
          <Box mt={2}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Period: <strong>{selectedPeriod?.periodName}</strong>
            </Typography>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Total Amount: <strong>
                {selectedPeriod?.totalNetPay?.toLocaleString('en-UG', {
                  style: 'currency',
                  currency: 'UGX',
                })}
              </strong>
            </Typography>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Employees: <strong>{selectedPeriod?.totalEmployees}</strong>
            </Typography>

            <TextField
              select
              fullWidth
              label="Payment Method"
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              margin="normal"
            >
              <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
              <MenuItem value="CHEQUE">Cheque</MenuItem>
              <MenuItem value="CASH">Cash</MenuItem>
              <MenuItem value="MOBILE_MONEY">Mobile Money</MenuItem>
            </TextField>

            <TextField
              fullWidth
              label="Payment Reference (Optional)"
              value={paymentReference}
              onChange={(e) => setPaymentReference(e.target.value)}
              margin="normal"
            />

            <TextField
              fullWidth
              label="Notes (Optional)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              margin="normal"
              multiline
              rows={3}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAuthorizeDialog(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleAuthorizePayment}>
            Authorize Payment
          </Button>
        </DialogActions>
      </Dialog>

      {/* Bank File Download Dialog */}
      <Dialog open={bankFileDialog} onClose={() => setBankFileDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Download Bank File</DialogTitle>
        <DialogContent>
          <Box mt={2}>
            <Alert severity="info" sx={{ mb: 2 }}>
              Select the format for your bank's upload system
            </Alert>
            <Stack spacing={2}>
              <Button
                variant="outlined"
                size="large"
                startIcon={<DownloadIcon />}
                onClick={() => handleDownloadBankFile('CSV')}
                fullWidth
              >
                Download CSV Format
              </Button>
              <Button
                variant="outlined"
                size="large"
                startIcon={<DownloadIcon />}
                onClick={() => handleDownloadBankFile('EXCEL')}
                fullWidth
              >
                Download Excel Format
              </Button>
            </Stack>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setBankFileDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Execute Payment Dialog */}
      <Dialog open={executeDialog} onClose={() => setExecuteDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Execute Payment</DialogTitle>
        <DialogContent>
          <Box mt={2}>
            <Alert severity="warning" sx={{ mb: 2 }}>
              Mark payment as executed after uploading the bank file to your banking system
            </Alert>
            <TextField
              fullWidth
              label="Transaction Reference (Optional)"
              value={transactionReference}
              onChange={(e) => setTransactionReference(e.target.value)}
              helperText="Bank transaction or batch reference number"
              margin="normal"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setExecuteDialog(false)}>Cancel</Button>
          <Button variant="contained" color="warning" onClick={handleExecutePayment}>
            Mark as Executed
          </Button>
        </DialogActions>
      </Dialog>

      {/* Confirm Payment Dialog */}
      <Dialog open={confirmDialog} onClose={() => setConfirmDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Confirm Payment Completion</DialogTitle>
        <DialogContent>
          <Box mt={2}>
            <Alert severity="success" sx={{ mb: 2 }}>
              <Typography variant="body2" fontWeight="bold">
                This will mark the payroll period as PAID
              </Typography>
              <Typography variant="caption">
                Confirm that all bank transfers have been successfully completed
              </Typography>
            </Alert>
            <TextField
              fullWidth
              label="Confirmation Notes"
              value={confirmationNotes}
              onChange={(e) => setConfirmationNotes(e.target.value)}
              margin="normal"
              multiline
              rows={3}
              helperText="Document the payment completion"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialog(false)}>Cancel</Button>
          <Button variant="contained" color="success" onClick={handleConfirmPayment}>
            Confirm Payment
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
};

export default FinancePayrollPayment;
