import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Chip,
  Grid,
  Stack,
  Paper,
  IconButton,
} from '@mui/material';
import {
  Close as CloseIcon,
  CalendarMonth as CalendarIcon,
  People as PeopleIcon,
  Schedule as ScheduleIcon,
} from '@mui/icons-material';
import type { PayrollPeriod } from '../../../api/payrollApi';
import { format } from 'date-fns';
import { useQuery } from '@tanstack/react-query';
import { employeesApi } from '../../../api/employees.api';

interface PeriodDetailsDialogProps {
  open: boolean;
  period: PayrollPeriod | null;
  onClose: () => void;
}

const PeriodDetailsDialog = ({ open, period, onClose }: PeriodDetailsDialogProps) => {
  // Fetch employee statistics
  const { data: employeeStats } = useQuery({
    queryKey: ['employeeCount', period?.organizationId],
    queryFn: () => {
      if (!period?.organizationId) throw new Error('Organization ID is required');
      return employeesApi.getEmployeeCount(period.organizationId);
    },
    enabled: !!period?.organizationId && open,
  });

  if (!period) return null;

  const stats = employeeStats?.data || { total: 0, active: 0, inactive: 0 };

  const getStatusColor = (status: string) => {
    const colors: Record<string, 'default' | 'info' | 'warning' | 'success' | 'error'> = {
      DRAFT: 'default',
      IN_PROGRESS: 'info',
      PENDING_APPROVAL: 'warning',
      APPROVED: 'success',
      PAID: 'success',
      LOCKED: 'error',
      DELETED: 'error',
    };
    return colors[status] || 'default';
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return format(new Date(dateString), 'PPP');
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box>
            <Box sx={{ fontWeight: 'bold', fontSize: '1.5rem' }}>
              {period.periodName}
            </Box>
            <Typography variant="caption" color="text.secondary">
              {period.periodType}
            </Typography>
          </Box>
          <Box display="flex" alignItems="center" gap={1}>
            <Chip
              label={period.status.replace('_', ' ')}
              color={getStatusColor(period.status)}
              size="medium"
            />
            <IconButton onClick={onClose} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        <Stack spacing={3}>
          {/* Period Dates */}
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Box display="flex" alignItems="center" mb={2}>
              <CalendarIcon color="primary" sx={{ mr: 1 }} />
              <Typography variant="h6" fontWeight="600">
                Period Dates
              </Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">
                  Start Date
                </Typography>
                <Typography variant="body1" fontWeight="500">
                  {formatDate(period.startDate)}
                </Typography>
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">
                  End Date
                </Typography>
                <Typography variant="body1" fontWeight="500">
                  {formatDate(period.endDate)}
                </Typography>
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">
                  Payment Date
                </Typography>
                <Typography variant="body1" fontWeight="500">
                  {formatDate(period.paymentDate)}
                </Typography>
              </Grid>
            </Grid>
          </Paper>

          {/* Employee Stats */}
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Box display="flex" alignItems="center" mb={2}>
              <PeopleIcon color="primary" sx={{ mr: 1 }} />
              <Typography variant="h6" fontWeight="600">
                Employee Statistics
              </Typography>
            </Box>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">
                  Total Employees
                </Typography>
                <Typography variant="h4" fontWeight="700" color="primary.main">
                  {stats.total}
                </Typography>
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">
                  Active Employees
                </Typography>
                <Typography variant="h4" fontWeight="700" color="success.main">
                  {stats.active}
                </Typography>
              </Grid>
              <Grid size={{ xs: 12, sm: 4 }}>
                <Typography variant="caption" color="text.secondary">
                  Total Employees
                </Typography>
                <Typography variant="h4" fontWeight="700" color="info.main">
                  {period.totalEmployees}
                </Typography>
              </Grid>
            </Grid>
          </Paper>

          {/* Processing Timeline */}
          {(period.processedAt || period.approvedAt) && (
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Box display="flex" alignItems="center" mb={2}>
                <ScheduleIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6" fontWeight="600">
                  Timeline
                </Typography>
              </Box>
              <Stack spacing={1.5}>
                {period.processedAt && (
                  <Box display="flex" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">
                      Processed
                    </Typography>
                    <Typography variant="body2" fontWeight="500">
                      {formatDate(period.processedAt)}
                    </Typography>
                  </Box>
                )}
                {period.approvedAt && (
                  <Box display="flex" justifyContent="space-between">
                    <Typography variant="body2" color="text.secondary">
                      Approved
                    </Typography>
                    <Typography variant="body2" fontWeight="500">
                      {formatDate(period.approvedAt)}
                    </Typography>
                  </Box>
                )}
              </Stack>
            </Paper>
          )}

          {/* Notes */}
          {period.notes && (
            <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50' }}>
              <Typography variant="caption" color="text.secondary" display="block" mb={1}>
                Notes
              </Typography>
              <Typography variant="body2">{period.notes}</Typography>
            </Paper>
          )}
        </Stack>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose} variant="outlined">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PeriodDetailsDialog;
