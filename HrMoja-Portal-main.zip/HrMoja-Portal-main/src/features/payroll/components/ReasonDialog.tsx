import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Alert,
} from '@mui/material';

interface ReasonDialogProps {
  open: boolean;
  title: string;
  message: string;
  onClose: () => void;
  onConfirm: (reason: string) => void;
  isLoading: boolean;
  severity?: 'info' | 'warning' | 'error';
}

const ReasonDialog = ({
  open,
  title,
  message,
  onClose,
  onConfirm,
  isLoading,
  severity = 'warning',
}: ReasonDialogProps) => {
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');

  const handleConfirm = () => {
    if (!reason.trim()) {
      setError('Reason is required');
      return;
    }
    onConfirm(reason);
    setReason('');
    setError('');
  };

  const handleClose = () => {
    setReason('');
    setError('');
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold', fontSize: '1.5rem' }}>
        {title}
      </DialogTitle>

      <DialogContent>
        <Alert severity={severity} sx={{ mb: 3 }}>
          {message}
        </Alert>

        <TextField
          label="Reason *"
          multiline
          rows={4}
          fullWidth
          value={reason}
          onChange={(e) => {
            setReason(e.target.value);
            setError('');
          }}
          error={!!error}
          helperText={error || 'Please provide a detailed reason for this action'}
          placeholder="Enter the reason for this action..."
        />
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={handleClose} disabled={isLoading}>
          Cancel
        </Button>
        <Button
          onClick={handleConfirm}
          variant="contained"
          color={severity === 'error' ? 'error' : 'primary'}
          disabled={isLoading}
        >
          {isLoading ? 'Processing...' : 'Confirm'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ReasonDialog;
