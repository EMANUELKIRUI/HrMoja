import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Alert,
  Typography,
  Box,
} from '@mui/material';
import { Warning as WarningIcon } from '@mui/icons-material';
import type { PayrollPeriod } from '../../../api/payrollApi';

interface DeleteConfirmDialogProps {
  open: boolean;
  period: PayrollPeriod | null;
  onClose: () => void;
  onConfirm: () => void;
  isLoading: boolean;
}

const DeleteConfirmDialog = ({ open, period, onClose, onConfirm, isLoading }: DeleteConfirmDialogProps) => {
  if (!period) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box display="flex" alignItems="center" gap={1}>
          <WarningIcon color="error" />
          <Box sx={{ fontWeight: 'bold', fontSize: '1.5rem' }}>
            Delete Payroll Period
          </Box>
        </Box>
      </DialogTitle>

      <DialogContent>
        <Alert severity="error" sx={{ mb: 2 }}>
          This action cannot be undone!
        </Alert>

        <Typography variant="body1" gutterBottom>
          Are you sure you want to delete the following payroll period?
        </Typography>

        <Box
          sx={{
            mt: 2,
            p: 2,
            bgcolor: 'grey.100',
            borderRadius: 1,
            border: '1px solid',
            borderColor: 'grey.300',
          }}
        >
          <Typography variant="subtitle2" color="text.secondary">
            Period Name
          </Typography>
          <Typography variant="h6" fontWeight="600" gutterBottom>
            {period.periodName}
          </Typography>

          <Typography variant="subtitle2" color="text.secondary">
            Period Type
          </Typography>
          <Typography variant="body1">{period.periodType}</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
          Note: You can only delete periods in DRAFT status with no payroll records.
        </Typography>
      </DialogContent>

      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button onClick={onClose} disabled={isLoading}>
          Cancel
        </Button>
        <Button onClick={onConfirm} variant="contained" color="error" disabled={isLoading}>
          {isLoading ? 'Deleting...' : 'Delete Period'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteConfirmDialog;
