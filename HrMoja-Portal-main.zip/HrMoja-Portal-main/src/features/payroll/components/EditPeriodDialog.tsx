import { useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  Alert,
  Typography,
  Box,
} from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import type { PayrollPeriod } from '../../../api/payrollApi';

const editPeriodSchema = z.object({
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  paymentDate: z.string().min(1, 'Payment date is required'),
}).refine(data => new Date(data.endDate) >= new Date(data.startDate), {
  message: 'End date must be after start date',
  path: ['endDate'],
}).refine(data => new Date(data.paymentDate) >= new Date(data.endDate), {
  message: 'Payment date must be on or after end date',
  path: ['paymentDate'],
});

type EditPeriodFormData = z.infer<typeof editPeriodSchema>;

interface EditPeriodDialogProps {
  open: boolean;
  period: PayrollPeriod | null;
  onClose: () => void;
  onSave: (data: EditPeriodFormData) => void;
  isLoading: boolean;
}

const EditPeriodDialog = ({ open, period, onClose, onSave, isLoading }: EditPeriodDialogProps) => {
  const { control, handleSubmit, formState: { errors }, reset } = useForm<EditPeriodFormData>({
    resolver: zodResolver(editPeriodSchema),
  });

  useEffect(() => {
    if (period) {
      reset({
        startDate: period.startDate,
        endDate: period.endDate,
        paymentDate: period.paymentDate,
      });
    }
  }, [period, reset]);

  const handleClose = () => {
    reset();
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <form onSubmit={handleSubmit(onSave)}>
        <DialogTitle>
          <Box>
            <Box sx={{ fontWeight: 'bold', fontSize: '1.5rem' }}>
              Edit Payroll Period
            </Box>
            <Typography variant="body2" color="text.secondary">
              {period?.periodName}
            </Typography>
          </Box>
        </DialogTitle>

        <DialogContent>
          <Alert severity="info" sx={{ mb: 3 }}>
            You can only edit periods in DRAFT status. Dates must be logical and sequential.
          </Alert>

          <Grid container spacing={2}>
            <Grid size={12}>
              <Controller
                name="startDate"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Start Date"
                    type="date"
                    fullWidth
                    required
                    error={!!errors.startDate}
                    helperText={errors.startDate?.message}
                    InputLabelProps={{ shrink: true }}
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Controller
                name="endDate"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="End Date"
                    type="date"
                    fullWidth
                    required
                    error={!!errors.endDate}
                    helperText={errors.endDate?.message}
                    InputLabelProps={{ shrink: true }}
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Controller
                name="paymentDate"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Payment Date"
                    type="date"
                    fullWidth
                    required
                    error={!!errors.paymentDate}
                    helperText={errors.paymentDate?.message}
                    InputLabelProps={{ shrink: true }}
                  />
                )}
              />
            </Grid>
          </Grid>
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={handleClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button type="submit" variant="contained" disabled={isLoading}>
            {isLoading ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default EditPeriodDialog;
