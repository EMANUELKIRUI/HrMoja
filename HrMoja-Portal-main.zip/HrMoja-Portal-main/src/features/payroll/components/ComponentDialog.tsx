import { useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  MenuItem,
  FormControlLabel,
  Switch,
  Box,
  Typography,
  Alert,
  CircularProgress,
} from '@mui/material';
import { payrollComponentsApi } from '../../../api/payroll-components.api';
import { referenceDataApi } from '../../../api/reference-data.api';
import { useAuthStore } from '../../../store/authStore';
import { useToast } from '../../../hooks/useToast';
import type { PayrollComponent } from '../../../api/payrollApi';
import type { PayrollComponentType } from '../../../types/api.types';

interface Props {
  open: boolean;
  onClose: () => void;
  component: PayrollComponent | null;
}

const componentSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  code: z.string().min(1, 'Code is required'),
  componentTypeId: z.number().min(1, 'Component type is required'),
  description: z.string().optional(),
  calculationMethod: z.enum(['FIXED', 'PERCENTAGE', 'FORMULA', 'RANGE']),
  calculationBasis: z.enum(['BASIC_SALARY', 'GROSS_SALARY', 'TAXABLE_INCOME']).nullable().optional(),
  fixedAmount: z.number().optional(),
  percentageValue: z.number().optional(),
  maxAmount: z.number().optional(),
  formula: z.string().optional(),
  taxable: z.boolean(),
  pensionable: z.boolean(),
  affectsGross: z.boolean(),
  affectsNet: z.boolean(),
  displayOnPayslip: z.boolean(),
  priorityOrder: z.number().optional(),
  statutory: z.boolean(),
  active: z.boolean(),
  notes: z.string().optional(),
});

type ComponentFormData = z.infer<typeof componentSchema>;

const ComponentDialog = ({ open, onClose, component }: Props) => {
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const user = useAuthStore((state) => state.user);
  const organizationId = user?.organizationId || 1;

  const {
    control,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<ComponentFormData>({
    resolver: zodResolver(componentSchema),
    defaultValues: {
      name: '',
      code: '',
      componentTypeId: 0,
      description: '',
      calculationMethod: 'FIXED',
      calculationBasis: 'BASIC_SALARY',
      fixedAmount: 0,
      percentageValue: 0,
      maxAmount: 0,
      formula: '',
      taxable: true,
      pensionable: true,
      affectsGross: true,
      affectsNet: true,
      displayOnPayslip: true,
      priorityOrder: 0,
      statutory: false,
      active: true,
      notes: '',
    },
  });

  const calculationMethod = watch('calculationMethod');

  // Fetch component types
  const { data: componentTypesData, isLoading: typesLoading } = useQuery({
    queryKey: ['componentTypes'],
    queryFn: () => referenceDataApi.getAllComponentTypes(),
  });

  const componentTypes = (componentTypesData?.data || []) as PayrollComponentType[];

  // Reset form when dialog opens with existing component
  useEffect(() => {
    if (open && component) {
      reset({
        name: component.name,
        code: component.code,
        componentTypeId: component.componentTypeId,
        description: component.description || '',
        calculationMethod: component.calculationMethod as 'FIXED' | 'PERCENTAGE' | 'FORMULA' | 'RANGE',
        calculationBasis: component.calculationBasis,
        fixedAmount: component.fixedAmount || 0,
        percentageValue: component.percentageValue || 0,
        maxAmount: component.maxAmount || 0,
        formula: component.formula || '',
        taxable: component.taxable ?? component.isTaxable ?? false,
        pensionable: component.pensionable ?? component.isPensionable ?? false,
        affectsGross: component.affectsGross ?? false,
        affectsNet: component.affectsNet ?? false,
        displayOnPayslip: component.displayOnPayslip ?? false,
        priorityOrder: component.priorityOrder || 0,
        statutory: component.statutory ?? component.isStatutory ?? false,
        active: component.active ?? component.isActive ?? false,
        notes: component.notes || '',
      } as any);
    } else if (open && !component) {
      reset({
        name: '',
        code: '',
        componentTypeId: 0,
        description: '',
        calculationMethod: 'FIXED',
        calculationBasis: 'BASIC_SALARY',
        fixedAmount: 0,
        percentageValue: 0,
        maxAmount: 0,
        formula: '',
        taxable: true,
        pensionable: true,
        affectsGross: true,
        affectsNet: true,
        displayOnPayslip: true,
        priorityOrder: 0,
        statutory: false,
        active: true,
        notes: '',
      });
    }
  }, [open, component, reset]);

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: Partial<PayrollComponent>) => payrollComponentsApi.createComponent(data),
    onSuccess: () => {
      showToast({ message: 'Component created successfully', severity: 'success' });
      queryClient.invalidateQueries({ queryKey: ['payrollComponents'] });
      onClose();
    },
    onError: (error: any) => {
      showToast({ message: error.response?.data?.message || 'Failed to create component', severity: 'error' });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<PayrollComponent> }) =>
      payrollComponentsApi.updateComponent(id, data),
    onSuccess: () => {
      showToast({ message: 'Component updated successfully', severity: 'success' });
      queryClient.invalidateQueries({ queryKey: ['payrollComponents'] });
      onClose();
    },
    onError: (error: any) => {
      showToast({ message: error.response?.data?.message || 'Failed to update component', severity: 'error' });
    },
  });

  const onSubmit = (data: ComponentFormData) => {
    const componentData: Partial<PayrollComponent> = {
      ...data,
      organizationId,
      isTaxable: data.taxable,
      isPensionable: data.pensionable,
      isStatutory: data.statutory,
      isActive: data.active,
      fixedAmount: data.calculationMethod === 'FIXED' ? data.fixedAmount : undefined,
      percentageValue: data.calculationMethod === 'PERCENTAGE' ? data.percentageValue : undefined,
      formula: data.calculationMethod === 'FORMULA' ? data.formula : undefined,
      calculationBasis: data.calculationMethod === 'PERCENTAGE' ? (data.calculationBasis || undefined) : undefined,
    };

    if (component?.id) {
      updateMutation.mutate({ id: component.id, data: componentData });
    } else {
      createMutation.mutate(componentData);
    }
  };

  const onError = (_formErrors: any) => {
    showToast({ message: 'Please fix form errors before submitting', severity: 'error' });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        {component ? 'Edit Payroll Component' : 'Create Payroll Component'}
      </DialogTitle>

      <form onSubmit={handleSubmit(onSubmit, onError)}>
        <DialogContent dividers>
          {typesLoading ? (
            <Box display="flex" justifyContent="center" py={4}>
              <CircularProgress />
            </Box>
          ) : (
            <Grid container spacing={3}>
              <Grid size={12}>
                <Alert severity="info">
                  Configure a payroll component for earnings, deductions, benefits, taxes, or statutory contributions.
                </Alert>
              </Grid>

              {/* Basic Information */}
              <Grid size={12}>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                  Basic Information
                </Typography>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="name"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Component Name"
                      fullWidth
                      required
                      error={!!errors.name}
                      helperText={errors.name?.message}
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="code"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Component Code"
                      fullWidth
                      required
                      error={!!errors.code}
                      helperText={errors.code?.message}
                    />
                  )}
                />
              </Grid>

              <Grid size={12}>
                <Controller
                  name="componentTypeId"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Component Type"
                      fullWidth
                      required
                      select
                      error={!!errors.componentTypeId}
                      helperText={errors.componentTypeId?.message}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                    >
                      <MenuItem value={0} disabled>Select component type</MenuItem>
                      {componentTypes.map((type) => (
                        <MenuItem key={type.id} value={type.id}>
                          {type.name} ({type.calculationCategory})
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Grid>

              <Grid size={12}>
                <Controller
                  name="description"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Description"
                      fullWidth
                      multiline
                      rows={2}
                      error={!!errors.description}
                      helperText={errors.description?.message}
                    />
                  )}
                />
              </Grid>

              {/* Calculation Configuration */}
              <Grid size={12}>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                  Calculation Configuration
                </Typography>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="calculationMethod"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Calculation Method"
                      fullWidth
                      required
                      select
                      error={!!errors.calculationMethod}
                      helperText={errors.calculationMethod?.message}
                    >
                      <MenuItem value="FIXED">Fixed Amount</MenuItem>
                      <MenuItem value="PERCENTAGE">Percentage</MenuItem>
                      <MenuItem value="FORMULA">Formula</MenuItem>
                      <MenuItem value="RANGE">Range-based</MenuItem>
                    </TextField>
                  )}
                />
              </Grid>

              {calculationMethod === 'PERCENTAGE' && (
                <Grid size={{ xs: 12, md: 6 }}>
                  <Controller
                    name="calculationBasis"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Calculation Basis"
                        fullWidth
                        select
                        error={!!errors.calculationBasis}
                        helperText={errors.calculationBasis?.message}
                      >
                        <MenuItem value="BASIC_SALARY">Basic Salary</MenuItem>
                        <MenuItem value="GROSS_SALARY">Gross Salary</MenuItem>
                        <MenuItem value="TAXABLE_INCOME">Taxable Income</MenuItem>
                      </TextField>
                    )}
                  />
                </Grid>
              )}

              {calculationMethod === 'FIXED' && (
                <Grid size={{ xs: 12, md: 6 }}>
                  <Controller
                    name="fixedAmount"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Fixed Amount"
                        type="number"
                        fullWidth
                        error={!!errors.fixedAmount}
                        helperText={errors.fixedAmount?.message}
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        InputProps={{
                          inputProps: { min: 0, step: 100 }
                        }}
                      />
                    )}
                  />
                </Grid>
              )}

              {calculationMethod === 'PERCENTAGE' && (
                <>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="percentageValue"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Percentage Value (%)"
                          type="number"
                          fullWidth
                          error={!!errors.percentageValue}
                          helperText={errors.percentageValue?.message}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          InputProps={{
                            inputProps: { min: 0, max: 100, step: 0.1 }
                          }}
                        />
                      )}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, md: 6 }}>
                    <Controller
                      name="maxAmount"
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          label="Max Amount (Ceiling)"
                          type="number"
                          fullWidth
                          error={!!errors.maxAmount}
                          helperText={errors.maxAmount?.message || "Optional: Maximum cap for this component (e.g., NSSF ceiling)"}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          InputProps={{
                            inputProps: { min: 0, step: 1000 }
                          }}
                        />
                      )}
                    />
                  </Grid>
                </>
              )}

              {calculationMethod === 'FORMULA' && (
                <Grid size={12}>
                  <Controller
                    name="formula"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Formula"
                        fullWidth
                        multiline
                        rows={2}
                        error={!!errors.formula}
                        helperText={errors.formula?.message || "e.g., BASIC_SALARY * 0.05"}
                      />
                    )}
                  />
                </Grid>
              )}

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="priorityOrder"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Priority Order"
                      type="number"
                      fullWidth
                      error={!!errors.priorityOrder}
                      helperText="Lower numbers are processed first"
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      InputProps={{
                        inputProps: { min: 0 }
                      }}
                    />
                  )}
                />
              </Grid>

              {/* Component Properties */}
              <Grid size={12}>
                <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                  Component Properties
                </Typography>
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="taxable"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Taxable"
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="pensionable"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Pensionable"
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="statutory"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Statutory"
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="affectsGross"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Affects Gross Pay"
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="affectsNet"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Affects Net Pay"
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="displayOnPayslip"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Display on Payslip"
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                <Controller
                  name="active"
                  control={control}
                  render={({ field }) => (
                    <FormControlLabel
                      control={<Switch {...field} checked={field.value} />}
                      label="Active"
                    />
                  )}
                />
              </Grid>

              <Grid size={12}>
                <Controller
                  name="notes"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Notes"
                      fullWidth
                      multiline
                      rows={2}
                      error={!!errors.notes}
                      helperText={errors.notes?.message}
                    />
                  )}
                />
              </Grid>
            </Grid>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button
            type="submit"
            variant="contained"
            disabled={createMutation.isPending || updateMutation.isPending}
          >
            {createMutation.isPending || updateMutation.isPending ? (
              <CircularProgress size={24} />
            ) : component ? (
              'Update'
            ) : (
              'Create'
            )}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default ComponentDialog;
