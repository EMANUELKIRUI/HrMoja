import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Alert,
  IconButton,
  Menu,
  MenuItem,
} from '@mui/material';
import {
  Add as AddIcon,
  MoreVert as MoreIcon,
  PlayArrow as ProcessIcon,
  Check as ApproveIcon,
  Visibility as ViewIcon,
} from '@mui/icons-material';
import payrollApi, { type PayrollPeriod } from '../../api/payrollApi';

const PayrollProcessingPage = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<PayrollPeriod | null>(null);
  
  const organizationId = 1; // Mock - should come from auth context

  const { data, isLoading, error } = useQuery({
    queryKey: ['payrollPeriods', organizationId],
    queryFn: () => payrollApi.getPeriods(organizationId),
  });

  const periods = data || [];

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, period: PayrollPeriod) => {
    setAnchorEl(event.currentTarget);
    setSelectedPeriod(period);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedPeriod(null);
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, 'default' | 'info' | 'warning' | 'success' | 'error'> = {
      DRAFT: 'default',
      PROCESSING: 'info',
      PROCESSED: 'warning',
      APPROVED: 'success',
      PAID: 'success',
      LOCKED: 'error',
    };
    return colors[status] || 'default';
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Payroll Processing
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Create and manage payroll periods
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />}>
          Create Period
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Failed to load payroll periods. Please try again.
        </Alert>
      )}

      {isLoading ? (
        <Box display="flex" justifyContent="center" p={4}>
          <CircularProgress />
        </Box>
      ) : periods.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No Payroll Periods
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Create your first payroll period to start processing payroll
          </Typography>
          <Button variant="contained" startIcon={<AddIcon />}>
            Create First Period
          </Button>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Period Name</TableCell>
                <TableCell>Start Date</TableCell>
                <TableCell>End Date</TableCell>
                <TableCell>Payment Date</TableCell>
                <TableCell align="right">Employees</TableCell>
                <TableCell align="right">Gross Pay</TableCell>
                <TableCell align="right">Net Pay</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {periods.map((period: PayrollPeriod) => (
                <TableRow key={period.id} hover>
                  <TableCell>
                    <Typography fontWeight="medium">{period.periodName}</Typography>
                  </TableCell>
                  <TableCell>{new Date(period.startDate).toLocaleDateString()}</TableCell>
                  <TableCell>{new Date(period.endDate).toLocaleDateString()}</TableCell>
                  <TableCell>{new Date(period.paymentDate).toLocaleDateString()}</TableCell>
                  <TableCell align="right">{period.totalEmployees}</TableCell>
                  <TableCell align="right">-</TableCell>
                  <TableCell align="right">
                    <Typography fontWeight="bold">
                      -
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={period.status}
                      color={getStatusColor(period.status)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="right">
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuOpen(e, period)}
                    >
                      <MoreIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleMenuClose}>
          <ViewIcon fontSize="small" sx={{ mr: 1 }} />
          View Details
        </MenuItem>
        {selectedPeriod?.status === 'DRAFT' && (
          <MenuItem onClick={handleMenuClose}>
            <ProcessIcon fontSize="small" sx={{ mr: 1 }} />
            Process Payroll
          </MenuItem>
        )}
        {(selectedPeriod?.status === 'PENDING_APPROVAL' || selectedPeriod?.status === 'APPROVED') && (
          <MenuItem onClick={handleMenuClose}>
            <ApproveIcon fontSize="small" sx={{ mr: 1 }} />
            Approve Payroll
          </MenuItem>
        )}
      </Menu>
    </Box>
  );
};

export default PayrollProcessingPage;
