import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  Tabs,
  Tab,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  IconButton,
  Tooltip,
  TextField,
  InputAdornment,
  Card,
  CardContent,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  TrendingUp as EarningIcon,
  TrendingDown as DeductionIcon,
  CardGiftcard as BenefitIcon,
  AccountBalance as TaxIcon,
  Gavel as StatutoryIcon,
} from '@mui/icons-material';
import { payrollComponentsApi } from '../../api/payroll-components.api';
import { useAuthStore } from '../../store/authStore';
import { useToast } from '../../hooks/useToast';
import type { PayrollComponent } from '../../api/payrollApi';
import ComponentDialog from './components/ComponentDialog';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = ({ children, value, index }: TabPanelProps) => {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
};

const ComponentsTable = ({ 
  components, 
  isLoading,
  onEdit,
  onDelete,
}: { 
  components: PayrollComponent[];
  isLoading: boolean;
  onEdit: (component: PayrollComponent) => void;
  onDelete: (id: number) => void;
}) => {
  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (components.length === 0) {
    return (
      <Box textAlign="center" py={4}>
        <Typography variant="h6" color="text.secondary" gutterBottom>
          No Components Found
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Click "Add Component" to create one.
        </Typography>
      </Box>
    );
  }

  const formatAmount = (component: PayrollComponent) => {
    if (component.calculationMethod === 'FIXED' && component.fixedAmount) {
      return `Fixed: ${component.fixedAmount.toLocaleString()}`;
    }
    if (component.calculationMethod === 'PERCENTAGE' && component.percentageValue) {
      return `${component.percentageValue}% of ${component.calculationBasis || 'Salary'}`;
    }
    if (component.calculationMethod === 'FORMULA') {
      return 'Formula-based';
    }
    return '-';
  };

  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Code</TableCell>
            <TableCell>Type</TableCell>
            <TableCell>Calculation</TableCell>
            <TableCell>Details</TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {components.map((component) => (
            <TableRow key={component.id} hover>
              <TableCell>
                <Typography fontWeight="medium">{component.name}</Typography>
                {component.description && (
                  <Typography variant="caption" color="text.secondary" display="block">
                    {component.description}
                  </Typography>
                )}
              </TableCell>
              <TableCell>
                <Chip label={component.code} size="small" variant="outlined" />
              </TableCell>
              <TableCell>
                <Typography variant="body2">{component.componentTypeName || '-'}</Typography>
              </TableCell>
              <TableCell>
                <Typography variant="body2" fontWeight="medium">
                  {component.calculationMethod}
                </Typography>
                <Typography variant="caption" color="text.secondary" display="block">
                  {formatAmount(component)}
                </Typography>
              </TableCell>
              <TableCell>
                <Box display="flex" gap={0.5} flexWrap="wrap">
                  {component.taxable && (
                    <Chip label="Taxable" size="small" color="primary" variant="outlined" />
                  )}
                  {component.pensionable && (
                    <Chip label="Pensionable" size="small" color="secondary" variant="outlined" />
                  )}
                  {component.statutory && (
                    <Chip label="Statutory" size="small" color="warning" variant="outlined" />
                  )}
                </Box>
              </TableCell>
              <TableCell>
                <Chip
                  label={component.active ? 'Active' : 'Inactive'}
                  color={component.active ? 'success' : 'default'}
                  size="small"
                />
              </TableCell>
              <TableCell align="right">
                <Tooltip title="Edit Component">
                  <IconButton
                    size="small"
                    color="primary"
                    onClick={() => onEdit(component)}
                  >
                    <EditIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Delete Component">
                  <IconButton
                    size="small"
                    color="error"
                    onClick={() => component.id && onDelete(component.id)}
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

const PayrollComponentsPage = () => {
  const [currentTab, setCurrentTab] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedComponent, setSelectedComponent] = useState<PayrollComponent | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  
  const user = useAuthStore((state) => state.user);
  const organizationId = user?.organizationId || 1;
  const queryClient = useQueryClient();
  const { showToast, ToastComponent } = useToast();

  const { data: componentsData, isLoading } = useQuery({
    queryKey: ['payrollComponents', organizationId],
    queryFn: () => payrollComponentsApi.getComponentsByOrganization(organizationId),
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id: number) => payrollComponentsApi.deleteComponent(id),
    onSuccess: () => {
      showToast({ message: 'Component deactivated successfully', severity: 'success' });
      queryClient.invalidateQueries({ queryKey: ['payrollComponents'] });
    },
    onError: (error: any) => {
      showToast({ message: error.response?.data?.message || 'Failed to delete component', severity: 'error' });
    },
  });

  const components = componentsData?.data || [];
  
  // Filter by category and search
  const categories = ['EARNING', 'DEDUCTION', 'BENEFIT', 'TAX', 'STATUTORY'];
  const currentCategory = categories[currentTab];
  
  const filteredComponents = components.filter((c) => {
    const matchesCategory = c.calculationCategory === currentCategory;
    const matchesSearch = searchTerm === '' ||
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.description?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false);
    return matchesCategory && matchesSearch;
  });
  
  const earnings = components.filter(c => c.calculationCategory === 'EARNING');
  const deductions = components.filter(c => c.calculationCategory === 'DEDUCTION');
  const benefits = components.filter(c => c.calculationCategory === 'BENEFIT');
  const taxes = components.filter(c => c.calculationCategory === 'TAX');
  const statutory = components.filter(c => c.calculationCategory === 'STATUTORY');

  const handleEdit = (component: PayrollComponent) => {
    setSelectedComponent(component);
    setDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to deactivate this component?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleAddNew = () => {
    setSelectedComponent(null);
    setDialogOpen(true);
  };

  return (
    <Box>
      <ToastComponent />
      
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Payroll Components
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage earnings, deductions, benefits, taxes, and statutory components
          </Typography>
        </Box>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={handleAddNew}
        >
          Add Component
        </Button>
      </Box>

      {/* Statistics Cards */}
      <Box display="grid" gridTemplateColumns={{ xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(5, 1fr)' }} gap={2} mb={3}>
        <Card>
          <CardContent sx={{ textAlign: 'center' }}>
            <EarningIcon sx={{ fontSize: 40, color: 'success.main', mb: 1 }} />
            <Typography variant="h4" fontWeight="bold">{earnings.length}</Typography>
            <Typography variant="body2" color="text.secondary">Earnings</Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent sx={{ textAlign: 'center' }}>
            <DeductionIcon sx={{ fontSize: 40, color: 'error.main', mb: 1 }} />
            <Typography variant="h4" fontWeight="bold">{deductions.length}</Typography>
            <Typography variant="body2" color="text.secondary">Deductions</Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent sx={{ textAlign: 'center' }}>
            <BenefitIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
            <Typography variant="h4" fontWeight="bold">{benefits.length}</Typography>
            <Typography variant="body2" color="text.secondary">Benefits</Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent sx={{ textAlign: 'center' }}>
            <TaxIcon sx={{ fontSize: 40, color: 'warning.main', mb: 1 }} />
            <Typography variant="h4" fontWeight="bold">{taxes.length}</Typography>
            <Typography variant="body2" color="text.secondary">Taxes</Typography>
          </CardContent>
        </Card>
        <Card>
          <CardContent sx={{ textAlign: 'center' }}>
            <StatutoryIcon sx={{ fontSize: 40, color: 'secondary.main', mb: 1 }} />
            <Typography variant="h4" fontWeight="bold">{statutory.length}</Typography>
            <Typography variant="body2" color="text.secondary">Statutory</Typography>
          </CardContent>
        </Card>
      </Box>

      {/* Search and Tabs */}
      <Paper>
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <TextField
            fullWidth
            placeholder="Search by name, code, or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        </Box>
        
        <Tabs
          value={currentTab}
          onChange={(_e, val) => setCurrentTab(val)}
          variant="fullWidth"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label={`Earnings (${earnings.length})`} icon={<EarningIcon />} iconPosition="start" />
          <Tab label={`Deductions (${deductions.length})`} icon={<DeductionIcon />} iconPosition="start" />
          <Tab label={`Benefits (${benefits.length})`} icon={<BenefitIcon />} iconPosition="start" />
          <Tab label={`Taxes (${taxes.length})`} icon={<TaxIcon />} iconPosition="start" />
          <Tab label={`Statutory (${statutory.length})`} icon={<StatutoryIcon />} iconPosition="start" />
        </Tabs>

        <Box sx={{ p: 3 }}>
          <TabPanel value={currentTab} index={0}>
            <ComponentsTable 
              components={filteredComponents} 
              isLoading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </TabPanel>
          <TabPanel value={currentTab} index={1}>
            <ComponentsTable 
              components={filteredComponents} 
              isLoading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </TabPanel>
          <TabPanel value={currentTab} index={2}>
            <ComponentsTable 
              components={filteredComponents} 
              isLoading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </TabPanel>
          <TabPanel value={currentTab} index={3}>
            <ComponentsTable 
              components={filteredComponents} 
              isLoading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </TabPanel>
          <TabPanel value={currentTab} index={4}>
            <ComponentsTable 
              components={filteredComponents} 
              isLoading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          </TabPanel>
        </Box>
      </Paper>

      {/* Component Dialog */}
      <ComponentDialog 
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        component={selectedComponent}
      />
    </Box>
  );
};

export default PayrollComponentsPage;
