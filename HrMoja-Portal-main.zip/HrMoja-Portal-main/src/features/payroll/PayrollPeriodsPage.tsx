import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Alert,
  IconButton,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Tabs,
  Tab,
  Grid,
} from '@mui/material';
import {
  Add as AddIcon,
  MoreVert as MoreIcon,
  Check as ApproveIcon,
  Visibility as ViewIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Block as RejectIcon,
  LockOpen as UnlockIcon,
} from '@mui/icons-material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import payrollApi from '../../api/payrollApi';
import { referenceDataApi } from '../../api/reference-data.api';
import type { PayrollPeriod } from '../../api/payrollApi';
import { useAuthStore } from '../../store/authStore';
import { useToast } from '../../hooks/useToast';
import PeriodDetailsDialog from './components/PeriodDetailsDialog';
import EditPeriodDialog from './components/EditPeriodDialog';
import ReasonDialog from './components/ReasonDialog';
import DeleteConfirmDialog from './components/DeleteConfirmDialog';

const periodSchema = z.object({
  organizationId: z.number(),
  periodName: z.string().min(1, 'Period name is required'),
  periodType: z.string().min(1, 'Period type is required'),
  payFrequencyId: z.number().min(1, 'Pay frequency is required'),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  paymentDate: z.string().min(1, 'Payment date is required'),
});

type PeriodFormData = z.infer<typeof periodSchema>;

const PayrollPeriodsPage = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<PayrollPeriod | null>(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [reasonDialog, setReasonDialog] = useState<{
    open: boolean;
    type: 'reject' | 'unlock' | null;
    title: string;
    message: string;
  }>({ open: false, type: null, title: '', message: '' });
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;
  const queryClient = useQueryClient();
  const { showToast, ToastComponent } = useToast();

  // Fetch payroll periods
  const { data: periodsData, isLoading, error } = useQuery({
    queryKey: ['payrollPeriods', organizationId],
    queryFn: () => payrollApi.getPeriods(organizationId),
  });

  // Fetch pay frequencies
  const { data: payFrequenciesData } = useQuery({
    queryKey: ['payFrequencies'],
    queryFn: referenceDataApi.getAllPayFrequencies,
  });

  const periods = periodsData || [];
  const payFrequencies = payFrequenciesData?.data || [];

  // Filter periods by status
  const filteredPeriods = statusFilter === 'all' 
    ? periods.filter((p: PayrollPeriod) => p.status !== 'DELETED')
    : periods.filter((p: PayrollPeriod) => p.status === statusFilter);

  const { control, handleSubmit, formState: { errors }, reset } = useForm<PeriodFormData>({
    resolver: zodResolver(periodSchema),
    defaultValues: {
      organizationId,
      payFrequencyId: undefined,
      startDate: '',
      endDate: '',
      paymentDate: '',
    },
  });

  // Create period mutation
  const createMutation = useMutation({
    mutationFn: (data: PeriodFormData) => payrollApi.createPeriod(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
      showToast({ message: 'Payroll period created successfully!', severity: 'success' });
      setCreateDialogOpen(false);
      reset();
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || 'Failed to create period';
      showToast({ message, severity: 'error' });
    },
  });

  // Approve period mutation
  const approveMutation = useMutation({
    mutationFn: (periodId: number) => payrollApi.approvePeriod(periodId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
      showToast({ message: 'Payroll approved successfully!', severity: 'success' });
      handleMenuClose();
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || 'Failed to approve payroll';
      showToast({ message, severity: 'error' });
    },
  });

  // Lock period mutation - API method not available, commenting out
  // const lockMutation = useMutation({
  //   mutationFn: (periodId: number) => payrollApi.lockPeriod(periodId),
  //   onSuccess: () => {
  //     queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
  //     showToast({ message: 'Payroll period locked!', severity: 'success' });
  //     handleMenuClose();
  //   },
  //   onError: (err: any) => {
  //     const message = err.response?.data?.message || 'Failed to lock period';
  //     showToast({ message, severity: 'error' });
  //   },
  // });

  // Update period mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => payrollApi.updatePeriod(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
      showToast({ message: 'Period updated successfully!', severity: 'success' });
      setEditDialogOpen(false);
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || 'Failed to update period';
      showToast({ message, severity: 'error' });
    },
  });

  // Delete period mutation
  const deleteMutation = useMutation({
    mutationFn: (periodId: number) => payrollApi.deletePeriod(periodId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
      showToast({ message: 'Period deleted successfully!', severity: 'success' });
      setDeleteDialogOpen(false);
      handleMenuClose();
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || 'Failed to delete period';
      showToast({ message, severity: 'error' });
    },
  });

  // Reject period mutation
  const rejectMutation = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason: string }) => payrollApi.rejectPayroll(id, reason),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
      showToast({ message: 'Period rejected successfully!', severity: 'success' });
      setReasonDialog({ open: false, type: null, title: '', message: '' });
      handleMenuClose();
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || 'Failed to reject period';
      showToast({ message, severity: 'error' });
    },
  });

  // Unlock period mutation
  const unlockMutation = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason: string }) => payrollApi.unlockPeriod(id, reason),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payrollPeriods'] });
      showToast({ message: 'Period unlocked successfully!', severity: 'success' });
      setReasonDialog({ open: false, type: null, title: '', message: '' });
      handleMenuClose();
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || 'Failed to unlock period';
      showToast({ message, severity: 'error' });
    },
  });

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, period: PayrollPeriod) => {
    setAnchorEl(event.currentTarget);
    setSelectedPeriod(period);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedPeriod(null);
  };

  const handleApprove = () => {
    if (selectedPeriod) {
      approveMutation.mutate(selectedPeriod.id);
    }
  };

  // Commented out - lockMutation is not available
  // const handleLock = () => {
  //   if (selectedPeriod) {
  //     lockMutation.mutate(selectedPeriod.id);
  //   }
  // };

  const handleView = () => {
    setDetailsDialogOpen(true);
    setAnchorEl(null);
  };

  const handleEdit = () => {
    setEditDialogOpen(true);
    setAnchorEl(null);
  };

  const handleDelete = () => {
    setDeleteDialogOpen(true);
    setAnchorEl(null);
  };

  const handleReject = () => {
    setReasonDialog({
      open: true,
      type: 'reject',
      title: 'Reject Payroll Period',
      message: 'Please provide a reason for rejecting this payroll period. It will be returned to DRAFT status.',
    });
    setAnchorEl(null);
  };

  const handleUnlock = () => {
    setReasonDialog({
      open: true,
      type: 'unlock',
      title: 'Unlock Payroll Period',
      message: 'Please provide a reason for unlocking this period. This action should only be done when necessary.',
    });
    setAnchorEl(null);
  };

  const handleReasonConfirm = (reason: string) => {
    if (!selectedPeriod) return;
    
    if (reasonDialog.type === 'reject') {
      rejectMutation.mutate({ id: selectedPeriod.id, reason });
    } else if (reasonDialog.type === 'unlock') {
      unlockMutation.mutate({ id: selectedPeriod.id, reason });
    }
  };

  const handleEditSave = (data: any) => {
    if (!selectedPeriod) return;
    updateMutation.mutate({ id: selectedPeriod.id, data });
  };

  const handleDeleteConfirm = () => {
    if (!selectedPeriod) return;
    deleteMutation.mutate(selectedPeriod.id);
  };

  const onSubmit = (data: PeriodFormData) => {
    createMutation.mutate(data);
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, 'default' | 'info' | 'warning' | 'success' | 'error'> = {
      DRAFT: 'default',
      IN_PROGRESS: 'info',
      PENDING_APPROVAL: 'warning',
      APPROVED: 'success',
      PAID: 'success',
      LOCKED: 'error',
      DELETED: 'error',
    };
    return colors[status] || 'default';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-UG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getStatusCounts = () => {
    return {
      all: periods.filter((p: PayrollPeriod) => p.status !== 'DELETED').length,
      DRAFT: periods.filter((p: PayrollPeriod) => p.status === 'DRAFT').length,
      IN_PROGRESS: periods.filter((p: PayrollPeriod) => p.status === 'IN_PROGRESS').length,
      PENDING_APPROVAL: periods.filter((p: PayrollPeriod) => p.status === 'PENDING_APPROVAL').length,
      APPROVED: periods.filter((p: PayrollPeriod) => p.status === 'APPROVED').length,
      LOCKED: periods.filter((p: PayrollPeriod) => p.status === 'LOCKED').length,
      DELETED: periods.filter((p: PayrollPeriod) => p.status === 'DELETED').length,
    };
  };

  const statusCounts = getStatusCounts();

  return (
    <Box>
      <ToastComponent />
      
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Payroll Periods
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Create and manage payroll processing periods
          </Typography>
        </Box>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => setCreateDialogOpen(true)}
        >
          Create Period
        </Button>
      </Box>

      {/* Status Filter Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={statusFilter}
          onChange={(_, newValue) => setStatusFilter(newValue)}
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label={`All (${statusCounts.all})`} value="all" />
          <Tab label={`Draft (${statusCounts.DRAFT})`} value="DRAFT" />
          <Tab label={`In Progress (${statusCounts.IN_PROGRESS})`} value="IN_PROGRESS" />
          <Tab label={`Pending Approval (${statusCounts.PENDING_APPROVAL})`} value="PENDING_APPROVAL" />
          <Tab label={`Approved (${statusCounts.APPROVED})`} value="APPROVED" />
          <Tab label={`Locked (${statusCounts.LOCKED})`} value="LOCKED" />
          <Tab label={`Deleted (${statusCounts.DELETED})`} value="DELETED" />
        </Tabs>
      </Paper>

      {statusFilter === 'DRAFT' && filteredPeriods.length > 0 && (
        <Alert severity="info" sx={{ mb: 2 }}>
          <strong>Note:</strong> Payroll processing is currently disabled. Complete employee salary configurations before processing payroll periods.
        </Alert>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Failed to load payroll periods. Please try again.
        </Alert>
      )}

      {isLoading ? (
        <Box display="flex" justifyContent="center" p={4}>
          <CircularProgress />
        </Box>
      ) : filteredPeriods.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            {statusFilter === 'all' ? 'No Payroll Periods' : `No ${statusFilter.replace('_', ' ')} Periods`}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            {statusFilter === 'all' 
              ? 'Create your first payroll period to start processing payroll'
              : 'No periods found with this status'}
          </Typography>
          {statusFilter === 'all' && (
            <Button 
              variant="contained" 
              startIcon={<AddIcon />}
              onClick={() => setCreateDialogOpen(true)}
            >
              Create First Period
            </Button>
          )}
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Period Name</TableCell>
                <TableCell>Period Code</TableCell>
                <TableCell>Start Date</TableCell>
                <TableCell>End Date</TableCell>
                <TableCell>Payment Date</TableCell>
                <TableCell align="right">Employees</TableCell>
                <TableCell align="right">Processed</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredPeriods.map((period: PayrollPeriod) => (
                <TableRow key={period.id} hover>
                  <TableCell>
                    <Typography fontWeight="medium">{period.periodName}</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" color="text.secondary">
                      {period.periodType}
                    </Typography>
                  </TableCell>
                  <TableCell>{formatDate(period.startDate)}</TableCell>
                  <TableCell>{formatDate(period.endDate)}</TableCell>
                  <TableCell>{formatDate(period.paymentDate)}</TableCell>
                  <TableCell align="right">{period.totalEmployees}</TableCell>
                  <TableCell align="right">
                    <Typography variant="body2">
                      {period.totalEmployees}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={period.status.replace('_', ' ')}
                      color={getStatusColor(period.status)}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="right">
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuOpen(e, period)}
                    >
                      <MoreIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Actions Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleView}>
          <ViewIcon fontSize="small" sx={{ mr: 1 }} />
          View Details
        </MenuItem>
        
        {selectedPeriod?.status === 'DRAFT' && [
          <MenuItem key="edit" onClick={handleEdit}>
            <EditIcon fontSize="small" sx={{ mr: 1 }} />
            Edit Period
          </MenuItem>,
          <MenuItem key="delete" onClick={handleDelete} sx={{ color: 'error.main' }}>
            <DeleteIcon fontSize="small" sx={{ mr: 1 }} />
            Delete Period
          </MenuItem>,
        ]}
        
        {selectedPeriod?.status === 'PENDING_APPROVAL' && [
          <MenuItem key="approve" onClick={handleApprove}>
            <ApproveIcon fontSize="small" sx={{ mr: 1 }} />
            Approve Payroll
          </MenuItem>,
          <MenuItem key="reject" onClick={handleReject} sx={{ color: 'warning.main' }}>
            <RejectIcon fontSize="small" sx={{ mr: 1 }} />
            Reject Payroll
          </MenuItem>,
        ]}
        
        {/* Commented out - lockMutation is not available
        {selectedPeriod?.status === 'APPROVED' && (
          <MenuItem onClick={handleLock}>
            <LockIcon fontSize="small" sx={{ mr: 1 }} />
            Lock Period
          </MenuItem>
        )}
        */}
        
        {selectedPeriod?.status === 'LOCKED' && (
          <MenuItem onClick={handleUnlock} sx={{ color: 'error.main' }}>
            <UnlockIcon fontSize="small" sx={{ mr: 1 }} />
            Unlock Period
          </MenuItem>
        )}
      </Menu>

      {/* Dialogs */}
      <PeriodDetailsDialog
        open={detailsDialogOpen}
        period={selectedPeriod}
        onClose={() => {
          setDetailsDialogOpen(false);
          setSelectedPeriod(null);
        }}
      />

      <EditPeriodDialog
        open={editDialogOpen}
        period={selectedPeriod}
        onClose={() => {
          setEditDialogOpen(false);
          setSelectedPeriod(null);
        }}
        onSave={handleEditSave}
        isLoading={updateMutation.isPending}
      />

      <DeleteConfirmDialog
        open={deleteDialogOpen}
        period={selectedPeriod}
        onClose={() => {
          setDeleteDialogOpen(false);
          setSelectedPeriod(null);
        }}
        onConfirm={handleDeleteConfirm}
        isLoading={deleteMutation.isPending}
      />

      <ReasonDialog
        open={reasonDialog.open}
        title={reasonDialog.title}
        message={reasonDialog.message}
        onClose={() => setReasonDialog({ open: false, type: null, title: '', message: '' })}
        onConfirm={handleReasonConfirm}
        isLoading={rejectMutation.isPending || unlockMutation.isPending}
        severity={reasonDialog.type === 'reject' ? 'warning' : 'error'}
      />

      {/* Create Period Dialog */}
      <Dialog 
        open={createDialogOpen} 
        onClose={() => setCreateDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle sx={{ fontWeight: 'bold' }}>Create Payroll Period</DialogTitle>
        <form onSubmit={handleSubmit(onSubmit)}>
          <DialogContent>
            <Grid container spacing={3}>
              <Grid size={12}>
                <Controller
                  name="payFrequencyId"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      select
                      label="Pay Frequency"
                      fullWidth
                      required
                      error={!!errors.payFrequencyId}
                      helperText={errors.payFrequencyId?.message}
                      value={field.value || ''}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                      name={field.name}
                      SelectProps={{
                        native: false,
                      }}
                    >
                      <MenuItem value="">Select...</MenuItem>
                      {payFrequencies.map((freq) => (
                        <MenuItem key={freq.id} value={freq.id}>
                          {freq.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 4 }}>
                <Controller
                  name="startDate"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Start Date"
                      type="date"
                      fullWidth
                      required
                      error={!!errors.startDate}
                      helperText={errors.startDate?.message}
                      InputLabelProps={{ shrink: true }}
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 4 }}>
                <Controller
                  name="endDate"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="End Date"
                      type="date"
                      fullWidth
                      required
                      error={!!errors.endDate}
                      helperText={errors.endDate?.message}
                      InputLabelProps={{ shrink: true }}
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 4 }}>
                <Controller
                  name="paymentDate"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Payment Date"
                      type="date"
                      fullWidth
                      required
                      error={!!errors.paymentDate}
                      helperText={errors.paymentDate?.message}
                      InputLabelProps={{ shrink: true }}
                    />
                  )}
                />
              </Grid>

              <Grid size={12}>
                <Alert severity="info">
                  <Typography variant="body2">
                    <strong>Note:</strong> The period name and code will be automatically generated based on the start date.
                    You can process payroll after creating the period.
                  </Typography>
                </Alert>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
            <Button 
              type="submit" 
              variant="contained"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? 'Creating...' : 'Create Period'}
            </Button>
          </DialogActions>
        </form>
      </Dialog>
    </Box>
  );
};

export default PayrollPeriodsPage;
