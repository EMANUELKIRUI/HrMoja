import { useState } from 'react';
import {
  Box,
  Tabs,
  Tab,
  Paper,
  Typography,
} from '@mui/material';
import CountriesTab from './tabs/CountriesTab';
import PayFrequenciesTab from './tabs/PayFrequenciesTab';
import EmploymentTypesTab from './tabs/EmploymentTypesTab';
import PaymentMethodsTab from './tabs/PaymentMethodsTab';
import JobTitlesTab from './tabs/JobTitlesTab';
import DepartmentsTab from './tabs/DepartmentsTab';
import BranchesTab from './tabs/BranchesTab';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = ({ children, value, index }: TabPanelProps) => {
  return (
    <div role="tabpanel" hidden={value !== index}>
      {value === index && <Box sx={{ pt: 3 }}>{children}</Box>}
    </div>
  );
};

const SettingsPage = () => {
  const [currentTab, setCurrentTab] = useState(0);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setCurrentTab(newValue);
  };

  return (
    <Box>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Settings
      </Typography>
      <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
        Manage system configurations and reference data
      </Typography>

      <Paper>
        <Tabs 
          value={currentTab} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab label="Job Titles" />
          <Tab label="Departments" />
          <Tab label="Branches" />
          <Tab label="Countries" />
          <Tab label="Pay Frequencies" />
          <Tab label="Employment Types" />
          <Tab label="Payment Methods" />
        </Tabs>

        <Box sx={{ p: 3 }}>
          <TabPanel value={currentTab} index={0}>
            <JobTitlesTab />
          </TabPanel>
          <TabPanel value={currentTab} index={1}>
            <DepartmentsTab />
          </TabPanel>
          <TabPanel value={currentTab} index={2}>
            <BranchesTab />
          </TabPanel>
          <TabPanel value={currentTab} index={3}>
            <CountriesTab />
          </TabPanel>
          <TabPanel value={currentTab} index={4}>
            <PayFrequenciesTab />
          </TabPanel>
          <TabPanel value={currentTab} index={5}>
            <EmploymentTypesTab />
          </TabPanel>
          <TabPanel value={currentTab} index={6}>
            <PaymentMethodsTab />
          </TabPanel>
        </Box>
      </Paper>
    </Box>
  );
};

export default SettingsPage;
