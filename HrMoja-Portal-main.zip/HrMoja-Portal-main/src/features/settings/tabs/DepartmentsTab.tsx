import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  MenuItem,
  Chip,
} from '@mui/material';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import type { GridColDef } from '@mui/x-data-grid';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { settingsApi } from '../../../api/settings.api';
import type { Department } from '../../../api/settings.api';
import { useAuthStore } from '../../../store/authStore';
import { useToast } from '../../../hooks/useToast';

const DepartmentsTab = () => {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;
  const { showToast, ToastComponent } = useToast();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Department | null>(null);
  const [formData, setFormData] = useState<Partial<Department>>({
    name: '',
    code: '',
    description: '',
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ['departments', organizationId],
    queryFn: () => settingsApi.getDepartments(organizationId),
  });

  const { data: branchesData } = useQuery({
    queryKey: ['branches', organizationId],
    queryFn: () => settingsApi.getActiveBranches(organizationId),
  });

  const createMutation = useMutation({
    mutationFn: settingsApi.createDepartment,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments'] });
      showToast({ message: 'Department created successfully', severity: 'success' });
      handleCloseDialog();
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to create department';
      showToast({ message, severity: 'error' });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Department }) =>
      settingsApi.updateDepartment(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments'] });
      showToast({ message: 'Department updated successfully', severity: 'success' });
      handleCloseDialog();
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to update department';
      showToast({ message, severity: 'error' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: settingsApi.deleteDepartment,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments'] });
      showToast({ message: 'Department deleted successfully', severity: 'success' });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to delete department';
      showToast({ message, severity: 'error' });
    },
  });

  const handleOpenDialog = (item?: Department) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ name: '', code: '', description: '' });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingItem(null);
    setFormData({ name: '', code: '', description: '' });
  };

  const handleSubmit = () => {
    const payload = {
      ...formData,
      organizationId,
    } as Department;

    if (editingItem?.id) {
      updateMutation.mutate({ id: editingItem.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this department?')) {
      deleteMutation.mutate(id);
    }
  };

  const columns: GridColDef[] = [
    { field: 'code', headerName: 'Code', width: 150 },
    { field: 'name', headerName: 'Name', flex: 1, minWidth: 200 },
    { field: 'branchName', headerName: 'Branch', width: 150 },
    { field: 'description', headerName: 'Description', flex: 1, minWidth: 200 },
    { field: 'costCenterCode', headerName: 'Cost Center', width: 150 },
    {
      field: 'active',
      headerName: 'Status',
      width: 120,
      renderCell: (params) => (
        <Chip
          label={params.value ? 'Active' : 'Inactive'}
          color={params.value ? 'success' : 'default'}
          size="small"
        />
      ),
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Actions',
      width: 100,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<EditIcon />}
          label="Edit"
          onClick={() => handleOpenDialog(params.row)}
        />,
        <GridActionsCellItem
          icon={<DeleteIcon />}
          label="Delete"
          onClick={() => handleDelete(params.row.id)}
        />,
      ],
    },
  ];

  if (error) {
    return <Alert severity="error">Failed to load departments</Alert>;
  }

  return (
    <Box>
      <ToastComponent />
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Box>
          <strong>Departments</strong>
          <br />
          <small>Manage organizational departments</small>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenDialog()}>
          Add Department
        </Button>
      </Box>

      <DataGrid
        rows={data?.data || []}
        columns={columns}
        loading={isLoading}
        autoHeight
        pageSizeOptions={[10, 25, 50]}
        initialState={{
          pagination: { paginationModel: { pageSize: 10 } },
        }}
        sx={{
          '& .MuiDataGrid-cell:focus': {
            outline: 'none',
          },
        }}
      />

      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>{editingItem ? 'Edit Department' : 'Add Department'}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 2 }}>
            <TextField
              label="Code"
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value })}
              required
              fullWidth
            />
            <TextField
              label="Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              fullWidth
            />
            <TextField
              label="Branch"
              select
              value={formData.branchId || ''}
              onChange={(e) => setFormData({ ...formData, branchId: Number(e.target.value) || undefined })}
              fullWidth
            >
              <MenuItem value="">None</MenuItem>
              {branchesData?.data?.map((branch) => (
                <MenuItem key={branch.id} value={branch.id}>
                  {branch.name}
                </MenuItem>
              ))}
            </TextField>
            <TextField
              label="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              multiline
              rows={3}
              fullWidth
            />
            <TextField
              label="Cost Center Code"
              value={formData.costCenterCode}
              onChange={(e) => setFormData({ ...formData, costCenterCode: e.target.value })}
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            disabled={!formData.name || !formData.code || createMutation.isPending || updateMutation.isPending}
          >
            {createMutation.isPending || updateMutation.isPending ? (
              <CircularProgress size={24} />
            ) : editingItem ? (
              'Update'
            ) : (
              'Create'
            )}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default DepartmentsTab;
