import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Chip,
} from '@mui/material';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import type { GridColDef } from '@mui/x-data-grid';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { settingsApi } from '../../../api/settings.api';
import type { JobTitle } from '../../../api/settings.api';
import { useAuthStore } from '../../../store/authStore';
import { useToast } from '../../../hooks/useToast';

const JobTitlesTab = () => {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;
  const { showToast, ToastComponent } = useToast();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<JobTitle | null>(null);
  const [formData, setFormData] = useState<Partial<JobTitle>>({
    title: '',
    code: '',
    description: '',
    level: 1,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { data, isLoading, error } = useQuery({
    queryKey: ['jobTitles', organizationId],
    queryFn: () => settingsApi.getJobTitles(organizationId),
  });

  const createMutation = useMutation({
    mutationFn: settingsApi.createJobTitle,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobTitles'] });
      showToast({ message: 'Job title created successfully', severity: 'success' });
      handleCloseDialog();
    },
    onError: (error: any) => {
      if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
      } else if (error.response?.data?.message) {
        showToast({ message: error.response.data.message, severity: 'error' });
      } else {
        showToast({ message: 'Failed to create job title', severity: 'error' });
      }
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: JobTitle }) =>
      settingsApi.updateJobTitle(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobTitles'] });
      showToast({ message: 'Job title updated successfully', severity: 'success' });
      handleCloseDialog();
    },
    onError: (error: any) => {
      if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
      } else if (error.response?.data?.message) {
        showToast({ message: error.response.data.message, severity: 'error' });
      } else {
        showToast({ message: 'Failed to update job title', severity: 'error' });
      }
    },
  });

  const deleteMutation = useMutation({
    mutationFn: settingsApi.deleteJobTitle,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobTitles'] });
      showToast({ message: 'Job title deleted successfully', severity: 'success' });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to delete job title';
      showToast({ message, severity: 'error' });
    },
  });

  const handleOpenDialog = (item?: JobTitle) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ title: '', code: '', description: '', level: 1 });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingItem(null);
    setFormData({ title: '', code: '', description: '', level: 1 });
    setErrors({});
  };

  const handleSubmit = () => {
    const payload = {
      ...formData,
      organizationId,
    } as JobTitle;

    if (editingItem?.id) {
      updateMutation.mutate({ id: editingItem.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this job title?')) {
      deleteMutation.mutate(id);
    }
  };

  const columns: GridColDef[] = [
    { field: 'code', headerName: 'Code', width: 150 },
    { field: 'title', headerName: 'Title', flex: 1, minWidth: 200 },
    { field: 'description', headerName: 'Description', flex: 1, minWidth: 200 },
    { field: 'level', headerName: 'Level', width: 100 },
    {
      field: 'active',
      headerName: 'Status',
      width: 120,
      renderCell: (params) => (
        <Chip
          label={params.value ? 'Active' : 'Inactive'}
          color={params.value ? 'success' : 'default'}
          size="small"
        />
      ),
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Actions',
      width: 100,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<EditIcon />}
          label="Edit"
          onClick={() => handleOpenDialog(params.row)}
        />,
        <GridActionsCellItem
          icon={<DeleteIcon />}
          label="Delete"
          onClick={() => handleDelete(params.row.id)}
        />,
      ],
    },
  ];

  if (error) {
    return <Alert severity="error">Failed to load job titles</Alert>;
  }

  return (
    <Box>
      <ToastComponent />
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Box>
          <strong>Job Titles</strong>
          <br />
          <small>Manage job titles and positions</small>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenDialog()}>
          Add Job Title
        </Button>
      </Box>

      <DataGrid
        rows={data?.data || []}
        columns={columns}
        loading={isLoading}
        autoHeight
        pageSizeOptions={[10, 25, 50]}
        initialState={{
          pagination: { paginationModel: { pageSize: 10 } },
        }}
        sx={{
          '& .MuiDataGrid-cell:focus': {
            outline: 'none',
          },
        }}
      />

      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>{editingItem ? 'Edit Job Title' : 'Add Job Title'}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 2 }}>
            <TextField
              label="Code"
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value })}
              required
              fullWidth
              error={!!errors.code}
              helperText={errors.code}
            />
            <TextField
              label="Title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              fullWidth
              error={!!errors.title}
              helperText={errors.title}
            />
            <TextField
              label="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              multiline
              rows={3}
              fullWidth
            />
            <TextField
              label="Level"
              type="number"
              value={formData.level}
              onChange={(e) => setFormData({ ...formData, level: parseInt(e.target.value) })}
              fullWidth
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            disabled={!formData.title || !formData.code || createMutation.isPending || updateMutation.isPending}
          >
            {createMutation.isPending || updateMutation.isPending ? (
              <CircularProgress size={24} />
            ) : editingItem ? (
              'Update'
            ) : (
              'Create'
            )}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default JobTitlesTab;
