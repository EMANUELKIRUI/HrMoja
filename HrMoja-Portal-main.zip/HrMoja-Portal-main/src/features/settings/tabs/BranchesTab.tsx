import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Chip,
} from '@mui/material';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import type { GridColDef } from '@mui/x-data-grid';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { settingsApi } from '../../../api/settings.api';
import type { Branch } from '../../../api/settings.api';
import { useAuthStore } from '../../../store/authStore';
import { useToast } from '../../../hooks/useToast';

const BranchesTab = () => {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;
  const { showToast, ToastComponent } = useToast();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Branch | null>(null);
  const [formData, setFormData] = useState<Partial<Branch>>({
    name: '',
    code: '',
    description: '',
    isHeadOffice: false,
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ['branches', organizationId],
    queryFn: () => settingsApi.getBranches(organizationId),
  });

  const { data: countriesData } = useQuery({
    queryKey: ['countries'],
    queryFn: () => settingsApi.getActiveCountries(),
  });

  const createMutation = useMutation({
    mutationFn: settingsApi.createBranch,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['branches'] });
      showToast({ message: 'Branch created successfully', severity: 'success' });
      handleCloseDialog();
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to create branch';
      showToast({ message, severity: 'error' });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Branch }) =>
      settingsApi.updateBranch(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['branches'] });
      showToast({ message: 'Branch updated successfully', severity: 'success' });
      handleCloseDialog();
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to update branch';
      showToast({ message, severity: 'error' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: settingsApi.deleteBranch,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['branches'] });
      showToast({ message: 'Branch deleted successfully', severity: 'success' });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to delete branch';
      showToast({ message, severity: 'error' });
    },
  });

  const handleOpenDialog = (item?: Branch) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ name: '', code: '', description: '', isHeadOffice: false });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingItem(null);
    setFormData({ name: '', code: '', description: '', isHeadOffice: false });
  };

  const handleSubmit = () => {
    const payload = {
      ...formData,
      organizationId,
    } as Branch;

    if (editingItem?.id) {
      updateMutation.mutate({ id: editingItem.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this branch?')) {
      deleteMutation.mutate(id);
    }
  };

  const columns: GridColDef[] = [
    { field: 'code', headerName: 'Code', width: 120 },
    { field: 'name', headerName: 'Name', flex: 1, minWidth: 180 },
    { field: 'city', headerName: 'City', width: 150 },
    { field: 'phoneNumber', headerName: 'Phone', width: 150 },
    { field: 'email', headerName: 'Email', flex: 1, minWidth: 200 },
    {
      field: 'isHeadOffice',
      headerName: 'Head Office',
      width: 120,
      valueGetter: (value) => (value ? 'Yes' : 'No'),
    },
    {
      field: 'isActive',
      headerName: 'Status',
      width: 100,
      renderCell: (params) => (
        <Chip
          label={params.value ? 'Active' : 'Inactive'}
          color={params.value ? 'success' : 'default'}
          size="small"
        />
      ),
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Actions',
      width: 100,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<EditIcon />}
          label="Edit"
          onClick={() => handleOpenDialog(params.row)}
        />,
        <GridActionsCellItem
          icon={<DeleteIcon />}
          label="Delete"
          onClick={() => handleDelete(params.row.id)}
        />,
      ],
    },
  ];

  if (error) {
    return <Alert severity="error">Failed to load branches</Alert>;
  }

  return (
    <Box>
      <ToastComponent />
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Box>
          <strong>Branches</strong>
          <br />
          <small>Manage organization branches and locations</small>
        </Box>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenDialog()}>
          Add Branch
        </Button>
      </Box>

      <DataGrid
        rows={data?.data || []}
        columns={columns}
        loading={isLoading}
        autoHeight
        pageSizeOptions={[10, 25, 50]}
        initialState={{
          pagination: { paginationModel: { pageSize: 10 } },
        }}
        sx={{
          '& .MuiDataGrid-cell:focus': {
            outline: 'none',
          },
        }}
      />

      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>{editingItem ? 'Edit Branch' : 'Add Branch'}</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 2 }}>
            <Box display="flex" gap={2}>
              <TextField
                label="Code"
                value={formData.code}
                onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                required
                sx={{ flex: 1 }}
              />
              <TextField
                label="Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                sx={{ flex: 2 }}
              />
            </Box>

            <TextField
              label="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              multiline
              rows={2}
              fullWidth
            />

            <Box display="flex" gap={2}>
              <TextField
                label="Address Line 1"
                value={formData.addressLine1}
                onChange={(e) => setFormData({ ...formData, addressLine1: e.target.value })}
                fullWidth
              />
              <TextField
                label="Address Line 2"
                value={formData.addressLine2}
                onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                fullWidth
              />
            </Box>

            <Box display="flex" gap={2}>
              <TextField
                label="City"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                sx={{ flex: 1 }}
              />
              <TextField
                label="State/Province"
                value={formData.stateProvince}
                onChange={(e) => setFormData({ ...formData, stateProvince: e.target.value })}
                sx={{ flex: 1 }}
              />
              <TextField
                label="Postal Code"
                value={formData.postalCode}
                onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                sx={{ flex: 1 }}
              />
            </Box>

            <TextField
              label="Country"
              select
              value={formData.countryId || ''}
              onChange={(e) => setFormData({ ...formData, countryId: Number(e.target.value) || undefined })}
              fullWidth
            >
              <MenuItem value="">None</MenuItem>
              {countriesData?.data?.map((country) => (
                <MenuItem key={country.id} value={country.id}>
                  {country.name}
                </MenuItem>
              ))}
            </TextField>

            <Box display="flex" gap={2}>
              <TextField
                label="Phone Number"
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                fullWidth
              />
              <TextField
                label="Email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                fullWidth
              />
            </Box>

            <FormControlLabel
              control={
                <Checkbox
                  checked={formData.isHeadOffice || false}
                  onChange={(e) => setFormData({ ...formData, isHeadOffice: e.target.checked })}
                />
              }
              label="Head Office"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            disabled={!formData.name || !formData.code || createMutation.isPending || updateMutation.isPending}
          >
            {createMutation.isPending || updateMutation.isPending ? (
              <CircularProgress size={24} />
            ) : editingItem ? (
              'Update'
            ) : (
              'Create'
            )}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default BranchesTab;
