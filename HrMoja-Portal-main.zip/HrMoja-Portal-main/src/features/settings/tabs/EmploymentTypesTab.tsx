import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
} from '@mui/material';
import { settingsApi } from '../../../api/settings.api';

const EmploymentTypesTab = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['employmentTypes'],
    queryFn: () => settingsApi.getEmploymentTypes(),
  });

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error">
        Failed to load employment types. Please try again.
      </Alert>
    );
  }

  const types = data?.data || [];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Employment Types ({types.length})
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Available employment types for employee classification
      </Typography>

      <TableContainer component={Paper} variant="outlined">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Code</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {types.map((type) => (
              <TableRow key={type.id}>
                <TableCell>{type.name}</TableCell>
                <TableCell>{type.code}</TableCell>
                <TableCell>{type.description}</TableCell>
                <TableCell>
                  <Chip
                    label={type.active ? 'Active' : 'Inactive'}
                    color={type.active ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default EmploymentTypesTab;
