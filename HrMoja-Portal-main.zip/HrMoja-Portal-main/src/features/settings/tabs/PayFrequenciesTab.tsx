import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
} from '@mui/material';
import { settingsApi } from '../../../api/settings.api';

const PayFrequenciesTab = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['payFrequencies'],
    queryFn: () => settingsApi.getPayFrequencies(),
  });

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error">
        Failed to load pay frequencies. Please try again.
      </Alert>
    );
  }

  const frequencies = data?.data || [];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Pay Frequencies ({frequencies.length})
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Available payment frequencies for payroll processing
      </Typography>

      <TableContainer component={Paper} variant="outlined">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Code</TableCell>
              <TableCell>Periods Per Year</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {frequencies.map((freq) => (
              <TableRow key={freq.id}>
                <TableCell>{freq.name}</TableCell>
                <TableCell>{freq.code}</TableCell>
                <TableCell>{freq.periodsPerYear}</TableCell>
                <TableCell>{freq.description}</TableCell>
                <TableCell>
                  <Chip
                    label={freq.active ? 'Active' : 'Inactive'}
                    color={freq.active ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default PayFrequenciesTab;
