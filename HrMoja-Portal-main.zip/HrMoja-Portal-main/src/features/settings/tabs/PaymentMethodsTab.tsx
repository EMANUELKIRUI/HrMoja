import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
} from '@mui/material';
import { settingsApi } from '../../../api/settings.api';

const PaymentMethodsTab = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['paymentMethods'],
    queryFn: () => settingsApi.getPaymentMethods(),
  });

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error">
        Failed to load payment methods. Please try again.
      </Alert>
    );
  }

  const methods = data?.data || [];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Payment Methods ({methods.length})
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Available payment methods for salary disbursement
      </Typography>

      <TableContainer component={Paper} variant="outlined">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Code</TableCell>
              <TableCell>Requires Bank Details</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {methods.map((method) => (
              <TableRow key={method.id}>
                <TableCell>{method.name}</TableCell>
                <TableCell>{method.code}</TableCell>
                <TableCell>
                  <Chip
                    label={method.requiresBankDetails ? 'Yes' : 'No'}
                    color={method.requiresBankDetails ? 'primary' : 'default'}
                    size="small"
                  />
                </TableCell>
                <TableCell>{method.description}</TableCell>
                <TableCell>
                  <Chip
                    label={method.active ? 'Active' : 'Inactive'}
                    color={method.active ? 'success' : 'default'}
                    size="small"
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default PaymentMethodsTab;
