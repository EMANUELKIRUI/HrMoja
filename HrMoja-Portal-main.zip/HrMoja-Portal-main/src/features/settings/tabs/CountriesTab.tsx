import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  CircularProgress,
  Alert,
  Grid,
} from '@mui/material';
import { Public as PublicIcon } from '@mui/icons-material';
import { settingsApi } from '../../../api/settings.api';

const CountriesTab = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['countries'],
    queryFn: () => settingsApi.getCountries(),
  });

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error">
        Failed to load countries. Please try again.
      </Alert>
    );
  }

  const countries = data?.data || [];

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Countries ({countries.length})
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Available countries for organization setup
      </Typography>

      <Grid container spacing={2}>
        {countries.map((country) => (
          <Grid size={{ xs: 12, sm: 6, md: 4 }} key={country.id}>
            <Card>
              <CardContent>
                <Box display="flex" alignItems="center" gap={2} mb={2}>
                  <PublicIcon color="primary" />
                  <Box flex={1}>
                    <Typography variant="h6">{country.name}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {country.code} ({country.isoCode})
                    </Typography>
                  </Box>
                  <Chip
                    label={country.active ? 'Active' : 'Inactive'}
                    color={country.active ? 'success' : 'default'}
                    size="small"
                  />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    <strong>Currency:</strong> {country.currencyName} ({country.currencySymbol})
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <strong>Timezone:</strong> {country.timezone}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <strong>Date Format:</strong> {country.dateFormat}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default CountriesTab;
