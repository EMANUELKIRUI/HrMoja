import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm, Controller } from 'react-hook-form';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Tabs,
  Tab,
  Avatar,
  Chip,
  Button,
  Grid,
  Stack,
  Divider,
  IconButton,
  Alert,
  CircularProgress,
  TextField,
  MenuItem,
  Autocomplete,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  Business as BusinessIcon,
  Description as DocumentIcon,
  CloudUpload as UploadIcon,
  Delete as DeleteIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';
import { employeesApi } from '../../api/employees.api';
import { settingsApi } from '../../api/settings.api';
import { employeeSalaryApi } from '../../api/employee-salary.api';
import { employeeBankApi, type EmployeeBankDetails } from '../../api/employee-bank.api';
import { employeeDocumentsApi, type EmployeeDocument } from '../../api/employee-documents.api';
import { referenceDataApi } from '../../api/reference-data.api';
import { banksApi } from '../../api/banks.api';
import type { Employee, EmployeeSalaryStructure } from '../../types/api.types';
import { useToast } from '../../hooks/useToast';
import { useAuthStore } from '../../store/authStore';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = ({ children, value, index }: TabPanelProps) => {
  return (
    <div hidden={value !== index} style={{ paddingTop: 24 }}>
      {value === index && children}
    </div>
  );
};

const EmployeeProfilePage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const [currentTab, setCurrentTab] = useState(0);
  const isEditMode = searchParams.get('mode') === 'edit';
  const { showToast, ToastComponent } = useToast();
  const [uploadingDocument, setUploadingDocument] = useState(false);

  const { control, handleSubmit, reset, formState: { errors } } = useForm<Partial<Employee>>();
  const { control: salaryControl, handleSubmit: handleSalarySubmit, reset: resetSalary, formState: { errors: salaryErrors } } = useForm<Partial<EmployeeSalaryStructure>>();
  const { control: bankControl, handleSubmit: handleBankSubmit, reset: resetBank, watch: watchBank, setValue: setBankValue, formState: { errors: bankErrors } } = useForm<Partial<EmployeeBankDetails>>();
  const { user } = useAuthStore();
  const organizationId = user?.organizationId;

  const { data, isLoading, error } = useQuery({
    queryKey: ['employee', id],
    queryFn: () => employeesApi.getEmployeeById(Number(id)),
    enabled: !!id,
  });

  // Fetch dropdown options for employment details
  const { data: jobTitlesData } = useQuery({
    queryKey: ['jobTitles', organizationId],
    queryFn: () => settingsApi.getJobTitles(organizationId!),
    enabled: !!organizationId && isEditMode,
  });

  const { data: departmentsData } = useQuery({
    queryKey: ['departments', 'active', organizationId],
    queryFn: () => settingsApi.getActiveDepartments(organizationId!),
    enabled: !!organizationId && isEditMode,
  });

  const { data: branchesData } = useQuery({
    queryKey: ['branches', 'active', organizationId],
    queryFn: () => settingsApi.getActiveBranches(organizationId!),
    enabled: !!organizationId && isEditMode,
  });

  const { data: employmentTypesData } = useQuery({
    queryKey: ['employmentTypes'],
    queryFn: () => settingsApi.getEmploymentTypes(),
    enabled: isEditMode,
  });

  const jobTitles = jobTitlesData?.data || [];
  const departments = departmentsData?.data || [];
  const branches = branchesData?.data || [];
  const employmentTypes = employmentTypesData?.data || [];

  // Fetch salary data
  const { data: salaryData } = useQuery({
    queryKey: ['employee', id, 'salary'],
    queryFn: () => employeeSalaryApi.getCurrentSalary(Number(id)),
    enabled: !!id,
  });

  const { data: payFrequenciesData } = useQuery({
    queryKey: ['payFrequencies'],
    queryFn: () => referenceDataApi.getAllPayFrequencies(),
    enabled: isEditMode && currentTab === 2,
  });

  const currentSalary = salaryData?.data;
  const payFrequencies = payFrequenciesData?.data || [];

  // Fetch bank details data
  const { data: bankDetailsData } = useQuery({
    queryKey: ['employee', id, 'bankDetails'],
    queryFn: () => employeeBankApi.getPrimaryBankDetails(Number(id)),
    enabled: !!id,
  });

  const { data: banksData } = useQuery({
    queryKey: ['banks', 'active'],
    queryFn: () => banksApi.getActiveBanks(),
    enabled: isEditMode && currentTab === 3,
  });

  const selectedBankId = watchBank('bankId');
  const { data: bankBranchesData } = useQuery({
    queryKey: ['bankBranches', selectedBankId],
    queryFn: () => banksApi.getBankBranches(selectedBankId!),
    enabled: !!selectedBankId && isEditMode && currentTab === 3,
  });

  const currentBankDetails = bankDetailsData?.data;
  const banks = banksData?.data || [];
  const bankBranches = bankBranchesData?.data || [];

  // Reset salary form when salary data loads
  useEffect(() => {
    if (currentSalary) {
      resetSalary(currentSalary);
    } else {
      // Set defaults for new salary
      resetSalary({
        employeeId: Number(id),
        effectiveDate: new Date().toISOString().split('T')[0],
        currencyCode: 'UGX',
        basicSalary: 0,
        payFrequencyId: undefined,
      });
    }
  }, [currentSalary, resetSalary, id]);

  // Reset bank form when bank details loads
  useEffect(() => {
    if (currentBankDetails) {
      resetBank(currentBankDetails);
    } else {
      // Set defaults for new bank details
      resetBank({
        employeeId: Number(id),
        accountNumber: '',
        accountName: '',
        accountType: '',
        bankId: undefined,
        bankBranchId: undefined,
        primary: true,
      });
    }
  }, [currentBankDetails, resetBank, id]);

  // Fetch documents
  const { data: documentsData, refetch: refetchDocuments } = useQuery({
    queryKey: ['employee', id, 'documents'],
    queryFn: () => employeeDocumentsApi.getDocuments(Number(id)),
    enabled: !!id && currentTab === 4,
  });

  const documents = documentsData?.data || [];

  const employee = data?.data;

  // Reset form when employee data loads
  useEffect(() => {
    if (employee) {
      reset(employee);
    }
  }, [employee, reset]);

  const updateMutation = useMutation({
    mutationFn: (data: Partial<Employee>) => employeesApi.updateEmployee(Number(id), data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee', id] });
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      showToast({ message: 'Employee updated successfully', severity: 'success' });
      setSearchParams({});
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to update employee';
      showToast({ message, severity: 'error' });
    },
  });

  const onSubmit = (data: Partial<Employee>) => {
    updateMutation.mutate(data);
  };

  const salaryMutation = useMutation({
    mutationFn: (data: Partial<EmployeeSalaryStructure>) => {
      if (currentSalary?.id) {
        // Update existing salary
        return employeeSalaryApi.updateSalary(Number(id), currentSalary.id, data);
      } else {
        // Create new salary
        return employeeSalaryApi.createSalary({ ...data, employeeId: Number(id) } as EmployeeSalaryStructure);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee', id, 'salary'] });
      showToast({ message: 'Salary updated successfully', severity: 'success' });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to update salary';
      showToast({ message, severity: 'error' });
    },
  });

  const onSalarySubmit = (data: Partial<EmployeeSalaryStructure>) => {
    salaryMutation.mutate(data);
  };

  const bankMutation = useMutation({
    mutationFn: (data: Partial<EmployeeBankDetails>) => {
      if (currentBankDetails?.id) {
        // Update existing bank details
        return employeeBankApi.updateBankDetails(Number(id), currentBankDetails.id, data);
      } else {
        // Create new bank details
        return employeeBankApi.createBankDetails({ ...data, employeeId: Number(id), primary: true } as EmployeeBankDetails);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee', id, 'bankDetails'] });
      showToast({ message: 'Bank details updated successfully', severity: 'success' });
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to update bank details';
      showToast({ message, severity: 'error' });
    },
  });

  const onBankSubmit = (data: Partial<EmployeeBankDetails>) => {
    bankMutation.mutate(data);
  };

  const handleDocumentUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !id) return;

    setUploadingDocument(true);
    try {
      await employeeDocumentsApi.uploadDocument(Number(id), file, {
        employeeId: Number(id),
        documentType: 'OTHER',
        documentName: file.name,
      });
      showToast({ message: 'Document uploaded successfully', severity: 'success' });
      refetchDocuments();
    } catch (error: any) {
      showToast({ message: error.response?.data?.message || 'Failed to upload document', severity: 'error' });
    } finally {
      setUploadingDocument(false);
      event.target.value = '';
    }
  };

  const handleDocumentDownload = async (doc: EmployeeDocument) => {
    if (!id || !doc.id) return;
    
    try {
      const blob = await employeeDocumentsApi.downloadDocument(Number(id), doc.id);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.documentName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error: any) {
      showToast({ message: 'Failed to download document', severity: 'error' });
    }
  };

  const handleDocumentDelete = async (docId: number) => {
    if (!id || !window.confirm('Are you sure you want to delete this document?')) return;

    try {
      await employeeDocumentsApi.deleteDocument(Number(id), docId);
      showToast({ message: 'Document deleted successfully', severity: 'success' });
      refetchDocuments();
    } catch (error: any) {
      showToast({ message: 'Failed to delete document', severity: 'error' });
    }
  };

  const formatDate = (date: string | null | undefined) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };


  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (error || !employee) {
    return (
      <Box>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate(-1)} sx={{ mb: 2 }}>
          Back to Employees
        </Button>
        <Alert severity="error">Failed to load employee details. Please try again.</Alert>
      </Box>
    );
  }

  return (
    <Box>
      <ToastComponent />
      {/* Header */}
      <Box display="flex" alignItems="center" gap={2} mb={3}>
        <IconButton onClick={() => navigate(-1)}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h4" fontWeight="bold" flex={1}>
          Employee Profile
          {isEditMode && (
            <Chip label="Edit Mode" color="primary" size="small" sx={{ ml: 2 }} />
          )}
        </Typography>
        {!isEditMode ? (
          <Button 
            variant="outlined" 
            startIcon={<EditIcon />}
            onClick={() => setSearchParams({ mode: 'edit' })}
          >
            Edit Profile
          </Button>
        ) : (
          <Stack direction="row" spacing={2}>
            <Button 
              variant="outlined"
              onClick={() => setSearchParams({})}
            >
              Cancel
            </Button>
            <Button 
              variant="contained"
              onClick={handleSubmit(onSubmit)}
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </Stack>
        )}
      </Box>

      {/* Profile Card */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 'auto' }}>
              <Avatar
                sx={{
                  width: 120,
                  height: 120,
                  fontSize: 48,
                  bgcolor: 'primary.main',
                }}
              >
                {employee.firstName?.[0]}{employee.lastName?.[0]}
              </Avatar>
            </Grid>
            <Grid size={{ xs: 12, md: 8 }}>
              <Box display="flex" alignItems="flex-start" justifyContent="space-between">
                <Box>
                  <Typography variant="h5" fontWeight="bold">
                    {employee.firstName} {employee.middleName || ''} {employee.lastName}
                  </Typography>
                  <Typography variant="body1" color="text.secondary" gutterBottom>
                    {employee.jobTitleName || 'N/A'}
                  </Typography>
                  <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                    <Chip
                      label={employee.active ? 'Active' : 'Inactive'}
                      color={employee.active ? 'success' : 'default'}
                      size="small"
                    />
                    <Chip
                      label={employee.employeeNumber}
                      variant="outlined"
                      size="small"
                    />
                  </Stack>
                </Box>
              </Box>
              <Divider sx={{ my: 2 }} />
              <Grid container spacing={2}>
                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <EmailIcon fontSize="small" color="action" />
                    <Typography variant="body2">{employee.workEmail || 'N/A'}</Typography>
                  </Stack>
                </Grid>
                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <PhoneIcon fontSize="small" color="action" />
                    <Typography variant="body2">{employee.mobilePhone || 'N/A'}</Typography>
                  </Stack>
                </Grid>
                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <BusinessIcon fontSize="small" color="action" />
                    <Typography variant="body2">{employee.departmentName || 'N/A'}</Typography>
                  </Stack>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Card>
        <Tabs
          value={currentTab}
          onChange={(_, newValue) => setCurrentTab(newValue)}
          variant="scrollable"
          scrollButtons="auto"
          sx={{ borderBottom: 1, borderColor: 'divider', px: 2 }}
        >
          <Tab label="Personal Information" />
          <Tab label="Employment Details" />
          <Tab label="Salary & Benefits" />
          <Tab label="Bank Details" />
          <Tab label="Documents" />
          <Tab label="History" />
        </Tabs>

        {/* Personal Information Tab */}
        <TabPanel value={currentTab} index={0}>
          <CardContent>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              Personal Information
            </Typography>
            <Grid container spacing={3} sx={{ mt: 1 }}>
              {/* First Name */}
              <Grid size={{ xs: 12, sm: 4 }}>
                {isEditMode ? (
                  <Controller
                    name="firstName"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="First Name"
                        fullWidth
                        size="small"
                        error={!!errors.firstName}
                        helperText={errors.firstName?.message}
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">First Name</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.firstName}</Typography>
                  </>
                )}
              </Grid>

              {/* Middle Name */}
              <Grid size={{ xs: 12, sm: 4 }}>
                {isEditMode ? (
                  <Controller
                    name="middleName"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Middle Name"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Middle Name</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.middleName || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Last Name */}
              <Grid size={{ xs: 12, sm: 4 }}>
                {isEditMode ? (
                  <Controller
                    name="lastName"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Last Name"
                        fullWidth
                        size="small"
                        error={!!errors.lastName}
                        helperText={errors.lastName?.message}
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Last Name</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.lastName}</Typography>
                  </>
                )}
              </Grid>

              {/* Date of Birth */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="dateOfBirth"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Date of Birth"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Date of Birth</Typography>
                    <Typography variant="body1" fontWeight={500}>{formatDate(employee.dateOfBirth)}</Typography>
                  </>
                )}
              </Grid>

              {/* Gender */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="gender"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Gender"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="">Select...</MenuItem>
                        <MenuItem value="MALE">Male</MenuItem>
                        <MenuItem value="FEMALE">Female</MenuItem>
                        <MenuItem value="OTHER">Other</MenuItem>
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Gender</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.gender || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Marital Status */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="maritalStatus"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Marital Status"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="">Select...</MenuItem>
                        <MenuItem value="SINGLE">Single</MenuItem>
                        <MenuItem value="MARRIED">Married</MenuItem>
                        <MenuItem value="DIVORCED">Divorced</MenuItem>
                        <MenuItem value="WIDOWED">Widowed</MenuItem>
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Marital Status</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.maritalStatus || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* National ID */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="nationalId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="National ID"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">National ID</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.nationalId || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Personal Email */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="personalEmail"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Personal Email"
                        type="email"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Personal Email</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.personalEmail || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Mobile Phone */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="mobilePhone"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Mobile Phone"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Mobile Phone</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.mobilePhone || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Address */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="addressLine1"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Address Line 1"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Current Address</Typography>
                    <Typography variant="body1" fontWeight={500}>
                      {employee.addressLine1 || 'N/A'}
                    </Typography>
                  </>
                )}
              </Grid>

              {/* City */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="city"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="City"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">City</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.city || 'N/A'}</Typography>
                  </>
                )}
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Employment Details Tab */}
        <TabPanel value={currentTab} index={1}>
          <CardContent>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              Employment Details
            </Typography>
            <Grid container spacing={3} sx={{ mt: 1 }}>
              {/* Employee Number - Read Only */}
              <Grid size={{ xs: 12, sm: 6 }}>
                <Typography variant="caption" color="text.secondary">Employee Number</Typography>
                <Typography variant="body1" fontWeight={500}>{employee.employeeNumber}</Typography>
              </Grid>

              {/* Hire Date */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="hireDate"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Hire Date"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Hire Date</Typography>
                    <Typography variant="body1" fontWeight={500}>{formatDate(employee.hireDate)}</Typography>
                  </>
                )}
              </Grid>

              {/* Job Title */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="jobTitleId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Job Title"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="">Select...</MenuItem>
                        {jobTitles.map((title: any) => (
                          <MenuItem key={title.id} value={title.id}>
                            {title.title}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Job Title</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.jobTitleName || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Department */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="departmentId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Department"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="">Select...</MenuItem>
                        {departments.map((dept: any) => (
                          <MenuItem key={dept.id} value={dept.id}>
                            {dept.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Department</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.departmentName || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Branch */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="branchId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Branch"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="">Select...</MenuItem>
                        {branches.map((branch: any) => (
                          <MenuItem key={branch.id} value={branch.id}>
                            {branch.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Branch</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.branchName || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Employment Type */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="employmentTypeId"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Employment Type"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="">Select...</MenuItem>
                        {employmentTypes.map((type: any) => (
                          <MenuItem key={type.id} value={type.id}>
                            {type.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Employment Type</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.employmentTypeName || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Work Email */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="workEmail"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Work Email"
                        type="email"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Work Email</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.workEmail || 'N/A'}</Typography>
                  </>
                )}
              </Grid>

              {/* Probation End Date */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="probationEndDate"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Probation End Date"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                      />
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Probation End Date</Typography>
                    <Typography variant="body1" fontWeight={500}>{formatDate(employee.probationEndDate)}</Typography>
                  </>
                )}
              </Grid>

              {/* Employment Status */}
              <Grid size={{ xs: 12, sm: 6 }}>
                {isEditMode ? (
                  <Controller
                    name="employmentStatus"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Employment Status"
                        fullWidth
                        size="small"
                      >
                        <MenuItem value="ACTIVE">Active</MenuItem>
                        <MenuItem value="ON_LEAVE">On Leave</MenuItem>
                        <MenuItem value="SUSPENDED">Suspended</MenuItem>
                        <MenuItem value="TERMINATED">Terminated</MenuItem>
                      </TextField>
                    )}
                  />
                ) : (
                  <>
                    <Typography variant="caption" color="text.secondary">Employment Status</Typography>
                    <Typography variant="body1" fontWeight={500}>{employee.employmentStatus || 'N/A'}</Typography>
                  </>
                )}
              </Grid>
            </Grid>
          </CardContent>
        </TabPanel>

        {/* Salary & Benefits Tab */}
        <TabPanel value={currentTab} index={2}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6" fontWeight="bold">
                Salary & Benefits
              </Typography>
              {isEditMode && (
                <Button 
                  variant="contained" 
                  size="small"
                  onClick={handleSalarySubmit(onSalarySubmit)}
                  disabled={salaryMutation.isPending}
                >
                  {salaryMutation.isPending ? 'Saving...' : currentSalary ? 'Update Salary' : 'Create Salary'}
                </Button>
              )}
            </Box>
            
            {isEditMode ? (
              <Grid container spacing={3} sx={{ mt: 1 }}>
                {/* Basic Salary */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="basicSalary"
                    control={salaryControl}
                    rules={{ required: 'Basic salary is required', min: { value: 0, message: 'Must be positive' } }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Basic Salary"
                        type="number"
                        fullWidth
                        size="small"
                        error={!!salaryErrors.basicSalary}
                        helperText={salaryErrors.basicSalary?.message}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    )}
                  />
                </Grid>

                {/* Currency Code */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="currencyCode"
                    control={salaryControl}
                    rules={{ required: 'Currency is required' }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Currency"
                        fullWidth
                        size="small"
                        error={!!salaryErrors.currencyCode}
                        helperText={salaryErrors.currencyCode?.message}
                      >
                        <MenuItem value="">Select...</MenuItem>
                        <MenuItem value="UGX">UGX - Ugandan Shilling</MenuItem>
                        <MenuItem value="USD">USD - US Dollar</MenuItem>
                        <MenuItem value="KES">KES - Kenyan Shilling</MenuItem>
                        <MenuItem value="TZS">TZS - Tanzanian Shilling</MenuItem>
                        <MenuItem value="EUR">EUR - Euro</MenuItem>
                        <MenuItem value="GBP">GBP - British Pound</MenuItem>
                      </TextField>
                    )}
                  />
                </Grid>

                {/* Pay Frequency */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="payFrequencyId"
                    control={salaryControl}
                    rules={{ required: 'Pay frequency is required' }}
                    render={({ field: { ref, ...field } }) => (
                      <TextField
                        {...field}
                        inputRef={ref}
                        select
                        label="Pay Frequency"
                        fullWidth
                        size="small"
                        value={field.value ?? ''}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        error={!!salaryErrors.payFrequencyId}
                        helperText={salaryErrors.payFrequencyId?.message}
                      >
                        <MenuItem value="">Select...</MenuItem>
                        {payFrequencies.map((freq: any) => (
                          <MenuItem key={freq.id} value={freq.id}>
                            {freq.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                </Grid>

                {/* Effective Date */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="effectiveDate"
                    control={salaryControl}
                    rules={{ required: 'Effective date is required' }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Effective Date"
                        type="date"
                        fullWidth
                        size="small"
                        InputLabelProps={{ shrink: true }}
                        error={!!salaryErrors.effectiveDate}
                        helperText={salaryErrors.effectiveDate?.message}
                      />
                    )}
                  />
                </Grid>

                {currentSalary && (
                  <Grid size={12}>
                    <Alert severity="info" icon={false}>
                      <Typography variant="caption" display="block">Current Salary: {currentSalary.currencyCode} {currentSalary.basicSalary.toLocaleString()}</Typography>
                      <Typography variant="caption" display="block">Last Updated: {formatDate(currentSalary.effectiveDate)}</Typography>
                    </Alert>
                  </Grid>
                )}
              </Grid>
            ) : currentSalary ? (
              <Grid container spacing={3} sx={{ mt: 1 }}>
                {/* Basic Salary */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Basic Salary</Typography>
                  <Typography variant="h6" fontWeight={600} color="primary.main">
                    {currentSalary.currencyCode} {currentSalary.basicSalary.toLocaleString()}
                  </Typography>
                </Grid>

                {/* Pay Frequency */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Pay Frequency</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {payFrequencies.find(f => f.id === currentSalary.payFrequencyId)?.name || 'N/A'}
                  </Typography>
                </Grid>

                {/* Effective Date */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Effective Date</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {formatDate(currentSalary.effectiveDate)}
                  </Typography>
                </Grid>

                {/* Currency */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Currency</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {currentSalary.currencyCode}
                  </Typography>
                </Grid>

                {/* Status */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Status</Typography>
                  <Chip 
                    label={currentSalary.active ? 'Active' : 'Inactive'} 
                    color={currentSalary.active ? 'success' : 'default'}
                    size="small"
                  />
                </Grid>
              </Grid>
            ) : (
              <Alert severity="info" sx={{ mt: 2 }}>
                No salary information configured for this employee. {isEditMode && 'Click "Edit Profile" and add salary details to enable payroll processing.'}
              </Alert>
            )}
          </CardContent>
        </TabPanel>

        {/* Bank Details Tab */}
        <TabPanel value={currentTab} index={3}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6" fontWeight="bold">
                Bank Details
              </Typography>
              {isEditMode && (
                <Button 
                  variant="contained" 
                  size="small"
                  onClick={handleBankSubmit(onBankSubmit)}
                  disabled={bankMutation.isPending}
                >
                  {bankMutation.isPending ? 'Saving...' : currentBankDetails ? 'Update Bank Details' : 'Add Bank Details'}
                </Button>
              )}
            </Box>
            
            {isEditMode ? (
              <Grid container spacing={3} sx={{ mt: 1 }}>
                {/* Bank */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="bankId"
                    control={bankControl}
                    rules={{ required: 'Bank is required' }}
                    render={({ field: { onChange, value, ...field } }) => (
                      <Autocomplete
                        {...field}
                        options={banks}
                        getOptionLabel={(option) => option.name}
                        value={banks.find((bank) => bank.id === value) || null}
                        onChange={(_, newValue) => {
                          onChange(newValue?.id || undefined);
                          // Auto-fill SWIFT code when bank is selected
                          if (newValue?.swiftCode) {
                            setBankValue('swiftCode', newValue.swiftCode);
                          }
                        }}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label="Bank"
                            placeholder="Search banks..."
                            size="small"
                            error={!!bankErrors.bankId}
                            helperText={bankErrors.bankId?.message}
                          />
                        )}
                        isOptionEqualToValue={(option, value) => option.id === value.id}
                        size="small"
                      />
                    )}
                  />
                </Grid>

                {/* Bank Branch */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="bankBranchId"
                    control={bankControl}
                    render={({ field: { ref, ...field } }) => (
                      <TextField
                        {...field}
                        inputRef={ref}
                        select
                        label="Bank Branch"
                        fullWidth
                        size="small"
                        disabled={!selectedBankId}
                        value={field.value ?? ''}
                        onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                        error={!!bankErrors.bankBranchId}
                        helperText={bankErrors.bankBranchId?.message}
                      >
                        <MenuItem value="">Select...</MenuItem>
                        {bankBranches.map((branch) => (
                          <MenuItem key={branch.id} value={branch.id}>
                            {branch.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                </Grid>

                {/* Account Number */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="accountNumber"
                    control={bankControl}
                    rules={{ required: 'Account number is required' }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Account Number"
                        fullWidth
                        size="small"
                        error={!!bankErrors.accountNumber}
                        helperText={bankErrors.accountNumber?.message}
                      />
                    )}
                  />
                </Grid>

                {/* Account Name */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="accountName"
                    control={bankControl}
                    rules={{ required: 'Account name is required' }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="Account Name"
                        fullWidth
                        size="small"
                        error={!!bankErrors.accountName}
                        helperText={bankErrors.accountName?.message}
                      />
                    )}
                  />
                </Grid>

                {/* Account Type */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="accountType"
                    control={bankControl}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        select
                        label="Account Type"
                        fullWidth
                        size="small"
                        value={field.value || ''}
                      >
                        <MenuItem value="">Select...</MenuItem>
                        <MenuItem value="SAVINGS">Savings</MenuItem>
                        <MenuItem value="CURRENT">Current</MenuItem>
                        <MenuItem value="CHECKING">Checking</MenuItem>
                      </TextField>
                    )}
                  />
                </Grid>

                {/* SWIFT Code */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="swiftCode"
                    control={bankControl}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="SWIFT Code"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                </Grid>

                {/* IBAN */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Controller
                    name="iban"
                    control={bankControl}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label="IBAN"
                        fullWidth
                        size="small"
                      />
                    )}
                  />
                </Grid>

                {currentBankDetails && (
                  <Grid size={12}>
                    <Alert severity="info" icon={false}>
                      <Typography variant="caption" display="block">Current Bank: {currentBankDetails.bankName}</Typography>
                      <Typography variant="caption" display="block">Account: {currentBankDetails.accountNumber}</Typography>
                    </Alert>
                  </Grid>
                )}
              </Grid>
            ) : currentBankDetails ? (
              <Grid container spacing={3} sx={{ mt: 1 }}>
                {/* Bank Name */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Bank</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {currentBankDetails.bankName}
                  </Typography>
                </Grid>

                {/* Branch */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Branch</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {currentBankDetails.bankBranchName || 'N/A'}
                  </Typography>
                </Grid>

                {/* Account Number */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Account Number</Typography>
                  <Typography variant="h6" fontWeight={600} color="primary.main">
                    {currentBankDetails.accountNumber}
                  </Typography>
                </Grid>

                {/* Account Name */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Account Name</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {currentBankDetails.accountName}
                  </Typography>
                </Grid>

                {/* Account Type */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Account Type</Typography>
                  <Typography variant="body1" fontWeight={500}>
                    {currentBankDetails.accountType || 'N/A'}
                  </Typography>
                </Grid>

                {/* Status */}
                <Grid size={{ xs: 12, sm: 6 }}>
                  <Typography variant="caption" color="text.secondary">Status</Typography>
                  <Chip 
                    label={currentBankDetails.primary ? 'Primary' : 'Secondary'} 
                    color={currentBankDetails.primary ? 'success' : 'default'}
                    size="small"
                  />
                </Grid>
              </Grid>
            ) : (
              <Alert severity="info" sx={{ mt: 2 }}>
                No bank details configured for this employee. {isEditMode && 'Click "Edit Profile" and add bank details for salary payment.'}
              </Alert>
            )}
          </CardContent>
        </TabPanel>

        {/* Documents Tab */}
        <TabPanel value={currentTab} index={4}>
          <CardContent>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6" fontWeight="bold">
                Documents
              </Typography>
              <Button 
                variant="outlined" 
                component="label"
                startIcon={<UploadIcon />} 
                size="small"
                disabled={uploadingDocument}
              >
                {uploadingDocument ? 'Uploading...' : 'Upload Document'}
                <input
                  type="file"
                  hidden
                  onChange={handleDocumentUpload}
                  accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                />
              </Button>
            </Box>

            {documents.length > 0 ? (
              <Grid container spacing={2} sx={{ mt: 1 }}>
                {documents.map((doc) => (
                  <Grid size={{ xs: 12, sm: 6, md: 4 }} key={doc.id}>
                    <Card variant="outlined">
                      <CardContent>
                        <Stack direction="row" spacing={1} alignItems="flex-start">
                          <DocumentIcon color="action" />
                          <Box flex={1}>
                            <Typography variant="body2" fontWeight={500} noWrap>
                              {doc.documentName}
                            </Typography>
                            <Typography variant="caption" color="text.secondary">
                              {doc.documentType}
                            </Typography>
                            {doc.issueDate && (
                              <Typography variant="caption" color="text.secondary" display="block">
                                Issued: {formatDate(doc.issueDate)}
                              </Typography>
                            )}
                          </Box>
                        </Stack>
                        <Divider sx={{ my: 1 }} />
                        <Stack direction="row" spacing={1}>
                          <IconButton 
                            size="small" 
                            color="primary"
                            onClick={() => handleDocumentDownload(doc)}
                            title="Download"
                          >
                            <DownloadIcon fontSize="small" />
                          </IconButton>
                          <IconButton 
                            size="small" 
                            color="error"
                            onClick={() => handleDocumentDelete(doc.id!)}
                            title="Delete"
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Stack>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Alert severity="info" sx={{ mt: 2 }}>
                No documents uploaded yet. Click "Upload Document" to add employee documents.
              </Alert>
            )}
          </CardContent>
        </TabPanel>

        {/* History Tab */}
        <TabPanel value={currentTab} index={5}>
          <CardContent>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              Employment History
            </Typography>
            <Alert severity="info">
              Employment history and audit trail will be displayed here.
            </Alert>
          </CardContent>
        </TabPanel>
      </Card>
    </Box>
  );
};

export default EmployeeProfilePage;
