import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  TextField,
  InputAdornment,
  Paper,
  Alert,
  Chip,
  MenuItem,
  IconButton,
  Collapse,
  Stack,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  FileDownload as ExportIcon,
  FilterList as FilterIcon,
  Clear as ClearIcon,
  Visibility as ViewIcon,
  Edit as EditIcon,
} from '@mui/icons-material';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import type { GridColDef } from '@mui/x-data-grid';
import { employeesApi } from '../../api/employees.api';
import { settingsApi } from '../../api/settings.api';
import type { Employee } from '../../types/api.types';
import { useAuthStore } from '../../store/authStore';

const EmployeesPage = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter states
  const [departmentId, setDepartmentId] = useState<number | undefined>();
  const [branchId, setBranchId] = useState<number | undefined>();
  const [employmentTypeId, setEmploymentTypeId] = useState<number | undefined>();
  const [statusFilter, setStatusFilter] = useState<string | undefined>();
  const [isActiveFilter, setIsActiveFilter] = useState<boolean | undefined>();
  
  // Get organization ID from auth context
  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1; // Fallback to 1 for Platform Admin

  // Fetch filter options
  const { data: departmentsData } = useQuery({
    queryKey: ['departments', 'active', organizationId],
    queryFn: () => settingsApi.getActiveDepartments(organizationId),
  });

  const { data: branchesData } = useQuery({
    queryKey: ['branches', 'active', organizationId],
    queryFn: () => settingsApi.getActiveBranches(organizationId),
  });

  const { data: employmentTypesData } = useQuery({
    queryKey: ['employmentTypes'],
    queryFn: () => settingsApi.getEmploymentTypes(),
  });

  const departments = departmentsData?.data || [];
  const branches = branchesData?.data || [];
  const employmentTypes = employmentTypesData?.data || [];

  const { data, isLoading, error } = useQuery({
    queryKey: ['employees', organizationId, page, pageSize, search, departmentId, branchId, employmentTypeId, statusFilter, isActiveFilter],
    queryFn: () => employeesApi.searchEmployeesWithFilters(
      organizationId,
      { search, departmentId, branchId, employmentTypeId, status: statusFilter, isActive: isActiveFilter },
      page,
      pageSize
    ),
  });

  const columns: GridColDef[] = [
    {
      field: 'employeeNumber',
      headerName: 'Employee #',
      width: 120,
    },
    {
      field: 'fullName',
      headerName: 'Full Name',
      flex: 1,
      minWidth: 180,
      valueGetter: (_value, row: Employee) => `${row.firstName} ${row.lastName}`,
    },
    {
      field: 'workEmail',
      headerName: 'Email',
      flex: 1,
      minWidth: 200,
    },
    {
      field: 'jobTitleName',
      headerName: 'Job Title',
      flex: 0.8,
      minWidth: 150,
    },
    {
      field: 'departmentName',
      headerName: 'Department',
      flex: 0.7,
      minWidth: 130,
    },
    {
      field: 'hireDate',
      headerName: 'Hire Date',
      width: 120,
      valueFormatter: (value) => value ? new Date(value).toLocaleDateString() : '',
    },
    {
      field: 'employmentStatus',
      headerName: 'Status',
      width: 100,
      renderCell: (params) => {
        const isActive = params.row.active;
        return (
          <Chip
            label={isActive ? 'Active' : 'Inactive'}
            color={isActive ? 'success' : 'default'}
            size="small"
          />
        );
      },
    },
    {
      field: 'actions',
      type: 'actions',
      headerName: 'Actions',
      width: 100,
      getActions: (params) => [
        <GridActionsCellItem
          icon={<ViewIcon />}
          label="View"
          onClick={() => navigate(`/employees/${params.row.id}`)}
          showInMenu={false}
        />,
        <GridActionsCellItem
          icon={<EditIcon />}
          label="Edit"
          onClick={() => navigate(`/employees/${params.row.id}?mode=edit`)}
          showInMenu={false}
        />,
      ],
    },
  ];

  const employees = data?.data?.content || [];
  const totalElements = data?.data?.totalElements || 0;

  const handleClearFilters = () => {
    setSearch('');
    setDepartmentId(undefined);
    setBranchId(undefined);
    setEmploymentTypeId(undefined);
    setStatusFilter(undefined);
    setIsActiveFilter(undefined);
  };

  const hasActiveFilters = search || departmentId || branchId || employmentTypeId || statusFilter || isActiveFilter !== undefined;

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Employees
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage your organization's employee records
          </Typography>
        </Box>
        <Box display="flex" gap={2}>
          <Button
            variant="outlined"
            startIcon={<ExportIcon />}
            disabled={employees.length === 0}
          >
            Export
          </Button>
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => navigate('/employees/new')}
          >
            Add Employee
          </Button>
        </Box>
      </Box>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Box display="flex" gap={2} alignItems="center">
          <TextField
            fullWidth
            placeholder="Search employees by name, email, or employee number..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
          <Button
            variant="outlined"
            startIcon={<FilterIcon />}
            onClick={() => setShowFilters(!showFilters)}
            sx={{ minWidth: 120 }}
          >
            Filters
          </Button>
          {hasActiveFilters && (
            <IconButton onClick={handleClearFilters} color="primary" title="Clear all filters">
              <ClearIcon />
            </IconButton>
          )}
        </Box>

        <Collapse in={showFilters}>
          <Stack direction="row" spacing={2} sx={{ mt: 2, flexWrap: 'wrap', gap: 2 }}>
            <Box sx={{ minWidth: { xs: '100%', sm: '48%', md: '23%' } }}>
              <TextField
                select
                fullWidth
                label="Department"
                value={departmentId || ''}
                onChange={(e) => setDepartmentId(e.target.value ? Number(e.target.value) : undefined)}
                size="small"
              >
                <MenuItem value="">All Departments</MenuItem>
                {departments.map((dept) => (
                  <MenuItem key={dept.id} value={dept.id}>
                    {dept.name}
                  </MenuItem>
                ))}
              </TextField>
            </Box>

            <Box sx={{ minWidth: { xs: '100%', sm: '48%', md: '23%' } }}>
              <TextField
                select
                fullWidth
                label="Branch"
                value={branchId || ''}
                onChange={(e) => setBranchId(e.target.value ? Number(e.target.value) : undefined)}
                size="small"
              >
                <MenuItem value="">All Branches</MenuItem>
                {branches.map((branch) => (
                  <MenuItem key={branch.id} value={branch.id}>
                    {branch.name}
                  </MenuItem>
                ))}
              </TextField>
            </Box>

            <Box sx={{ minWidth: { xs: '100%', sm: '48%', md: '23%' } }}>
              <TextField
                select
                fullWidth
                label="Employment Type"
                value={employmentTypeId || ''}
                onChange={(e) => setEmploymentTypeId(e.target.value ? Number(e.target.value) : undefined)}
                size="small"
              >
                <MenuItem value="">All Types</MenuItem>
                {employmentTypes.map((type: any) => (
                  <MenuItem key={type.id} value={type.id}>
                    {type.name}
                  </MenuItem>
                ))}
              </TextField>
            </Box>

            <Box sx={{ minWidth: { xs: '100%', sm: '48%', md: '23%' } }}>
              <TextField
                select
                fullWidth
                label="Status"
                value={isActiveFilter === undefined ? '' : isActiveFilter ? 'active' : 'inactive'}
                onChange={(e) => {
                  const val = e.target.value;
                  setIsActiveFilter(val === '' ? undefined : val === 'active');
                }}
                size="small"
              >
                <MenuItem value="">All Status</MenuItem>
                <MenuItem value="active">Active</MenuItem>
                <MenuItem value="inactive">Inactive</MenuItem>
              </TextField>
            </Box>
          </Stack>
        </Collapse>
      </Paper>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Failed to load employees. Please try again.
        </Alert>
      )}

      <Paper>
        <DataGrid
          rows={employees}
          columns={columns}
          paginationMode="server"
          rowCount={totalElements}
          loading={isLoading}
          pageSizeOptions={[5, 10, 25, 50]}
          paginationModel={{ page, pageSize }}
          onPaginationModelChange={(model) => {
            setPage(model.page);
            setPageSize(model.pageSize);
          }}
          autoHeight
          onRowClick={(params) => navigate(`/employees/${params.row.id}`)}
          sx={{
            '& .MuiDataGrid-cell:focus': {
              outline: 'none',
            },
            '& .MuiDataGrid-row': {
              cursor: 'pointer',
            },
          }}
        />
      </Paper>

    </Box>
  );
};

export default EmployeesPage;
