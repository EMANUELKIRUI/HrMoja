import { useState, useEffect } from 'react';
import {
  Box,
  Button,
  TextField,
  Grid,
  MenuItem,
  Typography,
  Alert,
  Stepper,
  Step,
  StepLabel,
  Card,
  CardContent,
  InputAdornment,
  FormControlLabel,
  Switch,
  Divider,
  Paper,
  Container,
  Chip,
  Autocomplete,
} from '@mui/material';
import { ArrowBack as ArrowBackIcon } from '@mui/icons-material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { employeesApi } from '../../api/employees.api';
import { departmentsApi } from '../../api/departments.api';
import { branchesApi } from '../../api/branches.api';
import { jobTitlesApi } from '../../api/job-titles.api';
import { referenceDataApi } from '../../api/reference-data.api';
import { countriesApi } from '../../api/countries.api';
import { roleManagementApi } from '../../api/role-management.api';
import { banksApi } from '../../api/banks.api';
import type { EmployeeCreateRequest } from '../../types/api.types';
import { useAuthStore } from '../../store/authStore';
import { useToast } from '../../hooks/useToast';

const employeeSchema = z.object({
  // Personal Information
  firstName: z.string().min(1, 'First name is required'),
  middleName: z.string().optional(),
  lastName: z.string().min(1, 'Last name is required'),
  dateOfBirth: z.string().min(1, 'Date of birth is required'),
  gender: z.string().optional(),
  maritalStatus: z.string().optional(),
  nationality: z.string().optional(),
  nationalId: z.string().optional(),
  passportNumber: z.string().optional(),

  // Contact Information
  personalEmail: z.string().email('Invalid email').optional().or(z.literal('')),
  workEmail: z.string().email('Invalid email').optional().or(z.literal('')),
  mobilePhone: z.string().min(1, 'Mobile phone is required'),
  homePhone: z.string().optional(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  emergencyContactRelationship: z.string().optional(),

  // Address
  addressLine1: z.string().optional(),
  addressLine2: z.string().optional(),
  city: z.string().optional(),
  stateProvince: z.string().optional(),
  postalCode: z.string().optional(),
  countryId: z.number().optional(),

  // Employment Information
  hireDate: z.string().min(1, 'Hire date is required'),
  probationEndDate: z.string().optional(),
  employmentTypeId: z.number().min(1, 'Employment type is required'),
  jobTitleId: z.number().min(1, 'Job title is required'),
  employeeGradeId: z.number().optional(),
  branchId: z.number().optional(),
  departmentId: z.number().optional(),
  reportsToEmployeeId: z.number().optional(),

  // Salary Information
  basicSalary: z.number().min(0, 'Basic salary must be positive').optional(),
  currencyCode: z.string().optional(),
  payFrequencyId: z.number().optional(),

  // User Account
  createUserAccount: z.boolean().optional(),
  roleId: z.number().optional(),

  // Bank Details
  bankId: z.number().optional(),
  bankBranchId: z.number().optional(),
  accountNumber: z.string().optional(),
  accountName: z.string().optional(),
  accountType: z.string().optional(),
  swiftCode: z.string().optional(),
  iban: z.string().optional(),
}).refine(
  (data) => {
    // If createUserAccount is true, roleId must be provided
    if (data.createUserAccount && !data.roleId) {
      return false;
    }
    return true;
  },
  {
    message: 'Role is required when creating a user account',
    path: ['roleId'],
  }
);

type EmployeeFormData = z.infer<typeof employeeSchema>;

const steps = ['Personal Information', 'Contact & Address', 'Employment Details', 'Salary & Account', 'Bank Details', 'Review & Confirm'];

const AddEmployeePage = () => {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeStep, setActiveStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const { showToast, ToastComponent } = useToast();

  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;

  // Fetch reference data
  const { data: departmentsResponse } = useQuery({
    queryKey: ['departments', 'active', organizationId],
    queryFn: () => departmentsApi.getActiveDepartments(organizationId),
  });

  const { data: branchesResponse } = useQuery({
    queryKey: ['branches', 'active', organizationId],
    queryFn: () => branchesApi.getActiveBranches(organizationId),
  });

  const { data: jobTitlesResponse } = useQuery({
    queryKey: ['jobTitles', organizationId],
    queryFn: () => jobTitlesApi.getJobTitlesByOrganization(organizationId),
  });

  const { data: employmentTypesResponse } = useQuery({
    queryKey: ['employmentTypes'],
    queryFn: referenceDataApi.getAllEmploymentTypes,
  });

  const { data: countriesResponse } = useQuery({
    queryKey: ['countries', 'active'],
    queryFn: countriesApi.getActiveCountries,
  });

  const { data: payFrequenciesResponse } = useQuery({
    queryKey: ['payFrequencies'],
    queryFn: referenceDataApi.getAllPayFrequencies,
  });

  const { data: rolesResponse } = useQuery({
    queryKey: ['roles', 'active'],
    queryFn: roleManagementApi.getActiveRoles,
  });

  const { data: banksResponse } = useQuery({
    queryKey: ['banks', 'active'],
    queryFn: banksApi.getActiveBanks,
  });

  const departments = departmentsResponse?.data || [];
  const branches = branchesResponse?.data || [];
  const jobTitles = jobTitlesResponse?.data || [];
  const employmentTypes = employmentTypesResponse?.data || [];
  const countries = countriesResponse?.data || [];
  const payFrequencies = payFrequenciesResponse?.data || [];
  const roles = rolesResponse?.data || [];
  const banks = banksResponse?.data || [];

  const { control, handleSubmit, trigger, watch, setValue, formState: { errors, isSubmitting } } = useForm<EmployeeFormData>({
    resolver: zodResolver(employeeSchema),
    mode: 'onChange',
    shouldUnregister: false,
    defaultValues: {
      firstName: '',
      middleName: '',
      lastName: '',
      dateOfBirth: '',
      gender: '',
      maritalStatus: '',
      nationality: '',
      nationalId: '',
      passportNumber: '',
      personalEmail: '',
      workEmail: '',
      mobilePhone: '',
      homePhone: '',
      emergencyContactName: '',
      emergencyContactPhone: '',
      emergencyContactRelationship: '',
      addressLine1: '',
      addressLine2: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      countryId: countries[0]?.id || undefined,
      hireDate: '',
      probationEndDate: '',
      employmentTypeId: undefined,
      jobTitleId: undefined,
      employeeGradeId: undefined,
      branchId: undefined,
      departmentId: undefined,
      reportsToEmployeeId: undefined,
      basicSalary: undefined,
      currencyCode: 'UGX',
      payFrequencyId: undefined,
      createUserAccount: false,
      roleId: undefined,
      bankId: undefined,
      bankBranchId: undefined,
      accountNumber: '',
      accountName: '',
      accountType: '',
      swiftCode: '',
      iban: '',
    },
  });

  // Watch bank selection for branches query
  const selectedBankId = watch('bankId');
  const { data: bankBranchesResponse } = useQuery({
    queryKey: ['bankBranches', selectedBankId],
    queryFn: () => banksApi.getBankBranches(selectedBankId!),
    enabled: !!selectedBankId,
  });
  const bankBranches = bankBranchesResponse?.data || [];

  // Debug: Log form state on mount and when it changes
  useEffect(() => {
    console.log('📋 Form mounted/updated. Current values:', watch());
    console.log('📋 Form errors:', errors);
  }, [errors]);

  const createMutation = useMutation({
    mutationFn: (data: EmployeeCreateRequest) => employeesApi.createEmployee(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      showToast({ message: 'Employee created successfully!', severity: 'success' });
      navigate('/employees');
    },
    onError: (err: any) => {
      const message = err.response?.data?.message || err.message || 'Failed to create employee';
      setError(message);
      showToast({ message, severity: 'error' });
    },
  });

  const handleNext = async (e?: React.MouseEvent) => {
    // Prevent any default behavior
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    console.log('🔄 handleNext called - Current step:', activeStep);
    
    let fieldsToValidate: (keyof EmployeeFormData)[] = [];

    if (activeStep === 0) {
      fieldsToValidate = ['firstName', 'lastName', 'dateOfBirth'];
    } else if (activeStep === 1) {
      fieldsToValidate = ['mobilePhone'];
    } else if (activeStep === 2) {
      fieldsToValidate = ['hireDate', 'employmentTypeId', 'jobTitleId'];
    } else if (activeStep === 3) {
      // Validate roleId if user account creation is enabled
      if (watch('createUserAccount')) {
        fieldsToValidate = ['roleId'];
      } else {
        fieldsToValidate = [];
      }
    } else if (activeStep === 4) {
      fieldsToValidate = [];
    }

    console.log('🔍 Fields to validate:', fieldsToValidate);
    const isValid = await trigger(fieldsToValidate.length > 0 ? fieldsToValidate : undefined);
    console.log('✅ Validation result:', isValid);
    
    if (isValid) {
      const nextStep = activeStep + 1;
      console.log('➡️ Moving to step:', nextStep);
      setActiveStep(nextStep);
      setError(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const onSubmit = async (data: EmployeeFormData) => {
    console.log('===== FORM SUBMIT TRIGGERED =====');
    console.log('Form data received:', data);
    
    // Validate all fields before submission
    const isValid = await trigger();
    console.log('Form validation result:', isValid);

    if (!isValid) {
      const formErrors = Object.keys(errors).length > 0 ? errors : 'Unknown validation error';
      console.error('Form validation failed:', formErrors);
      setError('Please check all required fields. If creating a user account, a role must be selected.');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    // Additional check for user account creation
    if (data.createUserAccount && !data.roleId) {
      console.error('Role is required but not provided');
      setError('Please select a role when creating a user account');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const request: EmployeeCreateRequest = {
      ...data,
      organizationId,
    };

    console.log('✅ Submitting employee data to API:', request);
    console.log('Organization ID:', organizationId);
    setError(null);
    createMutation.mutate(request);
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Basic personal information about the employee
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 4 }}>
              <Controller
                name="firstName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="First Name"
                    fullWidth
                    required
                    error={!!errors.firstName}
                    helperText={errors.firstName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 4 }}>
              <Controller
                name="middleName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Middle Name"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 4 }}>
              <Controller
                name="lastName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Last Name"
                    fullWidth
                    required
                    error={!!errors.lastName}
                    helperText={errors.lastName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="dateOfBirth"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Date of Birth"
                    type="date"
                    fullWidth
                    required
                    error={!!errors.dateOfBirth}
                    helperText={errors.dateOfBirth?.message}
                    InputLabelProps={{ shrink: true }}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="gender"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="Gender"
                    fullWidth
                    value={field.value || ''}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    <MenuItem value="MALE">Male</MenuItem>
                    <MenuItem value="FEMALE">Female</MenuItem>
                    <MenuItem value="OTHER">Other</MenuItem>
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="maritalStatus"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="Marital Status"
                    fullWidth
                    value={field.value || ''}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    <MenuItem value="SINGLE">Single</MenuItem>
                    <MenuItem value="MARRIED">Married</MenuItem>
                    <MenuItem value="DIVORCED">Divorced</MenuItem>
                    <MenuItem value="WIDOWED">Widowed</MenuItem>
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="nationality"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Nationality"
                    fullWidth
                    placeholder="e.g., Ugandan, Kenyan, etc."
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="nationalId"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="National ID"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="passportNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Passport Number"
                    fullWidth
                  />
                )}
              />
            </Grid>
          </Grid>
        );

      case 1:
        return (
          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                Contact Information
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="mobilePhone"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Mobile Phone"
                    fullWidth
                    required
                    error={!!errors.mobilePhone}
                    helperText={errors.mobilePhone?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="personalEmail"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Personal Email"
                    type="email"
                    fullWidth
                    error={!!errors.personalEmail}
                    helperText={errors.personalEmail?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="workEmail"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Work Email"
                    type="email"
                    fullWidth
                    error={!!errors.workEmail}
                    helperText={errors.workEmail?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="homePhone"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Home Phone"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                Emergency Contact
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="emergencyContactName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Emergency Contact Name"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="emergencyContactPhone"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Emergency Contact Phone"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="emergencyContactRelationship"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Relationship"
                    fullWidth
                    placeholder="e.g., Spouse, Parent, Sibling"
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                Address
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="addressLine1"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Address Line 1"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="addressLine2"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Address Line 2"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="city"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="City"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="stateProvince"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="State/Province"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="postalCode"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Postal Code"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="countryId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Country"
                    fullWidth
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    {countries.map((country) => (
                      <MenuItem key={country.id} value={country.id}>
                        {country.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>
          </Grid>
        );

      case 2:
        return (
          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Employment and job details
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="hireDate"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Hire Date"
                    type="date"
                    fullWidth
                    required
                    error={!!errors.hireDate}
                    helperText={errors.hireDate?.message}
                    InputLabelProps={{ shrink: true }}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="employmentTypeId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Employment Type"
                    fullWidth
                    required
                    error={!!errors.employmentTypeId}
                    helperText={errors.employmentTypeId?.message}
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    {employmentTypes.map((type) => (
                      <MenuItem key={type.id} value={type.id}>
                        {type.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="jobTitleId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Job Title"
                    fullWidth
                    required
                    error={!!errors.jobTitleId}
                    helperText={errors.jobTitleId?.message}
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    {jobTitles.map((title) => (
                      <MenuItem key={title.id} value={title.id}>
                        {title.title}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="branchId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Branch"
                    fullWidth
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    {branches.map((branch) => (
                      <MenuItem key={branch.id} value={branch.id}>
                        {branch.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="departmentId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Department"
                    fullWidth
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    {departments.map((dept) => (
                      <MenuItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>
          </Grid>
        );

      case 3:
        return (
          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Salary and compensation details (optional - can be added later)
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="basicSalary"
                control={control}
                render={({ field: { ref, value, onChange, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    label="Basic Salary"
                    type="number"
                    fullWidth
                    InputProps={{
                      startAdornment: <InputAdornment position="start">UGX</InputAdornment>,
                    }}
                    value={value ?? ''}
                    onChange={(e) => onChange(e.target.value ? Number(e.target.value) : undefined)}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="payFrequencyId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Pay Frequency"
                    fullWidth
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    {payFrequencies.map((freq) => (
                      <MenuItem key={freq.id} value={freq.id}>
                        {freq.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={12}>
              <Divider sx={{ my: 2 }} />
              <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                User Account Creation
              </Typography>
              <Controller
                name="createUserAccount"
                control={control}
                render={({ field }) => (
                  <FormControlLabel
                    control={
                      <Switch
                        checked={field.value || false}
                        onChange={(e) => field.onChange(e.target.checked)}
                        onBlur={field.onBlur}
                        color="primary"
                        name="createUserAccount"
                        id="createUserAccount"
                        inputRef={field.ref}
                      />
                    }
                    label={
                      <Box>
                        <Typography variant="body2" fontWeight={500}>
                          Create User Account
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Allow this employee to log in to the system.
                        </Typography>
                      </Box>
                    }
                  />
                )}
              />
            </Grid>

            {watch('createUserAccount') && (
              <Grid size={{ xs: 12, sm: 6 }}>
                <Controller
                  name="roleId"
                  control={control}
                  render={({ field: { ref, ...field } }) => (
                    <TextField
                      {...field}
                      inputRef={ref}
                      select
                      label="User Role"
                      fullWidth
                      required
                      error={!!errors.roleId}
                      helperText={errors.roleId?.message || 'Select the role for this user account'}
                      value={field.value ?? ''}
                      onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                    >
                      <MenuItem value="">Select Role...</MenuItem>
                      {roles.map((role) => (
                        <MenuItem key={role.id} value={role.id}>
                          {role.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Grid>
            )}
          </Grid>
        );

      case 4:
        return (
          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Bank account details for salary payment (optional - can be added later)
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="bankId"
                control={control}
                render={({ field: { onChange, value, ...field } }) => (
                  <Autocomplete
                    {...field}
                    options={banks}
                    getOptionLabel={(option) => option.name}
                    value={banks.find((bank) => bank.id === value) || null}
                    onChange={(_, newValue) => {
                      onChange(newValue?.id || undefined);
                      // Auto-fill SWIFT code when bank is selected
                      if (newValue?.swiftCode) {
                        setValue('swiftCode', newValue.swiftCode);
                      }
                    }}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Bank"
                        placeholder="Search banks..."
                        error={!!errors.bankId}
                        helperText={errors.bankId?.message}
                      />
                    )}
                    isOptionEqualToValue={(option, value) => option.id === value.id}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="bankBranchId"
                control={control}
                render={({ field: { ref, ...field } }) => (
                  <TextField
                    {...field}
                    inputRef={ref}
                    select
                    label="Bank Branch"
                    fullWidth
                    disabled={!selectedBankId}
                    value={field.value ?? ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">Select Branch...</MenuItem>
                    {bankBranches.map((branch) => (
                      <MenuItem key={branch.id} value={branch.id}>
                        {branch.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="accountNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Account Number"
                    fullWidth
                    error={!!errors.accountNumber}
                    helperText={errors.accountNumber?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="accountName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Account Name"
                    fullWidth
                    error={!!errors.accountName}
                    helperText={errors.accountName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="accountType"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="Account Type"
                    fullWidth
                    value={field.value || ''}
                  >
                    <MenuItem value="">Select...</MenuItem>
                    <MenuItem value="SAVINGS">Savings</MenuItem>
                    <MenuItem value="CURRENT">Current</MenuItem>
                    <MenuItem value="CHECKING">Checking</MenuItem>
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="swiftCode"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="SWIFT Code"
                    fullWidth
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="iban"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="IBAN"
                    fullWidth
                  />
                )}
              />
            </Grid>
          </Grid>
        );

      case 5:
        // Get all form values for review
        const formValues = watch();
        console.log('📊 Review Step - All Form Values:', formValues);
        
        return (
          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Review Employee Information
              </Typography>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Please review all information before creating the employee record.
              </Typography>
            </Grid>

            {/* Personal Information */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom sx={{ mt: 2 }}>
                Personal Information
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Full Name</Typography>
              <Typography variant="body1">
                {[formValues.firstName, formValues.middleName, formValues.lastName].filter(Boolean).join(' ') || 'Not provided'}
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Date of Birth</Typography>
              <Typography variant="body1">{formValues.dateOfBirth || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Gender</Typography>
              <Typography variant="body1">{formValues.gender || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Marital Status</Typography>
              <Typography variant="body1">{formValues.maritalStatus || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Nationality</Typography>
              <Typography variant="body1">{formValues.nationality || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">National ID</Typography>
              <Typography variant="body1">{formValues.nationalId || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Passport Number</Typography>
              <Typography variant="body1">{formValues.passportNumber || 'Not provided'}</Typography>
            </Grid>

            {/* Contact Information */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom sx={{ mt: 2 }}>
                Contact Information
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Mobile Phone</Typography>
              <Typography variant="body1">{formValues.mobilePhone || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Home Phone</Typography>
              <Typography variant="body1">{formValues.homePhone || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Personal Email</Typography>
              <Typography variant="body1">{formValues.personalEmail || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Work Email</Typography>
              <Typography variant="body1">{formValues.workEmail || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Emergency Contact Name</Typography>
              <Typography variant="body1">{formValues.emergencyContactName || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Emergency Contact Phone</Typography>
              <Typography variant="body1">{formValues.emergencyContactPhone || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Emergency Contact Relationship</Typography>
              <Typography variant="body1">{formValues.emergencyContactRelationship || 'Not provided'}</Typography>
            </Grid>

            {/* Address Information */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom sx={{ mt: 2 }}>
                Address Information
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Address Line 1</Typography>
              <Typography variant="body1">{formValues.addressLine1 || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Address Line 2</Typography>
              <Typography variant="body1">{formValues.addressLine2 || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">City</Typography>
              <Typography variant="body1">{formValues.city || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">State/Province</Typography>
              <Typography variant="body1">{formValues.stateProvince || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Postal Code</Typography>
              <Typography variant="body1">{formValues.postalCode || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Country</Typography>
              <Typography variant="body1">
                {countries.find(c => c.id === formValues.countryId)?.name || 'Not provided'}
              </Typography>
            </Grid>

            {/* Employment Details */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom sx={{ mt: 2 }}>
                Employment Details
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Hire Date</Typography>
              <Typography variant="body1">{formValues.hireDate || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Probation End Date</Typography>
              <Typography variant="body1">{formValues.probationEndDate || 'Not provided'}</Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Employment Type</Typography>
              <Typography variant="body1">
                {employmentTypes.find(t => t.id === formValues.employmentTypeId)?.name || 'Not selected'}
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Job Title</Typography>
              <Typography variant="body1">
                {jobTitles.find(t => t.id === formValues.jobTitleId)?.title || 'Not selected'}
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Department</Typography>
              <Typography variant="body1">
                {departments.find(d => d.id === formValues.departmentId)?.name || 'Not selected'}
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Branch</Typography>
              <Typography variant="body1">
                {branches.find(b => b.id === formValues.branchId)?.name || 'Not selected'}
              </Typography>
            </Grid>

            {/* Salary & Account */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight={600} gutterBottom sx={{ mt: 2 }}>
                Salary & Account
              </Typography>
              <Divider />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Basic Salary</Typography>
              <Typography variant="body1">
                {formValues.basicSalary ? `${formValues.currencyCode || 'UGX'} ${formValues.basicSalary?.toLocaleString()}` : 'Not provided'}
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Pay Frequency</Typography>
              <Typography variant="body1">
                {payFrequencies.find(f => f.id === formValues.payFrequencyId)?.name || 'Not provided'}
              </Typography>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Typography variant="caption" color="text.secondary" display="block">Create User Account</Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
                {formValues.createUserAccount ? (
                  <Chip label="Yes" color="success" size="small" />
                ) : (
                  <Chip label="No" size="small" />
                )}
              </Box>
            </Grid>
            {formValues.createUserAccount && (
              <Grid size={{ xs: 12, sm: 6 }}>
                <Typography variant="caption" color="text.secondary" display="block">User Role</Typography>
                <Typography variant="body1">
                  {roles.find(r => r.id === formValues.roleId)?.name || 'Not selected'}
                </Typography>
              </Grid>
            )}

            <Grid size={12}>
              <Alert severity="info" sx={{ mt: 2 }}>
                <Typography variant="body2">
                  <strong>Ready to submit!</strong> Please review all the information above and click "Create Employee" to save this employee record.
                </Typography>
              </Alert>
            </Grid>
          </Grid>
        );

      default:
        return null;
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <ToastComponent />
      
      <Box display="flex" alignItems="center" gap={2} mb={3}>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/employees')}>
          Back to Employees
        </Button>
      </Box>

      <Card>
        <CardContent sx={{ p: 4 }}>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Add New Employee
          </Typography>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Complete all steps to create a new employee record
          </Typography>

          <Box sx={{ mt: 4, mb: 4 }}>
            <Stepper activeStep={activeStep}>
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>{label}</StepLabel>
                </Step>
              ))}
            </Stepper>
          </Box>

          <form 
            onSubmit={handleSubmit(onSubmit)}
            onKeyDown={(e) => {
              // Prevent Enter key from submitting form unless on final step
              if (e.key === 'Enter' && activeStep < steps.length - 1) {
                e.preventDefault();
                console.log('⚠️ Enter key pressed - form submission prevented (not on final step)');
              }
            }}
          >
            <Paper elevation={0} sx={{ p: 3, bgcolor: 'grey.50', minHeight: 400 }}>
              {error && (
                <Alert severity="error" sx={{ mb: 3 }}>
                  {error}
                </Alert>
              )}

              {/* Render all steps but hide inactive ones to preserve form state */}
              <Box sx={{ display: activeStep === 0 ? 'block' : 'none' }}>
                {renderStepContent(0)}
              </Box>
              <Box sx={{ display: activeStep === 1 ? 'block' : 'none' }}>
                {renderStepContent(1)}
              </Box>
              <Box sx={{ display: activeStep === 2 ? 'block' : 'none' }}>
                {renderStepContent(2)}
              </Box>
              <Box sx={{ display: activeStep === 3 ? 'block' : 'none' }}>
                {renderStepContent(3)}
              </Box>
              <Box sx={{ display: activeStep === 4 ? 'block' : 'none' }}>
                {renderStepContent(4)}
              </Box>
              <Box sx={{ display: activeStep === 5 ? 'block' : 'none' }}>
                {renderStepContent(5)}
              </Box>
            </Paper>

            <Box display="flex" justifyContent="space-between" sx={{ mt: 3 }}>
              <Button
                type="button"
                disabled={activeStep === 0}
                onClick={handleBack}
                size="large"
              >
                Back
              </Button>
              <Box display="flex" gap={2}>
                <Button
                  type="button"
                  variant="outlined"
                  onClick={() => navigate('/employees')}
                  size="large"
                >
                  Cancel
                </Button>
                {activeStep < steps.length - 1 ? (
                  <Button 
                    type="button" 
                    variant="contained" 
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      handleNext(e);
                    }} 
                    size="large"
                  >
                    Next
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    variant="contained"
                    disabled={isSubmitting}
                    size="large"
                    onClick={() => {
                      console.log('🔵 Create Employee button clicked! Active step:', activeStep);
                      console.log('Form errors:', errors);
                      console.log('Form values:', watch());
                      console.log('Is form valid?', Object.keys(errors).length === 0);
                    }}
                  >
                    {isSubmitting ? 'Creating...' : 'Create Employee'}
                  </Button>
                )}
              </Box>
            </Box>
          </form>
        </CardContent>
      </Card>
    </Container>
  );
};

export default AddEmployeePage;
