import { useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  MenuItem,
  Box,
  Typography,
  Alert,
  CircularProgress,
} from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { employeeSalaryApi } from '../../../api/employee-salary.api';
import { referenceDataApi } from '../../../api/reference-data.api';
import { useToast } from '../../../hooks/useToast';
import type { Employee, EmployeeSalaryStructure, PayFrequency, PaymentMethod } from '../../../types/api.types';

const salarySchema = z.object({
  basicSalary: z.number().min(0, 'Basic salary must be positive'),
  currencyCode: z.string().min(1, 'Currency is required'),
  payFrequencyId: z.number().min(1, 'Pay frequency is required'),
  paymentMethodId: z.number().optional(),
  effectiveDate: z.string().min(1, 'Effective date is required'),
  endDate: z.string().optional(),
});

type SalaryFormData = z.infer<typeof salarySchema>;

interface Props {
  open: boolean;
  onClose: () => void;
  employee: Employee;
  existingSalary?: EmployeeSalaryStructure | null;
}

const SalaryStructureDialog = ({ open, onClose, employee, existingSalary }: Props) => {
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const isEditing = !!existingSalary?.id;

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<SalaryFormData>({
    resolver: zodResolver(salarySchema),
    defaultValues: {
      basicSalary: 0,
      currencyCode: 'UGX',
      payFrequencyId: 1,
      paymentMethodId: undefined,
      effectiveDate: new Date().toISOString().split('T')[0],
      endDate: '',
    },
  });

  // Fetch pay frequencies
  const { data: frequenciesData, isLoading: frequenciesLoading } = useQuery({
    queryKey: ['payFrequencies'],
    queryFn: () => referenceDataApi.getAllPayFrequencies(),
  });

  // Fetch payment methods
  const { data: paymentMethodsData, isLoading: paymentMethodsLoading } = useQuery({
    queryKey: ['paymentMethods'],
    queryFn: () => referenceDataApi.getAllPaymentMethods(),
  });

  const payFrequencies = (frequenciesData?.data || []) as PayFrequency[];
  const paymentMethods = (paymentMethodsData?.data || []) as PaymentMethod[];

  // Reset form when dialog opens with existing data
  useEffect(() => {
    if (open && existingSalary) {
      reset({
        basicSalary: existingSalary.basicSalary,
        currencyCode: existingSalary.currencyCode,
        payFrequencyId: existingSalary.payFrequencyId,
        paymentMethodId: existingSalary.paymentMethodId || undefined,
        effectiveDate: existingSalary.effectiveDate,
        endDate: existingSalary.endDate || '',
      });
    } else if (open && !existingSalary) {
      reset({
        basicSalary: 0,
        currencyCode: 'UGX',
        payFrequencyId: 1,
        paymentMethodId: undefined,
        effectiveDate: new Date().toISOString().split('T')[0],
        endDate: '',
      });
    }
  }, [open, existingSalary, reset]);

  // Create salary mutation
  const createMutation = useMutation({
    mutationFn: (data: EmployeeSalaryStructure) => employeeSalaryApi.createSalary(data),
    onSuccess: () => {
      showToast({ message: 'Salary structure created successfully', severity: 'success' });
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      queryClient.invalidateQueries({ queryKey: ['employeeSalary', employee.id] });
      onClose();
    },
    onError: (error: any) => {
      showToast({ message: error.response?.data?.message || 'Failed to create salary structure', severity: 'error' });
    },
  });

  // Update salary mutation
  const updateMutation = useMutation({
    mutationFn: ({ employeeId, salaryId, data }: { employeeId: number; salaryId: number; data: Partial<EmployeeSalaryStructure> }) =>
      employeeSalaryApi.updateSalary(employeeId, salaryId, data),
    onSuccess: () => {
      showToast({ message: 'Salary structure updated successfully', severity: 'success' });
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      queryClient.invalidateQueries({ queryKey: ['employeeSalary', employee.id] });
      onClose();
    },
    onError: (error: any) => {
      showToast({ message: error.response?.data?.message || 'Failed to update salary structure', severity: 'error' });
    },
  });

  const onSubmit = async (data: SalaryFormData) => {
    const salaryData: EmployeeSalaryStructure = {
      ...data,
      employeeId: employee.id!,
      endDate: data.endDate || undefined,
    };

    if (isEditing && existingSalary?.id) {
      updateMutation.mutate({
        employeeId: employee.id!,
        salaryId: existingSalary.id,
        data: salaryData,
      });
    } else {
      createMutation.mutate(salaryData);
    }
  };

  const handleClose = () => {
    if (!isSubmitting) {
      reset();
      onClose();
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box>
          <Typography variant="h6">
            {isEditing ? 'Edit Salary Structure' : 'Create Salary Structure'}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {employee.firstName} {employee.lastName} ({employee.employeeNumber})
          </Typography>
        </Box>
      </DialogTitle>

      <form onSubmit={handleSubmit(onSubmit)}>
        <DialogContent dividers>
          {(frequenciesLoading || paymentMethodsLoading) ? (
            <Box display="flex" justifyContent="center" py={4}>
              <CircularProgress />
            </Box>
          ) : (
            <Grid container spacing={3}>
              <Grid size={12}>
                <Alert severity="info">
                  Create a new salary structure for this employee. The effective date determines when this salary becomes active.
                </Alert>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="basicSalary"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Basic Salary"
                      type="number"
                      fullWidth
                      required
                      error={!!errors.basicSalary}
                      helperText={errors.basicSalary?.message}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      InputProps={{
                        inputProps: { min: 0, step: 1000 }
                      }}
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="currencyCode"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Currency"
                      fullWidth
                      required
                      select
                      error={!!errors.currencyCode}
                      helperText={errors.currencyCode?.message}
                    >
                      <MenuItem value="UGX">UGX - Ugandan Shilling</MenuItem>
                      <MenuItem value="KES">KES - Kenyan Shilling</MenuItem>
                      <MenuItem value="ZMW">ZMW - Zambian Kwacha</MenuItem>
                      <MenuItem value="USD">USD - US Dollar</MenuItem>
                    </TextField>
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="payFrequencyId"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Pay Frequency"
                      fullWidth
                      required
                      select
                      error={!!errors.payFrequencyId}
                      helperText={errors.payFrequencyId?.message}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                    >
                      {payFrequencies.map((freq) => (
                        <MenuItem key={freq.id} value={freq.id}>
                          {freq.name} ({freq.periodsPerYear} per year)
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="paymentMethodId"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Payment Method"
                      fullWidth
                      select
                      error={!!errors.paymentMethodId}
                      helperText={errors.paymentMethodId?.message}
                      onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                      value={field.value || ''}
                    >
                      <MenuItem value="">
                        <em>Not specified</em>
                      </MenuItem>
                      {paymentMethods.map((method) => (
                        <MenuItem key={method.id} value={method.id}>
                          {method.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="effectiveDate"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Effective Date"
                      type="date"
                      fullWidth
                      required
                      error={!!errors.effectiveDate}
                      helperText={errors.effectiveDate?.message}
                      InputLabelProps={{ shrink: true }}
                    />
                  )}
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }}>
                <Controller
                  name="endDate"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="End Date (Optional)"
                      type="date"
                      fullWidth
                      error={!!errors.endDate}
                      helperText={errors.endDate?.message || 'Leave blank if ongoing'}
                      InputLabelProps={{ shrink: true }}
                    />
                  )}
                />
              </Grid>
            </Grid>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={handleClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button
            type="submit"
            variant="contained"
            disabled={isSubmitting || frequenciesLoading || paymentMethodsLoading}
          >
            {isSubmitting ? <CircularProgress size={24} /> : isEditing ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default SalaryStructureDialog;
