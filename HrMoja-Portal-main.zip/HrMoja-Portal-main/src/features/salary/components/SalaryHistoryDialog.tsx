import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Paper,
  Chip,
  CircularProgress,
  Alert,
  IconButton,
  Tooltip,
  Stack,
  Divider,
} from '@mui/material';
import {
  CheckCircle as ActiveIcon,
  Cancel as InactiveIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';
import { employeeSalaryApi } from '../../../api/employee-salary.api';
import { useToast } from '../../../hooks/useToast';
import type { Employee, EmployeeSalaryStructure } from '../../../types/api.types';

interface Props {
  open: boolean;
  onClose: () => void;
  employee: Employee;
}

const SalaryHistoryDialog = ({ open, onClose, employee }: Props) => {
  const queryClient = useQueryClient();
  const { showToast } = useToast();
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Fetch salary history
  const { data: historyData, isLoading, error } = useQuery({
    queryKey: ['employeeSalary', employee.id, 'history'],
    queryFn: () => employeeSalaryApi.getSalaryHistory(employee.id!),
    enabled: open && !!employee.id,
  });

  const salaryHistory = (historyData?.data || []) as EmployeeSalaryStructure[];

  // Delete salary mutation
  const deleteMutation = useMutation({
    mutationFn: (salaryId: number) => employeeSalaryApi.deactivateSalary(employee.id!, salaryId),
    onSuccess: () => {
      showToast({ message: 'Salary structure deactivated successfully', severity: 'success' });
      queryClient.invalidateQueries({ queryKey: ['employeeSalary', employee.id] });
      setDeletingId(null);
    },
    onError: (error: any) => {
      showToast({ message: error.response?.data?.message || 'Failed to deactivate salary structure', severity: 'error' });
      setDeletingId(null);
    },
  });

  const handleDeactivate = (salaryId: number) => {
    if (window.confirm('Are you sure you want to deactivate this salary structure?')) {
      setDeletingId(salaryId);
      deleteMutation.mutate(salaryId);
    }
  };

  const formatCurrency = (amount: number, currencyCode: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode,
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box>
          <Typography variant="h6">Salary History</Typography>
          <Typography variant="body2" color="text.secondary">
            {employee.firstName} {employee.lastName} ({employee.employeeNumber})
          </Typography>
        </Box>
      </DialogTitle>

      <DialogContent dividers>
        {isLoading ? (
          <Box display="flex" justifyContent="center" py={4}>
            <CircularProgress />
          </Box>
        ) : error ? (
          <Alert severity="error">
            Failed to load salary history. Please try again.
          </Alert>
        ) : salaryHistory.length === 0 ? (
          <Box textAlign="center" py={4}>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No Salary History
            </Typography>
            <Typography variant="body2" color="text.secondary">
              This employee doesn't have any salary records yet.
            </Typography>
          </Box>
        ) : (
          <Stack spacing={2}>
            {salaryHistory.map((salary) => (
              <Paper key={salary.id} elevation={2} sx={{ p: 3 }}>
                <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
                  <Box>
                    <Typography variant="h5" color="primary" fontWeight="bold">
                      {formatCurrency(salary.basicSalary, salary.currencyCode)}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      Basic Salary
                    </Typography>
                  </Box>
                  <Box display="flex" gap={1} alignItems="center">
                    <Chip
                      icon={salary.active ? <ActiveIcon /> : <InactiveIcon />}
                      label={salary.active ? 'Active' : 'Inactive'}
                      color={salary.active ? 'success' : 'default'}
                      size="small"
                    />
                    {salary.active && (
                      <Tooltip title="Deactivate Salary">
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => handleDeactivate(salary.id!)}
                          disabled={deletingId === salary.id}
                        >
                          {deletingId === salary.id ? (
                            <CircularProgress size={20} />
                          ) : (
                            <DeleteIcon fontSize="small" />
                          )}
                        </IconButton>
                      </Tooltip>
                    )}
                  </Box>
                </Box>

                <Divider sx={{ my: 2 }} />

                <Box display="grid" gridTemplateColumns="repeat(2, 1fr)" gap={2}>
                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block">
                      Effective Date
                    </Typography>
                    <Typography variant="body2" fontWeight="medium">
                      {formatDate(salary.effectiveDate)}
                    </Typography>
                  </Box>

                  {salary.endDate && (
                    <Box>
                      <Typography variant="caption" color="text.secondary" display="block">
                        End Date
                      </Typography>
                      <Typography variant="body2" fontWeight="medium">
                        {formatDate(salary.endDate)}
                      </Typography>
                    </Box>
                  )}

                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block">
                      Pay Frequency
                    </Typography>
                    <Typography variant="body2" fontWeight="medium">
                      {salary.payFrequencyName || 'Not specified'}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block">
                      Payment Method
                    </Typography>
                    <Typography variant="body2" fontWeight="medium">
                      {salary.paymentMethodName || 'Not specified'}
                    </Typography>
                  </Box>

                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block">
                      Created
                    </Typography>
                    <Typography variant="body2" fontWeight="medium">
                      {salary.createdAt ? formatDate(salary.createdAt) : 'N/A'}
                    </Typography>
                  </Box>

                  {salary.updatedAt && salary.updatedAt !== salary.createdAt && (
                    <Box>
                      <Typography variant="caption" color="text.secondary" display="block">
                        Last Updated
                      </Typography>
                      <Typography variant="body2" fontWeight="medium">
                        {formatDate(salary.updatedAt)}
                      </Typography>
                    </Box>
                  )}
                </Box>
              </Paper>
            ))}
          </Stack>
        )}
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
};

export default SalaryHistoryDialog;
