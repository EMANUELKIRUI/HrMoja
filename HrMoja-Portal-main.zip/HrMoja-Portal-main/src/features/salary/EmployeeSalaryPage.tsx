import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Alert,
  IconButton,
  Tooltip,
  InputAdornment,
  TextField,
  TablePagination,
} from '@mui/material';
import {
  Add as AddIcon,
  History as HistoryIcon,
  Edit as EditIcon,
  Search as SearchIcon,
  AttachMoney as MoneyIcon,
} from '@mui/icons-material';
import { employeesApi } from '../../api/employees.api';
import { employeeSalaryApi } from '../../api/employee-salary.api';
import { useAuthStore } from '../../store/authStore';
import type { Employee, EmployeeSalaryStructure } from '../../types/api.types';
import SalaryStructureDialog from './components/SalaryStructureDialog';
import SalaryHistoryDialog from './components/SalaryHistoryDialog';

const EmployeeSalaryPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [salaryDialogOpen, setSalaryDialogOpen] = useState(false);
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false);
  const [editingSalary, setEditingSalary] = useState<EmployeeSalaryStructure | null>(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  const user = useAuthStore((state) => state.user);
  const organizationId = user?.organizationId || 1;

  // Fetch paginated employees
  const { data: employeesData, isLoading: employeesLoading, error: employeesError } = useQuery({
    queryKey: ['employees', organizationId, page, rowsPerPage, searchTerm],
    queryFn: () => employeesApi.getEmployeesByOrganization(organizationId, page, rowsPerPage, searchTerm || undefined),
  });

  const employees = Array.isArray(employeesData?.data?.content) ? employeesData.data.content : [];
  const totalElements = employeesData?.data?.totalElements || 0;

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleCreateSalary = (employee: Employee) => {
    setSelectedEmployee(employee);
    setEditingSalary(null);
    setSalaryDialogOpen(true);
  };

  const handleEditSalary = async (employee: Employee) => {
    setSelectedEmployee(employee);
    try {
      const response = await employeeSalaryApi.getCurrentSalary(employee.id!);
      setEditingSalary(response.data);
      setSalaryDialogOpen(true);
    } catch (error) {
      console.error('Failed to fetch current salary', error);
    }
  };

  const handleViewHistory = (employee: Employee) => {
    setSelectedEmployee(employee);
    setHistoryDialogOpen(true);
  };

  const handleCloseSalaryDialog = () => {
    setSalaryDialogOpen(false);
    setSelectedEmployee(null);
    setEditingSalary(null);
  };

  const handleCloseHistoryDialog = () => {
    setHistoryDialogOpen(false);
    setSelectedEmployee(null);
  };


  if (employeesLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (employeesError) {
    return (
      <Alert severity="error">
        Failed to load employees. Please try again.
      </Alert>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Employee Salary Management
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage employee salary structures and view salary history
          </Typography>
        </Box>
      </Box>

      {/* Search Bar */}
      <Box mb={3}>
        <TextField
          fullWidth
          placeholder="Search by name, employee number, or email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>

      {/* Statistics Cards */}
      <Box display="grid" gridTemplateColumns={{ xs: '1fr', md: 'repeat(3, 1fr)' }} gap={2} mb={3}>
        <Paper sx={{ p: 2 }}>
          <Box display="flex" alignItems="center" gap={2}>
            <Box
              sx={{
                bgcolor: 'primary.main',
                color: 'white',
                p: 1.5,
                borderRadius: 2,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <MoneyIcon />
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">
                Total Employees
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {totalElements}
              </Typography>
            </Box>
          </Box>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Box display="flex" alignItems="center" gap={2}>
            <Box
              sx={{
                bgcolor: 'success.main',
                color: 'white',
                p: 1.5,
                borderRadius: 2,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <AddIcon />
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">
                Active
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {employees.filter(e => e.active).length}
              </Typography>
            </Box>
          </Box>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Box display="flex" alignItems="center" gap={2}>
            <Box
              sx={{
                bgcolor: 'warning.main',
                color: 'white',
                p: 1.5,
                borderRadius: 2,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <HistoryIcon />
            </Box>
            <Box>
              <Typography variant="body2" color="text.secondary">
                Departments
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {new Set(employees.map(e => e.departmentId).filter(Boolean)).size}
              </Typography>
            </Box>
          </Box>
        </Paper>
      </Box>

      {/* Employees Table */}
      {employees.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No Employees Found
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {searchTerm ? 'Try adjusting your search criteria' : 'No employees available'}
          </Typography>
        </Paper>
      ) : (
        <Paper>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Employee #</TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Department</TableCell>
                  <TableCell>Job Title</TableCell>
                  <TableCell>Employment Type</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {employees.map((employee) => (
                <TableRow key={employee.id} hover>
                  <TableCell>
                    <Typography fontWeight="medium">
                      {employee.employeeNumber}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box>
                      <Typography fontWeight="medium">
                        {employee.firstName} {employee.lastName}
                      </Typography>
                      {employee.workEmail && (
                        <Typography variant="caption" color="text.secondary">
                          {employee.workEmail}
                        </Typography>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell>{employee.departmentName || '-'}</TableCell>
                  <TableCell>{employee.jobTitleName || '-'}</TableCell>
                  <TableCell>{employee.employmentTypeName || '-'}</TableCell>
                  <TableCell>
                    <Chip
                      label={employee.active ? 'Active' : 'Inactive'}
                      color={employee.active ? 'success' : 'default'}
                      size="small"
                    />
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="View Salary History">
                      <IconButton
                        size="small"
                        onClick={() => handleViewHistory(employee)}
                        color="primary"
                      >
                        <HistoryIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Edit Current Salary">
                      <IconButton
                        size="small"
                        onClick={() => handleEditSalary(employee)}
                        color="primary"
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Add New Salary">
                      <IconButton
                        size="small"
                        onClick={() => handleCreateSalary(employee)}
                        color="success"
                      >
                        <AddIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={totalElements}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      )}

      {/* Dialogs */}
      {selectedEmployee && (
        <>
          <SalaryStructureDialog
            open={salaryDialogOpen}
            onClose={handleCloseSalaryDialog}
            employee={selectedEmployee}
            existingSalary={editingSalary}
          />
          <SalaryHistoryDialog
            open={historyDialogOpen}
            onClose={handleCloseHistoryDialog}
            employee={selectedEmployee}
          />
        </>
      )}
    </Box>
  );
};

export default EmployeeSalaryPage;
