import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Stack,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Alert,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import {
  Warning as WarningIcon,
  CheckCircle as CheckIcon,
  Visibility as ViewIcon,
  Security as SecurityIcon,
  Assessment as AnalyticsIcon,
  Close as CloseIcon,
} from '@mui/icons-material';
import { toast } from 'react-toastify';
import axios from 'axios';

const ExecutivePaymentAnalytics: React.FC = () => {
  const [, setLoading] = useState(false);
  const [periods, setPeriods] = useState<any[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<any>(null);
  const [discrepancyReport, setDiscrepancyReport] = useState<any>(null);
  const [integrityReport, setIntegrityReport] = useState<any>(null);
  const [detailsDialog, setDetailsDialog] = useState(false);

  useEffect(() => {
    loadPaymentPeriods();
  }, []);

  const loadPaymentPeriods = async () => {
    setLoading(true);
    try {
      // Load approved/paid periods with payment data
      const response = await axios.get('/api/executive/payroll/periods', {
        params: { status: 'APPROVED,PAID' },
      });
      setPeriods(response.data);
    } catch (error: any) {
      toast.error('Failed to load payment periods');
    } finally {
      setLoading(false);
    }
  };

  const loadDiscrepancyDetails = async (periodId: number) => {
    try {
      const [discrepancyRes, integrityRes] = await Promise.all([
        axios.get(`/api/executive/payment-analytics/periods/${periodId}/discrepancies`),
        axios.get(`/api/executive/payment-analytics/periods/${periodId}/integrity`),
      ]);

      setDiscrepancyReport(discrepancyRes.data);
      setIntegrityReport(integrityRes.data);
    } catch (error: any) {
      toast.error('Failed to load discrepancy details');
    }
  };

  const handleViewDetails = async (period: any) => {
    setSelectedPeriod(period);
    await loadDiscrepancyDetails(period.id);
    setDetailsDialog(true);
  };

  const handleCloseDetails = () => {
    setDetailsDialog(false);
    setSelectedPeriod(null);
    setDiscrepancyReport(null);
    setIntegrityReport(null);
  };

  // Unused - keeping for future reference
  // const getDiscrepancyColor = (hasDiscrepancies: boolean) => {
  //   return hasDiscrepancies ? 'error' : 'success';
  // };

  return (
    <Box p={3}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Payment Analytics & Oversight</Typography>
        <Button variant="outlined" startIcon={<AnalyticsIcon />} onClick={loadPaymentPeriods}>
          Refresh
        </Button>
      </Box>

      {/* Summary Cards */}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} mb={4}>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2">
                    Total Periods
                  </Typography>
                  <Typography variant="h4">{periods.length}</Typography>
                </Box>
                <AnalyticsIcon color="primary" sx={{ fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2">
                    With Discrepancies
                  </Typography>
                  <Typography variant="h4" color="error">
                    {periods.filter((p) => p.hasDiscrepancies).length}
                  </Typography>
                </Box>
                <WarningIcon color="error" sx={{ fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2">
                    Verified Clean
                  </Typography>
                  <Typography variant="h4" color="success.main">
                    {periods.filter((p) => !p.hasDiscrepancies && p.feedbackReceived).length}
                  </Typography>
                </Box>
                <CheckIcon color="success" sx={{ fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
      </Stack>

      {/* Alert for Discrepancies */}
      {periods.some((p) => p.hasDiscrepancies) && (
        <Alert severity="error" icon={<WarningIcon />} sx={{ mb: 3 }}>
          <Typography variant="body2" fontWeight="bold">
            Action Required: {periods.filter((p) => p.hasDiscrepancies).length} payment period(s) have
            discrepancies
          </Typography>
          <Typography variant="caption">
            Review bank feedback files and resolve discrepancies before final approval
          </Typography>
        </Alert>
      )}

      {/* Payment Periods Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Payment Periods with Bank Feedback Analysis
          </Typography>

          <TableContainer component={Paper} variant="outlined">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Period</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="right">Total Amount</TableCell>
                  <TableCell align="center">Feedback Files</TableCell>
                  <TableCell align="center">Discrepancies</TableCell>
                  <TableCell align="center">File Integrity</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {periods.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <Typography color="text.secondary">No payment periods found</Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  periods.map((period) => (
                    <TableRow key={period.id}>
                      <TableCell>
                        <Typography variant="body2" fontWeight="bold">
                          {period.periodName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {period.periodCode}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip label={period.status} color="primary" size="small" />
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2">
                          {period.totalAmount
                            ? `UGX ${Number(period.totalAmount).toLocaleString()}`
                            : '-'}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Chip
                          label={period.feedbackFilesCount || 0}
                          color={period.feedbackFilesCount > 0 ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="center">
                        {period.hasDiscrepancies ? (
                          <Chip
                            label={`${period.discrepancyCount} Issues`}
                            color="error"
                            size="small"
                            icon={<WarningIcon />}
                          />
                        ) : period.feedbackFilesCount > 0 ? (
                          <Chip
                            label="Verified"
                            color="success"
                            size="small"
                            icon={<CheckIcon />}
                          />
                        ) : (
                          <Chip label="Pending" color="default" size="small" />
                        )}
                      </TableCell>
                      <TableCell align="center">
                        {period.bankFileGenerated && period.fileLocked ? (
                          <Chip
                            label="Locked"
                            color="success"
                            size="small"
                            icon={<SecurityIcon />}
                          />
                        ) : (
                          <Chip label="N/A" color="default" size="small" />
                        )}
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={() => handleViewDetails(period)}
                        >
                          <ViewIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Details Dialog */}
      <Dialog open={detailsDialog} onClose={handleCloseDetails} maxWidth="md" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Typography variant="h6">
              Payment Analysis - {selectedPeriod?.periodName}
            </Typography>
            <IconButton onClick={handleCloseDetails} size="small">
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent>
          {integrityReport && (
            <Box mb={3}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                File Integrity Report
              </Typography>
              <Stack spacing={2}>
                <Stack direction="row" spacing={2}>
                  <Typography variant="body2" color="text.secondary">
                    File Status
                  </Typography>
                  <Typography variant="body1">
                    {integrityReport.fileLocked ? (
                      <Chip label="🔒 Locked" color="success" size="small" />
                    ) : (
                      <Chip label="Unlocked" color="default" size="small" />
                    )}
                  </Typography>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    File Hash (SHA-256)
                  </Typography>
                  <Typography variant="caption" fontFamily="monospace">
                    {integrityReport.fileHash?.substring(0, 16)}...
                  </Typography>
                </Box>
                </Stack>
                <Stack direction="row" spacing={2}>
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Total Records
                  </Typography>
                    <Typography variant="body1">{integrityReport.totalRecords}</Typography>
                  </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Total Amount
                  </Typography>
                  <Typography variant="body1">
                    UGX {Number(integrityReport.totalAmount).toLocaleString()}
                  </Typography>
                </Box>
                </Stack>
              </Stack>
            </Box>
          )}

          {discrepancyReport && (
            <Box>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                Discrepancy Analysis
              </Typography>

              {discrepancyReport.hasDiscrepancies ? (
                <Alert severity="error" sx={{ mb: 2 }}>
                  <Typography variant="body2" fontWeight="bold">
                    {discrepancyReport.totalDiscrepancies} Discrepancies Detected
                  </Typography>
                  <Typography variant="caption">
                    Review required before final payment confirmation
                  </Typography>
                </Alert>
              ) : discrepancyReport.totalFeedbackFiles > 0 ? (
                <Alert severity="success" sx={{ mb: 2 }}>
                  <Typography variant="body2">
                    All feedback files verified. No discrepancies found.
                  </Typography>
                </Alert>
              ) : (
                <Alert severity="info" sx={{ mb: 2 }}>
                  <Typography variant="body2">No feedback files uploaded yet.</Typography>
                </Alert>
              )}

              {discrepancyReport.feedbackFiles && discrepancyReport.feedbackFiles.length > 0 && (
                <Box>
                  <Typography variant="body2" fontWeight="bold" gutterBottom>
                    Feedback Files
                  </Typography>
                  <TableContainer component={Paper} variant="outlined" sx={{ mt: 1 }}>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>File Name</TableCell>
                          <TableCell>Uploaded By</TableCell>
                          <TableCell>Uploaded At</TableCell>
                          <TableCell align="right">Discrepancies</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {discrepancyReport.feedbackFiles.map((file: any) => (
                          <TableRow key={file.id}>
                            <TableCell>{file.fileName}</TableCell>
                            <TableCell>{file.uploadedBy || 'System'}</TableCell>
                            <TableCell>
                              {new Date(file.uploadedAt).toLocaleString()}
                            </TableCell>
                            <TableCell align="right">
                              {file.discrepancyCount > 0 ? (
                                <Chip
                                  label={file.discrepancyCount}
                                  color="error"
                                  size="small"
                                />
                              ) : (
                                <Chip label="0" color="success" size="small" />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDetails}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ExecutivePaymentAnalytics;
