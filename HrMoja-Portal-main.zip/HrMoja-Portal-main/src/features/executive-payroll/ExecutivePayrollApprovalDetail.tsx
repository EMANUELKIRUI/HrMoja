import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  CircularProgress,
  Card,
  CardContent,
  Divider,
  Tabs,
  Tab,
  Stack,
  TablePagination,
  InputAdornment,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Menu,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
  CheckCircle as ApproveIcon,
  Cancel as RejectIcon,
  Refresh as RefreshIcon,
  Search as SearchIcon,
  Visibility as ViewIcon,
  MoreVert as MoreVertIcon,
  Payment as PaymentIcon,
} from '@mui/icons-material';
import { executivePayrollApi } from '../../api/executivePayrollApi';
import { toast } from 'react-toastify';
import ViewBankDetailsDialog from '../../components/dialogs/ViewBankDetailsDialog';

interface PayrollPeriod {
  id: number;
  periodName: string;
  periodCode: string;
  status: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
  totalEmployees: number;
  totalGrossPay: number;
  totalNetPay: number;
  totalDeductions: number;
  totalStatutory: number;
  totalTaxes: number;
}

const ExecutivePayrollApprovalDetail: React.FC = () => {
  const { periodId } = useParams<{ periodId: string }>();
  const navigate = useNavigate();

  const [period, setPeriod] = useState<PayrollPeriod | null>(null);
  const [records, setRecords] = useState<any>(null);
  const [financialSummary, setFinancialSummary] = useState<any>(null);
  const [validationReport, setValidationReport] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(20);
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [departments, setDepartments] = useState<string[]>([]);
  
  const [approveDialog, setApproveDialog] = useState(false);
  const [rejectDialog, setRejectDialog] = useState(false);
  const [paymentDialog, setPaymentDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [approvalComment, setApprovalComment] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [bankDetailsDialogOpen, setBankDetailsDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<{ id: number; name: string } | null>(null);
  const [actionsMenuAnchor, setActionsMenuAnchor] = useState<null | HTMLElement>(null);

  useEffect(() => {
    if (periodId) {
      loadPeriodData();
    }
  }, [periodId, page, rowsPerPage, searchTerm, departmentFilter]);

  const loadPeriodData = async () => {
    try {
      setLoading(true);
      const [periodRes, recordsRes, summaryRes, validationRes] = await Promise.all([
        executivePayrollApi.getPeriodDetails(Number(periodId)),
        executivePayrollApi.getEmployeeRecords(Number(periodId), searchTerm, departmentFilter, page, rowsPerPage),
        executivePayrollApi.getFinancialSummary(Number(periodId)),
        executivePayrollApi.getValidationReport(Number(periodId)),
      ]);
      
      setPeriod(periodRes.data.data || null);
      setRecords(recordsRes.data.data || null);
      setFinancialSummary(summaryRes.data.data || null);
      
      // Extract unique departments for filter
      if (summaryRes.data.data?.departmentBreakdown) {
        const depts = summaryRes.data.data.departmentBreakdown.map((d: any) => d.department);
        setDepartments(depts);
      }
      
      setValidationReport(validationRes.data.data || null);
    } catch (error: any) {
      console.error('Error loading period data:', error);
      toast.error(error.response?.data?.message || 'Failed to load period data');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!periodId) return;

    if (!approvalComment || approvalComment.trim() === '') {
      toast.error('Executive approval comments are mandatory for audit compliance');
      return;
    }

    try {
      await executivePayrollApi.giveFinalApproval(Number(periodId), approvalComment);
      toast.success('✅ Final Approval Granted - Payroll period approved successfully');
      setApproveDialog(false);
      setApprovalComment('');
      navigate('/executive/payroll/approval');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve period');
    }
  };

  const handleReject = async () => {
    if (!periodId || !rejectReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    try {
      await executivePayrollApi.rejectPeriod(Number(periodId), rejectReason);
      toast.success('❌ Period Rejected - Returned to Finance for corrections');
      setRejectDialog(false);
      setRejectReason('');
      navigate('/executive/payroll/approval');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to reject period');
    }
  };

  const handleAuthorizePayment = async () => {
    if (!periodId) return;

    try {
      await executivePayrollApi.authorizePayment(Number(periodId));
      toast.success('💳 Payment Authorized - Disbursement approved');
      setPaymentDialog(false);
      loadPeriodData();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to authorize payment');
    }
  };

  const handleViewBankDetails = (record: any) => {
    setSelectedEmployee({
      id: record.employeeId,
      name: record.employeeName
    });
    setBankDetailsDialogOpen(true);
  };

  const handleOpenActionsMenu = (event: React.MouseEvent<HTMLElement>, record: any) => {
    setActionsMenuAnchor(event.currentTarget);
    setSelectedRecord(record);
  };

  const handleCloseActionsMenu = () => {
    setActionsMenuAnchor(null);
  };

  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('en-UG', {
      style: 'currency',
      currency: 'UGX',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'APPROVED':
        return 'success';
      case 'REJECTED':
        return 'error';
      case 'PENDING':
        return 'warning';
      default:
        return 'default';
    }
  };

  if (loading && !period) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center" gap={2}>
          <IconButton onClick={() => navigate('/executive/payroll/approval')}>
            <BackIcon />
          </IconButton>
          <Box>
            <Box display="flex" alignItems="center" gap={2}>
              <Typography variant="h4" fontWeight="bold">
                Executive Payroll Approval
              </Typography>
              {period?.status && (
                <Chip
                  label={period.status}
                  color={getStatusColor(period.status) as any}
                  size="medium"
                  sx={{ fontWeight: 'bold' }}
                />
              )}
            </Box>
            <Typography variant="body2" color="text.secondary">
              {period?.periodName} - {period?.periodCode}
            </Typography>
          </Box>
        </Box>
        <Box display="flex" gap={2}>
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={loadPeriodData}
            disabled={loading}
          >
            Refresh
          </Button>
          <Button
            variant="outlined"
            color="error"
            startIcon={<RejectIcon />}
            onClick={() => setRejectDialog(true)}
            disabled={loading || period?.status !== 'REVIEWED'}
          >
            Reject
          </Button>
          <Button
            variant="contained"
            color="success"
            startIcon={<ApproveIcon />}
            onClick={() => setApproveDialog(true)}
            disabled={loading || period?.status !== 'REVIEWED'}
          >
            Final Approval
          </Button>
          {period?.status === 'APPROVED' && (
            <Button
              variant="contained"
              color="primary"
              startIcon={<PaymentIcon />}
              onClick={() => setPaymentDialog(true)}
              disabled={loading}
            >
              Authorize Payment
            </Button>
          )}
        </Box>
      </Box>

      {/* Summary Cards */}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} mb={3}>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Employees
              </Typography>
              <Typography variant="h4" fontWeight="bold">
                {period?.totalEmployees || 0}
              </Typography>
            </CardContent>
          </Card>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Gross Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold">
                {formatCurrency(period?.totalGrossPay || 0)}
              </Typography>
            </CardContent>
          </Card>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Total Deductions
              </Typography>
              <Typography variant="h5" fontWeight="bold" color="warning.main">
                {formatCurrency(period?.totalDeductions || 0)}
              </Typography>
            </CardContent>
          </Card>
        <Card sx={{ flex: 1 }}>
            <CardContent>
              <Typography color="text.secondary" variant="body2">
                Net Pay
              </Typography>
              <Typography variant="h5" fontWeight="bold" color="success.main">
                {formatCurrency(period?.totalNetPay || 0)}
              </Typography>
            </CardContent>
          </Card>
      </Stack>

      {/* Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs value={activeTab} onChange={(_, newValue) => setActiveTab(newValue)}>
          <Tab label="Employee Records" />
          <Tab label="Financial Summary" />
          <Tab label="Validation Report" />
        </Tabs>
      </Paper>

      {/* Tab Content */}
      {activeTab === 0 && (
        <Card>
          <CardContent>
            {/* Search and Filters */}
            <Box display="flex" gap={2} mb={3}>
              <TextField
                placeholder="Search by employee name or number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                size="small"
                sx={{ flexGrow: 1 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
              <FormControl size="small" sx={{ minWidth: 200 }}>
                <InputLabel>Department</InputLabel>
                <Select
                  value={departmentFilter}
                  label="Department"
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                >
                  <MenuItem value="">All Departments</MenuItem>
                  {departments.map((dept) => (
                    <MenuItem key={dept} value={dept}>
                      {dept}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            {/* Employee Records Table */}
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell width="60">S/No</TableCell>
                    <TableCell>Employee Code</TableCell>
                    <TableCell>Employee Name</TableCell>
                    <TableCell>Department</TableCell>
                    <TableCell align="right">Gross Pay</TableCell>
                    <TableCell align="right">Deductions</TableCell>
                    <TableCell align="right">Net Pay</TableCell>
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {records?.content?.map((record: any, index: number) => (
                    <TableRow key={record.id} hover>
                      <TableCell>
                        <Typography variant="body2" color="text.secondary">
                          {page * rowsPerPage + index + 1}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight="medium">
                          {record.employeeNumber}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {record.employeeName}
                        </Typography>
                      </TableCell>
                      <TableCell>{record.departmentName}</TableCell>
                      <TableCell align="right">{formatCurrency(record.grossSalary)}</TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" color="error.main">
                          {formatCurrency(record.totalDeductions)}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" fontWeight="bold" color="success.main">
                          {formatCurrency(record.netSalary)}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          onClick={(e) => handleOpenActionsMenu(e, record)}
                        >
                          <MoreVertIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            <TablePagination
              component="div"
              count={records?.totalElements || 0}
              page={page}
              onPageChange={(_, newPage) => setPage(newPage)}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={(e) => {
                setRowsPerPage(parseInt(e.target.value, 10));
                setPage(0);
              }}
              rowsPerPageOptions={[10, 20, 50, 100]}
            />
          </CardContent>
        </Card>
      )}

      {activeTab === 1 && (
        <Box>
          <Typography variant="h5" fontWeight="bold" gutterBottom>
            Financial Summary
          </Typography>
          
          {financialSummary ? (
            <Box>
              {/* Main Financial Cards */}
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} mb={3}>
                <Card sx={{ bgcolor: 'primary.main', color: 'white', flex: 1 }}>
                    <CardContent>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Total Gross Pay
                      </Typography>
                      <Typography variant="h5" fontWeight="bold">
                        {formatCurrency(financialSummary.totalGrossPay || 0)}
                      </Typography>
                    </CardContent>
                  </Card>
                <Card sx={{ bgcolor: 'warning.main', color: 'white', flex: 1 }}>
                    <CardContent>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Total Deductions
                      </Typography>
                      <Typography variant="h5" fontWeight="bold">
                        {formatCurrency(financialSummary.totalDeductions || 0)}
                      </Typography>
                    </CardContent>
                  </Card>
                <Card sx={{ bgcolor: 'success.main', color: 'white', flex: 1 }}>
                    <CardContent>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Total Net Pay
                      </Typography>
                      <Typography variant="h5" fontWeight="bold">
                        {formatCurrency(financialSummary.totalNetPay || 0)}
                      </Typography>
                    </CardContent>
                  </Card>
                <Card sx={{ bgcolor: 'info.main', color: 'white', flex: 1 }}>
                    <CardContent>
                      <Typography variant="body2" sx={{ opacity: 0.9 }}>
                        Total Employees
                      </Typography>
                      <Typography variant="h5" fontWeight="bold">
                        {financialSummary.employeeCounts?.active || 0}
                      </Typography>
                    </CardContent>
                  </Card>
              </Stack>

              {/* Detailed Breakdown */}
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={3}>
                {/* Left Column - Statutory & Taxes */}
                  <Card>
                    <CardContent>
                      <Typography variant="h6" fontWeight="bold" gutterBottom>
                        Statutory & Taxes Breakdown
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      <Box display="flex" justifyContent="space-between" mb={1}>
                        <Typography variant="body2" color="text.secondary">
                          Total Statutory Deductions
                        </Typography>
                        <Typography variant="body1" fontWeight="medium">
                          {formatCurrency(financialSummary.totalStatutoryDeductions || 0)}
                        </Typography>
                      </Box>
                      <Box display="flex" justifyContent="space-between" mb={1}>
                        <Typography variant="body2" color="text.secondary">
                          Total Taxes (PAYE)
                        </Typography>
                        <Typography variant="body1" fontWeight="medium">
                          {formatCurrency(financialSummary.totalTaxes || 0)}
                        </Typography>
                      </Box>
                      <Box display="flex" justifyContent="space-between" mb={1}>
                        <Typography variant="body2" color="text.secondary">
                          Total Earnings/Allowances
                        </Typography>
                        <Typography variant="body1" fontWeight="medium">
                          {formatCurrency(financialSummary.totalEarnings || 0)}
                        </Typography>
                      </Box>
                    </CardContent>
                  </Card>

                {/* Right Column - Employee Statistics */}
                  <Card>
                    <CardContent>
                      <Typography variant="h6" fontWeight="bold" gutterBottom>
                        Employee Statistics
                      </Typography>
                      <Divider sx={{ mb: 2 }} />
                      {financialSummary.employeeCounts && (
                        <Box>
                          <Box display="flex" justifyContent="space-between" mb={1}>
                            <Typography variant="body2" color="text.secondary">
                              Total Employees
                            </Typography>
                            <Typography variant="body1" fontWeight="medium">
                              {financialSummary.employeeCounts.total || 0}
                            </Typography>
                          </Box>
                          <Box display="flex" justifyContent="space-between" mb={1}>
                            <Typography variant="body2" color="text.secondary">
                              Active Records
                            </Typography>
                            <Typography variant="body1" fontWeight="medium" color="success.main">
                              {financialSummary.employeeCounts.active || 0}
                            </Typography>
                          </Box>
                          <Box display="flex" justifyContent="space-between" mb={1}>
                            <Typography variant="body2" color="text.secondary">
                              With Bank Details
                            </Typography>
                            <Typography variant="body1" fontWeight="medium">
                              {financialSummary.employeeCounts.withBankDetails || 0}
                            </Typography>
                          </Box>
                          <Box display="flex" justifyContent="space-between" mb={1}>
                            <Typography variant="body2" color="text.secondary">
                              Missing Bank Details
                            </Typography>
                            <Typography variant="body1" fontWeight="medium" color="error.main">
                              {financialSummary.employeeCounts.missingBankDetails || 0}
                            </Typography>
                          </Box>
                        </Box>
                      )}
                    </CardContent>
                  </Card>

              </Stack>

              {/* Department Breakdown */}
              {financialSummary.departmentBreakdown && financialSummary.departmentBreakdown.length > 0 && (
                    <Card>
                      <CardContent>
                        <Typography variant="h6" fontWeight="bold" gutterBottom>
                          Department Breakdown
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <TableContainer>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                <TableCell><strong>Department</strong></TableCell>
                                <TableCell align="right"><strong>Employees</strong></TableCell>
                                <TableCell align="right"><strong>Gross Pay</strong></TableCell>
                                <TableCell align="right"><strong>Net Pay</strong></TableCell>
                                <TableCell align="right"><strong>Taxes</strong></TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {financialSummary.departmentBreakdown.map((dept: any, index: number) => (
                                <TableRow key={index} hover>
                                  <TableCell>{dept.department}</TableCell>
                                  <TableCell align="right">{dept.employeeCount}</TableCell>
                                  <TableCell align="right">{formatCurrency(dept.totalGross)}</TableCell>
                                  <TableCell align="right">
                                    <Typography variant="body2" color="success.main" fontWeight="medium">
                                      {formatCurrency(dept.totalNet)}
                                    </Typography>
                                  </TableCell>
                                  <TableCell align="right">{formatCurrency(dept.totalTaxes)}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </CardContent>
                    </Card>
              )}
            </Box>
          ) : (
            <Alert severity="info">No financial summary data available</Alert>
          )}
        </Box>
      )}

      {activeTab === 2 && (
        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Validation Report
            </Typography>
            <Divider sx={{ mb: 2 }} />
            {validationReport ? (
              <Box>
                <Alert severity={validationReport.hasErrors ? 'error' : 'success'}>
                  {validationReport.hasErrors ? 'Validation issues found' : 'All validations passed'}
                </Alert>
              </Box>
            ) : (
              <Typography>No validation report available</Typography>
            )}
          </CardContent>
        </Card>
      )}

      {/* Actions Menu */}
      <Menu
        anchorEl={actionsMenuAnchor}
        open={Boolean(actionsMenuAnchor)}
        onClose={handleCloseActionsMenu}
      >
        <MenuItem
          onClick={() => {
            handleViewBankDetails(selectedRecord);
            handleCloseActionsMenu();
          }}
        >
          <ListItemIcon>
            <ViewIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>View Bank Details</ListItemText>
        </MenuItem>
      </Menu>

      {/* Final Approval Dialog */}
      <Dialog open={approveDialog} onClose={() => setApproveDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" alignItems="center" gap={1}>
            <ApproveIcon color="success" />
            <Typography variant="h6" fontWeight="bold">
              Executive Final Approval
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Box mb={2}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Payroll Period
            </Typography>
            <Typography variant="h6" fontWeight="medium">
              {period?.periodName}
            </Typography>
          </Box>
          
          <Divider sx={{ my: 2 }} />
          
          <Stack direction="row" spacing={2} mb={2}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Employees
              </Typography>
              <Typography variant="body1" fontWeight="medium">
                {period?.totalEmployees}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Net Payroll
              </Typography>
              <Typography variant="body1" fontWeight="bold" color="success.main">
                {formatCurrency(period?.totalNetPay || 0)}
              </Typography>
            </Box>
          </Stack>

          <Alert severity="warning" sx={{ mb: 2 }}>
            <strong>Final Approval Authority:</strong> By approving this payroll, you authorize the disbursement of funds. 
            This action requires mandatory executive comments for audit compliance.
          </Alert>

          <TextField 
            fullWidth 
            required
            multiline 
            rows={4} 
            label="Executive Approval Comments" 
            placeholder="Add your executive approval notes, authorization remarks, or any relevant observations... (Required for audit trail)"
            value={approvalComment} 
            onChange={(e) => setApprovalComment(e.target.value)} 
            error={approvalComment.trim() === ''}
            helperText="Required: Provide executive authorization justification"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setApproveDialog(false); setApprovalComment(''); }}>Cancel</Button>
          <Button 
            onClick={handleApprove} 
            variant="contained" 
            color="success"
            disabled={!approvalComment.trim()}
            startIcon={<ApproveIcon />}
          >
            Grant Final Approval
          </Button>
        </DialogActions>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog open={rejectDialog} onClose={() => setRejectDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" alignItems="center" gap={1}>
            <RejectIcon color="error" />
            <Typography variant="h6" fontWeight="bold">
              Reject Payroll Period
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Box mb={2}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Payroll Period
            </Typography>
            <Typography variant="h6" fontWeight="medium">
              {period?.periodName}
            </Typography>
          </Box>

          <Alert severity="error" sx={{ mb: 2 }}>
            <strong>Executive Rejection:</strong> This action will return the payroll period to Finance for corrections. 
            Provide a detailed reason for rejection.
          </Alert>

          <TextField 
            fullWidth 
            required 
            multiline 
            rows={5} 
            label="Rejection Reason" 
            placeholder="Provide detailed executive-level concerns, compliance issues, or corrections needed..."
            value={rejectReason} 
            onChange={(e) => setRejectReason(e.target.value)}
            error={rejectReason.trim() === ''}
            helperText="Required: Specify reasons for rejection and required corrections"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setRejectDialog(false); setRejectReason(''); }}>Cancel</Button>
          <Button 
            onClick={handleReject} 
            variant="contained" 
            color="error" 
            disabled={!rejectReason.trim()}
            startIcon={<RejectIcon />}
          >
            Reject & Return to Finance
          </Button>
        </DialogActions>
      </Dialog>

      {/* Payment Authorization Dialog */}
      <Dialog open={paymentDialog} onClose={() => setPaymentDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" alignItems="center" gap={1}>
            <PaymentIcon color="primary" />
            <Typography variant="h6" fontWeight="bold">
              Authorize Payment
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            <strong>Payment Authorization:</strong> This will authorize the disbursement of {formatCurrency(period?.totalNetPay || 0)} 
            to {period?.totalEmployees} employees. This action is irreversible.
          </Alert>
          <Typography>
            Are you sure you want to authorize payment for this payroll period?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setPaymentDialog(false)}>Cancel</Button>
          <Button 
            onClick={handleAuthorizePayment} 
            variant="contained" 
            color="primary"
            startIcon={<PaymentIcon />}
          >
            Authorize Payment
          </Button>
        </DialogActions>
      </Dialog>

      {/* Bank Details Dialog */}
      <ViewBankDetailsDialog
        open={bankDetailsDialogOpen}
        onClose={() => setBankDetailsDialogOpen(false)}
        employeeId={selectedEmployee?.id || 0}
        employeeName={selectedEmployee?.name || ''}
      />
    </Box>
  );
};

export default ExecutivePayrollApprovalDetail;
