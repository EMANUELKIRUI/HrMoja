import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Alert,
  Card,
  CardContent,
  Stack,
  CircularProgress,
  Tabs,
  Tab,
  Divider,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  CheckCircle as ApproveIcon,
  Cancel as RejectIcon,
  Refresh as RefreshIcon,
  TrendingUp as TrendingUpIcon,
  AccountBalance as AccountBalanceIcon,
  People as PeopleIcon,
  AttachMoney as MoneyIcon,
  Schedule as ScheduleIcon,
  Assessment as AssessmentIcon,
} from '@mui/icons-material';
import { executivePayrollApi } from '../../api/executivePayrollApi';
import { toast } from 'react-toastify';

interface PayrollPeriod {
  id: number;
  periodName: string;
  periodCode: string;
  status: string;
  totalEmployees: number;
  totalGrossPay: number;
  totalNetPay: number;
  totalDeductions: number;
  reviewedAt: string;
  reviewedBy: number;
  reviewedByName: string;
  preparedBy: string;
  startDate: string;
  endDate: string;
}

interface DashboardStats {
  pendingApprovals: number;
  totalPayrollAmount: number;
  totalEmployees: number;
  approvedThisMonth: number;
  averageProcessingTime: number;
  complianceScore: number;
}

const ExecutivePayrollApproval: React.FC = () => {
  const navigate = useNavigate();
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<PayrollPeriod | null>(null);
  const [approveDialog, setApproveDialog] = useState(false);
  const [rejectDialog, setRejectDialog] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [comment, setComment] = useState('');
  const [activeTab, setActiveTab] = useState(0);
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);

  useEffect(() => {
    loadPeriods();
    loadDashboardStats();
  }, [activeTab]);

  const loadPeriods = async () => {
    try {
      setLoading(true);
      let statusFilter = undefined;
      if (activeTab === 0) statusFilter = 'REVIEWED';
      else if (activeTab === 1) statusFilter = 'APPROVED';
      else if (activeTab === 2) statusFilter = 'PAID';
      
      const response = await executivePayrollApi.getPeriodsForApproval(statusFilter);
      setPeriods(response.data.data || []);
    } catch (error: any) {
      toast.error('Failed to load periods');
    } finally {
      setLoading(false);
    }
  };

  const loadDashboardStats = async () => {
    try {
      setStatsLoading(true);
      const response = await executivePayrollApi.getDashboard();
      // Handle both response.data.data and response.data formats
      const data = response.data?.data || response.data;
      setDashboardStats(data || null);
    } catch (error: any) {
      console.error('Failed to load dashboard stats:', error);
      // Set default values if API fails
      setDashboardStats({
        pendingApprovals: 0,
        totalPayrollAmount: 0,
        totalEmployees: 0,
        approvedThisMonth: 0,
        averageProcessingTime: 0,
        complianceScore: 0,
      });
    } finally {
      setStatsLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!selectedPeriod) return;

    if (!comment || comment.trim() === '') {
      toast.error('Approval comments are mandatory for audit compliance');
      return;
    }

    try {
      await executivePayrollApi.giveFinalApproval(selectedPeriod.id, comment);
      toast.success('✅ Final Approval Granted - Payroll period approved successfully');
      setApproveDialog(false);
      setComment('');
      setSelectedPeriod(null);
      loadPeriods();
      loadDashboardStats();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to approve period');
    }
  };

  const handleReject = async () => {
    if (!selectedPeriod || !rejectReason || rejectReason.trim() === '') {
      toast.error('Rejection reason is required');
      return;
    }

    try {
      await executivePayrollApi.rejectPeriod(selectedPeriod.id, rejectReason);
      toast.success('❌ Period Rejected - Returned to Finance for corrections');
      setRejectDialog(false);
      setRejectReason('');
      setSelectedPeriod(null);
      loadPeriods();
      loadDashboardStats();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to reject period');
    }
  };

  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('en-UG', {
      style: 'currency',
      currency: 'UGX',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'REVIEWED':
        return 'warning';
      case 'APPROVED':
        return 'success';
      case 'PAID':
        return 'info';
      case 'REJECTED':
        return 'error';
      default:
        return 'default';
    }
  };

  return (
    <Box p={3}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Executive Payroll Oversight
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Final approval authority for organizational payroll
          </Typography>
        </Box>
        <Box display="flex" gap={2}>
          <Button 
            variant="outlined" 
            startIcon={<AssessmentIcon />}
            onClick={() => navigate('/reports')}
          >
            Reports
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<RefreshIcon />} 
            onClick={() => { loadPeriods(); loadDashboardStats(); }} 
            disabled={loading || statsLoading}
          >
            Refresh
          </Button>
        </Box>
      </Box>

      {/* Executive Analytics Dashboard */}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} mb={4}>
        <Card elevation={2} sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2" gutterBottom>
                    Pending Approvals
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {statsLoading ? <CircularProgress size={24} /> : (dashboardStats?.pendingApprovals || 0)}
                  </Typography>
                </Box>
                <ScheduleIcon sx={{ fontSize: 48, color: 'warning.main', opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        <Card elevation={2} sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2" gutterBottom>
                    Total Payroll Value
                  </Typography>
                  <Typography variant="h5" fontWeight="bold">
                    {statsLoading ? <CircularProgress size={24} /> : formatCurrency(dashboardStats?.totalPayrollAmount || 0)}
                  </Typography>
                </Box>
                <MoneyIcon sx={{ fontSize: 48, color: 'success.main', opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        <Card elevation={2} sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2" gutterBottom>
                    Total Employees
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {statsLoading ? <CircularProgress size={24} /> : (dashboardStats?.totalEmployees || 0)}
                  </Typography>
                </Box>
                <PeopleIcon sx={{ fontSize: 48, color: 'primary.main', opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        <Card elevation={2} sx={{ flex: 1 }}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="text.secondary" variant="body2" gutterBottom>
                    Approved This Month
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {statsLoading ? <CircularProgress size={24} /> : (dashboardStats?.approvedThisMonth || 0)}
                  </Typography>
                </Box>
                <TrendingUpIcon sx={{ fontSize: 48, color: 'info.main', opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
      </Stack>

      {/* Status Tabs */}
      <Paper sx={{ mb: 3 }}>
        <Tabs 
          value={activeTab} 
          onChange={(_, newValue) => setActiveTab(newValue)}
          indicatorColor="primary"
          textColor="primary"
        >
          <Tab label="Pending Final Approval" icon={<ScheduleIcon />} iconPosition="start" />
          <Tab label="Approved" icon={<ApproveIcon />} iconPosition="start" />
          <Tab label="Payment Authorized" icon={<AccountBalanceIcon />} iconPosition="start" />
          <Tab label="All Periods" />
        </Tabs>
      </Paper>

      {/* Payroll Periods Table */}
      <Card>
        <CardContent>
          {loading ? (
            <Box display="flex" justifyContent="center" alignItems="center" p={5}>
              <CircularProgress />
            </Box>
          ) : periods.length === 0 ? (
            <Box textAlign="center" py={5}>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No Payroll Periods Found
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {activeTab === 0 && 'No periods are awaiting your final approval'}
                {activeTab === 1 && 'No approved periods found'}
                {activeTab === 2 && 'No periods with payment authorization found'}
                {activeTab === 3 && 'No payroll periods available'}
              </Typography>
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell><strong>Period</strong></TableCell>
                    <TableCell><strong>Status</strong></TableCell>
                    <TableCell align="right"><strong>Employees</strong></TableCell>
                    <TableCell align="right"><strong>Gross Pay</strong></TableCell>
                    <TableCell align="right"><strong>Deductions</strong></TableCell>
                    <TableCell align="right"><strong>Net Pay</strong></TableCell>
                    <TableCell><strong>Reviewed By</strong></TableCell>
                    <TableCell align="center"><strong>Actions</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {periods.map((period) => (
                    <TableRow key={period.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight="medium">
                          {period.periodName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {period.periodCode}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={period.status} 
                          color={getStatusColor(period.status) as any}
                          size="small" 
                        />
                      </TableCell>
                      <TableCell align="right">{period.totalEmployees}</TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" fontWeight="medium">
                          {formatCurrency(period.totalGrossPay)}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" color="error.main">
                          {formatCurrency(period.totalDeductions || 0)}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        <Typography variant="body2" fontWeight="bold" color="success.main">
                          {formatCurrency(period.totalNetPay)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          {period.reviewedByName || 'N/A'}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Button
                          variant="contained"
                          size="small"
                          startIcon={<ViewIcon />}
                          onClick={() => navigate(`/executive/payroll/approval/${period.id}`)}
                          sx={{ textTransform: 'none' }}
                        >
                          Review Payroll
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>

      {/* Executive Final Approval Dialog */}
      <Dialog 
        open={approveDialog} 
        onClose={() => setApproveDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box display="flex" alignItems="center" gap={1}>
            <ApproveIcon color="success" />
            <Typography variant="h6" fontWeight="bold">
              Executive Final Approval
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Box mb={2}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Payroll Period
            </Typography>
            <Typography variant="h6" fontWeight="medium">
              {selectedPeriod?.periodName}
            </Typography>
          </Box>
          
          <Divider sx={{ my: 2 }} />
          
          <Stack direction="row" spacing={2} mb={2}>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Employees
              </Typography>
              <Typography variant="body1" fontWeight="medium">
                {selectedPeriod?.totalEmployees}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary">
                Net Payroll
              </Typography>
              <Typography variant="body1" fontWeight="bold" color="success.main">
                {selectedPeriod && formatCurrency(selectedPeriod.totalNetPay)}
              </Typography>
            </Box>
          </Stack>

          <Alert severity="warning" sx={{ mb: 2 }}>
            <strong>Final Approval Authority:</strong> By approving this payroll, you authorize the disbursement of funds. 
            This action requires mandatory executive comments for audit compliance.
          </Alert>

          <TextField 
            fullWidth 
            required
            multiline 
            rows={4} 
            label="Executive Approval Comments" 
            placeholder="Add your executive approval notes, authorization remarks, or any relevant observations... (Required for audit trail)"
            value={comment} 
            onChange={(e) => setComment(e.target.value)} 
            error={comment.trim() === ''}
            helperText="Required: Provide executive authorization justification"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setApproveDialog(false); setComment(''); }}>Cancel</Button>
          <Button 
            onClick={handleApprove} 
            variant="contained" 
            color="success"
            disabled={!comment.trim()}
            startIcon={<ApproveIcon />}
          >
            Grant Final Approval
          </Button>
        </DialogActions>
      </Dialog>

      {/* Executive Rejection Dialog */}
      <Dialog 
        open={rejectDialog} 
        onClose={() => setRejectDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Box display="flex" alignItems="center" gap={1}>
            <RejectIcon color="error" />
            <Typography variant="h6" fontWeight="bold">
              Reject Payroll Period
            </Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Box mb={2}>
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Payroll Period
            </Typography>
            <Typography variant="h6" fontWeight="medium">
              {selectedPeriod?.periodName}
            </Typography>
          </Box>

          <Alert severity="error" sx={{ mb: 2 }}>
            <strong>Executive Rejection:</strong> This action will return the payroll period to Finance for corrections. 
            Provide a detailed reason for rejection.
          </Alert>

          <TextField 
            fullWidth 
            required 
            multiline 
            rows={5} 
            label="Rejection Reason" 
            placeholder="Provide detailed executive-level concerns, compliance issues, or corrections needed..."
            value={rejectReason} 
            onChange={(e) => setRejectReason(e.target.value)}
            error={rejectReason.trim() === ''}
            helperText="Required: Specify reasons for rejection and required corrections"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setRejectDialog(false); setRejectReason(''); }}>Cancel</Button>
          <Button 
            onClick={handleReject} 
            variant="contained" 
            color="error" 
            disabled={!rejectReason.trim()}
            startIcon={<RejectIcon />}
          >
            Reject & Return to Finance
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ExecutivePayrollApproval;
