import {
  Box,
  Typography,
  Grid,
  Card,
  CardActionArea,
  Paper,
  Divider,
} from '@mui/material';
import {
  Assessment as AssessmentIcon,
  AccountBalance as BankIcon,
  TrendingUp as TrendingIcon,
  PieChart as ChartIcon,
  Description as DocumentIcon,
  LocalAtm as PayrollIcon,
} from '@mui/icons-material';

interface ReportCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

const ReportCard = ({ title, description, icon, color }: ReportCardProps) => (
  <Card>
    <CardActionArea sx={{ p: 3 }}>
      <Box display="flex" alignItems="flex-start" gap={2}>
        <Box
          sx={{
            bgcolor: color,
            borderRadius: 2,
            p: 2,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {icon}
        </Box>
        <Box flex={1}>
          <Typography variant="h6" fontWeight="bold" gutterBottom>
            {title}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {description}
          </Typography>
        </Box>
      </Box>
    </CardActionArea>
  </Card>
);

const ReportsPage = () => {
  const payrollReports = [
    {
      title: 'Payroll Summary Report',
      description: 'Comprehensive overview of payroll period with totals',
      icon: <PayrollIcon sx={{ color: 'white', fontSize: 32 }} />,
      color: 'primary.main',
    },
    {
      title: 'Department Payroll Report',
      description: 'Breakdown of payroll costs by department',
      icon: <ChartIcon sx={{ color: 'white', fontSize: 32 }} />,
      color: 'success.main',
    },
    {
      title: 'Employee Payslips',
      description: 'Individual employee payslips for the period',
      icon: <DocumentIcon sx={{ color: 'white', fontSize: 32 }} />,
      color: 'info.main',
    },
  ];

  const statutoryReports = [
    {
      title: 'PAYE Tax Report',
      description: 'Pay As You Earn tax deductions report',
      icon: <BankIcon sx={{ color: 'white', fontSize: 32 }} />,
      color: 'warning.main',
    },
    {
      title: 'NSSF Contributions Report',
      description: 'National Social Security Fund contributions',
      icon: <AssessmentIcon sx={{ color: 'white', fontSize: 32 }} />,
      color: 'error.main',
    },
    {
      title: 'Local Service Tax Report',
      description: 'LST deductions and remittances',
      icon: <TrendingIcon sx={{ color: 'white', fontSize: 32 }} />,
      color: 'secondary.main',
    },
  ];

  return (
    <Box>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Reports & Analytics
      </Typography>
      <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
        Generate and export payroll and statutory reports
      </Typography>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" fontWeight="bold" gutterBottom>
          Payroll Reports
        </Typography>
        <Divider sx={{ mb: 3 }} />
        <Grid container spacing={3}>
          {payrollReports.map((report) => (
            <Grid size={{ xs: 12, md: 4 }} key={report.title}>
              <ReportCard {...report} />
            </Grid>
          ))}
        </Grid>
      </Paper>

      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" fontWeight="bold" gutterBottom>
          Statutory Reports
        </Typography>
        <Divider sx={{ mb: 3 }} />
        <Grid container spacing={3}>
          {statutoryReports.map((report) => (
            <Grid size={{ xs: 12, md: 4 }} key={report.title}>
              <ReportCard {...report} />
            </Grid>
          ))}
        </Grid>
      </Paper>

      <Paper sx={{ p: 3, mt: 3, bgcolor: 'info.lighter' }}>
        <Typography variant="body2" color="info.dark">
          <strong>Note:</strong> Report generation functionality requires selecting a payroll period. 
          All reports can be exported to Excel format.
        </Typography>
      </Paper>
    </Box>
  );
};

export default ReportsPage;
