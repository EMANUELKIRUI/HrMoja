import { Box, Typography, Card, CardContent, Grid, Button } from '@mui/material';
import { Download as DownloadIcon } from '@mui/icons-material';

const SystemReportsPage = () => {
  const reportTypes = [
    {
      title: 'Platform Analytics',
      description: 'Overall platform usage, user engagement, and growth metrics',
      icon: '📊',
    },
    {
      title: 'Organization Reports',
      description: 'Organization-wise statistics, subscription status, and activity',
      icon: '🏢',
    },
    {
      title: 'Financial Reports',
      description: 'Revenue, subscriptions, billing, and financial analytics',
      icon: '💰',
    },
    {
      title: 'System Health',
      description: 'Server performance, uptime, errors, and system metrics',
      icon: '🔧',
    },
    {
      title: 'User Activity',
      description: 'Login patterns, feature usage, and user behavior analytics',
      icon: '👥',
    },
    {
      title: 'Audit Logs',
      description: 'Security events, admin actions, and compliance reports',
      icon: '📋',
    },
  ];

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          System Reports
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Platform-wide analytics and reporting
        </Typography>
      </Box>

      <Grid container spacing={3}>
        {reportTypes.map((report, index) => (
          <Grid size={{ xs: 12, md: 6 }} key={index}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ fontSize: 40, mr: 2 }}>{report.icon}</Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="h6" fontWeight="bold">
                      {report.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {report.description}
                    </Typography>
                  </Box>
                </Box>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<DownloadIcon />}
                  fullWidth
                >
                  Generate Report
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default SystemReportsPage;
