import { Box, Typography, Card, CardContent, Grid, List, ListItem, ListItemText, Chip } from '@mui/material';

const SecurityPage = () => {
  const roles = [
    { name: 'Super Admin', users: 2, permissions: 'All' },
    { name: 'Platform Admin', users: 5, permissions: 'Platform Management' },
    { name: 'Organization Admin', users: 32, permissions: 'Organization Management' },
    { name: 'HR Manager', users: 78, permissions: 'Employee & Payroll Management' },
    { name: 'Payroll Officer', users: 45, permissions: 'Payroll Processing' },
    { name: 'Employee', users: 863, permissions: 'Self Service' },
  ];

  const permissions = [
    'SETTINGS_MANAGE',
    'SETTINGS_READ',
    'EMPLOYEE_MANAGE',
    'EMPLOYEE_READ',
    'PAYROLL_MANAGE',
    'PAYROLL_READ',
    'REPORTS_VIEW',
    'USER_MANAGE',
  ];

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Security & Roles
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Manage system roles, permissions, and security settings
        </Typography>
      </Box>

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                System Roles
              </Typography>
              <List>
                {roles.map((role, index) => (
                  <ListItem key={index} divider={index < roles.length - 1}>
                    <ListItemText
                      primary={role.name}
                      secondary={`${role.users} users • ${role.permissions}`}
                    />
                    <Chip label="Active" color="success" size="small" />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Platform Permissions
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Available system permissions
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                {permissions.map((permission, index) => (
                  <Chip key={index} label={permission} variant="outlined" size="small" />
                ))}
              </Box>
            </CardContent>
          </Card>

          <Card sx={{ mt: 3 }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Security Settings
              </Typography>
              <List dense>
                <ListItem>
                  <ListItemText primary="Two-Factor Authentication" secondary="Enforced for all admins" />
                  <Chip label="Enabled" color="success" size="small" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Session Timeout" secondary="30 minutes of inactivity" />
                </ListItem>
                <ListItem>
                  <ListItemText primary="Password Policy" secondary="Minimum 8 characters, complexity required" />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SecurityPage;
