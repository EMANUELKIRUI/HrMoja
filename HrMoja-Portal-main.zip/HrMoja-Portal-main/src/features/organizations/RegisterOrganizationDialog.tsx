import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Grid,
  MenuItem,
  Typography,
  Alert,
  Stepper,
  Step,
  StepLabel,
  Box,
  InputAdornment,
  IconButton,
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { organizationsApi, type OrganizationRegistrationRequest } from '../../api/organizations.api';
import { countriesApi } from '../../api/countries.api';

const registrationSchema = z.object({
  // Organization Details
  organizationName: z.string().min(1, 'Organization name is required'),
  legalName: z.string().optional(),
  registrationNumber: z.string().optional(),
  taxIdentificationNumber: z.string().min(1, 'Tax identification number is required'),
  countryId: z.number().min(1, 'Country is required'),
  addressLine1: z.string().min(1, 'Address is required'),
  addressLine2: z.string().optional(),
  city: z.string().min(1, 'City is required'),
  stateProvince: z.string().optional(),
  postalCode: z.string().optional(),
  phoneNumber: z.string().min(1, 'Phone number is required'),
  organizationEmail: z.string().email('Invalid email address'),
  website: z.string().url('Invalid URL').optional().or(z.literal('')),
  
  // Admin User Details
  adminFirstName: z.string().min(1, 'Admin first name is required'),
  adminLastName: z.string().min(1, 'Admin last name is required'),
  adminEmail: z.string().email('Invalid email address'),
  adminUsername: z.string().min(3, 'Username must be at least 3 characters'),
  adminPassword: z.string().min(8, 'Password must be at least 8 characters'),
  adminPhoneNumber: z.string().optional(),
  
  // Branch Details
  branchName: z.string().min(1, 'Headquarters branch name is required'),
  branchCity: z.string().optional(),
});

type RegistrationFormData = z.infer<typeof registrationSchema>;

const steps = ['Organization Details', 'Admin User', 'Review & Submit'];

interface RegisterOrganizationDialogProps {
  open: boolean;
  onClose: () => void;
}

const RegisterOrganizationDialog = ({ open, onClose }: RegisterOrganizationDialogProps) => {
  const queryClient = useQueryClient();
  const [activeStep, setActiveStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  // Fetch countries
  const { data: countriesResponse } = useQuery({
    queryKey: ['countries', 'active'],
    queryFn: countriesApi.getActiveCountries,
  });

  const countries = countriesResponse?.data || [];

  const {
    control,
    handleSubmit,
    reset,
    trigger,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm<RegistrationFormData>({
    resolver: zodResolver(registrationSchema),
    mode: 'onChange',
    shouldUnregister: false, // CRITICAL: Keep form values when fields unmount during step changes
    defaultValues: {
      organizationName: '',
      legalName: '',
      registrationNumber: '',
      taxIdentificationNumber: '',
      countryId: countries[0]?.id || 1,
      addressLine1: '',
      addressLine2: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      phoneNumber: '',
      organizationEmail: '',
      website: '',
      adminFirstName: '',
      adminLastName: '',
      adminEmail: '',
      adminUsername: '',
      adminPassword: '',
      adminPhoneNumber: '',
      branchName: 'Headquarters',
      branchCity: '',
    },
  });

  const registerMutation = useMutation({
    mutationFn: (data: OrganizationRegistrationRequest) => organizationsApi.registerOrganization(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
      reset();
      setError(null);
      setActiveStep(0);
      onClose();
    },
    onError: (err: any) => {
      setError(err.response?.data?.message || err.message || 'Failed to register organization');
    },
  });

  const handleNext = async () => {
    let fieldsToValidate: (keyof RegistrationFormData)[] = [];
    
    if (activeStep === 0) {
      fieldsToValidate = [
        'organizationName', 'taxIdentificationNumber', 'countryId',
        'addressLine1', 'city', 'phoneNumber', 'organizationEmail', 'branchName'
      ];
    } else if (activeStep === 1) {
      fieldsToValidate = [
        'adminFirstName', 'adminLastName', 'adminEmail',
        'adminUsername', 'adminPassword'
      ];
    }

    const isValid = await trigger(fieldsToValidate);
    if (isValid) {
      setActiveStep((prev) => prev + 1);
      setError(null);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    setError(null);
  };

  const onSubmit = async (data: RegistrationFormData) => {
    // Validate all fields one more time
    const isValid = await trigger();
    
    if (!isValid) {
      setError('Please check all required fields');
      return;
    }
    
    setError(null);
    registerMutation.mutate(data);
  };

  const handleClose = () => {
    if (!isSubmitting) {
      reset();
      setError(null);
      setActiveStep(0);
      onClose();
    }
  };

  const renderStepContent = () => {
    return (
      <>
        {/* Step 0: Organization Details - Always rendered, hidden when not active */}
        <Grid container spacing={3} sx={{ display: activeStep === 0 ? 'flex' : 'none' }}>
            {/* Organization Information */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
                Organization Information
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="organizationName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Organization Name"
                    fullWidth
                    required
                    error={!!errors.organizationName}
                    helperText={errors.organizationName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="legalName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Legal Name"
                    fullWidth
                    error={!!errors.legalName}
                    helperText={errors.legalName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="registrationNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Registration Number"
                    fullWidth
                    error={!!errors.registrationNumber}
                    helperText={errors.registrationNumber?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="taxIdentificationNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Tax Identification Number (TIN)"
                    fullWidth
                    required
                    error={!!errors.taxIdentificationNumber}
                    helperText={errors.taxIdentificationNumber?.message}
                  />
                )}
              />
            </Grid>

            {/* Location */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                Location
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="countryId"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="Country"
                    fullWidth
                    required
                    error={!!errors.countryId}
                    helperText={errors.countryId?.message}
                  >
                    {countries.map((country) => (
                      <MenuItem key={country.id} value={country.id}>
                        {country.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="city"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="City"
                    fullWidth
                    required
                    error={!!errors.city}
                    helperText={errors.city?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Controller
                name="addressLine1"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Address Line 1"
                    fullWidth
                    required
                    error={!!errors.addressLine1}
                    helperText={errors.addressLine1?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Controller
                name="addressLine2"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Address Line 2"
                    fullWidth
                    error={!!errors.addressLine2}
                    helperText={errors.addressLine2?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="stateProvince"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="State/Province"
                    fullWidth
                    error={!!errors.stateProvince}
                    helperText={errors.stateProvince?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="postalCode"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Postal Code"
                    fullWidth
                    error={!!errors.postalCode}
                    helperText={errors.postalCode?.message}
                  />
                )}
              />
            </Grid>

            {/* Contact Information */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                Contact Information
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="phoneNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Phone Number"
                    fullWidth
                    required
                    error={!!errors.phoneNumber}
                    helperText={errors.phoneNumber?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="organizationEmail"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Organization Email"
                    type="email"
                    fullWidth
                    required
                    error={!!errors.organizationEmail}
                    helperText={errors.organizationEmail?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Controller
                name="website"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Website"
                    fullWidth
                    placeholder="https://example.com"
                    error={!!errors.website}
                    helperText={errors.website?.message}
                  />
                )}
              />
            </Grid>

            {/* Branch Information */}
            <Grid size={12}>
              <Typography variant="subtitle1" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                Headquarters Branch
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="branchName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Branch Name"
                    fullWidth
                    required
                    error={!!errors.branchName}
                    helperText={errors.branchName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="branchCity"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Branch City"
                    fullWidth
                    error={!!errors.branchCity}
                    helperText={errors.branchCity?.message}
                  />
                )}
              />
            </Grid>
        </Grid>

        {/* Step 1: Admin User - Always rendered, hidden when not active */}
        <Grid container spacing={3} sx={{ display: activeStep === 1 ? 'flex' : 'none' }}>
            <Grid size={12}>
              <Alert severity="info" sx={{ mb: 2 }}>
                Create an administrator account for this organization. This user will have full access to manage the organization.
              </Alert>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="adminFirstName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="First Name"
                    fullWidth
                    required
                    error={!!errors.adminFirstName}
                    helperText={errors.adminFirstName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="adminLastName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Last Name"
                    fullWidth
                    required
                    error={!!errors.adminLastName}
                    helperText={errors.adminLastName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="adminEmail"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Email"
                    type="email"
                    fullWidth
                    required
                    error={!!errors.adminEmail}
                    helperText={errors.adminEmail?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="adminPhoneNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Phone Number"
                    fullWidth
                    error={!!errors.adminPhoneNumber}
                    helperText={errors.adminPhoneNumber?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="adminUsername"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Username"
                    fullWidth
                    required
                    error={!!errors.adminUsername}
                    helperText={errors.adminUsername?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="adminPassword"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Password"
                    type={showPassword ? 'text' : 'password'}
                    fullWidth
                    required
                    error={!!errors.adminPassword}
                    helperText={errors.adminPassword?.message}
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton
                            onClick={() => setShowPassword(!showPassword)}
                            edge="end"
                          >
                            {showPassword ? <VisibilityOff /> : <Visibility />}
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />
                )}
              />
            </Grid>
        </Grid>

        {/* Step 2: Review - Always rendered, hidden when not active */}
        <Box sx={{ display: activeStep === 2 ? 'block' : 'none' }}>
            <Alert severity="info" sx={{ mb: 3 }}>
              Please review the information below before submitting.
            </Alert>

            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Organization Details
            </Typography>
            <Box sx={{ mb: 3, p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
              <Typography variant="body2"><strong>Name:</strong> {getValues('organizationName')}</Typography>
              <Typography variant="body2"><strong>TIN:</strong> {getValues('taxIdentificationNumber')}</Typography>
              <Typography variant="body2"><strong>Email:</strong> {getValues('organizationEmail')}</Typography>
              <Typography variant="body2"><strong>Phone:</strong> {getValues('phoneNumber')}</Typography>
              <Typography variant="body2"><strong>Address:</strong> {getValues('addressLine1')}, {getValues('city')}</Typography>
              <Typography variant="body2"><strong>Branch:</strong> {getValues('branchName')}</Typography>
            </Box>

            <Typography variant="subtitle1" fontWeight="bold" gutterBottom>
              Administrator Account
            </Typography>
            <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
              <Typography variant="body2"><strong>Name:</strong> {getValues('adminFirstName')} {getValues('adminLastName')}</Typography>
              <Typography variant="body2"><strong>Email:</strong> {getValues('adminEmail')}</Typography>
              <Typography variant="body2"><strong>Username:</strong> {getValues('adminUsername')}</Typography>
            </Box>
        </Box>
      </>
    );
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box>
          <Typography variant="h6" fontWeight="bold" component="span" display="block">
            Register New Organization
          </Typography>
          <Typography variant="body2" color="text.secondary" component="span" display="block">
            Onboard a new organization with administrator account
          </Typography>
        </Box>
      </DialogTitle>

      <Box sx={{ px: 3, pt: 2 }}>
        <Stepper activeStep={activeStep}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>

      <form onSubmit={handleSubmit(onSubmit)}>
        <DialogContent dividers>
          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          {renderStepContent()}
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={handleClose} disabled={isSubmitting}>
            Cancel
          </Button>
          {activeStep > 0 && (
            <Button onClick={handleBack} disabled={isSubmitting}>
              Back
            </Button>
          )}
          {activeStep < steps.length - 1 ? (
            <Button variant="contained" onClick={handleNext}>
              Next
            </Button>
          ) : (
            <Button
              type="submit"
              variant="contained"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Registering...' : 'Register Organization'}
            </Button>
          )}
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default RegisterOrganizationDialog;
