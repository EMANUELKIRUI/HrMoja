import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  CircularProgress,
  Dialog,
  Tooltip,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  Business as BusinessIcon,
  CheckCircle as CheckCircleIcon,
  Block as BlockIcon,
} from '@mui/icons-material';
import { organizationsApi } from '../../api/organizations.api';
import RegisterOrganizationDialog from './RegisterOrganizationDialog';

const OrganizationsPage = () => {
  const queryClient = useQueryClient();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    orgId: number | null;
    orgName: string;
    action: 'activate' | 'deactivate';
  }>({ open: false, orgId: null, orgName: '', action: 'deactivate' });

  const { data: orgsResponse, isLoading } = useQuery({
    queryKey: ['organizations'],
    queryFn: organizationsApi.getAllOrganizations,
  });

  const organizations = orgsResponse?.data || [];
  const activeOrgs = organizations.filter(org => org.active);
  const inactiveOrgs = organizations.filter(org => !org.active);

  const filteredOrgs = organizations.filter(org =>
    org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    org.countryName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Toggle organization active status
  const toggleStatusMutation = useMutation({
    mutationFn: (orgId: number) => organizationsApi.deleteOrganization(orgId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['organizations'] });
      setConfirmDialog({ open: false, orgId: null, orgName: '', action: 'deactivate' });
    },
  });

  const handleToggleStatus = (org: typeof organizations[0]) => {
    setConfirmDialog({
      open: true,
      orgId: org.id!,
      orgName: org.name,
      action: org.active ? 'deactivate' : 'activate',
    });
  };

  const confirmToggleStatus = () => {
    if (confirmDialog.orgId) {
      toggleStatusMutation.mutate(confirmDialog.orgId);
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Organizations Management
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage all organizations on the platform
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setCreateDialogOpen(true)}
        >
          Register Organization
        </Button>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <BusinessIcon sx={{ fontSize: 40, color: 'primary.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {organizations.length}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Organizations
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <BusinessIcon sx={{ fontSize: 40, color: 'success.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {activeOrgs.length}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Active Organizations
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <BusinessIcon sx={{ fontSize: 40, color: 'warning.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {inactiveOrgs.length}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Inactive Organizations
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Search Bar */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <TextField
          fullWidth
          placeholder="Search organizations by name or country..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Paper>

      {/* Organizations Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight="bold" gutterBottom>
            All Organizations
          </Typography>
          {isLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Country</TableCell>
                    <TableCell>City</TableCell>
                    <TableCell>Contact</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredOrgs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        <Typography variant="body2" color="text.secondary">
                          No organizations found
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredOrgs.map((org) => (
                      <TableRow key={org.id} hover>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {org.name}
                          </Typography>
                          {org.legalName && (
                            <Typography variant="caption" color="text.secondary">
                              {org.legalName}
                            </Typography>
                          )}
                        </TableCell>
                        <TableCell>{org.countryName || '-'}</TableCell>
                        <TableCell>{org.city || '-'}</TableCell>
                        <TableCell>
                          <Typography variant="body2">{org.email || '-'}</Typography>
                          <Typography variant="caption" color="text.secondary">
                            {org.phoneNumber || '-'}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={org.active ? 'Active' : 'Inactive'}
                            color={org.active ? 'success' : 'default'}
                            size="small"
                          />
                        </TableCell>
                        <TableCell align="right">
                          <Tooltip title={org.active ? 'Deactivate Organization' : 'Activate Organization'}>
                            <IconButton
                              size="small"
                              color={org.active ? 'error' : 'success'}
                              onClick={() => handleToggleStatus(org)}
                            >
                              {org.active ? (
                                <BlockIcon fontSize="small" />
                              ) : (
                                <CheckCircleIcon fontSize="small" />
                              )}
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>

      {/* Register Organization Dialog */}
      <RegisterOrganizationDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
      />

      {/* Confirm Toggle Status Dialog */}
      <Dialog
        open={confirmDialog.open}
        onClose={() => setConfirmDialog({ open: false, orgId: null, orgName: '', action: 'deactivate' })}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)',
          },
        }}
      >
        <Box sx={{ p: 3 }}>
          {/* Icon Header */}
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              mb: 3,
            }}
          >
            <Box
              sx={{
                width: 80,
                height: 80,
                borderRadius: '50%',
                background:
                  confirmDialog.action === 'deactivate'
                    ? 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'
                    : 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mb: 2,
                boxShadow:
                  confirmDialog.action === 'deactivate'
                    ? '0 8px 24px rgba(239, 68, 68, 0.3)'
                    : '0 8px 24px rgba(16, 185, 129, 0.3)',
              }}
            >
              {confirmDialog.action === 'deactivate' ? (
                <BlockIcon sx={{ fontSize: 40, color: 'white' }} />
              ) : (
                <CheckCircleIcon sx={{ fontSize: 40, color: 'white' }} />
              )}
            </Box>
            <Typography variant="h5" fontWeight="bold" gutterBottom>
              {confirmDialog.action === 'deactivate' ? 'Deactivate' : 'Activate'} Organization?
            </Typography>
          </Box>

          {/* Content */}
          <Box sx={{ mb: 3, textAlign: 'center' }}>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
              You are about to {confirmDialog.action === 'deactivate' ? 'deactivate' : 'activate'}:
            </Typography>
            <Chip
              label={confirmDialog.orgName}
              size="medium"
              sx={{
                fontWeight: 600,
                fontSize: '1rem',
                py: 2.5,
                px: 2,
                backgroundColor: 'primary.50',
                border: '2px solid',
                borderColor: 'primary.main',
              }}
            />
            {confirmDialog.action === 'deactivate' ? (
              <Box
                sx={{
                  mt: 3,
                  p: 2,
                  borderRadius: 2,
                  backgroundColor: 'error.50',
                  border: '1px solid',
                  borderColor: 'error.200',
                }}
              >
                <Typography variant="body2" color="error.dark" fontWeight={500}>
                  ⚠️ Users from this organization will be unable to access the system
                </Typography>
              </Box>
            ) : (
              <Box
                sx={{
                  mt: 3,
                  p: 2,
                  borderRadius: 2,
                  backgroundColor: 'success.50',
                  border: '1px solid',
                  borderColor: 'success.200',
                }}
              >
                <Typography variant="body2" color="success.dark" fontWeight={500}>
                  ✅ Users from this organization will regain system access
                </Typography>
              </Box>
            )}
          </Box>

          {/* Actions */}
          <Box sx={{ display: 'flex', gap: 2, mt: 4 }}>
            <Button
              fullWidth
              variant="outlined"
              onClick={() => setConfirmDialog({ open: false, orgId: null, orgName: '', action: 'deactivate' })}
              sx={{ py: 1.5, fontWeight: 600 }}
            >
              Cancel
            </Button>
            <Button
              fullWidth
              onClick={confirmToggleStatus}
              color={confirmDialog.action === 'deactivate' ? 'error' : 'success'}
              variant="contained"
              disabled={toggleStatusMutation.isPending}
              sx={{
                py: 1.5,
                fontWeight: 600,
                boxShadow:
                  confirmDialog.action === 'deactivate'
                    ? '0 4px 12px rgba(239, 68, 68, 0.3)'
                    : '0 4px 12px rgba(16, 185, 129, 0.3)',
              }}
            >
              {toggleStatusMutation.isPending
                ? 'Processing...'
                : confirmDialog.action === 'deactivate'
                ? 'Yes, Deactivate'
                : 'Yes, Activate'}
            </Button>
          </Box>
        </Box>
      </Dialog>
    </Box>
  );
};

export default OrganizationsPage;
