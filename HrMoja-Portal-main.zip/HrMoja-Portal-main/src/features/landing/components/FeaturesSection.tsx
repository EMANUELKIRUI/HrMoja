import React from 'react';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Grid, Card, CardContent } from '@mui/material';
import {
  AccountBalance,
  Assessment,
  Badge,
  CalendarToday,
  Security,
} from '@mui/icons-material';

const features = [
  {
    icon: <AccountBalance sx={{ fontSize: 48, color: '#667eea' }} />,
    title: 'Automated Payroll Processing',
    description: 'Instant salary, tax, and deduction calculations. Process payroll for thousands of employees in minutes.',
  },
  {
    icon: <Assessment sx={{ fontSize: 48, color: '#f093fb' }} />,
    title: 'Compliance Reports',
    description: 'KRA, NHIF, NSSF, PAYE auto-generated reports. Stay compliant with Uganda and Kenya tax regulations.',
  },
  {
    icon: <Badge sx={{ fontSize: 48, color: '#4facfe' }} />,
    title: 'Employee Self-Service Portal',
    description: 'Employees access payslips, submit leave requests, and update personal details independently.',
  },
  {
    icon: <CalendarToday sx={{ fontSize: 48, color: '#43e97b' }} />,
    title: 'Leave & Attendance Tracking',
    description: 'Manage leave requests, approvals, and attendance logs seamlessly with automated workflows.',
  },
  {
    icon: <Assessment sx={{ fontSize: 48, color: '#fa709a' }} />,
    title: 'HR Analytics Dashboard',
    description: 'Real-time insights into workforce metrics, payroll costs, and employee performance trends.',
  },
  {
    icon: <Security sx={{ fontSize: 48, color: '#667eea' }} />,
    title: 'Secure Cloud Access',
    description: 'Role-based access control, encrypted data storage, and SOC 2 compliance for enterprise security.',
  },
];

const FeaturesSection: React.FC = () => {
  return (
    <Box id="features" sx={{ py: { xs: 8, md: 12 }, background: '#f8fafc' }}>
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Core Features
            </Typography>
            <Typography variant="h6" sx={{ color: '#64748b', maxWidth: 700, mx: 'auto' }}>
              Everything you need to manage HR and payroll operations efficiently
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={4}>
          {features.map((feature, index) => (
            <Grid size={{ xs: 12, sm: 6, md: 4 }} key={feature.title}>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card
                  sx={{
                    height: '100%',
                    p: 3,
                    borderRadius: 3,
                    border: '1px solid #e2e8f0',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.15)',
                      borderColor: '#667eea',
                    },
                  }}
                >
                  <CardContent sx={{ p: 0 }}>
                    <Box sx={{ mb: 2 }}>{feature.icon}</Box>
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 1.5, color: '#1e293b' }}>
                      {feature.title}
                    </Typography>
                    <Typography variant="body2" sx={{ color: '#64748b', lineHeight: 1.7 }}>
                      {feature.description}
                    </Typography>
                  </CardContent>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default FeaturesSection;
