import { useEffect } from 'react';

const StructuredData = () => {
  useEffect(() => {
    // Organization Schema
    const organizationSchema = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'HRMoja',
      url: 'https://hrmoja.com',
      logo: 'https://hrmoja.com/logo.png',
      description: 'Modern HR & Payroll Management platform for Healthcare, Insurance, and enterprises',
      address: {
        '@type': 'PostalAddress',
        addressCountry: 'KE',
        addressLocality: 'Nairobi',
      },
      contactPoint: {
        '@type': 'ContactPoint',
        telephone: '+254-735-023-566',
        contactType: 'Customer Service',
        email: 'hello@coremoja.com',
        availableLanguage: ['en', 'sw'],
      },
      sameAs: [
        'https://www.linkedin.com/company/hrmoja',
        'https://twitter.com/hrmoja',
        'https://www.facebook.com/hrmoja',
      ],
    };

    // Software Application Schema
    const softwareSchema = {
      '@context': 'https://schema.org',
      '@type': 'SoftwareApplication',
      name: 'HRMoja',
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Web Browser',
      offers: {
        '@type': 'AggregateOffer',
        lowPrice: '49',
        highPrice: 'Contact for pricing',
        priceCurrency: 'USD',
      },
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: '4.8',
        ratingCount: '120',
      },
      description: 'Cloud-based HR and Payroll Management system with multi-country support for Kenya and Uganda',
      featureList: [
        'Automated Payroll Processing',
        'Compliance Reports (KRA, NSSF, NHIF)',
        'Employee Self-Service Portal',
        'Leave & Attendance Tracking',
        'HR Analytics Dashboard',
        'Secure Cloud Access',
      ],
    };

    // FAQ Schema
    const faqSchema = {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: [
        {
          '@type': 'Question',
          name: 'Can HRMoja handle multiple companies?',
          acceptedAnswer: {
            '@type': 'Answer',
            text: 'Yes, HRMoja supports multiple payroll setups in one account. Perfect for organizations managing subsidiaries or group companies.',
          },
        },
        {
          '@type': 'Question',
          name: 'Is it cloud-based?',
          acceptedAnswer: {
            '@type': 'Answer',
            text: '100% cloud-based with secure login. Access your HR data from anywhere, anytime with enterprise-grade security and encryption.',
          },
        },
        {
          '@type': 'Question',
          name: 'Which countries does HRMoja support?',
          acceptedAnswer: {
            '@type': 'Answer',
            text: 'Currently supports Uganda and Kenya with full tax compliance (KRA, NSSF, NHIF, PAYE). We handle multi-country payroll seamlessly.',
          },
        },
      ],
    };

    // Service Schema
    const serviceSchema = {
      '@context': 'https://schema.org',
      '@type': 'Service',
      serviceType: 'Payroll and HR Management',
      provider: {
        '@type': 'Organization',
        name: 'HRMoja',
      },
      areaServed: [
        {
          '@type': 'Country',
          name: 'Kenya',
        },
        {
          '@type': 'Country',
          name: 'Uganda',
        },
      ],
      hasOfferCatalog: {
        '@type': 'OfferCatalog',
        name: 'HRMoja Services',
        itemListElement: [
          {
            '@type': 'Offer',
            itemOffered: {
              '@type': 'Service',
              name: 'Payroll Processing',
            },
          },
          {
            '@type': 'Offer',
            itemOffered: {
              '@type': 'Service',
              name: 'HR Management',
            },
          },
          {
            '@type': 'Offer',
            itemOffered: {
              '@type': 'Service',
              name: 'Compliance Management',
            },
          },
        ],
      },
    };

    // Add all schemas to page
    const addSchema = (schema: object, id: string) => {
      let script = document.getElementById(id) as HTMLScriptElement | null;
      if (!script) {
        script = document.createElement('script');
        script.type = 'application/ld+json';
        script.id = id;
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(schema);
    };

    addSchema(organizationSchema, 'organization-schema');
    addSchema(softwareSchema, 'software-schema');
    addSchema(faqSchema, 'faq-schema');
    addSchema(serviceSchema, 'service-schema');
  }, []);

  return null;
};

export default StructuredData;
