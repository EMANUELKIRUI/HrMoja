import React from 'react';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Grid, Card, Button, Stack } from '@mui/material';
import { CheckCircle, ArrowForward } from '@mui/icons-material';

const plans = [
  {
    name: 'Starter',
    price: '$49',
    period: '/month',
    description: 'Perfect for small businesses',
    features: [
      'Up to 50 employees',
      'Basic payroll processing',
      'Employee self-service',
      'Email support',
      'Monthly compliance reports',
    ],
    popular: false,
  },
  {
    name: 'Professional',
    price: '$149',
    period: '/month',
    description: 'Best for growing companies',
    features: [
      'Up to 250 employees',
      'Advanced payroll & tax',
      'Multi-country support',
      'Leave & attendance',
      'Priority support',
      'Custom reports',
      'API access',
    ],
    popular: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For large organizations',
    features: [
      'Unlimited employees',
      'Dedicated account manager',
      'Custom integrations',
      'SLA guarantee',
      '24/7 phone support',
      'Advanced security',
      'On-premise option',
    ],
    popular: false,
  },
];

const PricingSection: React.FC = () => {
  return (
    <Box id="pricing" sx={{ py: { xs: 8, md: 12 }, background: '#f8fafc' }}>
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Pricing Plans
            </Typography>
            <Typography variant="h6" sx={{ color: '#64748b', maxWidth: 700, mx: 'auto' }}>
              Choose the plan that fits your organization
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={4} alignItems="stretch">
          {plans.map((plan, index) => (
            <Grid size={{ xs: 12, md: 4 }} key={plan.name}>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                style={{ height: '100%' }}
              >
                <Card
                  sx={{
                    height: '100%',
                    p: 4,
                    borderRadius: 3,
                    border: plan.popular ? '2px solid #667eea' : '1px solid #e2e8f0',
                    boxShadow: plan.popular
                      ? '0 12px 40px rgba(102, 126, 234, 0.2)'
                      : '0 2px 8px rgba(0,0,0,0.05)',
                    position: 'relative',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.2)',
                    },
                  }}
                >
                  {plan.popular && (
                    <Box
                      sx={{
                        position: 'absolute',
                        top: -12,
                        left: '50%',
                        transform: 'translateX(-50%)',
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        color: 'white',
                        px: 3,
                        py: 0.5,
                        borderRadius: 2,
                        fontSize: '0.875rem',
                        fontWeight: 700,
                      }}
                    >
                      MOST POPULAR
                    </Box>
                  )}

                  <Typography variant="h5" sx={{ fontWeight: 700, mb: 1, color: '#1e293b' }}>
                    {plan.name}
                  </Typography>

                  <Typography variant="body2" sx={{ color: '#64748b', mb: 3 }}>
                    {plan.description}
                  </Typography>

                  <Box sx={{ display: 'flex', alignItems: 'baseline', mb: 4 }}>
                    <Typography
                      variant="h3"
                      sx={{
                        fontWeight: 900,
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        backgroundClip: 'text',
                        WebkitBackgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                      }}
                    >
                      {plan.price}
                    </Typography>
                    <Typography variant="body1" sx={{ color: '#64748b', ml: 1 }}>
                      {plan.period}
                    </Typography>
                  </Box>

                  <Stack spacing={2} sx={{ mb: 4 }}>
                    {plan.features.map((feature) => (
                      <Stack key={feature} direction="row" spacing={1.5} alignItems="flex-start">
                        <CheckCircle sx={{ color: '#43e97b', fontSize: 20, mt: 0.3 }} />
                        <Typography variant="body2" sx={{ color: '#64748b' }}>
                          {feature}
                        </Typography>
                      </Stack>
                    ))}
                  </Stack>

                  <Button
                    variant={plan.popular ? 'contained' : 'outlined'}
                    fullWidth
                    endIcon={<ArrowForward />}
                    sx={{
                      py: 1.5,
                      borderRadius: 2,
                      fontWeight: 600,
                      ...(plan.popular
                        ? {
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                            '&:hover': {
                              background: 'linear-gradient(135deg, #764ba2 0%, #667eea 100%)',
                            },
                          }
                        : {
                            borderColor: '#667eea',
                            color: '#667eea',
                            '&:hover': {
                              background: 'rgba(102, 126, 234, 0.1)',
                              borderColor: '#667eea',
                            },
                          }),
                    }}
                  >
                    {plan.name === 'Enterprise' ? 'Contact Sales' : 'Get Started'}
                  </Button>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default PricingSection;
