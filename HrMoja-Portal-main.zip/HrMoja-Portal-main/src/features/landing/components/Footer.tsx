import React from 'react';
import { Box, Container, Grid, Typography, Stack, IconButton, Divider } from '@mui/material';
import { LinkedIn, Twitter, Facebook, Instagram } from '@mui/icons-material';

const Footer: React.FC = () => {
  return (
    <Box sx={{ background: '#1e293b', py: 6 }}>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          {/* Company Info */}
          <Grid size={{ xs: 12, md: 4 }}>
            <Typography
              variant="h5"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #f093fb 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              HRMoja
            </Typography>
            <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)', mb: 3, lineHeight: 1.7 }}>
              Modern HR & Payroll Management made simple.
              Automate payroll, manage employees effortlessly, and gain real-time insights — all in one powerful, secure, and easy-to-use platform.
            </Typography>
            <Stack direction="row" spacing={1}>
              <IconButton
                size="small"
                sx={{
                  background: 'rgba(102, 126, 234, 0.2)',
                  color: '#667eea',
                  '&:hover': { background: 'rgba(102, 126, 234, 0.3)' },
                }}
              >
                <LinkedIn />
              </IconButton>
              <IconButton
                size="small"
                sx={{
                  background: 'rgba(102, 126, 234, 0.2)',
                  color: '#667eea',
                  '&:hover': { background: 'rgba(102, 126, 234, 0.3)' },
                }}
              >
                <Twitter />
              </IconButton>
              <IconButton
                size="small"
                sx={{
                  background: 'rgba(102, 126, 234, 0.2)',
                  color: '#667eea',
                  '&:hover': { background: 'rgba(102, 126, 234, 0.3)' },
                }}
              >
                <Facebook />
              </IconButton>
              <IconButton
                size="small"
                sx={{
                  background: 'rgba(102, 126, 234, 0.2)',
                  color: '#667eea',
                  '&:hover': { background: 'rgba(102, 126, 234, 0.3)' },
                }}
              >
                <Instagram />
              </IconButton>
            </Stack>
          </Grid>

          {/* Products */}
          <Grid size={{ xs: 6, sm: 3, md: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, mb: 2, color: 'white' }}>
              Products
            </Typography>
            <Stack spacing={1.5}>
              {['Payroll', 'HR Management', 'Time & Attendance', 'Reports & Analytics'].map((item) => (
                <Typography
                  key={item}
                  variant="body2"
                  sx={{
                    color: 'rgba(255, 255, 255, 0.6)',
                    cursor: 'pointer',
                    '&:hover': { color: '#667eea' },
                    transition: 'color 0.3s ease',
                  }}
                >
                  {item}
                </Typography>
              ))}
            </Stack>
          </Grid>

          {/* Company */}
          <Grid size={{ xs: 6, sm: 3, md: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, mb: 2, color: 'white' }}>
              Company
            </Typography>
            <Stack spacing={1.5}>
              {['About Us', 'Careers', 'Blog', 'Partners'].map((item) => (
                <Typography
                  key={item}
                  variant="body2"
                  sx={{
                    color: 'rgba(255, 255, 255, 0.6)',
                    cursor: 'pointer',
                    '&:hover': { color: '#667eea' },
                    transition: 'color 0.3s ease',
                  }}
                >
                  {item}
                </Typography>
              ))}
            </Stack>
          </Grid>

          {/* Support */}
          <Grid size={{ xs: 6, sm: 3, md: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, mb: 2, color: 'white' }}>
              Support
            </Typography>
            <Stack spacing={1.5}>
              {['Help Center', 'Contact Us', 'API Docs', 'Status'].map((item) => (
                <Typography
                  key={item}
                  variant="body2"
                  sx={{
                    color: 'rgba(255, 255, 255, 0.6)',
                    cursor: 'pointer',
                    '&:hover': { color: '#667eea' },
                    transition: 'color 0.3s ease',
                  }}
                  onClick={() => {
                    if (item === 'Contact Us') {
                      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                >
                  {item}
                </Typography>
              ))}
            </Stack>
          </Grid>

          {/* Legal */}
          <Grid size={{ xs: 6, sm: 3, md: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, mb: 2, color: 'white' }}>
              Legal
            </Typography>
            <Stack spacing={1.5}>
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'GDPR'].map((item) => (
                <Typography
                  key={item}
                  variant="body2"
                  sx={{
                    color: 'rgba(255, 255, 255, 0.6)',
                    cursor: 'pointer',
                    '&:hover': { color: '#667eea' },
                    transition: 'color 0.3s ease',
                  }}
                >
                  {item}
                </Typography>
              ))}
            </Stack>
          </Grid>
        </Grid>

        <Divider sx={{ my: 4, borderColor: 'rgba(255, 255, 255, 0.1)' }} />

        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          justifyContent="space-between"
          alignItems="center"
          spacing={2}
        >
          <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.6)' }}>
            © {new Date().getFullYear()} HRMoja. All rights reserved.
          </Typography>
          <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.6)' }}>
            Made with ❤️ in Kenya & Uganda
          </Typography>
        </Stack>
      </Container>
    </Box>
  );
};

export default Footer;
