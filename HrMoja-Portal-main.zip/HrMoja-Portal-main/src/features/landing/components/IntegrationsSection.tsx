import React from 'react';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Grid, Card, Avatar } from '@mui/material';
import { AccountBalance, Assessment, DevicesOther } from '@mui/icons-material';

const integrations = [
  {
    icon: <Assessment sx={{ fontSize: 32 }} />,
    title: 'Accounting Systems',
    items: ['QuickBooks', 'Xero', 'Sage', 'SAP'],
    color: '#667eea',
  },
  {
    icon: <AccountBalance sx={{ fontSize: 32 }} />,
    title: 'Banking Integration',
    items: ['API-based salary disbursement', 'Direct bank transfers', 'Multi-currency support'],
    color: '#f093fb',
  },
  {
    icon: <Assessment sx={{ fontSize: 32 }} />,
    title: 'Compliance Systems',
    items: ['KRA iTax', 'NSSF Portal', 'NHIF Portal', 'SHIF Integration'],
    color: '#4facfe',
  },
  {
    icon: <DevicesOther sx={{ fontSize: 32 }} />,
    title: 'HR & ERP Tools',
    items: ['Biometric devices', 'ERP systems', 'Time tracking', 'Attendance systems'],
    color: '#43e97b',
  },
];

const IntegrationsSection: React.FC = () => {
  return (
    <Box sx={{ py: { xs: 8, md: 12 }, background: 'white' }}>
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Seamless Integrations
            </Typography>
            <Typography variant="h6" sx={{ color: '#64748b', maxWidth: 700, mx: 'auto' }}>
              Connect HRMoja with your existing tools and systems
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={4}>
          {integrations.map((integration, index) => (
            <Grid size={{ xs: 12, sm: 6, md: 3 }} key={integration.title}>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card
                  sx={{
                    height: '100%',
                    p: 3,
                    borderRadius: 3,
                    border: '1px solid #e2e8f0',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                    textAlign: 'center',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.15)',
                    },
                  }}
                >
                  <Avatar
                    sx={{
                      width: 64,
                      height: 64,
                      background: integration.color,
                      mb: 2,
                      mx: 'auto',
                    }}
                  >
                    {integration.icon}
                  </Avatar>

                  <Typography variant="h6" sx={{ fontWeight: 700, mb: 2, color: '#1e293b' }}>
                    {integration.title}
                  </Typography>

                  <Box>
                    {integration.items.map((item) => (
                      <Typography
                        key={item}
                        variant="body2"
                        sx={{ color: '#64748b', mb: 0.5, lineHeight: 1.6 }}
                      >
                        • {item}
                      </Typography>
                    ))}
                  </Box>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default IntegrationsSection;
