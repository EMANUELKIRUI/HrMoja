import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import { ExpandMore } from '@mui/icons-material';

const faqs = [
  {
    question: 'Can HRMoja handle multiple companies?',
    answer: 'Yes, HRMoja supports multiple payroll setups in one account. Perfect for organizations managing subsidiaries or group companies.',
  },
  {
    question: 'Is it cloud-based?',
    answer: '100% cloud-based with secure login. Access your HR data from anywhere, anytime with enterprise-grade security and encryption.',
  },
  {
    question: 'Can employees access payslips online?',
    answer: 'Yes, employees have access to a self-service portal where they can view and download payslips, submit leave requests, and update personal information.',
  },
  {
    question: 'Which countries does HRMoja support?',
    answer: 'Currently supports Uganda and Kenya with full tax compliance (KRA, NSSF, NHIF, PAYE). We handle multi-country payroll seamlessly.',
  },
  {
    question: 'How secure is my data?',
    answer: 'We use bank-grade 256-bit encryption, SOC 2 Type II certification, and GDPR compliance. All data is backed up daily with disaster recovery protocols.',
  },
  {
    question: 'What kind of support do you provide?',
    answer: 'We offer email support for all plans, priority support for Professional plans, and 24/7 phone support with dedicated account managers for Enterprise customers.',
  },
  {
    question: 'Can I integrate with my existing accounting system?',
    answer: 'Yes, HRMoja integrates with QuickBooks, Xero, Sage, and other major accounting systems. We also provide API access for custom integrations.',
  },
  {
    question: 'Is there a free trial?',
    answer: 'Yes, we offer a 14-day free trial with no credit card required. Experience all features before making a commitment.',
  },
];

const FAQSection: React.FC = () => {
  const [expanded, setExpanded] = useState<string | false>(false);

  const handleChange = (panel: string) => (_event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false);
  };

  return (
    <Box sx={{ py: { xs: 8, md: 12 }, background: '#f8fafc' }}>
      <Container maxWidth="md">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Frequently Asked Questions
            </Typography>
            <Typography variant="h6" sx={{ color: '#64748b' }}>
              Got questions? We've got answers
            </Typography>
          </Box>
        </motion.div>

        <Box>
          {faqs.map((faq, index) => (
            <motion.div
              key={faq.question}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              viewport={{ once: true }}
            >
              <Accordion
                expanded={expanded === `panel${index}`}
                onChange={handleChange(`panel${index}`)}
                sx={{
                  mb: 2,
                  borderRadius: 2,
                  border: '1px solid #e2e8f0',
                  boxShadow: 'none',
                  '&:before': { display: 'none' },
                  '&.Mui-expanded': {
                    boxShadow: '0 4px 20px rgba(102, 126, 234, 0.1)',
                    borderColor: '#667eea',
                  },
                }}
              >
                <AccordionSummary
                  expandIcon={<ExpandMore sx={{ color: '#667eea' }} />}
                  sx={{
                    '& .MuiAccordionSummary-content': {
                      my: 2,
                    },
                  }}
                >
                  <Typography variant="h6" sx={{ fontWeight: 600, color: '#1e293b' }}>
                    {faq.question}
                  </Typography>
                </AccordionSummary>
                <AccordionDetails sx={{ pt: 0, pb: 3 }}>
                  <Typography variant="body1" sx={{ color: '#64748b', lineHeight: 1.7 }}>
                    {faq.answer}
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </motion.div>
          ))}
        </Box>
      </Container>
    </Box>
  );
};

export default FAQSection;
