import React from 'react';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Grid, Card, Avatar } from '@mui/material';
import { PersonAdd, Settings, Payment, Assessment } from '@mui/icons-material';

const steps = [
  {
    icon: <PersonAdd sx={{ fontSize: 32 }} />,
    title: 'Add Employees',
    description: 'Upload employee data via CSV or register them individually. Import from existing systems seamlessly.',
    number: '01',
  },
  {
    icon: <Settings sx={{ fontSize: 32 }} />,
    title: 'Configure Payroll Rules',
    description: 'Set up salary structures, allowances, deductions, and tax configurations for Uganda and Kenya.',
    number: '02',
  },
  {
    icon: <Payment sx={{ fontSize: 32 }} />,
    title: 'Process Payroll',
    description: 'Run payroll with a single click. System calculates everything automatically with 100% accuracy.',
    number: '03',
  },
  {
    icon: <Assessment sx={{ fontSize: 32 }} />,
    title: 'Review & Generate Reports',
    description: 'Instantly generate statutory reports (KRA, NSSF, NHIF) and financial summaries for compliance.',
    number: '04',
  },
];

const HowItWorksSection: React.FC = () => {
  return (
    <Box sx={{ py: { xs: 8, md: 12 }, background: 'white' }}>
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              How It Works
            </Typography>
            <Typography variant="h6" sx={{ color: '#64748b', maxWidth: 700, mx: 'auto' }}>
              Get started in 4 simple steps
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={4}>
          {steps.map((step, index) => (
            <Grid size={{ xs: 12, sm: 6, md: 3 }} key={step.title}>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card
                  sx={{
                    height: '100%',
                    p: 3,
                    borderRadius: 3,
                    border: '1px solid #e2e8f0',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                    position: 'relative',
                    textAlign: 'center',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.15)',
                    },
                  }}
                >
                  <Typography
                    variant="h3"
                    sx={{
                      position: 'absolute',
                      top: -20,
                      right: 20,
                      fontWeight: 900,
                      color: '#e2e8f0',
                      fontSize: '4rem',
                    }}
                  >
                    {step.number}
                  </Typography>

                  <Avatar
                    sx={{
                      width: 72,
                      height: 72,
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      mb: 2,
                      mx: 'auto',
                    }}
                  >
                    {step.icon}
                  </Avatar>

                  <Typography variant="h6" sx={{ fontWeight: 700, mb: 1.5, color: '#1e293b' }}>
                    {step.title}
                  </Typography>

                  <Typography variant="body2" sx={{ color: '#64748b', lineHeight: 1.7 }}>
                    {step.description}
                  </Typography>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default HowItWorksSection;
