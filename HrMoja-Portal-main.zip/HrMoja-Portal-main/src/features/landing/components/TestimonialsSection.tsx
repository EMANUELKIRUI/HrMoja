import React from 'react';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Grid, Card, Avatar, Stack, Chip } from '@mui/material';
import { Star, VerifiedUser } from '@mui/icons-material';

const testimonials = [
  {
    name: 'Sarah Kimani',
    title: 'HR Director',
    company: 'Aga Khan Hospital',
    quote: 'HRMoja transformed our payroll processing. What used to take 3 days now takes 30 minutes. The compliance reports are a lifesaver.',
    avatar: 'SK',
  },
  {
    name: 'John Ochieng',
    title: 'Finance Manager',
    company: 'UAP Insurance',
    quote: 'The multi-country payroll feature handles our Kenya and Uganda operations seamlessly. Tax calculations are always accurate.',
    avatar: 'JO',
  },
  {
    name: 'Mary Wanjiru',
    title: 'CEO',
    company: 'Mediheal Group',
    quote: 'Employee self-service reduced HR queries by 80%. Our staff love the mobile app and instant payslip access.',
    avatar: 'MW',
  },
];

const trustBadges = [
  { label: 'GDPR Compliant', icon: <VerifiedUser /> },
  { label: 'ISO 27001 Certified', icon: <VerifiedUser /> },
  { label: 'SOC 2 Type II', icon: <VerifiedUser /> },
];

const TestimonialsSection: React.FC = () => {
  return (
    <Box sx={{ py: { xs: 8, md: 12 }, background: '#f8fafc' }}>
      <Container maxWidth="lg">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Box sx={{ textAlign: 'center', mb: 8 }}>
            <Typography
              variant="h2"
              sx={{
                fontWeight: 800,
                mb: 2,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Trusted by Leading Organizations
            </Typography>
            <Typography variant="h6" sx={{ color: '#64748b', maxWidth: 700, mx: 'auto' }}>
              See what our customers say about HRMoja
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={4} sx={{ mb: 8 }}>
          {testimonials.map((testimonial, index) => (
            <Grid size={{ xs: 12, md: 4 }} key={testimonial.name}>
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card
                  sx={{
                    height: '100%',
                    p: 4,
                    borderRadius: 3,
                    border: '1px solid #e2e8f0',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.15)',
                    },
                  }}
                >
                  <Stack direction="row" spacing={0.5} sx={{ mb: 2 }}>
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} sx={{ color: '#fbbf24', fontSize: 20 }} />
                    ))}
                  </Stack>

                  <Typography
                    variant="body1"
                    sx={{
                      color: '#1e293b',
                      mb: 3,
                      lineHeight: 1.7,
                      fontStyle: 'italic',
                    }}
                  >
                    "{testimonial.quote}"
                  </Typography>

                  <Stack direction="row" spacing={2} alignItems="center">
                    <Avatar
                      sx={{
                        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        width: 48,
                        height: 48,
                        fontWeight: 700,
                      }}
                    >
                      {testimonial.avatar}
                    </Avatar>
                    <Box>
                      <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#1e293b' }}>
                        {testimonial.name}
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#64748b' }}>
                        {testimonial.title}, {testimonial.company}
                      </Typography>
                    </Box>
                  </Stack>
                </Card>
              </motion.div>
            </Grid>
          ))}
        </Grid>

        {/* Trust Badges */}
        <Box sx={{ textAlign: 'center' }}>
          <Stack
            direction={{ xs: 'column', sm: 'row' }}
            spacing={3}
            justifyContent="center"
            alignItems="center"
          >
            {trustBadges.map((badge, index) => (
              <motion.div
                key={badge.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Chip
                  icon={badge.icon}
                  label={badge.label}
                  sx={{
                    py: 2.5,
                    px: 2,
                    fontSize: '1rem',
                    fontWeight: 600,
                    background: 'white',
                    border: '2px solid #667eea',
                    color: '#667eea',
                    '& .MuiChip-icon': {
                      color: '#667eea',
                    },
                  }}
                />
              </motion.div>
            ))}
          </Stack>
        </Box>
      </Container>
    </Box>
  );
};

export default TestimonialsSection;
