import { useEffect } from 'react';

const SEOHelmet = () => {
  useEffect(() => {
    // Set page title
    document.title = 'HRMoja - Modern HR & Payroll Management for Healthcare & Insurance';

    // Function to update or create meta tag
    const setMetaTag = (name: string, content: string, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attribute}="${name}"]`);
      
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, name);
        document.head.appendChild(element);
      }
      
      element.setAttribute('content', content);
    };

    // Primary Meta Tags
    setMetaTag('description', 'Simplify HR and payroll management with HRMoja. Automate payroll processing, ensure compliance with KRA, NSSF, NHIF. Built for Healthcare, Insurance, and modern enterprises in Kenya & Uganda.');
    setMetaTag('keywords', 'payroll software, HR management, Kenya payroll, Uganda payroll, NSSF, NHIF, KRA, PAYE, healthcare payroll, insurance payroll, employee management, cloud HR');
    setMetaTag('author', 'HRMoja');
    setMetaTag('robots', 'index, follow');

    // Open Graph / Facebook
    setMetaTag('og:type', 'website', true);
    setMetaTag('og:url', 'https://hrmoja.com/', true);
    setMetaTag('og:title', 'HRMoja - Modern HR & Payroll Management for Healthcare & Insurance', true);
    setMetaTag('og:description', 'Simplify HR and payroll management with HRMoja. Automate payroll processing, ensure compliance with KRA, NSSF, NHIF.', true);
    setMetaTag('og:image', 'https://hrmoja.com/og-image.png', true);

    // Twitter
    setMetaTag('twitter:card', 'summary_large_image', true);
    setMetaTag('twitter:url', 'https://hrmoja.com/', true);
    setMetaTag('twitter:title', 'HRMoja - Modern HR & Payroll Management for Healthcare & Insurance', true);
    setMetaTag('twitter:description', 'Simplify HR and payroll management with HRMoja. Automate payroll processing, ensure compliance with KRA, NSSF, NHIF.', true);
    setMetaTag('twitter:image', 'https://hrmoja.com/twitter-image.png', true);

    // Additional Meta Tags
    setMetaTag('theme-color', '#667eea');
    setMetaTag('mobile-web-app-capable', 'yes');
    setMetaTag('apple-mobile-web-app-capable', 'yes');
    setMetaTag('apple-mobile-web-app-status-bar-style', 'default');
    setMetaTag('apple-mobile-web-app-title', 'HRMoja');
  }, []);

  return null;
};

export default SEOHelmet;
