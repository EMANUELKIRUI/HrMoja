import React, { useMemo, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Box, Container, Typography, Button, Stack, Grid } from '@mui/material';
import { ArrowForward, PlayCircleOutline } from '@mui/icons-material';

const StarfieldBackground: React.FC<{ count?: number }> = ({ count = 80 }) => {
  // Generate stationary twinkling stars (60% of total)
  const stationaryStars = useMemo(() => {
    return Array.from({ length: Math.floor(count * 0.6) }).map((_, i) => {
      const size = Math.random() < 0.5 ? 2 : Math.random() < 0.8 ? 3 : 4;
      const x = Math.random() * 100;
      const y = Math.random() * 100;
      const baseOpacity = 0.8 + Math.random() * 0.2; // 0.6 to 1.0 (brighter)
      const twinkleDuration = 2 + Math.random() * 4;
      const twinkleDelay = Math.random() * 5;
      const blur = Math.random() < 0.3 ? 1 : 0; // 30% have glow
      
      return {
        x,
        y,
        size,
        baseOpacity,
        twinkleDuration,
        twinkleDelay,
        blur,
        id: `static-${i}`,
      };
    });
  }, [count]);

  // Generate moving/drifting stars (40% of total)
  const movingStars = useMemo(() => {
    return Array.from({ length: Math.floor(count * 0.4) }).map((_, i) => {
      const size = Math.random() < 0.6 ? 2 : 3;
      const startX = Math.random() * 100;
      const startY = Math.random() * 100;
      const baseOpacity = 0.8 + Math.random() * 0.2; // 0.8 to 1.0
      const driftDuration = 15 + Math.random() * 25; // 15-40 seconds slow drift
      const driftDelay = Math.random() * 10;
      const driftDistance = 20 + Math.random() * 30; // drift 20-50% across screen
      const driftAngle = Math.random() * 360; // random direction
      const twinkleDuration = 3 + Math.random() * 5;
      const twinkleDelay = Math.random() * 5;
      
      return {
        startX,
        startY,
        size,
        baseOpacity,
        driftDuration,
        driftDelay,
        driftDistance,
        driftAngle,
        twinkleDuration,
        twinkleDelay,
        id: `moving-${i}`,
      };
    });
  }, [count]);

  // Generate realistic comets
  const comets = useMemo(() => {
    return Array.from({ length: 3 }).map((_, i) => {
      // Start from random position in top 40%
      const startX = 20 + Math.random() * 60;
      const startY = Math.random() * 40;
      // Realistic diagonal trajectory (mostly top-right to bottom-left)
      const angle = Math.random() < 0.7 ? 135 + Math.random() * 20 : 45 + Math.random() * 20;
      const length = 60 + Math.random() * 80; // 60-140px trail
      const duration = 3 + Math.random() * 2; // 3-5 seconds
      const delay = Math.random() * 20; // random timing
      const brightness = 0.8 + Math.random() * 0.2; // varied brightness
      
      return { startX, startY, angle, length, duration, delay, brightness, id: i };
    });
  }, []);

  return (
    <>
      {/* Stationary twinkling stars */}
      {stationaryStars.map((star) => (
        <Box
          key={star.id}
          sx={{
            position: 'absolute',
            top: `${star.y}%`,
            left: `${star.x}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            borderRadius: '50%',
            background: 'white',
            opacity: star.baseOpacity,
            filter: star.blur ? 'blur(0.5px)' : 'none',
            animation: `twinkle${star.id} ${star.twinkleDuration}s ease-in-out infinite`,
            animationDelay: `${star.twinkleDelay}s`,
            boxShadow: star.size > 2 
              ? '0 0 3px rgba(255,255,255,0.8), 0 0 6px rgba(255,255,255,0.4)' 
              : '0 0 2px rgba(255,255,255,0.6)',
            [`@keyframes twinkle${star.id}`]: {
              '0%, 100%': { 
                opacity: star.baseOpacity,
                transform: 'scale(1)',
              },
              '50%': { 
                opacity: Math.max(0.3, star.baseOpacity - 0.4),
                transform: 'scale(0.85)',
              },
            },
          }}
        />
      ))}

      {/* Moving/drifting stars */}
      {movingStars.map((star) => {
        const endX = star.startX + star.driftDistance * Math.cos(star.driftAngle * Math.PI / 180);
        const endY = star.startY + star.driftDistance * Math.sin(star.driftAngle * Math.PI / 180);
        
        return (
          <Box
            key={star.id}
            sx={{
              position: 'absolute',
              top: `${star.startY}%`,
              left: `${star.startX}%`,
              width: `${star.size}px`,
              height: `${star.size}px`,
              borderRadius: '50%',
              background: 'white',
              opacity: star.baseOpacity,
              boxShadow: '0 0 2px rgba(255,255,255,0.7)',
              animation: `drift${star.id} ${star.driftDuration}s linear infinite, twinkleDrift${star.id} ${star.twinkleDuration}s ease-in-out infinite`,
              animationDelay: `${star.driftDelay}s, ${star.twinkleDelay}s`,
              [`@keyframes drift${star.id}`]: {
                '0%': {
                  top: `${star.startY}%`,
                  left: `${star.startX}%`,
                },
                '100%': {
                  top: `${endY}%`,
                  left: `${endX}%`,
                },
              },
              [`@keyframes twinkleDrift${star.id}`]: {
                '0%, 100%': { 
                  opacity: star.baseOpacity,
                },
                '50%': { 
                  opacity: Math.max(0.3, star.baseOpacity - 0.3),
                },
              },
            }}
          />
        );
      })}
      
      {/* Realistic shooting stars/comets */}
      {comets.map((comet) => (
        <Box
          key={comet.id}
          sx={{
            position: 'absolute',
            top: `${comet.startY}%`,
            left: `${comet.startX}%`,
            width: `${comet.length}px`,
            height: '2px',
            background: `linear-gradient(90deg, 
              rgba(255,255,255,0) 0%, 
              rgba(255,255,255,${comet.brightness * 0.3}) 20%,
              rgba(255,255,255,${comet.brightness * 0.7}) 60%, 
              rgba(255,255,255,${comet.brightness}) 100%)`,
            borderRadius: '1px',
            transform: `rotate(${comet.angle}deg)`,
            transformOrigin: 'center right',
            animation: `shoot${comet.id} ${comet.duration}s ease-out infinite`,
            animationDelay: `${comet.delay}s`,
            opacity: 0,
            boxShadow: `0 0 8px rgba(255,255,255,${comet.brightness}), 0 0 4px rgba(255,255,255,${comet.brightness * 0.5})`,
            [`@keyframes shoot${comet.id}`]: {
              '0%': {
                opacity: 0,
                transform: `rotate(${comet.angle}deg) translateX(0)`,
              },
              '5%': {
                opacity: comet.brightness,
              },
              '95%': {
                opacity: comet.brightness * 0.8,
              },
              '100%': {
                opacity: 0,
                transform: `rotate(${comet.angle}deg) translateX(-150vw)`,
              },
            },
          }}
        />
      ))}
    </>
  );
};

const HeroSection: React.FC = () => {
  const navigate = useNavigate();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isMouseInHero, setIsMouseInHero] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseEnter = () => setIsMouseInHero(true);
    const handleMouseLeave = () => setIsMouseInHero(false);

    const heroSection = document.getElementById('hero-section');
    if (heroSection) {
      heroSection.addEventListener('mousemove', handleMouseMove);
      heroSection.addEventListener('mouseenter', handleMouseEnter);
      heroSection.addEventListener('mouseleave', handleMouseLeave);
    }

    return () => {
      if (heroSection) {
        heroSection.removeEventListener('mousemove', handleMouseMove);
        heroSection.removeEventListener('mouseenter', handleMouseEnter);
        heroSection.removeEventListener('mouseleave', handleMouseLeave);
      }
    };
  }, []);

  return (
    <Box
      id="hero-section"
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        background: 'linear-gradient(135deg,rgb(147, 156, 46) 0%,rgb(114, 84, 143) 50%,rgb(63, 168, 91) 100%)',
        position: 'relative',
        overflow: 'hidden',
        pt: { xs: 12, md: 16 },
        pb: { xs: 8, md: 12 },
      }}
    >
      {/* Animated Gradient Blobs */}
      <Box
        sx={{
          position: 'absolute',
          top: '-10%',
          right: '-5%',
          width: '600px',
          height: '600px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(176, 106, 240, 0.4) 0%, transparent 70%)',
          filter: 'blur(60px)',
          animation: 'float 20s ease-in-out infinite',
          '@keyframes float': {
            '0%, 100%': { transform: 'translate(0, 0) scale(1)' },
            '33%': { transform: 'translate(30px, -30px) scale(1.1)' },
            '66%': { transform: 'translate(-30px, 30px) scale(0.9)' },
          },
        }}
      />
      <Box
        sx={{
          position: 'absolute',
          bottom: '-10%',
          left: '-5%',
          width: '500px',
          height: '500px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(248, 103, 176, 0.4) 0%, transparent 70%)',
          filter: 'blur(60px)',
          animation: 'float 25s ease-in-out infinite reverse',
        }}
      />
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(99, 102, 241, 0.3) 0%, transparent 70%)',
          filter: 'blur(80px)',
          animation: 'pulse 15s ease-in-out infinite',
          '@keyframes pulse': {
            '0%, 100%': { transform: 'translate(-50%, -50%) scale(1)' },
            '50%': { transform: 'translate(-50%, -50%) scale(1.2)' },
          },
        }}
      />

      {/* Animated Particles/Stars */}
      <StarfieldBackground count={60} />

      {/* Cursor tracking glow effect */}
      {isMouseInHero && (
        <Box
          sx={{
            position: 'fixed',
            left: mousePosition.x,
            top: mousePosition.y,
            width: '400px',
            height: '400px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 30%, transparent 70%)',
            pointerEvents: 'none',
            transform: 'translate(-50%, -50%)',
            transition: 'opacity 0.3s ease',
            zIndex: 2,
            mixBlendMode: 'screen',
          }}
        />
      )}

      {/* Cursor trail particles */}
      {isMouseInHero && (
        <>
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0 }}
              animate={{
                opacity: [0, 0.6, 0],
                scale: [0, 1, 0],
                x: mousePosition.x,
                y: mousePosition.y,
              }}
              transition={{
                duration: 1,
                delay: i * 0.1,
                repeat: Infinity,
                repeatDelay: 0.2,
              }}
              style={{
                position: 'fixed',
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: 'rgba(255,255,255,0.8)',
                pointerEvents: 'none',
                transform: 'translate(-50%, -50%)',
                zIndex: 2,
                boxShadow: '0 0 10px rgba(255,255,255,0.6)',
              }}
            />
          ))}
        </>
      )}

      <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 1 }}>
        <Grid container spacing={6} alignItems="center">
          <Grid size={{ xs: 12, md: 7 }}>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Typography
                variant="h1"
                sx={{
                  fontWeight: 900,
                  fontSize: { xs: '2.5rem', md: '3.5rem', lg: '4rem' },
                  color: 'white',
                  mb: 3,
                  lineHeight: 1.2,
                }}
              >
                Simplify HR and Payroll Management — All in One Platform
              </Typography>

              <Typography
                variant="h5"
                sx={{
                  color: 'rgba(255, 255, 255, 0.95)',
                  mb: 5,
                  fontWeight: 400,
                  lineHeight: 1.6,
                }}
              >
                Automate payroll, manage employees, and stay compliant effortlessly. 
                Built for industries and enterprises.
              </Typography>

              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={3}>
                <Button
                  variant="contained"
                  size="large"
                  endIcon={<ArrowForward />}
                  onClick={() => navigate('/login')}
                  sx={{
                    px: 5,
                    py: 2,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    borderRadius: 3,
                    background: 'white',
                    color: '#667eea',
                    boxShadow: '0 8px 32px rgba(0,0,0,0.2)',
                    '&:hover': {
                      background: 'rgba(255, 255, 255, 0.95)',
                      transform: 'translateY(-2px)',
                      boxShadow: '0 12px 40px rgba(0,0,0,0.3)',
                    },
                    transition: 'all 0.3s ease',
                  }}
                >
                  Request a Demo
                </Button>

                <Button
                  variant="outlined"
                  size="large"
                  startIcon={<PlayCircleOutline />}
                  sx={{
                    px: 5,
                    py: 2,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    borderRadius: 3,
                    borderWidth: 2,
                    borderColor: 'white',
                    color: 'white',
                    '&:hover': {
                      borderWidth: 2,
                      background: 'rgba(255, 255, 255, 0.1)',
                      borderColor: 'white',
                    },
                  }}
                >
                  Watch Video
                </Button>
              </Stack>
            </motion.div>
          </Grid>

          <Grid size={{ xs: 12, md: 5 }}>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Box
                sx={{
                  background: 'rgba(255, 255, 255, 0.12)',
                  backdropFilter: 'blur(20px)',
                  borderRadius: 5,
                  p: 4,
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                }}
              >
                <Stack spacing={3}>
                  {[
                    { value: '10K+', label: 'Active Users', color: '#60a5fa' },
                    { value: '50+', label: 'Organizations', color: '#c084fc' },
                    { value: '99.9%', label: 'Uptime SLA', color: '#f472b6' },
                    { value: '24/7', label: 'Support Available', color: '#34d399' },
                  ].map((stat, index) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          p: 2.5,
                          background: 'rgba(255, 255, 255, 0.15)',
                          borderRadius: 3,
                          border: '1px solid rgba(255, 255, 255, 0.2)',
                          backdropFilter: 'blur(10px)',
                          transition: 'all 0.3s ease',
                          '&:hover': {
                            background: 'rgba(255, 255, 255, 0.2)',
                            transform: 'translateX(8px)',
                            boxShadow: `0 8px 32px ${stat.color}40`,
                          },
                        }}
                      >
                        <Typography 
                          variant="h4" 
                          sx={{ 
                            fontWeight: 900, 
                            color: 'white',
                            textShadow: `0 0 20px ${stat.color}`,
                          }}
                        >
                          {stat.value}
                        </Typography>
                        <Typography variant="body1" sx={{ color: 'rgba(255, 255, 255, 0.95)', fontWeight: 500 }}>
                          {stat.label}
                        </Typography>
                      </Box>
                    </motion.div>
                  ))}
                </Stack>
              </Box>
            </motion.div>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default HeroSection;
