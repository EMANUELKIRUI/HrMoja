import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, AppBar, Toolbar, Container, Typography, Button, IconButton, Avatar, Stack } from '@mui/material';
import { Menu as MenuIcon, Rocket } from '@mui/icons-material';
import SEOHelmet from './components/SEOHelmet';
import StructuredData from './components/StructuredData';
import HeroSection from './components/HeroSection';
import FeaturesSection from './components/FeaturesSection';
import TestimonialsSection from './components/TestimonialsSection';
import HowItWorksSection from './components/HowItWorksSection';
import PricingSection from './components/PricingSection';
import IntegrationsSection from './components/IntegrationsSection';
import FAQSection from './components/FAQSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Box>
      <SEOHelmet />
      <StructuredData />
      {/* Navigation Header */}
      <AppBar
        position="fixed"
        elevation={scrolled ? 8 : 0}
        sx={{
          background: scrolled ? 'rgba(255, 255, 255, 0.95)' : 'transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          borderBottom: scrolled ? '1px solid rgba(102, 126, 234, 0.15)' : 'none',
          boxShadow: scrolled ? '0 2px 10px rgba(0,0,0,0.05)' : 'none',
        }}
      >
        <Container maxWidth="lg">
          <Toolbar sx={{ px: { xs: 0 } }}>
            <Stack direction="row" alignItems="center" spacing={1} sx={{ flexGrow: 1 }}>
              <Avatar
                sx={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  width: 40,
                  height: 40,
                }}
              >
                <Rocket />
              </Avatar>
              <Typography
                variant="h5"
                sx={{
                  fontWeight: 800,
                  background: 'linear-gradient(135deg, #667eea 0%, #f093fb 100%)',
                  backgroundClip: 'text',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  cursor: 'pointer',
                }}
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              >
                HRMoja
              </Typography>
            </Stack>

            <Stack direction="row" spacing={2} sx={{ display: { xs: 'none', md: 'flex' } }}>
              <Button
                onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
                sx={{ color: scrolled ? '#1e293b' : 'white', fontWeight: 500 }}
              >
                Features
              </Button>
              <Button
                onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
                sx={{ color: scrolled ? '#1e293b' : 'white', fontWeight: 500 }}
              >
                Pricing
              </Button>
              <Button
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                sx={{ color: scrolled ? '#1e293b' : 'white', fontWeight: 500 }}
              >
                Contact
              </Button>
            </Stack>

            <Button
              variant="contained"
              onClick={() => navigate('/login')}
              sx={{
                ml: 3,
                px: 4,
                py: 1.5,
                borderRadius: 3,
                fontWeight: 600,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                boxShadow: '0 4px 20px rgba(102, 126, 234, 0.4)',
                '&:hover': {
                  background: 'linear-gradient(135deg, #764ba2 0%, #667eea 100%)',
                  transform: 'translateY(-2px)',
                  boxShadow: '0 6px 30px rgba(102, 126, 234, 0.6)',
                },
                transition: 'all 0.3s ease',
              }}
            >
              Sign In
            </Button>

            <IconButton sx={{ display: { xs: 'flex', md: 'none' }, color: scrolled ? '#1e293b' : 'white', ml: 2 }}>
              <MenuIcon />
            </IconButton>
          </Toolbar>
        </Container>
      </AppBar>

      {/* Page Sections */}
      <HeroSection />
      <FeaturesSection />
      <TestimonialsSection />
      <HowItWorksSection />
      <PricingSection />
      <IntegrationsSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </Box>
  );
};

export default LandingPage;
