# HRMoja Landing Page

## Overview
Professional, conversion-focused landing page for HRMoja HR & Payroll Management System. Built with React, TypeScript, Material-UI v6, and Framer Motion.

## Structure

```
landing/
├── LandingPage.tsx              # Main orchestrator component
├── components/
│   ├── HeroSection.tsx          # Hero with CTA & stats
│   ├── FeaturesSection.tsx      # 6 core features
│   ├── ProductPreviewSection.tsx # Demo video/screenshots
│   ├── TestimonialsSection.tsx  # Client testimonials + trust badges
│   ├── HowItWorksSection.tsx    # 4-step workflow
│   ├── PricingSection.tsx       # 3 pricing tiers
│   ├── IntegrationsSection.tsx  # Third-party integrations
│   ├── FAQSection.tsx           # Accordion FAQs
│   ├── ContactSection.tsx       # Contact form + info
│   ├── Footer.tsx               # Footer with links
│   ├── SEOHelmet.tsx            # Meta tags for SEO
│   └── StructuredData.tsx       # Schema.org JSON-LD
└── README.md                    # This file
```

## Features Implemented

### ✅ Content Sections
- **Hero Section**: Compelling headline, dual CTAs, live stats
- **Features**: 6 core features with icons and descriptions
- **Product Preview**: Placeholder for demo video/screenshots
- **Testimonials**: 3 client testimonials with trust badges (SOC 2, ISO, GDPR)
- **How It Works**: 4-step process visualization
- **Pricing**: 3 tiers (Starter, Professional, Enterprise)
- **Integrations**: Accounting, Banking, Compliance, HR tools
- **FAQs**: 8 common questions with accordion UI
- **Contact**: Form with validation + contact cards
- **Footer**: Comprehensive footer with social links

### ✅ SEO Optimization
- **Meta Tags**: Title, description, keywords, author, robots
- **Open Graph**: Facebook sharing optimization
- **Twitter Cards**: Twitter sharing optimization
- **Structured Data**: 
  - Organization schema
  - Software Application schema
  - FAQ schema
  - Service schema

### ✅ Design
- **Light Theme**: Clean white background with purple gradients
- **Color Palette**: #667eea (primary), #764ba2, #f093fb (accents)
- **Typography**: Modern, clean hierarchy
- **Animations**: Smooth scroll reveals with Framer Motion
- **Responsive**: Mobile-first design (xs, sm, md, lg breakpoints)

### ✅ System-Aware Content
- Multi-country payroll (Uganda & Kenya)
- KRA, NSSF, NHIF, PAYE compliance
- 3-level approval workflow
- Bank file management
- Healthcare & Insurance industry focus

## Technical Details

### Dependencies
- React 19.2.0
- Material-UI v6 (Grid2 API)
- Framer Motion (animations)
- React Router (navigation)
- TypeScript (type safety)

### Performance Optimizations
- Lazy loading sections with `viewport={{ once: true }}`
- Optimized animations with GPU acceleration
- Modular component architecture
- Tree-shaking friendly imports

### Accessibility
- Semantic HTML structure
- ARIA labels where needed
- Keyboard navigation support
- Proper heading hierarchy (h1 → h2 → h3)
- Color contrast ratios meet WCAG 2.1 AA

## Customization Guide

### Updating Content

**Hero Section** (`HeroSection.tsx`):
```typescript
// Update headline
<Typography variant="h1">
  Your New Headline Here
</Typography>

// Update stats
const stats = [
  { value: '10K+', label: 'Active Users' },
  // Add/modify stats
];
```

**Features** (`FeaturesSection.tsx`):
```typescript
const features = [
  {
    icon: <YourIcon />,
    title: 'Feature Title',
    description: 'Feature description',
  },
  // Add more features
];
```

**Pricing** (`PricingSection.tsx`):
```typescript
const plans = [
  {
    name: 'Plan Name',
    price: '$49',
    period: '/month',
    features: ['Feature 1', 'Feature 2'],
    popular: false,
  },
];
```

### Styling

**Color Scheme**:
```typescript
// Primary gradient
background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'

// Accent colors
#f093fb, #4facfe, #43e97b, #fa709a
```

**Typography**:
- H1: 4rem (desktop), 2.5rem (mobile)
- H2: 3rem
- Body: 1rem
- All weights: 400, 600, 700, 800, 900

### Adding Analytics

1. Install analytics package:
```bash
npm install @vercel/analytics
```

2. Add to `LandingPage.tsx`:
```typescript
import { Analytics } from '@vercel/analytics/react';

// In component
<Analytics />
```

### Image Optimization

**Recommended image specs**:
- Hero background: 1920x1080px, WebP format
- Product screenshots: 1440x900px, WebP format
- Testimonial avatars: 96x96px, WebP format
- OG image: 1200x630px, PNG/JPG
- Twitter image: 1200x600px, PNG/JPG

**Optimization tools**:
- [Squoosh](https://squoosh.app/) - Image compression
- [SVGOMG](https://jakearchibald.github.io/svgomg/) - SVG optimization

## Deployment Checklist

- [ ] Update meta tags with production URLs
- [ ] Add real demo video/screenshots
- [ ] Configure contact form backend endpoint
- [ ] Add Google Analytics/Tag Manager
- [ ] Test on multiple devices and browsers
- [ ] Run Lighthouse audit (target: 90+ score)
- [ ] Set up proper OG images
- [ ] Configure CORS for API calls
- [ ] Add sitemap.xml
- [ ] Add robots.txt
- [ ] Set up error tracking (Sentry)
- [ ] Enable gzip/brotli compression
- [ ] Configure CDN for assets
- [ ] Add SSL certificate

## Performance Targets

- **Lighthouse Score**: 90+ (all categories)
- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Time to Interactive**: < 3.5s
- **Cumulative Layout Shift**: < 0.1

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile Safari (iOS 13+)
- Chrome Mobile (Android 8+)

## Maintenance

### Regular Updates
- Review and update testimonials quarterly
- Update stats (users, organizations) monthly
- Check all links monthly
- Update pricing annually
- Review SEO meta tags quarterly

### Monitoring
- Track conversion rates (CTA clicks)
- Monitor form submissions
- Analyze scroll depth
- Track bounce rate
- Monitor page load times

## Contact

For questions or support:
- Email: support@hrmoja.com
- Phone: +254 735 023 566

---

**Last Updated**: November 2025
**Version**: 1.0.0
