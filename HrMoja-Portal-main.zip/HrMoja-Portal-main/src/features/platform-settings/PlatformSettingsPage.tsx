import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Card,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Button,
  Tabs,
  Tab,
  CircularProgress,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Public as PublicIcon,
  Payment as PaymentIcon,
  AccountBalance as BankIcon,
} from '@mui/icons-material';
import { countriesApi } from '../../api/countries.api';
import { referenceDataApi } from '../../api/reference-data.api';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel = ({ children, value, index }: TabPanelProps) => {
  return (
    <div hidden={value !== index}>
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
};

const PlatformSettingsPage = () => {
  const [tabValue, setTabValue] = useState(0);

  // Fetch Countries
  const { data: countriesData, isLoading: countriesLoading } = useQuery({
    queryKey: ['countries'],
    queryFn: countriesApi.getAllCountries,
  });

  // Fetch Pay Frequencies
  const { data: payFrequenciesData, isLoading: payFreqLoading } = useQuery({
    queryKey: ['payFrequencies'],
    queryFn: referenceDataApi.getAllPayFrequencies,
  });

  // Fetch Employment Types
  const { data: employmentTypesData, isLoading: empTypesLoading } = useQuery({
    queryKey: ['employmentTypes'],
    queryFn: referenceDataApi.getAllEmploymentTypes,
  });

  // Fetch Payment Methods
  const { data: paymentMethodsData, isLoading: payMethodsLoading } = useQuery({
    queryKey: ['paymentMethods'],
    queryFn: referenceDataApi.getAllPaymentMethods,
  });

  const countries = countriesData?.data || [];
  const payFrequencies = payFrequenciesData?.data || [];
  const employmentTypes = employmentTypesData?.data || [];
  const paymentMethods = paymentMethodsData?.data || [];

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Platform Settings
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Manage platform-wide configuration and reference data
        </Typography>
      </Box>

      <Card>
        <Tabs value={tabValue} onChange={(_, newValue) => setTabValue(newValue)} sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tab icon={<PublicIcon />} label="Countries" iconPosition="start" />
          <Tab icon={<PaymentIcon />} label="Pay Frequencies" iconPosition="start" />
          <Tab icon={<PaymentIcon />} label="Employment Types" iconPosition="start" />
          <Tab icon={<BankIcon />} label="Payment Methods" iconPosition="start" />
        </Tabs>

        {/* Countries Tab */}
        <TabPanel value={tabValue} index={0}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">Manage Countries</Typography>
            <Button variant="contained" startIcon={<AddIcon />} size="small">
              Add Country
            </Button>
          </Box>
          {countriesLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Code</TableCell>
                    <TableCell>Currency</TableCell>
                    <TableCell>Tax Rate</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {countries.map((country) => (
                    <TableRow key={country.id}>
                      <TableCell>{country.name}</TableCell>
                      <TableCell>{country.code}</TableCell>
                      <TableCell>
                        {country.currencySymbol} {country.currency}
                      </TableCell>
                      <TableCell>{country.taxRate ? `${country.taxRate}%` : '-'}</TableCell>
                      <TableCell>
                        <Chip
                          label={country.isActive ? 'Active' : 'Inactive'}
                          color={country.isActive ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="right">
                        <IconButton size="small" color="primary">
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </TabPanel>

        {/* Pay Frequencies Tab */}
        <TabPanel value={tabValue} index={1}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">Pay Frequencies</Typography>
            <Button variant="contained" startIcon={<AddIcon />} size="small">
              Add Pay Frequency
            </Button>
          </Box>
          {payFreqLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {payFrequencies.map((freq) => (
                    <TableRow key={freq.id}>
                      <TableCell>{freq.name}</TableCell>
                      <TableCell>{freq.description || '-'}</TableCell>
                      <TableCell>
                        <Chip
                          label={freq.isActive ? 'Active' : 'Inactive'}
                          color={freq.isActive ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="right">
                        <IconButton size="small" color="primary">
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </TabPanel>

        {/* Employment Types Tab */}
        <TabPanel value={tabValue} index={2}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">Employment Types</Typography>
            <Button variant="contained" startIcon={<AddIcon />} size="small">
              Add Employment Type
            </Button>
          </Box>
          {empTypesLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {employmentTypes.map((type) => (
                    <TableRow key={type.id}>
                      <TableCell>{type.name}</TableCell>
                      <TableCell>{type.description || '-'}</TableCell>
                      <TableCell>
                        <Chip
                          label={type.isActive ? 'Active' : 'Inactive'}
                          color={type.isActive ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="right">
                        <IconButton size="small" color="primary">
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </TabPanel>

        {/* Payment Methods Tab */}
        <TabPanel value={tabValue} index={3}>
          <Box sx={{ mb: 2 }}>
            <Typography variant="h6">Payment Methods</Typography>
            <Typography variant="body2" color="text.secondary">
              System-defined payment methods available for payroll processing
            </Typography>
          </Box>
          {payMethodsLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {paymentMethods.map((method) => (
                    <TableRow key={method.id}>
                      <TableCell>{method.name}</TableCell>
                      <TableCell>{method.description || '-'}</TableCell>
                      <TableCell>
                        <Chip
                          label={method.isActive ? 'Active' : 'Inactive'}
                          color={method.isActive ? 'success' : 'default'}
                          size="small"
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </TabPanel>
      </Card>
    </Box>
  );
};

export default PlatformSettingsPage;
