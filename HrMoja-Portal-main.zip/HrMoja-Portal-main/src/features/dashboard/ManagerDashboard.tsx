import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  useTheme,
  Grid,
  alpha,
  Stack,
  Chip,
  LinearProgress,
  Avatar,
} from '@mui/material';
import {
  People as PeopleIcon,
  AttachMoney as MoneyIcon,
  Assignment as AssignmentIcon,
  TrendingUp as TrendingUpIcon,
  CheckCircle as CheckCircleIcon,
  Assessment as AssessmentIcon,
} from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';
import { useQuery } from '@tanstack/react-query';
import { dashboardApi } from '../../api/dashboard.api';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  subtitle?: string;
}

const StatCard = ({ title, value, icon, color, subtitle }: StatCardProps) => {
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <Box sx={{ flex: 1 }}>
            <Typography color="text.secondary" variant="body2" fontWeight={500} gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" fontWeight="bold" sx={{ my: 1 }}>
              {value}
            </Typography>
            {subtitle && (
              <Typography variant="caption" color="text.secondary">
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box
            sx={{
              width: 56,
              height: 56,
              borderRadius: 2,
              background: `linear-gradient(135deg, ${color} 0%, ${alpha(color, 0.7)} 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 8px 16px ${alpha(color, 0.3)}`,
            }}
          >
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

const ManagerDashboard = () => {
  const { user } = useAuthStore();
  const theme = useTheme();

  // Fetch dashboard metrics
  const { data: metricsResponse, isLoading } = useQuery({
    queryKey: ['dashboardMetrics'],
    queryFn: dashboardApi.getMetrics,
  });

  const metrics = metricsResponse?.data;

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Transform payroll trend for chart
  const payrollTrendData = metrics?.payrollTrend?.map(item => ({
    month: item.month,
    budget: item.amount || 0,
  })) || [];

  // Transform employee trend for performance chart (using count as performance %)
  const employeeTrendData = metrics?.employeeTrend?.map((item, index) => ({
    month: item.month,
    performance: 85 + index * 2, // Mock performance growth
  })) || [];

  // Transform department distribution for pie chart
  const departmentData = metrics?.departmentDistribution?.map((dept, index) => {
    const colors = [theme.palette.primary.main, theme.palette.secondary.main, theme.palette.warning.main, theme.palette.success.main, theme.palette.info.main];
    return {
      name: dept.departmentName,
      value: dept.employeeCount,
      color: colors[index % colors.length],
    };
  }) || [];

  // Mock pending tasks (TODO: Implement when approval workflow is ready)
  const pendingTasks = [
    { title: 'Review Team Performance', dueDate: 'Today', priority: 'High', progress: 75 },
    { title: 'Approve Leave Requests', dueDate: 'Tomorrow', priority: 'Medium', progress: 40 },
    { title: 'Budget Planning Meeting', dueDate: 'In 2 days', priority: 'High', progress: 20 },
    { title: 'Monthly Report Submission', dueDate: 'In 3 days', priority: 'Medium', progress: 60 },
  ];

  // Mock team members (TODO: Implement when team hierarchy is ready)
  const teamMembers = [
    { name: 'Alice Johnson', role: 'Senior Developer', status: 'Active', avatar: 'AJ' },
    { name: 'Bob Smith', role: 'Developer', status: 'On Leave', avatar: 'BS' },
    { name: 'Carol White', role: 'Designer', status: 'Active', avatar: 'CW' },
    { name: 'David Brown', role: 'QA Engineer', status: 'Active', avatar: 'DB' },
  ];

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <Typography>Loading dashboard...</Typography>
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Welcome back, {user?.fullName}! 👋
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Manage employees, payroll, and organization operations
        </Typography>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Total Employees"
            value={metrics?.totalEmployees || 0}
            subtitle={`${metrics?.activeEmployees || 0} active, ${metrics?.inactiveEmployees || 0} inactive`}
            icon={<PeopleIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Monthly Payroll"
            value={formatCurrency(metrics?.monthlyPayroll || 0)}
            subtitle="Current month"
            icon={<MoneyIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Pending Tasks"
            value={metrics?.pendingTasks || 0}
            subtitle="Approvals and tasks"
            icon={<AssignmentIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.warning.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Team Performance"
            value={`${metrics?.teamPerformance || 0}%`}
            subtitle="Organization average"
            icon={<TrendingUpIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.info.main}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Team Performance Chart */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Team Performance Trend
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Average team performance over the last 6 months
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={employeeTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="performance"
                    stroke={theme.palette.primary.main}
                    strokeWidth={3}
                    dot={{ fill: theme.palette.primary.main, r: 5 }}
                    name="Performance %"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Pending Tasks */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Pending Tasks
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Tasks requiring your attention
              </Typography>
              <Stack spacing={2}>
                {pendingTasks.map((task, index) => (
                  <Box
                    key={index}
                    sx={{
                      p: 1.5,
                      bgcolor: 'background.default',
                      borderRadius: 1,
                      border: '1px solid',
                      borderColor: 'divider',
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="body2" fontWeight={600}>
                        {task.title}
                      </Typography>
                      <Chip
                        label={task.priority}
                        size="small"
                        color={task.priority === 'High' ? 'error' : 'default'}
                        sx={{ height: 20, fontSize: '0.7rem' }}
                      />
                    </Box>
                    <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
                      Due: {task.dueDate}
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={task.progress}
                      sx={{ height: 4, borderRadius: 2 }}
                    />
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* Department Distribution */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Department Distribution
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Employee distribution by department
              </Typography>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={departmentData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {departmentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Department Budget */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Department Budget
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Monthly budget utilization
              </Typography>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={payrollTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar
                    dataKey="budget"
                    fill={theme.palette.success.main}
                    radius={[8, 8, 0, 0]}
                    name="Budget (UGX)"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Team Members */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Team Members
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Your direct reports
              </Typography>
              <Stack spacing={2}>
                {teamMembers.map((member, index) => (
                  <Box key={index} sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Avatar
                      sx={{
                        width: 40,
                        height: 40,
                        background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                        fontWeight: 600,
                        fontSize: '0.875rem',
                      }}
                    >
                      {member.avatar}
                    </Avatar>
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="body2" fontWeight={600}>
                        {member.name}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {member.role}
                      </Typography>
                    </Box>
                    <Chip
                      label={member.status}
                      size="small"
                      color={member.status === 'Active' ? 'success' : 'default'}
                      sx={{ fontWeight: 500 }}
                    />
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* Quick Actions */}
        <Grid size={{ xs: 12 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Quick Actions
              </Typography>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<PeopleIcon />}
                    sx={{ py: 1.5 }}
                  >
                    Add Employee
                  </Button>
                </Grid>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<MoneyIcon />}
                    sx={{ py: 1.5 }}
                  >
                    Process Payroll
                  </Button>
                </Grid>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<CheckCircleIcon />}
                    sx={{ py: 1.5 }}
                  >
                    Approve Requests
                  </Button>
                </Grid>
                <Grid size={{ xs: 6, sm: 3 }}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<AssessmentIcon />}
                    sx={{ py: 1.5 }}
                  >
                    View Reports
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ManagerDashboard;
