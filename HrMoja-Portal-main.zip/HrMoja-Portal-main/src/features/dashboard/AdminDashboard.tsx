import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Stack,
  Chip,
  Avatar,
  alpha,
  useTheme,
  Grid,
} from '@mui/material';
import {
  People as PeopleIcon,
  Assignment as AssignmentIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  PersonAdd as PersonAddIcon,
} from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';
import { useQuery } from '@tanstack/react-query';
import { userManagementApi } from '../../api/user-management.api';
import { organizationsApi } from '../../api/organizations.api';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  subtitle?: string;
}

const StatCard = ({ title, value, icon, color, trend, subtitle }: StatCardProps) => {
  return (
    <Card
      sx={{
        height: '100%',
        position: 'relative',
        overflow: 'visible',
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <Box sx={{ flex: 1 }}>
            <Typography color="text.secondary" variant="body2" fontWeight={500} gutterBottom>
              {title}
            </Typography>
            <Typography variant="h3" fontWeight="bold" sx={{ mb: 1 }}>
              {value}
            </Typography>
            {subtitle && (
              <Typography variant="caption" color="text.secondary">
                {subtitle}
              </Typography>
            )}
            {trend && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mt: 1 }}>
                {trend.isPositive ? (
                  <TrendingUpIcon sx={{ fontSize: 18, color: 'success.main' }} />
                ) : (
                  <TrendingDownIcon sx={{ fontSize: 18, color: 'error.main' }} />
                )}
                <Typography
                  variant="body2"
                  color={trend.isPositive ? 'success.main' : 'error.main'}
                  fontWeight={600}
                >
                  {trend.value}%
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  vs last month
                </Typography>
              </Box>
            )}
          </Box>
          <Box
            sx={{
              width: 64,
              height: 64,
              borderRadius: 3,
              background: `linear-gradient(135deg, ${color} 0%, ${alpha(color, 0.7)} 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 8px 24px ${alpha(color, 0.3)}`,
            }}
          >
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

const AdminDashboard = () => {
  const { user } = useAuthStore();
  const theme = useTheme();

  // Fetch users data
  const { data: usersResponse } = useQuery({
    queryKey: ['users'],
    queryFn: userManagementApi.getAllUsers,
  });

  // Fetch organization data
  const { data: orgResponse } = useQuery({
    queryKey: ['organization', user?.organizationId],
    queryFn: () => organizationsApi.getOrganizationById(user?.organizationId!),
    enabled: !!user?.organizationId,
  });

  const users = usersResponse?.data || [];
  const organization = orgResponse?.data;
  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.active).length;
  const inactiveUsers = totalUsers - activeUsers;

  // Recent user management activities
  const recentActivities = [
    { user: 'Admin', action: 'Created new user account', time: '2 hours ago', avatar: 'AD' },
    { user: 'Admin', action: 'Updated user permissions', time: '5 hours ago', avatar: 'AD' },
    { user: 'Admin', action: 'Deactivated user account', time: '1 day ago', avatar: 'AD' },
    { user: 'Admin', action: 'Reset user password', time: '2 days ago', avatar: 'AD' },
  ];

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Welcome back, {user?.fullName}! 🔐
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Manage your organization and user access
        </Typography>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Total Users"
            value={totalUsers}
            subtitle="In your organization"
            icon={<PeopleIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Active Users"
            value={activeUsers}
            subtitle="Can access system"
            icon={<PeopleIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Inactive Users"
            value={inactiveUsers}
            subtitle="Locked or disabled"
            icon={<AssignmentIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.warning.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Organization Status"
            value={organization?.active ? 'Active' : 'Inactive'}
            subtitle="All systems operational"
            icon={<TrendingUpIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.info.main}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Organization Info */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Organization Management
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Manage your organization details
              </Typography>
              <Stack spacing={2}>
                <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Organization Name
                  </Typography>
                  <Typography variant="body1" fontWeight={600}>
                    {user?.organizationName || 'Your Organization'}
                  </Typography>
                </Box>
                <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Status
                  </Typography>
                  <Chip label="Active" color="success" size="small" />
                </Box>
                <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Email
                  </Typography>
                  <Typography variant="body1" fontWeight={600}>
                    {organization?.email || 'Not set'}
                  </Typography>
                </Box>
              </Stack>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3 }}
                onClick={() => window.location.href = '/organization'}
              >
                Manage Organization
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* User Management Overview */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                User Management
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Manage user access and permissions
              </Typography>
              <Stack spacing={2}>
                <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Total Users
                    </Typography>
                    <Typography variant="h6" fontWeight="bold" color="primary.main">
                      {totalUsers}
                    </Typography>
                  </Box>
                </Box>
                <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Active Users
                    </Typography>
                    <Typography variant="h6" fontWeight="bold" color="success.main">
                      {activeUsers}
                    </Typography>
                  </Box>
                </Box>
                <Box sx={{ p: 2, bgcolor: 'background.default', borderRadius: 1 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Inactive Users
                    </Typography>
                    <Typography variant="h6" fontWeight="bold" color="warning.main">
                      {inactiveUsers}
                    </Typography>
                  </Box>
                </Box>
              </Stack>
              <Button
                fullWidth
                variant="contained"
                sx={{ mt: 3 }}
                onClick={() => window.location.href = '/users'}
              >
                Manage Users
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Activity */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Recent Activity
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Latest actions in your organization
              </Typography>
              <Stack spacing={2}>
                {recentActivities.map((activity, index) => (
                  <Box key={index} sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <Avatar
                      sx={{
                        width: 40,
                        height: 40,
                        background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.secondary.main} 100%)`,
                        fontWeight: 600,
                        fontSize: '0.875rem',
                      }}
                    >
                      {activity.avatar}
                    </Avatar>
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="body2" fontWeight={500}>
                        {activity.user}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {activity.action}
                      </Typography>
                    </Box>
                    <Typography variant="caption" color="text.secondary">
                      {activity.time}
                    </Typography>
                  </Box>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* Quick Actions */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Quick Actions
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Common administrative tasks
              </Typography>
              <Grid container spacing={2}>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<PersonAddIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                    onClick={() => window.location.href = '/users'}
                  >
                    Add User
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<PeopleIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                    onClick={() => window.location.href = '/users'}
                  >
                    View Users
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<AssignmentIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                    onClick={() => window.location.href = '/settings'}
                  >
                    Organization Settings
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<TrendingUpIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                  >
                    Access Reports
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AdminDashboard;
