import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  useTheme,
  Grid,
  alpha,
  Stack,
} from '@mui/material';
import {
  Person as PersonIcon,
  CalendarToday as CalendarIcon,
  AttachMoney as MoneyIcon,
  Assignment as AssignmentIcon,
  Notifications as NotificationsIcon,
  EventAvailable as LeaveIcon,
} from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  subtitle?: string;
}

const StatCard = ({ title, value, icon, color, subtitle }: StatCardProps) => {
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <Box sx={{ flex: 1 }}>
            <Typography color="text.secondary" variant="body2" fontWeight={500} gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" fontWeight="bold" sx={{ my: 1 }}>
              {value}
            </Typography>
            {subtitle && (
              <Typography variant="caption" color="text.secondary">
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box
            sx={{
              width: 56,
              height: 56,
              borderRadius: 2,
              background: `linear-gradient(135deg, ${color} 0%, ${alpha(color, 0.7)} 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 8px 16px ${alpha(color, 0.3)}`,
            }}
          >
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

const EmployeeDashboard = () => {
  const { user } = useAuthStore();
  const theme = useTheme();

  return (
    <Box>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Welcome, {user?.fullName}! 👋
        </Typography>
        <Typography variant="body1" color="text.secondary">
          View your personal information and manage your profile
        </Typography>
      </Box>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Leave Balance"
            value="18"
            subtitle="Days remaining"
            icon={<LeaveIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="This Month Salary"
            value="UGX 2.5M"
            subtitle="Net pay"
            icon={<MoneyIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Pending Tasks"
            value="5"
            subtitle="Due this week"
            icon={<AssignmentIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.warning.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Notifications"
            value="3"
            subtitle="Unread"
            icon={<NotificationsIcon sx={{ color: 'white', fontSize: 28 }} />}
            color={theme.palette.info.main}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                My Profile
              </Typography>
              <Box sx={{ mt: 3 }}>
                <Stack spacing={2}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" color="text.secondary">Employee ID</Typography>
                    <Typography variant="body2" fontWeight={600}>EMP-{user?.id}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" color="text.secondary">Department</Typography>
                    <Typography variant="body2" fontWeight={600}>Engineering</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" color="text.secondary">Position</Typography>
                    <Typography variant="body2" fontWeight={600}>Software Developer</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" color="text.secondary">Email</Typography>
                    <Typography variant="body2" fontWeight={600}>{user?.email}</Typography>
                  </Box>
                </Stack>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Quick Actions
              </Typography>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                <Grid size={6}>
                  <Button fullWidth variant="outlined" startIcon={<LeaveIcon />} sx={{ py: 1.5 }}>
                    Apply Leave
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button fullWidth variant="outlined" startIcon={<MoneyIcon />} sx={{ py: 1.5 }}>
                    View Payslip
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button fullWidth variant="outlined" startIcon={<PersonIcon />} sx={{ py: 1.5 }}>
                    Update Profile
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button fullWidth variant="outlined" startIcon={<CalendarIcon />} sx={{ py: 1.5 }}>
                    My Schedule
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default EmployeeDashboard;
