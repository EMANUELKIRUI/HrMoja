import { useAuthStore } from '../../store/authStore';
import PlatformAdminDashboard from './PlatformAdminDashboard';
import AdminDashboard from './AdminDashboard';
import ManagerDashboard from './ManagerDashboard';
import EmployeeDashboard from './EmployeeDashboard';

const Dashboard = () => {
  const { hasRole } = useAuthStore();

  // 1. Platform Admin / Super Admin
  if (hasRole('PLATFORM_ADMIN') || hasRole('SUPER_ADMIN')) {
    return <PlatformAdminDashboard />;
  }

  // 2. Organization Admin
  if (hasRole('ADMIN')) {
    return <AdminDashboard />;
  }

  // 3. Managers (HR, Payroll, Finance, Department Managers)
  if (
    hasRole('HR_MANAGER') ||
    hasRole('PAYROLL_MANAGER') ||
    hasRole('FINANCE_MANAGER') ||
    hasRole('MANAGER')
  ) {
    return <ManagerDashboard />;
  }

  // 4. Employee (default)
  return <EmployeeDashboard />;
};

export default Dashboard;
