import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  useTheme,
  Grid,
  alpha,
} from '@mui/material';
import {
  Business as BusinessIcon,
  People as PeopleIcon,
  TrendingUp as TrendingUpIcon,
  Add as AddIcon,
  Settings as SettingsIcon,
} from '@mui/icons-material';
import { organizationsApi } from '../../api/organizations.api';
import { countriesApi } from '../../api/countries.api';
import RegisterOrganizationDialog from '../organizations/RegisterOrganizationDialog';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

// Mock data for Platform Admin charts
const organizationsGrowthData = [
  { month: 'Jan', count: 12 },
  { month: 'Feb', count: 15 },
  { month: 'Mar', count: 18 },
  { month: 'Apr', count: 22 },
  { month: 'May', count: 28 },
  { month: 'Jun', count: 32 },
];

const userGrowthData = [
  { month: 'Jan', users: 450 },
  { month: 'Feb', users: 520 },
  { month: 'Mar', users: 610 },
  { month: 'Apr', users: 720 },
  { month: 'May', users: 890 },
  { month: 'Jun', users: 1025 },
];


interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  color: string;
  subtitle?: string;
}

const StatCard = ({ title, value, icon, color, subtitle }: StatCardProps) => {
  return (
    <Card
      sx={{
        height: '100%',
        position: 'relative',
        overflow: 'visible',
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
          <Box sx={{ flex: 1 }}>
            <Typography color="text.secondary" variant="body2" fontWeight={500} gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" fontWeight="bold" sx={{ my: 1 }}>
              {value}
            </Typography>
            {subtitle && (
              <Typography variant="caption" color="text.secondary">
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box
            sx={{
              width: 64,
              height: 64,
              borderRadius: 2,
              background: `linear-gradient(135deg, ${color} 0%, ${alpha(color, 0.7)} 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 8px 16px ${alpha(color, 0.3)}`,
            }}
          >
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

const PlatformAdminDashboard = () => {
  const theme = useTheme();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  // Fetch organizations data
  const { data: orgsResponse } = useQuery({
    queryKey: ['organizations'],
    queryFn: organizationsApi.getAllOrganizations,
  });

  // Fetch countries data
  const { data: countriesResponse } = useQuery({
    queryKey: ['countries'],
    queryFn: countriesApi.getActiveCountries,
  });

  const organizations = orgsResponse?.data || [];
  const countries = countriesResponse?.data || [];
  const totalOrganizations = organizations.length;
  const activeOrganizations = organizations.filter(org => org.active).length;
  const totalCountries = countries.length;

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight="bold" gutterBottom>
          Platform Administration 🌐
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Monitor and manage all organizations on the platform
        </Typography>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Total Organizations"
            value={totalOrganizations.toString()}
            subtitle={`${activeOrganizations} active`}
            icon={<BusinessIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Active Organizations"
            value={activeOrganizations.toString()}
            subtitle="Currently active"
            icon={<PeopleIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="Countries Supported"
            value={totalCountries.toString()}
            subtitle={`${countries.map(c => c.name).slice(0, 3).join(', ')}`}
            icon={<TrendingUpIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.info.main}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
          <StatCard
            title="System Health"
            value="99.8%"
            subtitle="Uptime this month"
            icon={<SettingsIcon sx={{ color: 'white', fontSize: 32 }} />}
            color={theme.palette.info.main}
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Organizations Growth Chart */}
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Organizations Growth
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                New organizations registered over the last 6 months
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={organizationsGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill={theme.palette.primary.main} radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Platform User Growth */}
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                User Growth
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                Total platform users
              </Typography>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={userGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="users"
                    stroke={theme.palette.success.main}
                    strokeWidth={3}
                    dot={{ fill: theme.palette.success.main, r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Organizations */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h6" fontWeight="bold">
                  Organizations Overview
                </Typography>
                <Button variant="text" size="small" onClick={() => window.location.href = '/organizations'}>
                  View All
                </Button>
              </Box>
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="h2" fontWeight="bold" color="primary.main">
                  {totalOrganizations}
                </Typography>
                <Typography variant="body1" color="text.secondary" gutterBottom>
                  Total Organizations
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'center', gap: 4, mt: 3 }}>
                  <Box>
                    <Typography variant="h4" fontWeight="bold" color="success.main">
                      {activeOrganizations}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      Active
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="h4" fontWeight="bold" color="warning.main">
                      {totalOrganizations - activeOrganizations}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      Inactive
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Quick Actions */}
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Platform Actions
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Manage platform operations
              </Typography>
              <Grid container spacing={2}>
                <Grid size={6}>
                  <Button
                    variant="contained"
                    startIcon={<AddIcon />}
                    fullWidth
                    onClick={() => setCreateDialogOpen(true)}
                  >
                    Register Organization
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<BusinessIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                  >
                    Manage Orgs
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<PeopleIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                  >
                    User Management
                  </Button>
                </Grid>
                <Grid size={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<SettingsIcon />}
                    sx={{ py: 2, flexDirection: 'column', gap: 1 }}
                  >
                    System Settings
                  </Button>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Register Organization Dialog */}
      <RegisterOrganizationDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
      />
    </Box>
  );
};

export default PlatformAdminDashboard;
