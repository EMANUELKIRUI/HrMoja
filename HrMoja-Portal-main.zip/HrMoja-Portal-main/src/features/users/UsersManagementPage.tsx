import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  CircularProgress,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Select,
  FormControl,
  InputLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
} from '@mui/material';
import {
  PersonAdd as PersonAddIcon,
  Search as SearchIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  LockOpen as UnlockIcon,
  Lock as LockIcon,
  CheckCircle,
  Cancel as DeactivateIcon,
  People as PeopleIcon,
} from '@mui/icons-material';
import { userManagementApi, type UserDto } from '../../api/user-management.api';
import { organizationsApi } from '../../api/organizations.api';
import AddUserDialog from './AddUserDialog';
import EditUserDialog from './EditUserDialog';

const UsersManagementPage = () => {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterOrg, setFilterOrg] = useState<number | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedUser, setSelectedUser] = useState<UserDto | null>(null);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deactivateDialogOpen, setDeactivateDialogOpen] = useState(false);
  const [activateDialogOpen, setActivateDialogOpen] = useState(false);
  const [lockDialogOpen, setLockDialogOpen] = useState(false);
  const [unlockDialogOpen, setUnlockDialogOpen] = useState(false);

  // Fetch all users
  const { data: usersResponse, isLoading: usersLoading } = useQuery({
    queryKey: ['users'],
    queryFn: userManagementApi.getAllUsers,
  });

  // Fetch organizations for filter
  const { data: orgsResponse } = useQuery({
    queryKey: ['organizations'],
    queryFn: organizationsApi.getAllOrganizations,
  });

  const users = usersResponse?.data || [];
  const organizations = orgsResponse?.data || [];

  // Stats
  const totalUsers = users.length;
  const activeUsers = users.filter((u: UserDto) => u.active).length;
  const inactiveUsers = users.filter((u: UserDto) => !u.active).length;
  const lockedUsers = users.filter((u: UserDto) => u.locked).length;

  // Filter users
  const filteredUsers = users.filter((user: UserDto) => {
    const matchesSearch = 
      user.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesOrg = filterOrg === 'all' || user.organizationId === filterOrg;
    
    const matchesStatus = 
      filterStatus === 'all' ||
      (filterStatus === 'active' && user.active) ||
      (filterStatus === 'inactive' && !user.active) ||
      (filterStatus === 'locked' && user.locked);
    
    return matchesSearch && matchesOrg && matchesStatus;
  });

  // Mutations
  const lockMutation = useMutation({
    mutationFn: (userId: number) => userManagementApi.lockUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      handleMenuClose();
    },
  });

  const unlockMutation = useMutation({
    mutationFn: (userId: number) => userManagementApi.unlockUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      handleMenuClose();
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: (userId: number) => userManagementApi.deleteUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      handleMenuClose();
    },
  });

  const activateMutation = useMutation({
    mutationFn: (userId: number) => userManagementApi.activateUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      handleMenuClose();
    },
  });

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedUser(null);
  };

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, user: UserDto) => {
    setAnchorEl(event.currentTarget);
    setSelectedUser(user);
  };

  const handleEditUser = () => {
    setEditDialogOpen(true);
    setAnchorEl(null);
  };

  const handleLockUser = () => {
    setLockDialogOpen(true);
    setAnchorEl(null);
  };

  const handleUnlockUser = () => {
    setUnlockDialogOpen(true);
    setAnchorEl(null);
  };

  const confirmLock = () => {
    if (selectedUser?.id) {
      lockMutation.mutate(selectedUser.id);
    }
    setLockDialogOpen(false);
  };

  const confirmUnlock = () => {
    if (selectedUser?.id) {
      unlockMutation.mutate(selectedUser.id);
    }
    setUnlockDialogOpen(false);
  };

  const handleDeactivateUser = () => {
    setDeactivateDialogOpen(true);
    setAnchorEl(null);
  };

  const handleActivateUser = () => {
    setActivateDialogOpen(true);
    setAnchorEl(null);
  };

  const confirmDeactivate = () => {
    if (selectedUser?.id) {
      deactivateMutation.mutate(selectedUser.id);
    }
    setDeactivateDialogOpen(false);
  };

  const confirmActivate = () => {
    if (selectedUser?.id) {
      activateMutation.mutate(selectedUser.id);
    }
    setActivateDialogOpen(false);
  };

  const getUserStatusChip = (user: UserDto) => {
    if (user.active) {
      return <Chip label="Active" color="success" size="small" icon={<CheckCircle />} />;
    }
    return <Chip label="Inactive" color="default" size="small" />;
  };

  const getLockedStatusChip = (user: UserDto) => {
    if (user.locked) {
      return <Chip label="Yes" color="error" size="small" icon={<LockIcon />} />;
    }
    return <Chip label="No" color="default" size="small" />;
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Users Management
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage all platform users across organizations
          </Typography>
        </Box>
        <Button variant="contained" startIcon={<PersonAddIcon />} onClick={() => setAddDialogOpen(true)}>
          Add User
        </Button>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <PeopleIcon sx={{ fontSize: 40, color: 'primary.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {totalUsers}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Users
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <PeopleIcon sx={{ fontSize: 40, color: 'success.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {activeUsers}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Active Users
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <LockIcon sx={{ fontSize: 40, color: 'error.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {lockedUsers}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Locked Accounts
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <DeactivateIcon sx={{ fontSize: 40, color: 'warning.main' }} />
                <Box>
                  <Typography variant="h4" fontWeight="bold">
                    {inactiveUsers}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Inactive Users
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField
                fullWidth
                placeholder="Search by name, email, or username..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <FormControl fullWidth>
                <InputLabel>Organization</InputLabel>
                <Select
                  value={filterOrg}
                  label="Organization"
                  onChange={(e) => setFilterOrg(e.target.value as number | 'all')}
                >
                  <MenuItem value="all">All Organizations</MenuItem>
                  {organizations.map((org) => (
                    <MenuItem key={org.id} value={org.id}>
                      {org.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <FormControl fullWidth>
                <InputLabel>Status</InputLabel>
                <Select
                  value={filterStatus}
                  label="Status"
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <MenuItem value="all">All Status</MenuItem>
                  <MenuItem value="active">Active</MenuItem>
                  <MenuItem value="inactive">Inactive</MenuItem>
                  <MenuItem value="locked">Locked</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight="bold" gutterBottom>
            All Users ({filteredUsers.length})
          </Typography>
          {usersLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Organization</TableCell>
                    <TableCell>Roles</TableCell>
                    <TableCell>Last Login</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Locked</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredUsers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} align="center">
                        <Typography variant="body2" color="text.secondary">
                          No users found
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredUsers.map((user: UserDto) => (
                      <TableRow key={user.id} hover>
                        <TableCell>
                          <Typography variant="body2" fontWeight={600}>
                            {user.firstName} {user.lastName}
                          </Typography>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.organizationName || '-'}</TableCell>
                        <TableCell>
                          <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                            {user.roles?.map((role: string, idx: number) => (
                              <Chip
                                key={idx}
                                label={role.replace('_', ' ')}
                                size="small"
                                variant="outlined"
                              />
                            ))}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleDateString() : 'Never'}
                          </Typography>
                        </TableCell>
                        <TableCell>{getUserStatusChip(user)}</TableCell>
                        <TableCell>{getLockedStatusChip(user)}</TableCell>
                        <TableCell align="right">
                          <IconButton
                            size="small"
                            onClick={(e) => handleMenuOpen(e, user)}
                          >
                            <MoreVertIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>

      {/* Actions Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleEditUser}>
          <ListItemIcon>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Edit User</ListItemText>
        </MenuItem>
        {selectedUser?.locked ? (
          <MenuItem onClick={handleUnlockUser}>
            <ListItemIcon>
              <UnlockIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Unlock Account</ListItemText>
          </MenuItem>
        ) : (
          <MenuItem onClick={handleLockUser}>
            <ListItemIcon>
              <LockIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Lock Account</ListItemText>
          </MenuItem>
        )}
        {selectedUser?.active ? (
          <MenuItem onClick={handleDeactivateUser}>
            <ListItemIcon>
              <DeactivateIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Deactivate User</ListItemText>
          </MenuItem>
        ) : (
          <MenuItem onClick={handleActivateUser}>
            <ListItemIcon>
              <CheckCircle fontSize="small" />
            </ListItemIcon>
            <ListItemText>Activate User</ListItemText>
          </MenuItem>
        )}
      </Menu>

      <AddUserDialog open={addDialogOpen} onClose={() => setAddDialogOpen(false)} />
      <EditUserDialog 
        open={editDialogOpen} 
        onClose={() => {
          setEditDialogOpen(false);
          setSelectedUser(null);
        }} 
        user={selectedUser}
      />

      {/* Deactivate Confirmation Dialog */}
      <Dialog
        open={deactivateDialogOpen}
        onClose={() => setDeactivateDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ bgcolor: 'error.main', color: 'white' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <DeactivateIcon />
            <Typography variant="h6">Deactivate User</Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Alert severity="warning" sx={{ mb: 2 }}>
            This action will prevent the user from logging in.
          </Alert>
          <Typography variant="body1" gutterBottom>
            Are you sure you want to deactivate this user?
          </Typography>
          {selectedUser && (
            <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
              <Typography variant="body2" color="text.secondary">
                <strong>Name:</strong> {selectedUser.firstName} {selectedUser.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Email:</strong> {selectedUser.email}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Organization:</strong> {selectedUser.organizationName || 'N/A'}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setDeactivateDialogOpen(false)} color="inherit">
            Cancel
          </Button>
          <Button
            onClick={confirmDeactivate}
            variant="contained"
            color="error"
            startIcon={<DeactivateIcon />}
          >
            Deactivate User
          </Button>
        </DialogActions>
      </Dialog>

      {/* Activate Confirmation Dialog */}
      <Dialog
        open={activateDialogOpen}
        onClose={() => setActivateDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ bgcolor: 'success.main', color: 'white' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CheckCircle />
            <Typography variant="h6">Activate User</Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Alert severity="success" sx={{ mb: 2 }}>
            This action will allow the user to log in to the system.
          </Alert>
          <Typography variant="body1" gutterBottom>
            Are you sure you want to activate this user?
          </Typography>
          {selectedUser && (
            <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
              <Typography variant="body2" color="text.secondary">
                <strong>Name:</strong> {selectedUser.firstName} {selectedUser.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Email:</strong> {selectedUser.email}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Organization:</strong> {selectedUser.organizationName || 'N/A'}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setActivateDialogOpen(false)} color="inherit">
            Cancel
          </Button>
          <Button
            onClick={confirmActivate}
            variant="contained"
            color="success"
            startIcon={<CheckCircle />}
          >
            Activate User
          </Button>
        </DialogActions>
      </Dialog>

      {/* Lock Account Confirmation Dialog */}
      <Dialog
        open={lockDialogOpen}
        onClose={() => setLockDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ bgcolor: 'error.main', color: 'white' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <LockIcon />
            <Typography variant="h6">Lock Account</Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Alert severity="error" sx={{ mb: 2 }}>
            This action will immediately prevent the user from logging in.
          </Alert>
          <Typography variant="body1" gutterBottom>
            Are you sure you want to lock this account?
          </Typography>
          {selectedUser && (
            <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
              <Typography variant="body2" color="text.secondary">
                <strong>Name:</strong> {selectedUser.firstName} {selectedUser.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Email:</strong> {selectedUser.email}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Organization:</strong> {selectedUser.organizationName || 'N/A'}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setLockDialogOpen(false)} color="inherit">
            Cancel
          </Button>
          <Button
            onClick={confirmLock}
            variant="contained"
            color="error"
            startIcon={<LockIcon />}
          >
            Lock Account
          </Button>
        </DialogActions>
      </Dialog>

      {/* Unlock Account Confirmation Dialog */}
      <Dialog
        open={unlockDialogOpen}
        onClose={() => setUnlockDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle sx={{ bgcolor: 'info.main', color: 'white' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <UnlockIcon />
            <Typography variant="h6">Unlock Account</Typography>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Alert severity="info" sx={{ mb: 2 }}>
            This action will allow the user to log in again and reset failed login attempts.
          </Alert>
          <Typography variant="body1" gutterBottom>
            Are you sure you want to unlock this account?
          </Typography>
          {selectedUser && (
            <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
              <Typography variant="body2" color="text.secondary">
                <strong>Name:</strong> {selectedUser.firstName} {selectedUser.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Email:</strong> {selectedUser.email}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                <strong>Organization:</strong> {selectedUser.organizationName || 'N/A'}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setUnlockDialogOpen(false)} color="inherit">
            Cancel
          </Button>
          <Button
            onClick={confirmUnlock}
            variant="contained"
            color="info"
            startIcon={<UnlockIcon />}
          >
            Unlock Account
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default UsersManagementPage;
