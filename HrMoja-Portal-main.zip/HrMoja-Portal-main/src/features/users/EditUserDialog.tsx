import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Alert,
  Box,
  Typography,
  MenuItem,
  Chip,
  Grid,
  IconButton,
} from '@mui/material';
import { Close as CloseIcon } from '@mui/icons-material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { userManagementApi, type UserDto, type UserUpdateRequest } from '../../api/user-management.api';
import { roleManagementApi } from '../../api/role-management.api';
import { organizationsApi } from '../../api/organizations.api';

const userSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  email: z.string().email('Invalid email address'),
  phoneNumber: z.string().optional(),
  organizationId: z.number().optional(),
  roleIds: z.array(z.number()).optional(),
  active: z.boolean().optional(),
});

type UserFormData = z.infer<typeof userSchema>;

interface EditUserDialogProps {
  open: boolean;
  onClose: () => void;
  user: UserDto | null;
}

const EditUserDialog = ({ open, onClose, user }: EditUserDialogProps) => {
  const queryClient = useQueryClient();
  const [error, setError] = useState<string | null>(null);
  const [selectedRoleIds, setSelectedRoleIds] = useState<number[]>([]);

  // Fetch roles and organizations
  const { data: rolesResponse } = useQuery({
    queryKey: ['roles', 'active'],
    queryFn: roleManagementApi.getActiveRoles,
  });

  const { data: orgsResponse } = useQuery({
    queryKey: ['organizations'],
    queryFn: organizationsApi.getAllOrganizations,
  });

  const roles = rolesResponse?.data || [];
  const organizations = orgsResponse?.data || [];

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<UserFormData>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      organizationId: undefined,
      roleIds: [],
      active: true,
    },
  });

  // Update form when user changes
  useEffect(() => {
    if (user) {
      reset({
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        email: user.email || '',
        phoneNumber: user.phoneNumber || '',
        organizationId: user.organizationId || undefined,
        roleIds: user.roleIds || [],
        active: user.active,
      });
      setSelectedRoleIds(user.roleIds || []);
    }
  }, [user, reset]);

  const updateMutation = useMutation({
    mutationFn: (data: UserUpdateRequest) => {
      if (!user || !user.id) throw new Error('No user selected');
      return userManagementApi.updateUser(user.id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      handleClose();
    },
    onError: (err: any) => {
      setError(err.response?.data?.message || 'Failed to update user');
    },
  });

  const handleClose = () => {
    reset();
    setError(null);
    setSelectedRoleIds([]);
    onClose();
  };

  const onSubmit = (data: UserFormData) => {
    setError(null);
    updateMutation.mutate({
      ...data,
      roleIds: selectedRoleIds,
    });
  };

  const toggleRole = (roleId: number) => {
    setSelectedRoleIds((prev) =>
      prev.includes(roleId) ? prev.filter((id) => id !== roleId) : [...prev, roleId]
    );
  };

  if (!user) return null;

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6" fontWeight="bold">
            Edit User
          </Typography>
          <IconButton onClick={handleClose} size="small">
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>

      <form onSubmit={handleSubmit(onSubmit)}>
        <DialogContent dividers>
          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Personal Information
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="firstName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="First Name"
                    fullWidth
                    required
                    error={!!errors.firstName}
                    helperText={errors.firstName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="lastName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Last Name"
                    fullWidth
                    required
                    error={!!errors.lastName}
                    helperText={errors.lastName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="email"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Email"
                    type="email"
                    fullWidth
                    required
                    error={!!errors.email}
                    helperText={errors.email?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="phoneNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Phone Number"
                    fullWidth
                    error={!!errors.phoneNumber}
                    helperText={errors.phoneNumber?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="organizationId"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    select
                    label="Organization"
                    fullWidth
                    value={field.value || ''}
                    onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                  >
                    <MenuItem value="">None</MenuItem>
                    {organizations.map((org) => (
                      <MenuItem key={org.id} value={org.id}>
                        {org.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ mt: 2 }}>
                Roles & Permissions
              </Typography>
            </Grid>

            <Grid size={12}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Select roles for this user
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                {roles.map((role) => (
                  <Chip
                    key={role.id}
                    label={role.name}
                    color={selectedRoleIds.includes(role.id!) ? 'primary' : 'default'}
                    onClick={() => toggleRole(role.id!)}
                    sx={{ cursor: 'pointer' }}
                  />
                ))}
              </Box>
            </Grid>

            {selectedRoleIds.length > 0 && (
              <Grid size={12}>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Selected Roles
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 1 }}>
                  {selectedRoleIds.map((roleId) => {
                    const role = roles.find((r) => r.id === roleId);
                    return role ? (
                      <Chip key={roleId} label={role.name} color="primary" size="small" />
                    ) : null;
                  })}
                </Box>
              </Grid>
            )}
          </Grid>
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={handleClose} variant="outlined" disabled={updateMutation.isPending}>
            Cancel
          </Button>
          <Button type="submit" variant="contained" disabled={updateMutation.isPending}>
            {updateMutation.isPending ? 'Updating...' : 'Update User'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default EditUserDialog;
