import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Alert,
  Box,
  Typography,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Chip,
  Grid,
} from '@mui/material';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { userManagementApi, type UserCreateRequest } from '../../api/user-management.api';
import { roleManagementApi } from '../../api/role-management.api';
import { organizationsApi } from '../../api/organizations.api';
import { useAuthStore } from '../../store/authStore';

const userSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  phoneNumber: z.string().optional(),
  organizationId: z.number().optional(),
  roleIds: z.array(z.number()).optional(),
  mustChangePassword: z.boolean().optional(),
});

type UserFormData = z.infer<typeof userSchema>;

interface AddUserDialogProps {
  open: boolean;
  onClose: () => void;
}

const AddUserDialog = ({ open, onClose }: AddUserDialogProps) => {
  const queryClient = useQueryClient();
  const { user } = useAuthStore();
  const [error, setError] = useState<string | null>(null);

  // Check if user belongs to an organization (ADMIN) or is platform admin
  const userOrganizationId = user?.organizationId;
  const isPlatformAdmin = !userOrganizationId;

  // Fetch roles and organizations
  const { data: rolesResponse } = useQuery({
    queryKey: ['roles', 'active'],
    queryFn: roleManagementApi.getActiveRoles,
    enabled: open,
  });

  const { data: orgsResponse } = useQuery({
    queryKey: ['organizations', 'active'],
    queryFn: organizationsApi.getActiveOrganizations,
    enabled: open,
  });

  const roles = rolesResponse?.data || [];
  const organizations = orgsResponse?.data || [];

  const {
    control,
    handleSubmit,
    reset,
    setValue,
    formState: { errors, isSubmitting },
    watch,
  } = useForm<UserFormData>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      firstName: '',
      lastName: '',
      phoneNumber: '',
      organizationId: userOrganizationId || undefined,
      roleIds: [],
      mustChangePassword: false,
    },
  });

  // Auto-set organization when dialog opens if user has organizationId
  useEffect(() => {
    if (open && userOrganizationId) {
      setValue('organizationId', userOrganizationId);
    }
  }, [open, userOrganizationId, setValue]);

  const createMutation = useMutation({
    mutationFn: (data: UserCreateRequest) => userManagementApi.createUser(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      reset();
      setError(null);
      onClose();
    },
    onError: (err: any) => {
      setError(err.response?.data?.message || err.message || 'Failed to create user');
    },
  });

  const onSubmit = (data: UserFormData) => {
    setError(null);
    createMutation.mutate(data as UserCreateRequest);
  };

  const handleClose = () => {
    if (!isSubmitting) {
      reset();
      setError(null);
      onClose();
    }
  };

  const selectedRoleIds = watch('roleIds') || [];

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Typography variant="h6" fontWeight="bold">
          Add New User
        </Typography>
      </DialogTitle>

      <form onSubmit={handleSubmit(onSubmit)}>
        <DialogContent dividers>
          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          <Grid container spacing={3}>
            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Account Information
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="username"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Username"
                    fullWidth
                    required
                    error={!!errors.username}
                    helperText={errors.username?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="email"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Email"
                    type="email"
                    fullWidth
                    required
                    error={!!errors.email}
                    helperText={errors.email?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="password"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Password"
                    type="password"
                    fullWidth
                    required
                    error={!!errors.password}
                    helperText={errors.password?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="mustChangePassword"
                control={control}
                render={({ field }) => (
                  <FormControlLabel
                    control={<Checkbox {...field} checked={field.value} />}
                    label="Must change password on first login"
                  />
                )}
              />
            </Grid>

            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ mt: 2 }}>
                Personal Information
              </Typography>
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="firstName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="First Name"
                    fullWidth
                    required
                    error={!!errors.firstName}
                    helperText={errors.firstName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="lastName"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Last Name"
                    fullWidth
                    required
                    error={!!errors.lastName}
                    helperText={errors.lastName?.message}
                  />
                )}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6 }}>
              <Controller
                name="phoneNumber"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Phone Number"
                    fullWidth
                    error={!!errors.phoneNumber}
                    helperText={errors.phoneNumber?.message}
                  />
                )}
              />
            </Grid>

            {isPlatformAdmin ? (
              <Grid size={{ xs: 12, sm: 6 }}>
                <Controller
                  name="organizationId"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      select
                      label="Organization"
                      fullWidth
                      value={field.value || ''}
                      onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                    >
                      <MenuItem value="">None (Platform Admin)</MenuItem>
                      {organizations.map((org) => (
                        <MenuItem key={org.id} value={org.id}>
                          {org.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Grid>
            ) : (
              <Grid size={{ xs: 12, sm: 6 }}>
                <TextField
                  label="Organization"
                  fullWidth
                  value={user?.organizationName || 'Your Organization'}
                  disabled
                  helperText="Users will be added to your organization"
                />
              </Grid>
            )}

            <Grid size={12}>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ mt: 2 }}>
                Roles & Permissions
              </Typography>
            </Grid>

            <Grid size={12}>
              <Controller
                name="roleIds"
                control={control}
                render={({ field }) => (
                  <TextField
                    select
                    label="Assign Roles"
                    fullWidth
                    SelectProps={{
                      multiple: true,
                      renderValue: (selected) => (
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                          {(selected as number[]).map((value) => {
                            const role = roles.find((r) => r.id === value);
                            return <Chip key={value} label={role?.name || value} size="small" />;
                          })}
                        </Box>
                      ),
                    }}
                    value={field.value || []}
                    onChange={(e) => field.onChange(e.target.value)}
                  >
                    {roles.map((role) => (
                      <MenuItem key={role.id} value={role.id}>
                        {role.name}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>

            {selectedRoleIds.length > 0 && (
              <Grid size={12}>
                <Typography variant="caption" color="text.secondary">
                  Selected roles will grant the following permissions to this user
                </Typography>
                <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {roles
                    .filter((r) => selectedRoleIds.includes(r.id!))
                    .flatMap((r) => r.permissions || [])
                    .filter((v, i, a) => a.indexOf(v) === i)
                    .map((permission) => (
                      <Chip key={permission} label={permission} size="small" variant="outlined" />
                    ))}
                </Box>
              </Grid>
            )}
          </Grid>
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={handleClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" variant="contained" disabled={isSubmitting}>
            {isSubmitting ? 'Creating...' : 'Create User'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default AddUserDialog;
