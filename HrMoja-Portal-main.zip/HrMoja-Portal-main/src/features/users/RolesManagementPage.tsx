import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  CircularProgress,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Tabs,
  Tab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Security as SecurityIcon,
  CheckCircle,
  VpnKey as VpnKeyIcon,
  ManageAccounts as ManageAccountsIcon,
  ToggleOn as ToggleOnIcon,
  ToggleOff as ToggleOffIcon,
} from '@mui/icons-material';
import { roleManagementApi, type RoleDto } from '../../api/role-management.api';
import { permissionManagementApi, type PermissionDto } from '../../api/permission-management.api';
import RoleDialog from '../../components/dialogs/RoleDialog';
import PermissionDialog from '../../components/dialogs/PermissionDialog';
import ManageRolePermissionsDialog from '../../components/dialogs/ManageRolePermissionsDialog';

const RolesManagementPage = () => {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [permSearchQuery, setPermSearchQuery] = useState('');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [permAnchorEl, setPermAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedRole, setSelectedRole] = useState<RoleDto | null>(null);
  const [selectedPermission, setSelectedPermission] = useState<PermissionDto | null>(null);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [permissionDialogOpen, setPermissionDialogOpen] = useState(false);
  const [managePermissionsOpen, setManagePermissionsOpen] = useState(false);
  const [viewPermissionsOpen, setViewPermissionsOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  // Fetch roles
  const { data: rolesResponse, isLoading: rolesLoading } = useQuery({
    queryKey: ['roles'],
    queryFn: roleManagementApi.getAllRoles,
  });

  // Fetch permissions
  const { data: permissionsResponse, isLoading: permissionsLoading } = useQuery({
    queryKey: ['permissions'],
    queryFn: permissionManagementApi.getAllPermissions,
  });

  const roles = rolesResponse?.data || [];
  const permissions = permissionsResponse?.data || [];

  // Filter roles
  const filteredRoles = roles.filter((role: RoleDto) =>
    role.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    role.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filter permissions
  const filteredPermissions = permissions.filter((perm: PermissionDto) =>
    perm.name.toLowerCase().includes(permSearchQuery.toLowerCase()) ||
    perm.code.toLowerCase().includes(permSearchQuery.toLowerCase()) ||
    perm.module.toLowerCase().includes(permSearchQuery.toLowerCase())
  );

  // Stats
  const totalRoles = roles.length;
  const activeRoles = roles.filter((r: RoleDto) => r.isActive).length;
  const systemRoles = roles.filter((r: RoleDto) => r.isSystemRole).length;
  const totalPermissions = permissions.length;
  const activePermissions = permissions.filter((p: PermissionDto) => p.isActive).length;

  // Role handlers
  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, role: RoleDto) => {
    setAnchorEl(event.currentTarget);
    setSelectedRole(role);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedRole(null);
  };

  const handleViewPermissions = () => {
    setViewPermissionsOpen(true);
    handleMenuClose();
  };

  const handleEditRole = () => {
    setRoleDialogOpen(true);
    setAnchorEl(null); // Close menu but keep selectedRole
  };

  const handleManagePermissions = () => {
    setManagePermissionsOpen(true);
    handleMenuClose();
  };

  const handleDeleteRole = () => {
    setDeleteConfirmOpen(true);
    handleMenuClose();
  };

  // Permission handlers
  const handlePermMenuOpen = (event: React.MouseEvent<HTMLElement>, permission: PermissionDto) => {
    setPermAnchorEl(event.currentTarget);
    setSelectedPermission(permission);
  };

  const handlePermMenuClose = () => {
    setPermAnchorEl(null);
    setSelectedPermission(null);
  };

  const handleEditPermission = () => {
    setPermissionDialogOpen(true);
    setPermAnchorEl(null); // Close menu but keep selectedPermission
  };

  const handleTogglePermission = () => {
    if (selectedPermission?.id) {
      if (selectedPermission.isActive) {
        deletePermMutation.mutate(selectedPermission.id);
      } else {
        activatePermMutation.mutate(selectedPermission.id);
      }
    }
    handlePermMenuClose();
  };

  // Delete role mutation
  const deleteRoleMutation = useMutation({
    mutationFn: (id: number) => roleManagementApi.deleteRole(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      setDeleteConfirmOpen(false);
    },
  });

  // Delete permission mutation
  const deletePermMutation = useMutation({
    mutationFn: (id: number) => permissionManagementApi.deletePermission(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['permissions'] });
      queryClient.invalidateQueries({ queryKey: ['roles'] });
    },
  });

  // Activate permission mutation
  const activatePermMutation = useMutation({
    mutationFn: (id: number) => permissionManagementApi.activatePermission(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['permissions'] });
      queryClient.invalidateQueries({ queryKey: ['roles'] });
    },
  });

  // Group permissions by module
  const groupPermissionsByModule = (permissions: string[]) => {
    const grouped: Record<string, string[]> = {};
    permissions.forEach((perm: string) => {
      const module = perm.split('_')[0];
      if (!grouped[module]) {
        grouped[module] = [];
      }
      grouped[module].push(perm);
    });
    return grouped;
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight="bold" gutterBottom>
            Roles & Permissions
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Manage user roles and their associated permissions
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          {activeTab === 0 && (
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => {
                setSelectedRole(null);
                setRoleDialogOpen(true);
              }}
            >
              Add Role
            </Button>
          )}
          {activeTab === 1 && (
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => {
                setSelectedPermission(null);
                setPermissionDialogOpen(true);
              }}
            >
              Add Permission
            </Button>
          )}
        </Box>
      </Box>

      {/* Tabs */}
      <Card sx={{ mb: 3 }}>
        <Tabs value={activeTab} onChange={(_, newValue) => setActiveTab(newValue)}>
          <Tab label={`Roles (${totalRoles})`} />
          <Tab label={`Permissions (${totalPermissions})`} />
        </Tabs>
      </Card>

      {/* Roles Tab */}
      {activeTab === 0 && (
        <>
          {/* Stats Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid size={{ xs: 12, sm: 4 }}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <SecurityIcon sx={{ fontSize: 40, color: 'primary.main' }} />
                    <Box>
                      <Typography variant="h4" fontWeight="bold">
                        {totalRoles}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Total Roles
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <CheckCircle sx={{ fontSize: 40, color: 'success.main' }} />
                    <Box>
                      <Typography variant="h4" fontWeight="bold">
                        {activeRoles}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Active Roles
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            <Grid size={{ xs: 12, sm: 4 }}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <SecurityIcon sx={{ fontSize: 40, color: 'warning.main' }} />
                    <Box>
                      <Typography variant="h4" fontWeight="bold">
                        {systemRoles}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        System Roles
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Search */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <TextField
                fullWidth
                placeholder="Search roles by name or code..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
            </CardContent>
          </Card>

          {/* Roles Table */}
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                All Roles ({filteredRoles.length})
              </Typography>
              {rolesLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                </Box>
              ) : (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Role Name</TableCell>
                        <TableCell>Code</TableCell>
                        <TableCell>Description</TableCell>
                        <TableCell>Level</TableCell>
                        <TableCell>Permissions</TableCell>
                        <TableCell>Status</TableCell>
                        <TableCell align="right">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {filteredRoles.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} align="center">
                            <Typography variant="body2" color="text.secondary">
                              No roles found
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredRoles.map((role: RoleDto) => (
                          <TableRow key={role.id} hover>
                            <TableCell>
                              <Typography variant="body2" fontWeight={600}>
                                {role.name}
                                {role.isSystemRole && (
                                  <Chip label="System" size="small" sx={{ ml: 1 }} />
                                )}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Typography variant="caption" fontFamily="monospace">
                                {role.code}
                              </Typography>
                            </TableCell>
                            <TableCell>{role.description || '-'}</TableCell>
                            <TableCell>{role.level}</TableCell>
                            <TableCell>
                              <Chip
                                label={`${role.permissions?.length || 0} permissions`}
                                size="small"
                                color="primary"
                                variant="outlined"
                              />
                            </TableCell>
                            <TableCell>
                              <Chip
                                label={role.isActive ? 'Active' : 'Inactive'}
                                color={role.isActive ? 'success' : 'default'}
                                size="small"
                              />
                            </TableCell>
                            <TableCell align="right">
                              <IconButton
                                size="small"
                                onClick={(e) => handleMenuOpen(e, role)}
                              >
                                <MoreVertIcon />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {/* Permissions Tab */}
      {activeTab === 1 && (
        <>
          {/* Stats Cards */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <VpnKeyIcon sx={{ fontSize: 40, color: 'primary.main' }} />
                    <Box>
                      <Typography variant="h4" fontWeight="bold">
                        {totalPermissions}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Total Permissions
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Card>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <CheckCircle sx={{ fontSize: 40, color: 'success.main' }} />
                    <Box>
                      <Typography variant="h4" fontWeight="bold">
                        {activePermissions}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Active Permissions
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          {/* Search */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <TextField
                fullWidth
                placeholder="Search permissions by name, code, or module..."
                value={permSearchQuery}
                onChange={(e) => setPermSearchQuery(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
              />
            </CardContent>
          </Card>

          {/* Permissions Table */}
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                All Permissions ({filteredPermissions.length})
              </Typography>
              {permissionsLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                  <CircularProgress />
                </Box>
              ) : (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Permission Name</TableCell>
                        <TableCell>Code</TableCell>
                        <TableCell>Module</TableCell>
                        <TableCell>Description</TableCell>
                        <TableCell>Status</TableCell>
                        <TableCell align="right">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {filteredPermissions.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} align="center">
                            <Typography variant="body2" color="text.secondary">
                              No permissions found
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredPermissions.map((perm: PermissionDto) => (
                          <TableRow key={perm.id} hover>
                            <TableCell>
                              <Typography variant="body2" fontWeight={600}>
                                {perm.name}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Typography variant="caption" fontFamily="monospace">
                                {perm.code}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Chip label={perm.module} size="small" color="primary" variant="outlined" />
                            </TableCell>
                            <TableCell>{perm.description || '-'}</TableCell>
                            <TableCell>
                              <Chip
                                label={perm.isActive ? 'Active' : 'Inactive'}
                                color={perm.isActive ? 'success' : 'default'}
                                size="small"
                              />
                            </TableCell>
                            <TableCell align="right">
                              <IconButton
                                size="small"
                                onClick={(e) => handlePermMenuOpen(e, perm)}
                              >
                                <MoreVertIcon />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {/* Role Actions Menu */}
      <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
        <MenuItem onClick={handleViewPermissions}>
          <ListItemIcon>
            <SecurityIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>View Permissions</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleManagePermissions}>
          <ListItemIcon>
            <ManageAccountsIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Manage Permissions</ListItemText>
        </MenuItem>
        {!selectedRole?.isSystemRole && [
          <MenuItem key="edit" onClick={handleEditRole}>
            <ListItemIcon>
              <EditIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Edit Role</ListItemText>
          </MenuItem>,
          <MenuItem key="delete" onClick={handleDeleteRole}>
            <ListItemIcon>
              <DeleteIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Deactivate Role</ListItemText>
          </MenuItem>
        ]}
      </Menu>

      {/* Permission Actions Menu */}
      <Menu anchorEl={permAnchorEl} open={Boolean(permAnchorEl)} onClose={handlePermMenuClose}>
        <MenuItem onClick={handleEditPermission}>
          <ListItemIcon>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Edit Permission</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleTogglePermission}>
          <ListItemIcon>
            {selectedPermission?.isActive ? <ToggleOffIcon fontSize="small" /> : <ToggleOnIcon fontSize="small" />}
          </ListItemIcon>
          <ListItemText>{selectedPermission?.isActive ? 'Deactivate' : 'Activate'}</ListItemText>
        </MenuItem>
      </Menu>

      {/* View Permissions Dialog */}
      <Dialog
        open={viewPermissionsOpen}
        onClose={() => setViewPermissionsOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          <Typography variant="h6" fontWeight="bold">
            {selectedRole?.name} - Permissions
          </Typography>
        </DialogTitle>
        <DialogContent dividers>
          {selectedRole?.permissions && selectedRole.permissions.length > 0 ? (
            <Box>
              {Object.entries(groupPermissionsByModule(selectedRole.permissions)).map(
                ([module, perms]) => (
                  <Box key={module} sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
                      {module.toUpperCase()} Module
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                      {perms.map((perm: string) => (
                        <Chip key={perm} label={perm} size="small" />
                      ))}
                    </Box>
                  </Box>
                )
              )}
            </Box>
          ) : (
            <Alert severity="info">No permissions assigned to this role</Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setViewPermissionsOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Delete Role Confirmation */}
      <Dialog open={deleteConfirmOpen} onClose={() => setDeleteConfirmOpen(false)}>
        <DialogTitle>Confirm Deactivation</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to deactivate the role <strong>{selectedRole?.name}</strong>?
            This will prevent it from being assigned to new users.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteConfirmOpen(false)}>Cancel</Button>
          <Button
            onClick={() => selectedRole?.id && deleteRoleMutation.mutate(selectedRole.id)}
            color="error"
            variant="contained"
          >
            Deactivate
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialogs */}
      <RoleDialog
        open={roleDialogOpen}
        onClose={() => {
          setRoleDialogOpen(false);
          setSelectedRole(null);
        }}
        role={selectedRole}
      />

      <PermissionDialog
        open={permissionDialogOpen}
        onClose={() => {
          setPermissionDialogOpen(false);
          setSelectedPermission(null);
        }}
        permission={selectedPermission}
      />

      <ManageRolePermissionsDialog
        open={managePermissionsOpen}
        onClose={() => {
          setManagePermissionsOpen(false);
          setSelectedRole(null);
        }}
        role={selectedRole}
      />
    </Box>
  );
};

export default RolesManagementPage;
