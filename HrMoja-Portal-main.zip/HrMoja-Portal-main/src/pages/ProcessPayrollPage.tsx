import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Alert,
  Paper,
  Stack,
  Tabs,
  Tab,
  TablePagination,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
  CheckCircle as CheckIcon,
  Warning as WarningIcon,
  PersonAdd as AddSalaryIcon,
  PersonOff as DeactivateIcon,
  PlayArrow as ProcessIcon,
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import { employeesApi } from '../api/employees.api';
import { employeeSalaryApi } from '../api/employee-salary.api';
import { useAuthStore } from '../store/authStore';
import payrollApi from '../api/payrollApi';
import type { PayrollPeriod } from '../api/payrollApi';
import type { Employee } from '../types/api.types';
import { format, parseISO } from 'date-fns';
import { toast } from 'react-toastify';
import SalaryStructureDialog from '../features/salary/components/SalaryStructureDialog';
import DeactivateEmployeeDialog from '../components/dialogs/DeactivateEmployeeDialog';
import PayrollProgressDialog from '../components/dialogs/PayrollProgressDialog';

interface EmployeeWithSalary {
  id: number;
  employeeNumber: string;
  firstName: string;
  lastName: string;
  jobTitle: string;
  basicSalary: number;
  hasSalary: boolean;
  status: string;
}

const ProcessPayrollPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const organizationId = user?.organizationId || 1;

  const [period, setPeriod] = useState<PayrollPeriod | null>(null);
  const [loadingPeriod, setLoadingPeriod] = useState(true);
  const [loadingEmployees, setLoadingEmployees] = useState(false);
  const [processing, setProcessing] = useState(false);
  
  const [allEmployees, setAllEmployees] = useState<EmployeeWithSalary[]>([]);
  const [readyEmployees, setReadyEmployees] = useState<EmployeeWithSalary[]>([]);
  const [missingEmployees, setMissingEmployees] = useState<EmployeeWithSalary[]>([]);
  
  const [activeTab, setActiveTab] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Dialog state
  const [salaryDialogOpen, setSalaryDialogOpen] = useState(false);
  const [deactivateDialogOpen, setDeactivateDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [progressDialogOpen, setProgressDialogOpen] = useState(false);
  const [jobId, setJobId] = useState<number | null>(null);

  useEffect(() => {
    loadPeriodData();
    loadEmployees();
  }, [id]);

  const loadPeriodData = async () => {
    try {
      setLoadingPeriod(true);
      const periodData = await payrollApi.getPeriodById(Number(id));
      setPeriod(periodData);
    } catch (error: any) {
      toast.error('Failed to load payroll period');
      navigate('/payroll/periods');
    } finally {
      setLoadingPeriod(false);
    }
  };

  const loadEmployees = async () => {
    try {
      setLoadingEmployees(true);
      
      // Fetch all active employees
      const employeesResponse = await employeesApi.searchEmployeesWithFilters(
        organizationId,
        { isActive: true, status: 'ACTIVE' },
        0,
        1000
      );
      
      if (employeesResponse.success && employeesResponse.data) {
        const activeEmps = employeesResponse.data.content || [];
        
        // Fetch salary information for each employee
        const employeesWithSalaryStatus = await Promise.all(
          activeEmps.map(async (emp) => {
            try {
              const salaryResponse = await employeeSalaryApi.getCurrentSalary(emp.id!);
              const hasSalary = salaryResponse.success && salaryResponse.data;
              const basicSalary = hasSalary ? salaryResponse.data.basicSalary : 0;
              
              return {
                id: emp.id!,
                employeeNumber: emp.employeeNumber || 'N/A',
                firstName: emp.firstName,
                lastName: emp.lastName,
                jobTitle: emp.jobTitleName || 'N/A',
                basicSalary: basicSalary,
                hasSalary: !!hasSalary,
                status: emp.employmentStatus || 'ACTIVE',
              };
            } catch (err) {
              return {
                id: emp.id!,
                employeeNumber: emp.employeeNumber || 'N/A',
                firstName: emp.firstName,
                lastName: emp.lastName,
                jobTitle: emp.jobTitleName || 'N/A',
                basicSalary: 0,
                hasSalary: false,
                status: emp.employmentStatus || 'ACTIVE',
              };
            }
          })
        );
        
        setAllEmployees(employeesWithSalaryStatus);
        
        // Separate employees by salary status
        const ready = employeesWithSalaryStatus.filter(emp => emp.hasSalary);
        const missing = employeesWithSalaryStatus.filter(emp => !emp.hasSalary);
        
        setReadyEmployees(ready);
        setMissingEmployees(missing);
      }
    } catch (err: any) {
      toast.error('Failed to load employees');
    } finally {
      setLoadingEmployees(false);
    }
  };

  const handleProcessPayroll = async () => {
    if (!period || missingEmployees.length > 0) {
      toast.error('Cannot process payroll. Some employees are missing salary structures.');
      return;
    }

    try {
      setProcessing(true);
      const response = await payrollApi.processPeriod(period.id);
      setJobId(response.jobId);
      setProgressDialogOpen(true);
      toast.success('Payroll processing started!');
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || 'Failed to start payroll processing';
      toast.error(errorMessage);
      setProcessing(false);
    }
  };

  const handleProgressComplete = () => {
    setProgressDialogOpen(false);
    setProcessing(false);
    setJobId(null);
    toast.success('Payroll processed successfully!');
    navigate(`/payroll/periods/${period?.id || id}`);
  };

  const handleProgressClose = () => {
    setProgressDialogOpen(false);
    setProcessing(false);
    setJobId(null);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return format(parseISO(dateString), 'dd MMM yyyy');
  };

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const getCurrentEmployees = () => {
    const employees = activeTab === 0 ? allEmployees : (activeTab === 1 ? readyEmployees : missingEmployees);
    return employees.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);
  };

  const getCurrentCount = () => {
    return activeTab === 0 ? allEmployees.length : (activeTab === 1 ? readyEmployees.length : missingEmployees.length);
  };

  const totalGrossPay = readyEmployees.reduce((sum, emp) => sum + emp.basicSalary, 0);

  const handleAddSalary = (employee: EmployeeWithSalary) => {
    setSelectedEmployee({
      id: employee.id,
      employeeNumber: employee.employeeNumber,
      firstName: employee.firstName,
      lastName: employee.lastName,
      organizationId: organizationId,
      hireDate: '',
      employmentTypeId: 0,
      jobTitleId: 0,
    } as Employee);
    setSalaryDialogOpen(true);
  };

  const handleDeactivateEmployee = (employee: EmployeeWithSalary) => {
    setSelectedEmployee({
      id: employee.id,
      employeeNumber: employee.employeeNumber,
      firstName: employee.firstName,
      lastName: employee.lastName,
    } as any);
    setDeactivateDialogOpen(true);
  };

  const handleSalaryDialogClose = () => {
    setSalaryDialogOpen(false);
    setSelectedEmployee(null);
    // Refresh employee list
    loadEmployees();
  };

  const handleDeactivateSuccess = () => {
    setDeactivateDialogOpen(false);
    setSelectedEmployee(null);
    // Refresh employee list
    loadEmployees();
  };

  if (loadingPeriod) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  if (!period) {
    return (
      <Box p={3}>
        <Alert severity="error">Payroll period not found</Alert>
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center" gap={2}>
          <IconButton onClick={() => navigate(`/payroll/periods/${id}`)}>
            <BackIcon />
          </IconButton>
          <Box>
            <Typography variant="h4" fontWeight="bold">
              Process Payroll
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {period.periodName} • {formatDate(period.startDate)} - {formatDate(period.endDate)}
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Summary Cards */}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={3} mb={3}>
        <Paper sx={{ p: 2, bgcolor: 'primary.50', borderLeft: 4, borderColor: 'primary.main', flex: 1 }}>
          <Typography variant="subtitle2" color="text.secondary">
            Total Employees
          </Typography>
          <Typography variant="h3" fontWeight="bold" color="primary.main">
            {allEmployees.length}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Active employees
          </Typography>
        </Paper>
        <Paper sx={{ p: 2, bgcolor: 'success.50', borderLeft: 4, borderColor: 'success.main', flex: 1 }}>
          <Typography variant="subtitle2" color="text.secondary">
            Ready to Process
          </Typography>
          <Typography variant="h3" fontWeight="bold" color="success.main">
            {readyEmployees.length}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            With salary structure
          </Typography>
        </Paper>
        <Paper sx={{ p: 2, bgcolor: 'error.50', borderLeft: 4, borderColor: 'error.main', flex: 1 }}>
          <Typography variant="subtitle2" color="text.secondary">
            Missing Salary
          </Typography>
          <Typography variant="h3" fontWeight="bold" color="error.main">
            {missingEmployees.length}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Action required
          </Typography>
        </Paper>
        <Paper sx={{ p: 2, bgcolor: 'info.50', borderLeft: 4, borderColor: 'info.main', flex: 1 }}>
          <Typography variant="subtitle2" color="text.secondary">
            Estimated Gross Pay
          </Typography>
          <Typography variant="h5" fontWeight="bold" color="info.main">
            {formatCurrency(totalGrossPay)}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Total basic salary
          </Typography>
        </Paper>
      </Stack>

      {/* Validation Alert */}
      {missingEmployees.length > 0 && (
        <Alert severity="error" sx={{ mb: 3 }} icon={<WarningIcon />}>
          <Typography variant="subtitle2" fontWeight="bold">
            Cannot Process Payroll
          </Typography>
          <Typography variant="body2" sx={{ mt: 1 }}>
            {missingEmployees.length} employee(s) do not have a salary structure. 
            Please add salary structures or deactivate these employees before processing payroll.
          </Typography>
        </Alert>
      )}

      {missingEmployees.length === 0 && readyEmployees.length > 0 && (
        <Alert severity="success" sx={{ mb: 3 }} icon={<CheckIcon />}>
          <Typography variant="subtitle2" fontWeight="bold">
            Ready to Process
          </Typography>
          <Typography variant="body2" sx={{ mt: 1 }}>
            All {readyEmployees.length} employee(s) have valid salary structures. You can proceed with payroll processing.
          </Typography>
        </Alert>
      )}

      {/* Employee Lists */}
      <Card>
        <CardContent>
          <Tabs value={activeTab} onChange={(_e, val) => { setActiveTab(val); setPage(0); }} sx={{ mb: 2 }}>
            <Tab 
              label={`All Employees (${allEmployees.length})`} 
            />
            <Tab 
              label={
                <Box display="flex" alignItems="center" gap={1}>
                  Ready ({readyEmployees.length})
                  <CheckIcon fontSize="small" color="success" />
                </Box>
              }
            />
            <Tab 
              label={
                <Box display="flex" alignItems="center" gap={1}>
                  Missing Salary ({missingEmployees.length})
                  <WarningIcon fontSize="small" color="error" />
                </Box>
              }
            />
          </Tabs>

          {loadingEmployees ? (
            <Box display="flex" justifyContent="center" py={4}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow sx={{ bgcolor: 'grey.50' }}>
                      <TableCell>Employee #</TableCell>
                      <TableCell>Name</TableCell>
                      <TableCell>Job Title</TableCell>
                      <TableCell align="right">Basic Salary</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {getCurrentEmployees().length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} align="center">
                          <Typography variant="body2" color="text.secondary" py={2}>
                            No employees found
                          </Typography>
                        </TableCell>
                      </TableRow>
                    ) : (
                      getCurrentEmployees().map((employee) => (
                        <TableRow key={employee.id} hover>
                          <TableCell>
                            <Typography variant="body2" fontWeight="medium">
                              {employee.employeeNumber}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2">
                              {employee.firstName} {employee.lastName}
                            </Typography>
                          </TableCell>
                          <TableCell>
                            <Typography variant="body2" color="text.secondary">
                              {employee.jobTitle}
                            </Typography>
                          </TableCell>
                          <TableCell align="right">
                            {employee.hasSalary ? (
                              <Typography variant="body2" fontWeight="medium">
                                {formatCurrency(employee.basicSalary)}
                              </Typography>
                            ) : (
                              <Chip label="No Salary" color="error" size="small" />
                            )}
                          </TableCell>
                          <TableCell>
                            <Chip
                              label={employee.hasSalary ? 'Ready' : 'Missing Salary'}
                              color={employee.hasSalary ? 'success' : 'error'}
                              size="small"
                              variant="outlined"
                              icon={employee.hasSalary ? <CheckIcon /> : <WarningIcon />}
                            />
                          </TableCell>
                          <TableCell align="right">
                            {!employee.hasSalary && (
                              <Box display="flex" gap={1} justifyContent="flex-end">
                                <Tooltip title="Add Salary Structure">
                                  <IconButton 
                                    size="small" 
                                    color="primary"
                                    onClick={() => handleAddSalary(employee)}
                                  >
                                    <AddSalaryIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Deactivate Employee">
                                  <IconButton 
                                    size="small" 
                                    color="error"
                                    onClick={() => handleDeactivateEmployee(employee)}
                                  >
                                    <DeactivateIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                              </Box>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25, 50]}
                component="div"
                count={getCurrentCount()}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </>
          )}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <Box display="flex" justifyContent="flex-end" gap={2} mt={3}>
        <Button
          variant="outlined"
          onClick={() => navigate(`/payroll/periods/${id}`)}
          disabled={processing}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          startIcon={processing ? <CircularProgress size={16} /> : <ProcessIcon />}
          onClick={handleProcessPayroll}
          disabled={processing || missingEmployees.length > 0 || readyEmployees.length === 0}
        >
          {processing ? 'Processing...' : `Process Payroll (${readyEmployees.length} Employees)`}
        </Button>
      </Box>

      {/* Dialogs */}
      {selectedEmployee && (
        <>
          <SalaryStructureDialog
            open={salaryDialogOpen}
            onClose={handleSalaryDialogClose}
            employee={selectedEmployee}
            existingSalary={null}
          />
          <DeactivateEmployeeDialog
            open={deactivateDialogOpen}
            employee={selectedEmployee}
            onClose={() => setDeactivateDialogOpen(false)}
            onSuccess={handleDeactivateSuccess}
          />
        </>
      )}

      {/* Payroll Progress Dialog */}
      {jobId && period && (
        <PayrollProgressDialog
          open={progressDialogOpen}
          periodId={period.id}
          jobId={jobId}
          onClose={handleProgressClose}
          onComplete={handleProgressComplete}
        />
      )}
    </Box>
  );
};

export default ProcessPayrollPage;
