import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  TextField,
  InputAdornment,
  Select,
  FormControl,
  TablePagination,
  Stack,
} from '@mui/material';
import {
  Add as AddIcon,
  Search as SearchIcon,
  FilterList as FilterIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import payrollApi from '../api/payrollApi';
import type { PayrollPeriod, PaginatedResponse, PeriodFilters } from '../api/payrollApi';
import { format, parseISO } from 'date-fns';
import { toast } from 'react-toastify';

const PayrollPeriods: React.FC = () => {
  const navigate = useNavigate();
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [loading, setLoading] = useState(true);
  // Removed action menu state - all actions moved to details page
  
  // Pagination and filters
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalElements, setTotalElements] = useState(0);
  const [filters, setFilters] = useState<PeriodFilters>({
    status: '',
    search: '',
    periodType: '',
  });
  const [searchInput, setSearchInput] = useState('');

  const orgId = 1; // Get from context/auth

  useEffect(() => {
    loadPeriods();
  }, [page, rowsPerPage, filters]);

  const loadPeriods = async () => {
    try {
      setLoading(true);
      const response: PaginatedResponse<PayrollPeriod> = await payrollApi.getPeriodsPaginated(
        orgId,
        page,
        rowsPerPage,
        filters
      );
      setPeriods(response.content);
      setTotalElements(response.totalElements);
    } catch (error: any) {
      toast.error('Failed to load payroll periods');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  
  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput(event.target.value);
  };
  
  const handleSearchSubmit = () => {
    setFilters(prev => ({ ...prev, search: searchInput }));
    setPage(0);
  };
  
  const handleFilterChange = (filterName: keyof PeriodFilters, value: string) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
    setPage(0);
  };
  
  const handleClearFilters = () => {
    setFilters({
      status: '',
      search: '',
      periodType: '',
    });
    setSearchInput('');
    setPage(0);
  };

  const handleManage = (periodId: number) => {
    navigate(`/payroll/periods/${periodId}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'DRAFT':
        return 'default';
      case 'PROCESSING':
        return 'info';
      case 'PREPARED':
        return 'warning';
      case 'REVIEWED':
        return 'secondary';
      case 'APPROVED':
        return 'success';
      case 'PAID':
        return 'primary';
      case 'CLOSED':
        return 'error';
      default:
        return 'default';
    }
  };

  const getApprovalLevelBadge = (approvalLevel: string) => {
    const levels: { [key: string]: { label: string; color: 'default' | 'warning' | 'secondary' | 'success' } } = {
      'NONE': { label: 'No Approval', color: 'default' },
      'LEVEL_1_PREPARED': { label: '✓ L1 Prepared', color: 'warning' },
      'LEVEL_2_REVIEWED': { label: '✓✓ L2 Reviewed', color: 'secondary' },
      'LEVEL_3_APPROVED': { label: '✓✓✓ L3 Approved', color: 'success' },
    };
    return levels[approvalLevel] || levels['NONE'];
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return format(parseISO(dateString), 'dd MMM yyyy');
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" fontWeight="bold">
          Payroll Periods
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => navigate('/payroll/periods/new')}
        >
          Create Period
        </Button>
      </Box>

      {/* Search and Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Stack spacing={2}>
            <TextField
              fullWidth
              size="small"
              placeholder="Search by period name..."
              value={searchInput}
              onChange={handleSearchChange}
              onKeyPress={(e) => e.key === 'Enter' && handleSearchSubmit()}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
            <Stack spacing={2} direction={{ xs: 'column', md: 'row' }} alignItems="stretch">
              <FormControl fullWidth size="small">
                <Select
                  native
                  value={filters.status || ''}
                  onChange={(e) => handleFilterChange('status', e.target.value as string)}
                >
                  <option value="">All Statuses</option>
                  <option value="DRAFT">DRAFT</option>
                  <option value="PROCESSING">PROCESSING</option>
                  <option value="PREPARED">PREPARED</option>
                  <option value="REVIEWED">REVIEWED</option>
                  <option value="APPROVED">APPROVED</option>
                  <option value="PAID">PAID</option>
                  <option value="CLOSED">CLOSED</option>
                </Select>
              </FormControl>
              <FormControl fullWidth size="small">
                <Select
                  native
                  value={filters.periodType || ''}
                  onChange={(e) => handleFilterChange('periodType', e.target.value as string)}
                >
                  <option value="">All Types</option>
                  <option value="MONTHLY">Monthly</option>
                  <option value="BI_WEEKLY">Bi-Weekly</option>
                  <option value="WEEKLY">Weekly</option>
                </Select>
              </FormControl>
              <Button
                variant="contained"
                onClick={handleSearchSubmit}
                startIcon={<SearchIcon />}
                sx={{ minWidth: 120 }}
              >
                Search
              </Button>
              <Button
                variant="outlined"
                onClick={handleClearFilters}
                startIcon={<FilterIcon />}
                sx={{ minWidth: 120 }}
              >
                Clear
              </Button>
            </Stack>
          </Stack>
        </CardContent>
      </Card>

      {/* Periods Table */}
      <Card>
        <CardContent>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Period Name</TableCell>
                  <TableCell>Period</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Dates</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Approval</TableCell>
                  <TableCell align="right">Employees</TableCell>
                  <TableCell align="right">Gross Pay</TableCell>
                  <TableCell align="right">Net Pay</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {periods.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} align="center">
                      <Typography variant="body2" color="text.secondary" py={3}>
                        No payroll periods found. Create your first period to get started.
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  periods.map((period) => (
                    <TableRow key={period.id} hover>
                      <TableCell>
                        <Typography variant="body2" fontWeight="medium">
                          {period.periodName}
                        </Typography>
                      </TableCell>
                      <TableCell>{period.periodType}</TableCell>
                      <TableCell>{formatDate(period.startDate)} - {formatDate(period.endDate)}</TableCell>
                      <TableCell>{formatDate(period.paymentDate)}</TableCell>
                      <TableCell>
                        <Chip
                          label={period.status}
                          color={getStatusColor(period.status) as any}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={getApprovalLevelBadge(period.approvalLevel || 'NONE').label}
                          color={getApprovalLevelBadge(period.approvalLevel || 'NONE').color}
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell align="right">{period.totalEmployees || 0}</TableCell>
                      <TableCell align="right">
                        {formatCurrency(period.totalGrossPay || 0)}
                      </TableCell>
                      <TableCell align="right">
                        {formatCurrency(period.totalNetPay || 0)}
                      </TableCell>
                      <TableCell align="right">
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={() => handleManage(period.id)}
                        >
                          Manage
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25, 50]}
            component="div"
            count={totalElements}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </CardContent>
      </Card>
    </Box>
  );
};

export default PayrollPeriods;
