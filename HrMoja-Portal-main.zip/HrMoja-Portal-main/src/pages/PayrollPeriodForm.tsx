import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  TextField,
  Typography,
  Stack,
  MenuItem,
  Alert,
  CircularProgress,
} from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import payrollApi from '../api/payrollApi';
import type { CreatePeriodRequest, UpdatePeriodRequest } from '../api/payrollApi';
import { toast } from 'react-toastify';
import { format, parseISO, addMonths, startOfMonth, endOfMonth } from 'date-fns';

const validationSchema = Yup.object({
  periodName: Yup.string().required('Period name is required'),
  periodType: Yup.string().required('Period type is required'),
  startDate: Yup.date().required('Start date is required'),
  endDate: Yup.date()
    .required('End date is required')
    .min(Yup.ref('startDate'), 'End date must be after start date'),
  paymentDate: Yup.date()
    .required('Payment date is required')
    .min(Yup.ref('endDate'), 'Payment date must be on or after end date'),
});

const PayrollPeriodForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(!!id);
  const isEdit = !!id;

  const orgId = 1; // Get from context/auth

  const formik = useFormik({
    initialValues: {
      periodName: '',
      periodType: 'MONTHLY',
      startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
      endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
      paymentDate: format(addMonths(endOfMonth(new Date()), 0).setDate(5), 'yyyy-MM-dd'),
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        setLoading(true);
        
        if (isEdit) {
          const updateData: UpdatePeriodRequest = {
            periodName: values.periodName,
            startDate: values.startDate,
            endDate: values.endDate,
            paymentDate: values.paymentDate,
          };
          await payrollApi.updatePeriod(Number(id), updateData);
          toast.success('Payroll period updated successfully');
        } else {
          const createData: CreatePeriodRequest = {
            organizationId: orgId,
            periodName: values.periodName,
            periodType: values.periodType,
            startDate: values.startDate,
            endDate: values.endDate,
            paymentDate: values.paymentDate,
          };
          await payrollApi.createPeriod(createData);
          toast.success('Payroll period created successfully');
        }
        
        navigate('/payroll/periods');
      } catch (error: any) {
        toast.error(error.response?.data?.message || 'Failed to save payroll period');
      } finally {
        setLoading(false);
      }
    },
  });

  useEffect(() => {
    if (isEdit) {
      loadPeriod();
    }
  }, [id]);

  const loadPeriod = async () => {
    try {
      setInitialLoading(true);
      const period = await payrollApi.getPeriodById(Number(id));
      
      formik.setValues({
        periodName: period.periodName,
        periodType: period.periodType,
        startDate: period.startDate,
        endDate: period.endDate,
        paymentDate: period.paymentDate,
      });
    } catch (error: any) {
      toast.error('Failed to load payroll period');
      navigate('/payroll/periods');
    } finally {
      setInitialLoading(false);
    }
  };

  const handlePeriodTypeChange = (type: string) => {
    formik.setFieldValue('periodType', type);
    
    // Auto-generate period name based on type
    const startDate = parseISO(formik.values.startDate);
    let periodName = '';
    
    switch (type) {
      case 'MONTHLY':
        periodName = format(startDate, 'MMMM yyyy');
        break;
      case 'BI_WEEKLY':
        periodName = `Bi-Weekly ${format(startDate, 'dd MMM')} - ${format(parseISO(formik.values.endDate), 'dd MMM yyyy')}`;
        break;
      case 'WEEKLY':
        periodName = `Week ${format(startDate, 'dd MMM')} - ${format(parseISO(formik.values.endDate), 'dd MMM yyyy')}`;
        break;
      default:
        periodName = format(startDate, 'MMMM yyyy');
    }
    
    formik.setFieldValue('periodName', periodName);
  };

  const handleStartDateChange = (date: string) => {
    formik.setFieldValue('startDate', date);
    
    const startDate = parseISO(date);
    const type = formik.values.periodType;
    
    // Auto-calculate end date based on period type
    let endDate = endOfMonth(startDate);
    
    switch (type) {
      case 'MONTHLY':
        endDate = endOfMonth(startDate);
        break;
      case 'BI_WEEKLY':
        endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + 13);
        break;
      case 'WEEKLY':
        endDate = new Date(startDate);
        endDate.setDate(startDate.getDate() + 6);
        break;
    }
    
    formik.setFieldValue('endDate', format(endDate, 'yyyy-MM-dd'));
    
    // Set payment date (5th of next month for monthly, or 3 days after end for others)
    const paymentDate = type === 'MONTHLY' 
      ? new Date(endDate.getFullYear(), endDate.getMonth() + 1, 5)
      : new Date(endDate.getTime() + 3 * 24 * 60 * 60 * 1000);
    
    formik.setFieldValue('paymentDate', format(paymentDate, 'yyyy-MM-dd'));
    
    // Auto-generate period name
    handlePeriodTypeChange(type);
  };

  if (initialLoading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box mb={3}>
        <Typography variant="h4" fontWeight="bold">
          {isEdit ? 'Edit Payroll Period' : 'Create Payroll Period'}
        </Typography>
        <Typography variant="body2" color="text.secondary" mt={1}>
          {isEdit 
            ? 'Update the payroll period details below'
            : 'Create a new payroll period for processing employee salaries'}
        </Typography>
      </Box>

      <Card>
        <CardContent>
          <form onSubmit={formik.handleSubmit}>
            <Stack spacing={3}>
              <Alert severity="info">
                Period type and dates determine how payroll is calculated and when employees are paid.
              </Alert>

              <Stack spacing={3} direction={{ xs: 'column', md: 'row' }}>
                <TextField
                  fullWidth
                  select
                  label="Period Type"
                  name="periodType"
                  value={formik.values.periodType}
                  onChange={(e) => handlePeriodTypeChange(e.target.value)}
                  error={formik.touched.periodType && Boolean(formik.errors.periodType)}
                  helperText={formik.touched.periodType && formik.errors.periodType}
                  disabled={isEdit}
                >
                  <MenuItem value="MONTHLY">Monthly</MenuItem>
                  <MenuItem value="BI_WEEKLY">Bi-Weekly</MenuItem>
                  <MenuItem value="WEEKLY">Weekly</MenuItem>
                </TextField>
                <TextField
                  fullWidth
                  label="Period Name"
                  name="periodName"
                  value={formik.values.periodName}
                  onChange={formik.handleChange}
                  error={formik.touched.periodName && Boolean(formik.errors.periodName)}
                  helperText={formik.touched.periodName && formik.errors.periodName}
                  placeholder="e.g., January 2025"
                />
              </Stack>

              <Stack spacing={3} direction={{ xs: 'column', md: 'row' }}>
                <TextField
                  fullWidth
                  type="date"
                  label="Start Date"
                  name="startDate"
                  value={formik.values.startDate}
                  onChange={(e) => handleStartDateChange(e.target.value)}
                  error={formik.touched.startDate && Boolean(formik.errors.startDate)}
                  helperText={formik.touched.startDate && formik.errors.startDate}
                  InputLabelProps={{ shrink: true }}
                />
                <TextField
                  fullWidth
                  type="date"
                  label="End Date"
                  name="endDate"
                  value={formik.values.endDate}
                  onChange={formik.handleChange}
                  error={formik.touched.endDate && Boolean(formik.errors.endDate)}
                  helperText={formik.touched.endDate && formik.errors.endDate}
                  InputLabelProps={{ shrink: true }}
                />
                <TextField
                  fullWidth
                  type="date"
                  label="Payment Date"
                  name="paymentDate"
                  value={formik.values.paymentDate}
                  onChange={formik.handleChange}
                  error={formik.touched.paymentDate && Boolean(formik.errors.paymentDate)}
                  helperText={formik.touched.paymentDate && formik.errors.paymentDate}
                  InputLabelProps={{ shrink: true }}
                />
              </Stack>

              <Box display="flex" gap={2} justifyContent="flex-end">
                  <Button
                    variant="outlined"
                    onClick={() => navigate('/payroll/periods')}
                    disabled={loading}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    disabled={loading}
                    startIcon={loading && <CircularProgress size={20} />}
                  >
                    {isEdit ? 'Update Period' : 'Create Period'}
                  </Button>
                </Box>
            </Stack>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
};

export default PayrollPeriodForm;
