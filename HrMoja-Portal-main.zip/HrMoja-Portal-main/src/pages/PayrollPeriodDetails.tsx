import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Paper,
  Chip,
  CircularProgress,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
  PlayArrow as ProcessIcon,
  Payment as PaymentIcon,
  Lock as LockIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import payrollApi from '../api/payrollApi';
import type { PayrollPeriod, EmployeePayrollRecord } from '../api/payrollApi';
import { format, parseISO } from 'date-fns';
import { toast } from 'react-toastify';
import EmployeeLineItemEditor from '../components/payroll/EmployeeLineItemEditor';
import PartialApprovalPanel from '../components/payroll/PartialApprovalPanel';

const PayrollPeriodDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [period, setPeriod] = useState<PayrollPeriod | null>(null);
  const [records, setRecords] = useState<EmployeePayrollRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    action: string;
    title: string;
    message: string;
  }>({
    open: false,
    action: '',
    title: '',
    message: '',
  });
  const [editingRecord, setEditingRecord] = useState<EmployeePayrollRecord | null>(null);
  const [lineItemEditorOpen, setLineItemEditorOpen] = useState(false);

  useEffect(() => {
    loadPeriodDetails();
  }, [id]);

  const loadPeriodDetails = async () => {
    try {
      setLoading(true);
      const [periodData, recordsData] = await Promise.all([
        payrollApi.getPeriodById(Number(id)),
        payrollApi.getPeriodRecords(Number(id)),
      ]);
      setPeriod(periodData);
      setRecords(recordsData);
    } catch (error: any) {
      toast.error('Failed to load payroll period details');
      navigate('/payroll/periods');
    } finally {
      setLoading(false);
    }
  };

  const handleAction = (action: string, title: string, message: string) => {
    setConfirmDialog({
      open: true,
      action,
      title,
      message,
    });
  };


  const executeAction = async () => {
    if (!period) return;

    try {
      setProcessing(true);
      setConfirmDialog({ ...confirmDialog, open: false });

      switch (confirmDialog.action) {
        case 'recalculate':
          await payrollApi.recalculatePeriod(period.id);
          toast.success('Payroll recalculated successfully');
          // Reload page to refresh all data
          window.location.reload();
          return;
        case 'paid':
          await payrollApi.markAsPaid(period.id);
          toast.success('Payroll marked as paid');
          break;
        case 'close':
          await payrollApi.closePeriod(period.id);
          toast.success('Payroll period closed');
          break;
      }

      loadPeriodDetails();
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'Failed to execute action');
    } finally {
      setProcessing(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return format(parseISO(dateString), 'dd MMM yyyy');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'DRAFT':
        return 'default';
      case 'PROCESSING':
        return 'info';
      case 'PREPARED':
        return 'warning';
      case 'REVIEWED':
        return 'secondary';
      case 'APPROVED':
        return 'success';
      case 'PAID':
        return 'primary';
      case 'CLOSED':
        return 'default';
      default:
        return 'default';
    }
  };

  const handleEditLineItems = (record: EmployeePayrollRecord) => {
    setEditingRecord(record);
    setLineItemEditorOpen(true);
  };

  if (loading || !period) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  const canProcess = period.status === 'DRAFT';
  const canRecalculate = period.status === 'PROCESSING';
  const canMarkPaid = period.status === 'APPROVED';
  const canClose = period.status === 'PAID';
  const showPartialApproval = period.status === 'PROCESSING';
  const isReadOnly = !['DRAFT', 'PROCESSING'].includes(period.status);

  return (
    <Box>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center" gap={2}>
          <IconButton onClick={() => navigate('/payroll/periods')}>
            <BackIcon />
          </IconButton>
          <Box>
            <Typography variant="h4" fontWeight="bold">
              {period.periodName}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {formatDate(period.startDate)} - {formatDate(period.endDate)}
            </Typography>
          </Box>
          <Chip label={period.status} color={getStatusColor(period.status) as any} />
        </Box>
        <Box display="flex" gap={2}>
          {canProcess && (
            <Button
              variant="contained"
              startIcon={<ProcessIcon />}
              onClick={() => navigate(`/payroll/periods/${period.id}/process`)}
              disabled={processing}
            >
              Process Payroll
            </Button>
          )}
          {canRecalculate && (
            <Button
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={() =>
                handleAction(
                  'recalculate',
                  'Recalculate Payroll',
                  'This will recalculate all payroll records. Continue?'
                )
              }
              disabled={processing}
            >
              Recalculate
            </Button>
          )}
          {canMarkPaid && (
            <Button
              variant="contained"
              color="primary"
              startIcon={<PaymentIcon />}
              onClick={() =>
                handleAction('paid', 'Mark as Paid', 'Mark this payroll as paid?')
              }
              disabled={processing}
            >
              Mark as Paid
            </Button>
          )}
          {canClose && (
            <Button
              variant="outlined"
              startIcon={<LockIcon />}
              onClick={() =>
                handleAction(
                  'close',
                  'Close Period',
                  'Closing the period will lock it permanently. Continue?'
                )
              }
              disabled={processing}
            >
              Close Period
            </Button>
          )}
        </Box>
      </Box>

      {/* Current Stage Display */}
      {isReadOnly && (
        <Alert severity="info" sx={{ mb: 3 }}>
          <Typography variant="body2" fontWeight="bold">
            Current Stage: {period.status}
          </Typography>
          <Typography variant="caption">
            {period.status === 'PREPARED' && 'Approved by HR - Awaiting Finance Review'}
            {period.status === 'REVIEWED' && 'Reviewed by Finance - Awaiting Executive Approval'}
            {period.status === 'APPROVED' && 'Fully Approved - Ready for Payment'}
            {period.status === 'PAID' && 'Payment Processed'}
            {period.status === 'CLOSED' && 'Period Closed - No Further Changes Allowed'}
          </Typography>
        </Alert>
      )}

      {/* Summary Cards */}
      <Box display="flex" gap={3} mb={3} flexWrap="wrap">
        <Box flex="1 1 200px">
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="text.secondary">
              Total Employees
            </Typography>
            <Typography variant="h4" fontWeight="bold">
              {period.totalEmployees || 0}
            </Typography>
            {period.isPartiallyApproved && (
              <Typography variant="caption" color="warning.main">
                {period.totalApprovedLevel1} approved at L1
              </Typography>
            )}
          </Paper>
        </Box>
        <Box flex="1 1 200px">
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="text.secondary">
              Gross Pay
            </Typography>
            <Typography variant="h4" fontWeight="bold">
              {formatCurrency(period.totalGrossPay || 0)}
            </Typography>
          </Paper>
        </Box>
        <Box flex="1 1 200px">
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="text.secondary">
              Total Deductions
            </Typography>
            <Typography variant="h4" fontWeight="bold">
              {formatCurrency(period.totalDeductions || 0)}
            </Typography>
          </Paper>
        </Box>
        <Box flex="1 1 200px">
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="text.secondary">
              Net Pay
            </Typography>
            <Typography variant="h4" fontWeight="bold">
              {formatCurrency(period.totalNetPay || 0)}
            </Typography>
          </Paper>
        </Box>
      </Box>

      {/* Partial Approval Panel or Simple Records List */}
      {showPartialApproval && records.length > 0 ? (
        <PartialApprovalPanel
          periodId={period.id}
          records={records}
          canEdit={true}
          onUpdate={loadPeriodDetails}
          onEditRecord={handleEditLineItems}
        />
      ) : (
        <Card>
          <CardContent>
            <Typography variant="h6" fontWeight="bold" mb={2}>
              Employee Records ({records.length})
            </Typography>
            {records.length === 0 ? (
              <Alert severity="info">
                No payroll records found. Process the payroll to generate records.
              </Alert>
            ) : (
              <Alert severity="info">
                {records.length} employee record(s) in this payroll period.
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Confirmation Dialog */}
      <Dialog
        open={confirmDialog.open}
        onClose={() => setConfirmDialog({ ...confirmDialog, open: false })}
      >
        <DialogTitle>{confirmDialog.title}</DialogTitle>
        <DialogContent>
          <Alert severity="warning" sx={{ mb: 2 }}>
            {confirmDialog.message}
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialog({ ...confirmDialog, open: false })}>
            Cancel
          </Button>
          <Button onClick={executeAction} variant="contained" autoFocus>
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Line Item Editor */}
      {editingRecord && lineItemEditorOpen && (
        <EmployeeLineItemEditor
          open={lineItemEditorOpen}
          onClose={() => {
            setLineItemEditorOpen(false);
            setEditingRecord(null);
          }}
          record={editingRecord}
          onUpdate={loadPeriodDetails}
        />
      )}
    </Box>
  );
};

export default PayrollPeriodDetails;
