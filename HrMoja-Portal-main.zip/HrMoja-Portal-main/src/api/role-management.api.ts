import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface RoleDto {
  id?: number;
  name: string;
  code: string;
  description?: string;
  level?: number;
  isSystemRole?: boolean;
  isActive?: boolean;
  permissions?: string[];
  permissionIds?: number[];
  createdAt?: string;
  updatedAt?: string;
}

export interface RoleCreateRequest {
  name: string;
  code: string;
  description?: string;
  level?: number;
  permissionIds?: number[];
}

export const roleManagementApi = {
  // Get all roles
  getAllRoles: async (): Promise<ApiResponse<RoleDto[]>> => {
    const response = await apiClient.get('/roles');
    return response.data;
  },

  // Get active roles
  getActiveRoles: async (): Promise<ApiResponse<RoleDto[]>> => {
    const response = await apiClient.get('/roles/active');
    return response.data;
  },

  // Get role by ID
  getRoleById: async (id: number): Promise<ApiResponse<RoleDto>> => {
    const response = await apiClient.get(`/roles/${id}`);
    return response.data;
  },

  // Get role by code
  getRoleByCode: async (code: string): Promise<ApiResponse<RoleDto>> => {
    const response = await apiClient.get(`/roles/code/${code}`);
    return response.data;
  },

  // Create role
  createRole: async (role: RoleCreateRequest): Promise<ApiResponse<RoleDto>> => {
    const response = await apiClient.post('/roles', role);
    return response.data;
  },

  // Update role
  updateRole: async (id: number, role: RoleCreateRequest): Promise<ApiResponse<RoleDto>> => {
    const response = await apiClient.put(`/roles/${id}`, role);
    return response.data;
  },

  // Delete role (deactivate)
  deleteRole: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/roles/${id}`);
    return response.data;
  },

  // Add permissions to role
  addPermissionsToRole: async (id: number, permissionIds: number[]): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/roles/${id}/permissions/add`, permissionIds);
    return response.data;
  },

  // Remove permissions from role
  removePermissionsFromRole: async (id: number, permissionIds: number[]): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/roles/${id}/permissions/remove`, permissionIds);
    return response.data;
  },
};
