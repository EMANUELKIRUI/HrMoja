import apiClient from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface OrganizationDto {
  id?: number;
  name: string;
  legalName?: string;
  registrationNumber?: string;
  taxIdentificationNumber?: string;
  countryId: number;
  countryName?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  phoneNumber?: string;
  email?: string;
  website?: string;
  logoUrl?: string;
  active?: boolean; // Backend returns 'active', not 'isActive'
  createdAt?: string;
  updatedAt?: string;
}

export interface CreateOrganizationRequest {
  name: string;
  legalName?: string;
  registrationNumber?: string;
  taxIdentificationNumber?: string;
  countryId: number;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  phoneNumber?: string;
  email?: string;
  website?: string;
}

export interface OrganizationRegistrationRequest {
  // Organization Details
  organizationName: string;
  legalName?: string;
  registrationNumber?: string;
  taxIdentificationNumber: string;
  countryId: number;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  stateProvince?: string;
  postalCode?: string;
  phoneNumber: string;
  organizationEmail: string;
  website?: string;

  // Admin User Details
  adminFirstName: string;
  adminLastName: string;
  adminEmail: string;
  adminUsername: string;
  adminPassword: string;
  adminPhoneNumber?: string;

  // Headquarters Branch
  branchName: string;
  branchCity?: string;
}

export interface OrganizationRegistrationResponse {
  organization: OrganizationDto;
  adminUser: {
    id: number;
    username: string;
    email: string;
    fullName: string;
  };
  message: string;
}

export const organizationsApi = {
  getAllOrganizations: async (): Promise<ApiResponse<OrganizationDto[]>> => {
    const response = await apiClient.get('/settings/organizations');
    return response.data;
  },

  getActiveOrganizations: async (): Promise<ApiResponse<OrganizationDto[]>> => {
    const response = await apiClient.get('/settings/organizations/active');
    return response.data;
  },

  getOrganizationById: async (id: number): Promise<ApiResponse<OrganizationDto>> => {
    const response = await apiClient.get(`/settings/organizations/${id}`);
    return response.data;
  },

  createOrganization: async (data: CreateOrganizationRequest): Promise<ApiResponse<OrganizationDto>> => {
    const response = await apiClient.post('/settings/organizations', data);
    return response.data;
  },

  updateOrganization: async (id: number, data: CreateOrganizationRequest): Promise<ApiResponse<OrganizationDto>> => {
    const response = await apiClient.put(`/settings/organizations/${id}`, data);
    return response.data;
  },

  deleteOrganization: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/organizations/${id}`);
    return response.data;
  },

  // Organization Registration (with admin user creation)
  registerOrganization: async (data: OrganizationRegistrationRequest): Promise<ApiResponse<OrganizationRegistrationResponse>> => {
    const response = await apiClient.post('/organization/register', data);
    return response.data;
  },
};
