import { apiClient } from './axios.config';

export const hrPayrollApi = {
  getPeriodsForPreparation: async (status?: string, search?: string, page: number = 0, size: number = 10) => {
    const params: any = { page, size };
    if (status) params.status = status;
    if (search) params.search = search;
    return apiClient.get('/hr/payroll/periods', { params });
  },

  getPeriodDetails: async (periodId: number) => {
    return apiClient.get(`/hr/payroll/periods/${periodId}`);
  },

  getEmployeeRecords: async (
    periodId: number, 
    search?: string, 
    department?: string, 
    status?: string, 
    approvalLevel?: number,
    page: number = 0, 
    size: number = 20
  ) => {
    const params: any = { page, size };
    if (search) params.search = search;
    if (department) params.department = department;
    if (status) params.status = status;
    if (approvalLevel !== undefined) params.approvalLevel = approvalLevel;
    return apiClient.get(`/hr/payroll/periods/${periodId}/records`, { params });
  },

  approveRecord: async (recordId: number) => {
    return apiClient.post(`/hr/payroll/records/${recordId}/approve`);
  },

  unapproveRecord: async (recordId: number) => {
    return apiClient.post(`/hr/payroll/records/${recordId}/unapprove`);
  },

  rejectRecord: async (recordId: number, reason: string) => {
    return apiClient.post(`/hr/payroll/records/${recordId}/reject`, { reason });
  },

  approveAllRecords: async (periodId: number) => {
    return apiClient.post(`/hr/payroll/periods/${periodId}/approve-all`);
  },

  submitForReview: async (periodId: number, comment?: string) => {
    return apiClient.post(`/hr/payroll/periods/${periodId}/submit-for-review`, 
      comment ? { comment } : undefined);
  },

  getApprovalStats: async (periodId: number) => {
    return apiClient.get(`/hr/payroll/periods/${periodId}/approval-stats`);
  },

  addLineItem: async (data: any) => {
    return apiClient.post('/hr/payroll/line-items', data);
  },

  deleteLineItem: async (lineItemId: number) => {
    return apiClient.delete(`/hr/payroll/line-items/${lineItemId}`);
  },

  recalculateRecord: async (recordId: number) => {
    return apiClient.post(`/hr/payroll/records/${recordId}/recalculate`);
  },

  getLineItems: async (recordId: number) => {
    return apiClient.get(`/hr/payroll/records/${recordId}/line-items`);
  },

  updateLineItem: async (recordId: number, lineItemId: number, amount: number) => {
    return apiClient.put(`/hr/payroll/records/${recordId}/line-items/${lineItemId}`, { amount });
  },
};
