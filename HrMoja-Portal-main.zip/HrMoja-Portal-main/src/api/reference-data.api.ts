import apiClient from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface SimpleDto {
  id?: number;
  name: string;
  description?: string;
  isActive?: boolean;
}

export interface BankDto {
  id?: number;
  name: string;
  code: string;
  countryId: number;
  isActive?: boolean;
}

export const referenceDataApi = {
  // Pay Frequencies
  getAllPayFrequencies: async (): Promise<ApiResponse<SimpleDto[]>> => {
    const response = await apiClient.get('/settings/pay-frequencies');
    return response.data;
  },

  getActivePayFrequencies: async (): Promise<ApiResponse<SimpleDto[]>> => {
    const response = await apiClient.get('/settings/pay-frequencies/active');
    return response.data;
  },

  createPayFrequency: async (data: SimpleDto): Promise<ApiResponse<SimpleDto>> => {
    const response = await apiClient.post('/settings/pay-frequencies', data);
    return response.data;
  },

  // Employment Types
  getAllEmploymentTypes: async (): Promise<ApiResponse<SimpleDto[]>> => {
    const response = await apiClient.get('/settings/employment-types');
    return response.data;
  },

  createEmploymentType: async (data: SimpleDto): Promise<ApiResponse<SimpleDto>> => {
    const response = await apiClient.post('/settings/employment-types', data);
    return response.data;
  },

  // Payment Methods
  getAllPaymentMethods: async (): Promise<ApiResponse<SimpleDto[]>> => {
    const response = await apiClient.get('/settings/payment-methods');
    return response.data;
  },

  // Banks
  getBanksByCountry: async (countryId: number): Promise<ApiResponse<BankDto[]>> => {
    const response = await apiClient.get(`/settings/banks/country/${countryId}`);
    return response.data;
  },

  createBank: async (data: BankDto): Promise<ApiResponse<BankDto>> => {
    const response = await apiClient.post('/settings/banks', data);
    return response.data;
  },

  // Component Types
  getAllComponentTypes: async (): Promise<ApiResponse<any[]>> => {
    const response = await apiClient.get('/settings/component-types');
    return response.data;
  },
};
