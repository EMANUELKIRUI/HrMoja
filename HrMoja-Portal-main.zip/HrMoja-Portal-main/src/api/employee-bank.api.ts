import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface EmployeeBankDetails {
  id?: number;
  employeeId: number;
  bankId: number;
  bankName?: string;
  bankBranchId?: number;
  bankBranchName?: string;
  accountNumber: string;
  accountName: string;
  accountType?: string;
  swiftCode?: string;
  iban?: string;
  primary: boolean;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export const employeeBankApi = {
  // Get employee's primary bank details
  getPrimaryBankDetails: async (employeeId: number): Promise<ApiResponse<EmployeeBankDetails>> => {
    const response = await apiClient.get(`/employees/${employeeId}/bank-details/primary`);
    return response.data;
  },

  // Get all employee's bank details
  getAllBankDetails: async (employeeId: number): Promise<ApiResponse<EmployeeBankDetails[]>> => {
    const response = await apiClient.get(`/employees/${employeeId}/bank-details`);
    return response.data;
  },

  // Create bank details
  createBankDetails: async (data: EmployeeBankDetails): Promise<ApiResponse<EmployeeBankDetails>> => {
    const response = await apiClient.post(`/employees/${data.employeeId}/bank-details`, data);
    return response.data;
  },

  // Update bank details
  updateBankDetails: async (employeeId: number, bankDetailsId: number, data: Partial<EmployeeBankDetails>): Promise<ApiResponse<EmployeeBankDetails>> => {
    const response = await apiClient.put(`/employees/${employeeId}/bank-details/${bankDetailsId}`, data);
    return response.data;
  },

  // Delete bank details
  deleteBankDetails: async (employeeId: number, bankDetailsId: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/employees/${employeeId}/bank-details/${bankDetailsId}`);
    return response.data;
  },
};
