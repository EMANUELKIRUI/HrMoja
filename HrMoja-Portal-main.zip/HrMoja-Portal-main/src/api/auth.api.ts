import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';
import type { LoginRequest, LoginResponse } from '../types/auth.types';

export const authApi = {
  login: async (credentials: LoginRequest): Promise<ApiResponse<LoginResponse>> => {
    const response = await apiClient.post('/auth/login', credentials);
    return response.data;
  },

  logout: async (): Promise<void> => {
    // Clear token from storage (handled by authStore)
  },

  refreshToken: async (refreshToken: string): Promise<ApiResponse<LoginResponse>> => {
    const response = await apiClient.post('/auth/refresh', { refreshToken });
    return response.data;
  },

  getCurrentUser: async (): Promise<ApiResponse<LoginResponse>> => {
    const response = await apiClient.get('/auth/me');
    return response.data;
  },

  forgotPassword: async (email: string): Promise<ApiResponse<void>> => {
    const response = await apiClient.post('/auth/forgot-password', { email });
    return response.data;
  },

  resetPassword: async (token: string, newPassword: string, confirmPassword: string): Promise<ApiResponse<void>> => {
    const response = await apiClient.post('/auth/reset-password', { token, newPassword, confirmPassword });
    return response.data;
  },

  validateResetToken: async (token: string): Promise<ApiResponse<boolean>> => {
    const response = await apiClient.get(`/auth/validate-reset-token?token=${token}`);
    return response.data;
  },
};
