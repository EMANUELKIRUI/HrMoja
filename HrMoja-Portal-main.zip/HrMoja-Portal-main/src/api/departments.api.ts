import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface DepartmentDto {
  id?: number;
  organizationId: number;
  name: string;
  code: string;
  description?: string;
  parentDepartmentId?: number;
  parentDepartmentName?: string;
  managerId?: number;
  managerName?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export const departmentsApi = {
  // Get all departments by organization
  getDepartmentsByOrganization: async (organizationId: number): Promise<ApiResponse<DepartmentDto[]>> => {
    const response = await apiClient.get(`/settings/departments/organization/${organizationId}`);
    return response.data;
  },

  // Get active departments only
  getActiveDepartments: async (organizationId: number): Promise<ApiResponse<DepartmentDto[]>> => {
    const response = await apiClient.get(`/settings/departments/organization/${organizationId}/active`);
    return response.data;
  },

  // Get root departments (top-level)
  getRootDepartments: async (organizationId: number): Promise<ApiResponse<DepartmentDto[]>> => {
    const response = await apiClient.get(`/settings/departments/organization/${organizationId}/root`);
    return response.data;
  },

  // Get department by ID
  getDepartmentById: async (id: number): Promise<ApiResponse<DepartmentDto>> => {
    const response = await apiClient.get(`/settings/departments/${id}`);
    return response.data;
  },

  // Create department
  createDepartment: async (department: DepartmentDto): Promise<ApiResponse<DepartmentDto>> => {
    const response = await apiClient.post('/settings/departments', department);
    return response.data;
  },

  // Update department
  updateDepartment: async (id: number, department: DepartmentDto): Promise<ApiResponse<DepartmentDto>> => {
    const response = await apiClient.put(`/settings/departments/${id}`, department);
    return response.data;
  },

  // Delete department
  deleteDepartment: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/departments/${id}`);
    return response.data;
  },
};
