import { apiClient } from './axios.config';
import type { ApiResponse, PageResponse } from '../types/api.types';

export interface UserDto {
  id?: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName?: string;
  phoneNumber?: string;
  active?: boolean;
  locked?: boolean;
  emailVerified?: boolean;
  mustChangePassword?: boolean;
  employeeId?: number;
  organizationId?: number;
  organizationName?: string;
  lastLoginAt?: string;
  lastLoginIp?: string;
  failedLoginAttempts?: number;
  roles?: string[];
  roleIds?: number[];
  permissions?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface UserCreateRequest {
  username: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  organizationId?: number;
  employeeId?: number;
  roleIds?: number[];
  mustChangePassword?: boolean;
}

export interface UserUpdateRequest {
  email?: string;
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  organizationId?: number;
  employeeId?: number;
  roleIds?: number[];
  active?: boolean;
  locked?: boolean;
  mustChangePassword?: boolean;
}

export interface PasswordChangeRequest {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export const userManagementApi = {
  // Get all users
  getAllUsers: async (): Promise<ApiResponse<UserDto[]>> => {
    const response = await apiClient.get('/users');
    return response.data;
  },

  // Get users paginated
  getUsersPaginated: async (page: number = 0, size: number = 10): Promise<ApiResponse<PageResponse<UserDto>>> => {
    const params = new URLSearchParams({
      page: page.toString(),
      size: size.toString(),
    });
    const response = await apiClient.get(`/users/paginated?${params}`);
    return response.data;
  },

  // Get user by ID
  getUserById: async (id: number): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.get(`/users/${id}`);
    return response.data;
  },

  // Get user by username
  getUserByUsername: async (username: string): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.get(`/users/username/${username}`);
    return response.data;
  },

  // Get users by organization
  getUsersByOrganization: async (organizationId: number): Promise<ApiResponse<UserDto[]>> => {
    const response = await apiClient.get(`/users/organization/${organizationId}`);
    return response.data;
  },

  // Create user
  createUser: async (user: UserCreateRequest): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.post('/users', user);
    return response.data;
  },

  // Update user
  updateUser: async (id: number, user: UserUpdateRequest): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.put(`/users/${id}`, user);
    return response.data;
  },

  // Delete user (deactivate)
  deleteUser: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/users/${id}`);
    return response.data;
  },

  // Change password
  changePassword: async (id: number, request: PasswordChangeRequest): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/users/${id}/change-password`, request);
    return response.data;
  },

  // Reset password
  resetPassword: async (id: number, newPassword: string): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/users/${id}/reset-password?newPassword=${encodeURIComponent(newPassword)}`);
    return response.data;
  },

  // Lock user
  lockUser: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/users/${id}/lock`);
    return response.data;
  },

  // Unlock user
  unlockUser: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/users/${id}/unlock`);
    return response.data;
  },

  // Activate user
  activateUser: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/users/${id}/activate`);
    return response.data;
  },
};
