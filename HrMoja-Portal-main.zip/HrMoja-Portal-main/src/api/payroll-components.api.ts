import { apiClient } from './axios.config';
import type { ApiResponse, PayrollComponentType } from '../types/api.types';
import type { PayrollComponent } from './payrollApi';

export const payrollComponentsApi = {
  // Get all components by organization
  getComponentsByOrganization: async (organizationId: number): Promise<ApiResponse<PayrollComponent[]>> => {
    const response = await apiClient.get(`/payroll/components/organization/${organizationId}`);
    return response.data;
  },

  // Get active components
  getActiveComponents: async (organizationId: number): Promise<ApiResponse<PayrollComponent[]>> => {
    const response = await apiClient.get(`/payroll/components/organization/${organizationId}/active`);
    return response.data;
  },

  // Get components by category
  getComponentsByCategory: async (organizationId: number, category: string): Promise<ApiResponse<PayrollComponent[]>> => {
    const response = await apiClient.get(`/payroll/components/organization/${organizationId}/category/${category}`);
    return response.data;
  },

  // Get component by ID
  getComponentById: async (id: number): Promise<ApiResponse<PayrollComponent>> => {
    const response = await apiClient.get(`/payroll/components/${id}`);
    return response.data;
  },

  // Create component
  createComponent: async (data: Partial<PayrollComponent>): Promise<ApiResponse<PayrollComponent>> => {
    const response = await apiClient.post('/payroll/components', data);
    return response.data;
  },

  // Update component
  updateComponent: async (id: number, data: Partial<PayrollComponent>): Promise<ApiResponse<PayrollComponent>> => {
    const response = await apiClient.put(`/payroll/components/${id}`, data);
    return response.data;
  },

  // Delete (deactivate) component
  deleteComponent: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/payroll/components/${id}`);
    return response.data;
  },

  // Get component types
  getComponentTypes: async (): Promise<ApiResponse<PayrollComponentType[]>> => {
    const response = await apiClient.get('/settings/component-types');
    return response.data;
  },
};
