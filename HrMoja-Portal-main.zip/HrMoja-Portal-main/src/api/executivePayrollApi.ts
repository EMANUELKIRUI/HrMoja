import { apiClient } from './axios.config';

export const executivePayrollApi = {
  getPeriodsForApproval: async (status?: string) => {
    const params = status ? { status } : {};
    return apiClient.get('/executive/payroll/periods', { params });
  },

  getPeriodDetails: async (periodId: number) => {
    return apiClient.get(`/executive/payroll/periods/${periodId}`);
  },

  getExecutiveSummary: async (periodId: number) => {
    return apiClient.get(`/executive/payroll/periods/${periodId}/executive-summary`);
  },

  giveFinalApproval: async (periodId: number, comment?: string) => {
    return apiClient.post(`/executive/payroll/periods/${periodId}/approve`, { comment });
  },

  rejectPeriod: async (periodId: number, reason: string) => {
    return apiClient.post(`/executive/payroll/periods/${periodId}/reject`, { reason });
  },

  authorizePayment: async (periodId: number) => {
    return apiClient.post(`/executive/payroll/periods/${periodId}/authorize-payment`);
  },

  getAuditTrail: async (periodId: number) => {
    return apiClient.get(`/executive/payroll/periods/${periodId}/audit-trail`);
  },

  getDashboard: async () => {
    return apiClient.get('/executive/payroll/dashboard');
  },

  getEmployeeRecords: async (
    periodId: number,
    search?: string,
    department?: string,
    page: number = 0,
    size: number = 20
  ) => {
    const params: any = { page, size };
    if (search) params.search = search;
    if (department) params.department = department;
    return apiClient.get(`/executive/payroll/periods/${periodId}/records`, { params });
  },

  getFinancialSummary: async (periodId: number) => {
    return apiClient.get(`/executive/payroll/periods/${periodId}/summary`);
  },

  getValidationReport: async (periodId: number) => {
    return apiClient.get(`/executive/payroll/periods/${periodId}/validation-report`);
  },
};
