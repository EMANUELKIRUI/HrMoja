import apiClient from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface UserDto {
  id?: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  isActive?: boolean;
  isLocked?: boolean;
  isEmailVerified?: boolean;
  lastLoginAt?: string;
  lastLoginIp?: string;
  failedLoginAttempts?: number;
  mustChangePassword?: boolean;
  employeeId?: number;
  organizationId?: number;
  organizationName?: string;
  roles?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface CreateUserRequest {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  organizationId: number;
  roles: string[];
  mustChangePassword?: boolean;
}

export interface UpdateUserRequest {
  firstName: string;
  lastName: string;
  phoneNumber?: string;
  email?: string;
  roles?: string[];
}

export interface UserStatusUpdate {
  isActive?: boolean;
  isLocked?: boolean;
}

export const usersApi = {
  // Get all users (Platform Admin)
  getAllUsers: async (): Promise<ApiResponse<UserDto[]>> => {
    const response = await apiClient.get('/users');
    return response.data;
  },

  // Get users by organization
  getUsersByOrganization: async (organizationId: number): Promise<ApiResponse<UserDto[]>> => {
    const response = await apiClient.get(`/users/organization/${organizationId}`);
    return response.data;
  },

  // Get user by ID
  getUserById: async (id: number): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.get(`/users/${id}`);
    return response.data;
  },

  // Create user
  createUser: async (data: CreateUserRequest): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.post('/users', data);
    return response.data;
  },

  // Update user
  updateUser: async (id: number, data: UpdateUserRequest): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.put(`/users/${id}`, data);
    return response.data;
  },

  // Update user status (activate/deactivate/lock/unlock)
  updateUserStatus: async (id: number, data: UserStatusUpdate): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.patch(`/users/${id}/status`, data);
    return response.data;
  },

  // Reset user password (force reset)
  resetUserPassword: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/users/${id}/reset-password`);
    return response.data;
  },

  // Unlock user account
  unlockUser: async (id: number): Promise<ApiResponse<UserDto>> => {
    const response = await apiClient.post(`/users/${id}/unlock`);
    return response.data;
  },

  // Delete user
  deleteUser: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/users/${id}`);
    return response.data;
  },
};
