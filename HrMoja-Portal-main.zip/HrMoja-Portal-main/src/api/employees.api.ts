import { apiClient } from './axios.config';
import type { ApiResponse, Employee, EmployeeCreateRequest, PageResponse } from '../types/api.types';

export const employeesApi = {
  // Get employees by organization
  getEmployeesByOrganization: async (
    organizationId: number,
    page: number = 0,
    size: number = 10,
    search?: string
  ): Promise<ApiResponse<PageResponse<Employee>>> => {
    const params = new URLSearchParams({
      page: page.toString(),
      size: size.toString(),
      ...(search && { search }),
    });
    const response = await apiClient.get(
      `/employees/organization/${organizationId}/paginated?${params}`
    );
    return response.data;
  },

  // Get all employees (no pagination)
  getAllEmployees: async (organizationId: number): Promise<ApiResponse<Employee[]>> => {
    const response = await apiClient.get(`/employees/organization/${organizationId}`);
    return response.data;
  },

  // Get employee by ID
  getEmployeeById: async (id: number): Promise<ApiResponse<Employee>> => {
    const response = await apiClient.get(`/employees/${id}`);
    return response.data;
  },

  // Get employee by number
  getEmployeeByNumber: async (employeeNumber: string): Promise<ApiResponse<Employee>> => {
    const response = await apiClient.get(`/employees/number/${employeeNumber}`);
    return response.data;
  },

  // Create employee
  createEmployee: async (employee: EmployeeCreateRequest): Promise<ApiResponse<Employee>> => {
    const response = await apiClient.post('/employees', employee);
    return response.data;
  },

  // Update employee
  updateEmployee: async (id: number, employee: Partial<Employee>): Promise<ApiResponse<Employee>> => {
    const response = await apiClient.put(`/employees/${id}`, employee);
    return response.data;
  },

  // Deactivate employee (soft delete)
  deactivateEmployee: async (id: number, reason: string): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/employees/${id}?reason=${encodeURIComponent(reason)}`);
    return response.data;
  },

  // Search employees with filters
  searchEmployeesWithFilters: async (
    organizationId: number,
    filters: {
      search?: string;
      departmentId?: number;
      branchId?: number;
      employmentTypeId?: number;
      status?: string;
      isActive?: boolean;
    },
    page: number = 0,
    size: number = 10
  ): Promise<ApiResponse<PageResponse<Employee>>> => {
    const params = new URLSearchParams({
      page: page.toString(),
      size: size.toString(),
    });
    
    if (filters.search) params.append('search', filters.search);
    if (filters.departmentId) params.append('departmentId', filters.departmentId.toString());
    if (filters.branchId) params.append('branchId', filters.branchId.toString());
    if (filters.employmentTypeId) params.append('employmentTypeId', filters.employmentTypeId.toString());
    if (filters.status) params.append('status', filters.status);
    if (filters.isActive !== undefined) params.append('isActive', filters.isActive.toString());
    
    const response = await apiClient.get(
      `/employees/organization/${organizationId}/search?${params}`
    );
    return response.data;
  },

  // Get employee count statistics
  getEmployeeCount: async (organizationId: number): Promise<ApiResponse<{ total: number; active: number; inactive: number }>> => {
    const response = await apiClient.get(`/employees/organization/${organizationId}/count`);
    return response.data;
  },
};
