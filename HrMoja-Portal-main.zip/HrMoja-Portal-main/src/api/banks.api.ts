import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface Bank {
  id: number;
  name: string;
  code: string;
  swiftCode?: string;
  active: boolean;
}

export interface BankBranch {
  id: number;
  bankId: number;
  name: string;
  code: string;
  address?: string;
  active: boolean;
}

export const banksApi = {
  // Get all active banks
  getActiveBanks: async (): Promise<ApiResponse<Bank[]>> => {
    const response = await apiClient.get('/banks/active');
    return response.data;
  },

  // Get bank branches by bank ID
  getBankBranches: async (bankId: number): Promise<ApiResponse<BankBranch[]>> => {
    const response = await apiClient.get(`/banks/${bankId}/branches`);
    return response.data;
  },
};
