import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface BranchDto {
  id?: number;
  organizationId: number;
  name: string;
  code: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  countryId?: number;
  countryName?: string;
  phoneNumber?: string;
  email?: string;
  managerId?: number;
  managerName?: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export const branchesApi = {
  // Get all branches by organization
  getBranchesByOrganization: async (organizationId: number): Promise<ApiResponse<BranchDto[]>> => {
    const response = await apiClient.get(`/settings/branches/organization/${organizationId}`);
    return response.data;
  },

  // Get active branches only
  getActiveBranches: async (organizationId: number): Promise<ApiResponse<BranchDto[]>> => {
    const response = await apiClient.get(`/settings/branches/organization/${organizationId}/active`);
    return response.data;
  },

  // Get branch by ID
  getBranchById: async (id: number): Promise<ApiResponse<BranchDto>> => {
    const response = await apiClient.get(`/settings/branches/${id}`);
    return response.data;
  },

  // Create branch
  createBranch: async (branch: BranchDto): Promise<ApiResponse<BranchDto>> => {
    const response = await apiClient.post('/settings/branches', branch);
    return response.data;
  },

  // Update branch
  updateBranch: async (id: number, branch: BranchDto): Promise<ApiResponse<BranchDto>> => {
    const response = await apiClient.put(`/settings/branches/${id}`, branch);
    return response.data;
  },

  // Delete branch
  deleteBranch: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/branches/${id}`);
    return response.data;
  },
};
