import { apiClient } from './axios.config';

export const financePayrollApi = {
  getPeriodsForReview: async (status?: string) => {
    const params = status ? { status } : {};
    return apiClient.get('/finance/payroll/periods', { params });
  },

  getPeriodDetails: async (periodId: number) => {
    return apiClient.get(`/finance/payroll/periods/${periodId}`);
  },

  getEmployeeRecords: async (
    periodId: number,
    search?: string,
    department?: string,
    page: number = 0,
    size: number = 20
  ) => {
    const params: any = { page, size };
    if (search) params.search = search;
    if (department) params.department = department;
    return apiClient.get(`/finance/payroll/periods/${periodId}/records`, { params });
  },

  getFinancialSummary: async (periodId: number) => {
    return apiClient.get(`/finance/payroll/periods/${periodId}/summary`);
  },

  reviewPeriod: async (periodId: number, comment?: string) => {
    return apiClient.post(`/finance/payroll/periods/${periodId}/review`, { comment });
  },

  rejectPeriod: async (periodId: number, reason: string) => {
    return apiClient.post(`/finance/payroll/periods/${periodId}/reject`, { reason });
  },

  submitForFinalApproval: async (periodId: number) => {
    return apiClient.post(`/finance/payroll/periods/${periodId}/submit-for-approval`);
  },

  getValidationReport: async (periodId: number) => {
    return apiClient.get(`/finance/payroll/periods/${periodId}/validation-report`);
  },

  // Individual record actions
  approveRecord: async (recordId: number) => {
    return apiClient.post(`/finance/payroll/records/${recordId}/approve`);
  },

  rejectRecord: async (recordId: number, reason: string) => {
    return apiClient.post(`/finance/payroll/records/${recordId}/reject`, { reason });
  },

  approveAllRecords: async (periodId: number) => {
    return apiClient.post(`/finance/payroll/periods/${periodId}/approve-all`);
  },

  // Finance Level 2 review
  reviewRecord: async (recordId: number, remarks?: string) => {
    return apiClient.post(`/finance/payroll/records/${recordId}/review`, { remarks });
  },

  reviewBulkRecords: async (recordIds: number[], remarks?: string) => {
    return apiClient.post('/finance/payroll/records/review-bulk', { recordIds, remarks });
  },

  // ============= PAYMENT PROCESSING =============
  
  // Authorize payment for approved period
  authorizePayment: async (periodId: number, paymentDetails?: { 
    paymentMethod?: string; 
    paymentReference?: string; 
    notes?: string 
  }) => {
    return apiClient.post(`/finance/payroll/periods/${periodId}/authorize-payment`, paymentDetails || {});
  },

  // Mark payment as executed
  executePayment: async (paymentId: number, executionDetails?: { transactionReference?: string }) => {
    return apiClient.post(`/finance/payroll/payments/${paymentId}/execute`, executionDetails || {});
  },

  // Confirm payment completion
  confirmPayment: async (paymentId: number, confirmationDetails?: { notes?: string }) => {
    return apiClient.post(`/finance/payroll/payments/${paymentId}/confirm`, confirmationDetails || {});
  },

  // Get payment details for a period
  getPaymentDetails: async (periodId: number) => {
    return apiClient.get(`/finance/payroll/periods/${periodId}/payment-details`);
  },

  // Get payment audit trail
  getPaymentAuditTrail: async (paymentId: number) => {
    return apiClient.get(`/finance/payroll/payments/${paymentId}/audit-trail`);
  },

  // Reverse payment
  reversePayment: async (paymentId: number, reason: string) => {
    return apiClient.post(`/finance/payroll/payments/${paymentId}/reverse`, { reason });
  },

  // ============= BANK FILE GENERATION =============
  
  // Get bank file preview
  getBankFilePreview: async (periodId: number) => {
    return apiClient.get(`/finance/payroll/periods/${periodId}/bank-file-preview`);
  },

  // Generate and download bank file
  downloadBankFile: async (paymentId: number, format: 'CSV' | 'EXCEL' = 'CSV') => {
    return apiClient.get(`/finance/payroll/payments/${paymentId}/generate-bank-file`, {
      params: { format },
      responseType: 'blob',
    });
  },

  // ============= PAYMENT MANAGEMENT (Bank Feedback & Fraud Detection) =============
  
  // Get payment management details
  getPaymentManagementDetails: async (periodId: number) => {
    return apiClient.get(`/finance/payment-management/periods/${periodId}`);
  },

  // Download bank file with locking
  downloadLockedBankFile: async (paymentId: number, format: 'CSV' | 'EXCEL' = 'CSV') => {
    return apiClient.get(`/finance/payment-management/payments/${paymentId}/bank-file`, {
      params: { format },
      responseType: 'blob',
    });
  },

  // Get bank file preview
  getBankFilePreviewManagement: async (periodId: number) => {
    return apiClient.get(`/finance/payment-management/periods/${periodId}/bank-file-preview`);
  },

  // Upload bank feedback/acknowledgement file
  uploadBankFeedback: async (periodId: number, file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return apiClient.post(`/finance/payment-management/periods/${periodId}/feedback`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  // Get feedback files for a period
  getFeedbackFiles: async (periodId: number) => {
    return apiClient.get(`/finance/payment-management/periods/${periodId}/feedback`);
  },

  // Get discrepancy report
  getDiscrepancyReport: async (periodId: number) => {
    return apiClient.get(`/finance/payment-management/periods/${periodId}/discrepancy-report`);
  },

  // Authorize payment (management endpoint)
  authorizePaymentManagement: async (
    periodId: number,
    paymentMethod: string,
    paymentReference: string,
    notes: string
  ) => {
    return apiClient.post(`/finance/payment-management/periods/${periodId}/authorize`, {
      paymentMethod,
      paymentReference,
      notes,
    });
  },

  // Execute payment (management endpoint)
  executePaymentManagement: async (paymentId: number, transactionReference: string) => {
    return apiClient.post(`/finance/payment-management/payments/${paymentId}/execute`, {
      transactionReference,
    });
  },

  // Confirm payment (management endpoint)
  confirmPaymentManagement: async (paymentId: number, confirmationNotes: string) => {
    return apiClient.post(`/finance/payment-management/payments/${paymentId}/confirm`, {
      confirmationNotes,
    });
  },
};
