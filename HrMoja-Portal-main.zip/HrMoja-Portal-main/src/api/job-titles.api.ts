import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface JobTitleDto {
  id?: number;
  organizationId: number;
  title: string;
  code: string;
  description?: string;
  level?: number;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export const jobTitlesApi = {
  // Get all job titles by organization
  getJobTitlesByOrganization: async (organizationId: number): Promise<ApiResponse<JobTitleDto[]>> => {
    const response = await apiClient.get(`/settings/job-titles/organization/${organizationId}`);
    return response.data;
  },

  // Create job title
  createJobTitle: async (jobTitle: JobTitleDto): Promise<ApiResponse<JobTitleDto>> => {
    const response = await apiClient.post('/settings/job-titles', jobTitle);
    return response.data;
  },
};
