import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface PermissionDto {
  id?: number;
  name: string;
  code: string;
  description?: string;
  module: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface PermissionCreateRequest {
  name: string;
  code: string;
  description?: string;
  module: string;
}

export const permissionManagementApi = {
  // Get all permissions
  getAllPermissions: async (): Promise<ApiResponse<PermissionDto[]>> => {
    const response = await apiClient.get('/permissions');
    return response.data;
  },

  // Get active permissions
  getActivePermissions: async (): Promise<ApiResponse<PermissionDto[]>> => {
    const response = await apiClient.get('/permissions/active');
    return response.data;
  },

  // Get permissions by module
  getPermissionsByModule: async (module: string): Promise<ApiResponse<PermissionDto[]>> => {
    const response = await apiClient.get(`/permissions/module/${module}`);
    return response.data;
  },

  // Get permission by ID
  getPermissionById: async (id: number): Promise<ApiResponse<PermissionDto>> => {
    const response = await apiClient.get(`/permissions/${id}`);
    return response.data;
  },

  // Get permission by code
  getPermissionByCode: async (code: string): Promise<ApiResponse<PermissionDto>> => {
    const response = await apiClient.get(`/permissions/code/${code}`);
    return response.data;
  },

  // Create permission
  createPermission: async (permission: PermissionCreateRequest): Promise<ApiResponse<PermissionDto>> => {
    const response = await apiClient.post('/permissions', permission);
    return response.data;
  },

  // Update permission
  updatePermission: async (id: number, permission: PermissionCreateRequest): Promise<ApiResponse<PermissionDto>> => {
    const response = await apiClient.put(`/permissions/${id}`, permission);
    return response.data;
  },

  // Delete permission (deactivate)
  deletePermission: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/permissions/${id}`);
    return response.data;
  },

  // Activate permission
  activatePermission: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.post(`/permissions/${id}/activate`);
    return response.data;
  },
};
