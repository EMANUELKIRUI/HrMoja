import apiClient from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface CountryDto {
  id?: number;
  name: string;
  code: string;
  currency: string;
  currencySymbol?: string;
  taxRate?: number;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export const countriesApi = {
  getAllCountries: async (): Promise<ApiResponse<CountryDto[]>> => {
    const response = await apiClient.get('/settings/countries');
    return response.data;
  },

  getActiveCountries: async (): Promise<ApiResponse<CountryDto[]>> => {
    const response = await apiClient.get('/settings/countries/active');
    return response.data;
  },

  getCountryById: async (id: number): Promise<ApiResponse<CountryDto>> => {
    const response = await apiClient.get(`/settings/countries/${id}`);
    return response.data;
  },

  createCountry: async (data: CountryDto): Promise<ApiResponse<CountryDto>> => {
    const response = await apiClient.post('/settings/countries', data);
    return response.data;
  },

  updateCountry: async (id: number, data: CountryDto): Promise<ApiResponse<CountryDto>> => {
    const response = await apiClient.put(`/settings/countries/${id}`, data);
    return response.data;
  },

  deleteCountry: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/countries/${id}`);
    return response.data;
  },
};
