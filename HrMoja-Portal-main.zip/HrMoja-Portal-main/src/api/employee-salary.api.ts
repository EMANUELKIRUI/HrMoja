import { apiClient } from './axios.config';
import type { ApiResponse, EmployeeSalaryStructure } from '../types/api.types';

export const employeeSalaryApi = {
  // Get employee's current salary structure
  getCurrentSalary: async (employeeId: number): Promise<ApiResponse<EmployeeSalaryStructure>> => {
    const response = await apiClient.get(`/employees/${employeeId}/salary/current`);
    return response.data;
  },

  // Get employee's salary history
  getSalaryHistory: async (employeeId: number): Promise<ApiResponse<EmployeeSalaryStructure[]>> => {
    const response = await apiClient.get(`/employees/${employeeId}/salary/history`);
    return response.data;
  },

  // Create salary structure
  createSalary: async (data: EmployeeSalaryStructure): Promise<ApiResponse<EmployeeSalaryStructure>> => {
    const response = await apiClient.post(`/employees/${data.employeeId}/salary`, data);
    return response.data;
  },

  // Update salary structure
  updateSalary: async (employeeId: number, salaryId: number, data: Partial<EmployeeSalaryStructure>): Promise<ApiResponse<EmployeeSalaryStructure>> => {
    const response = await apiClient.put(`/employees/${employeeId}/salary/${salaryId}`, data);
    return response.data;
  },

  // Deactivate salary structure
  deactivateSalary: async (employeeId: number, salaryId: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/employees/${employeeId}/salary/${salaryId}`);
    return response.data;
  },
};
