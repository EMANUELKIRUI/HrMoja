import { apiClient } from './axios.config';
import type { ApiResponse, Country, Organization, PayFrequency, EmploymentType, PaymentMethod, PageResponse } from '../types/api.types';

export interface JobTitle {
  id?: number;
  organizationId: number;
  title: string;
  code: string;
  description?: string;
  level?: number;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface Department {
  id?: number;
  organizationId: number;
  branchId?: number;
  branchName?: string;
  name: string;
  code: string;
  description?: string;
  parentDepartmentId?: number;
  parentDepartmentName?: string;
  managerId?: number;
  managerName?: string;
  costCenterCode?: string;
  active?: boolean;
}

export interface Branch {
  id?: number;
  organizationId: number;
  name: string;
  code: string;
  description?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  countryId?: number;
  countryName?: string;
  phoneNumber?: string;
  email?: string;
  managerId?: number;
  managerName?: string;
  isActive?: boolean;
  isHeadOffice?: boolean;
}

export const settingsApi = {
  // Countries
  getCountries: async (): Promise<ApiResponse<Country[]>> => {
    const response = await apiClient.get('/settings/countries');
    return response.data;
  },

  getActiveCountries: async (): Promise<ApiResponse<Country[]>> => {
    const response = await apiClient.get('/settings/countries/active');
    return response.data;
  },

  getCountryById: async (id: number): Promise<ApiResponse<Country>> => {
    const response = await apiClient.get(`/settings/countries/${id}`);
    return response.data;
  },

  // Organizations
  getOrganizations: async (): Promise<ApiResponse<PageResponse<Organization>>> => {
    const response = await apiClient.get('/settings/organizations');
    return response.data;
  },

  getOrganizationById: async (id: number): Promise<ApiResponse<Organization>> => {
    const response = await apiClient.get(`/settings/organizations/${id}`);
    return response.data;
  },

  // Pay Frequencies
  getPayFrequencies: async (): Promise<ApiResponse<PayFrequency[]>> => {
    const response = await apiClient.get('/settings/pay-frequencies');
    return response.data;
  },

  // Employment Types
  getEmploymentTypes: async (): Promise<ApiResponse<EmploymentType[]>> => {
    const response = await apiClient.get('/settings/employment-types');
    return response.data;
  },

  // Payment Methods
  getPaymentMethods: async (): Promise<ApiResponse<PaymentMethod[]>> => {
    const response = await apiClient.get('/settings/payment-methods');
    return response.data;
  },

  // Job Titles
  getJobTitles: async (organizationId: number): Promise<ApiResponse<JobTitle[]>> => {
    const response = await apiClient.get(`/settings/job-titles/organization/${organizationId}`);
    return response.data;
  },

  createJobTitle: async (data: JobTitle): Promise<ApiResponse<JobTitle>> => {
    const response = await apiClient.post('/settings/job-titles', data);
    return response.data;
  },

  updateJobTitle: async (id: number, data: JobTitle): Promise<ApiResponse<JobTitle>> => {
    const response = await apiClient.put(`/settings/job-titles/${id}`, data);
    return response.data;
  },

  deleteJobTitle: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/job-titles/${id}`);
    return response.data;
  },

  // Departments
  getDepartments: async (organizationId: number): Promise<ApiResponse<Department[]>> => {
    const response = await apiClient.get(`/settings/departments/organization/${organizationId}`);
    return response.data;
  },

  getActiveDepartments: async (organizationId: number): Promise<ApiResponse<Department[]>> => {
    const response = await apiClient.get(`/settings/departments/organization/${organizationId}/active`);
    return response.data;
  },

  createDepartment: async (data: Department): Promise<ApiResponse<Department>> => {
    const response = await apiClient.post('/settings/departments', data);
    return response.data;
  },

  updateDepartment: async (id: number, data: Department): Promise<ApiResponse<Department>> => {
    const response = await apiClient.put(`/settings/departments/${id}`, data);
    return response.data;
  },

  deleteDepartment: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/departments/${id}`);
    return response.data;
  },

  // Branches
  getBranches: async (organizationId: number): Promise<ApiResponse<Branch[]>> => {
    const response = await apiClient.get(`/settings/branches/organization/${organizationId}`);
    return response.data;
  },

  getActiveBranches: async (organizationId: number): Promise<ApiResponse<Branch[]>> => {
    const response = await apiClient.get(`/settings/branches/organization/${organizationId}/active`);
    return response.data;
  },

  createBranch: async (data: Branch): Promise<ApiResponse<Branch>> => {
    const response = await apiClient.post('/settings/branches', data);
    return response.data;
  },

  updateBranch: async (id: number, data: Branch): Promise<ApiResponse<Branch>> => {
    const response = await apiClient.put(`/settings/branches/${id}`, data);
    return response.data;
  },

  deleteBranch: async (id: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/settings/branches/${id}`);
    return response.data;
  },
};
