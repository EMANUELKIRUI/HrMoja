import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface EmployeeDocument {
  id?: number;
  employeeId: number;
  documentType: string;
  documentName: string;
  documentNumber?: string;
  fileUrl: string;
  fileType?: string;
  fileSize?: number;
  issueDate?: string;
  expiryDate?: string;
  description?: string;
  isVerified?: boolean;
  verifiedBy?: number;
  verifiedAt?: string;
  uploadedBy?: number;
  createdAt?: string;
}

export const employeeDocumentsApi = {
  // Get all documents for an employee
  getDocuments: async (employeeId: number): Promise<ApiResponse<EmployeeDocument[]>> => {
    const response = await apiClient.get(`/api/employees/${employeeId}/documents`);
    return response.data;
  },

  // Upload document
  uploadDocument: async (employeeId: number, file: File, metadata: Partial<EmployeeDocument>): Promise<ApiResponse<EmployeeDocument>> => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('metadata', JSON.stringify(metadata));
    
    const response = await apiClient.post(`/api/employees/${employeeId}/documents`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  // Download document
  downloadDocument: async (employeeId: number, documentId: number): Promise<Blob> => {
    const response = await apiClient.get(`/api/employees/${employeeId}/documents/${documentId}/download`, {
      responseType: 'blob',
    });
    return response.data;
  },

  // Delete document
  deleteDocument: async (employeeId: number, documentId: number): Promise<ApiResponse<void>> => {
    const response = await apiClient.delete(`/api/employees/${employeeId}/documents/${documentId}`);
    return response.data;
  },

  // Verify document
  verifyDocument: async (employeeId: number, documentId: number): Promise<ApiResponse<EmployeeDocument>> => {
    const response = await apiClient.put(`/api/employees/${employeeId}/documents/${documentId}/verify`);
    return response.data;
  },
};
