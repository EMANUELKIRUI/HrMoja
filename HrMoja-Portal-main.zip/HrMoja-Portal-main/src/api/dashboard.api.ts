import { apiClient } from './axios.config';
import type { ApiResponse } from '../types/api.types';

export interface DashboardMetrics {
  totalEmployees: number;
  activeEmployees: number;
  inactiveEmployees: number;
  monthlyPayroll: number;
  pendingTasks: number;
  teamPerformance: number;
  payrollTrend: MonthlyTrend[];
  employeeTrend: MonthlyTrend[];
  departmentDistribution: DepartmentStats[];
  recentActivities: Activity[];
}

export interface MonthlyTrend {
  month: string;
  amount?: number;
  count?: number;
}

export interface DepartmentStats {
  departmentName: string;
  employeeCount: number;
  totalSalary: number;
}

export interface Activity {
  type: string;
  description: string;
  timestamp: string;
  user: string;
}

export const dashboardApi = {
  /**
   * Get dashboard metrics for the current organization
   */
  getMetrics: async (): Promise<ApiResponse<DashboardMetrics>> => {
    const response = await apiClient.get('/dashboard/metrics');
    return response.data;
  },
};
