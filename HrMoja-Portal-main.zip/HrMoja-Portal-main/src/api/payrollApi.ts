import { apiClient } from './axios.config';

export interface PayrollPeriod {
  id: number;
  organizationId: number;
  periodName: string;
  periodType: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
  status: string;
  approvalLevel: string;
  preparedBy?: number;
  preparedAt?: string;
  reviewedBy?: number;
  reviewedAt?: string;
  finalApprovedBy?: number;
  finalApprovedAt?: string;
  totalEmployees: number;
  totalApprovedLevel1: number;
  totalRejected: number;
  isPartiallyApproved: boolean;
  totalGrossPay: number;
  totalDeductions: number;
  totalNetPay: number;
  processedBy?: number;
  processedAt?: string;
  approvedBy?: number;
  approvedAt?: string;
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PayrollRun {
  id: number;
  payrollPeriodId: number;
  runNumber: number;
  runType: string;
  status: string;
  totalEmployeesProcessed: number;
  totalEmployeesFailed: number;
  totalGrossPay: number;
  totalDeductions: number;
  totalNetPay: number;
  processingStartedAt?: string;
  processingCompletedAt?: string;
  errorLog?: string;
  notes?: string;
}

export interface EmployeePayrollRecord {
  id: number;
  payrollPeriodId: number;
  payrollRunId?: number;
  employeeId: number;
  employeeName: string;
  employeeNumber: string;
  departmentName?: string;
  positionTitle?: string;
  basicSalary: number;
  grossSalary: number;
  taxableIncome: number;
  pensionableIncome: number;
  totalEarnings: number;
  totalDeductions: number;
  totalStatutory: number;
  totalTaxes: number;
  netSalary: number;
  status: string;
  isPaid: boolean;
  paymentDate?: string;
  // Legacy approval properties (for backward compatibility)
  rejected?: boolean;
  approvedLevel1?: boolean;
  rejectionReason?: string;
}

export interface PayrollComponent {
  id: number;
  organizationId: number;
  name: string;
  code: string;
  componentTypeId: number;
  calculationMethod: string;
  calculationBasis?: string;
  fixedAmount?: number;
  percentageValue?: number;
  maxAmount?: number;
  minAmount?: number;
  isTaxable: boolean;
  isPensionable: boolean;
  isStatutory: boolean;
  isActive: boolean;
  priorityOrder: number;
  description?: string;
  // Legacy properties for backward compatibility
  componentTypeName?: string;
  calculationCategory?: string;
  formula?: string;
  taxable?: boolean;  // Legacy - use isTaxable
  pensionable?: boolean;  // Legacy - use isPensionable
  statutory?: boolean;  // Legacy - use isStatutory
  active?: boolean;  // Legacy - use isActive
  affectsGross?: boolean;
  affectsNet?: boolean;
  displayOnPayslip?: boolean;
  notes?: string;
}

export interface PayrollLineItem {
  id: number;
  employeePayrollRecordId: number;
  componentId?: number;
  componentName: string;
  componentCode: string;
  componentCategory: string;
  calculationMethod?: string;
  calculationBasis?: string;
  rateOrAmount?: number;
  quantity: number;
  amount: number;
  isTaxable: boolean;
  isPensionable: boolean;
  isStatutory: boolean;
  displayOrder: number;
}

export interface CreatePeriodRequest {
  organizationId: number;
  periodName: string;
  periodType: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
}

export interface UpdatePeriodRequest {
  periodName: string;
  startDate: string;
  endDate: string;
  paymentDate: string;
}

export interface PaginatedResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
}

export interface PeriodFilters {
  status?: string;
  search?: string;
  periodType?: string;
  startDate?: string;
  endDate?: string;
}

const payrollApi = {
  // ============ PAYROLL COMPONENTS ============
  
  getComponentsByOrganization: async (organizationId: number): Promise<PayrollComponent[]> => {
    const response = await apiClient.get(`/payroll/components/organization/${organizationId}`);
    return response.data.data;
  },

  getActiveComponents: async (organizationId: number): Promise<PayrollComponent[]> => {
    const response = await apiClient.get(`/payroll/components/organization/${organizationId}/active`);
    return response.data.data;
  },

  getComponentsByCategory: async (
    organizationId: number,
    category: 'EARNING' | 'DEDUCTION' | 'BENEFIT' | 'CONTRIBUTION'
  ): Promise<PayrollComponent[]> => {
    const response = await apiClient.get(`/payroll/components/organization/${organizationId}/category/${category}`);
    return response.data.data;
  },

  getComponentById: async (id: number): Promise<PayrollComponent> => {
    const response = await apiClient.get(`/payroll/components/${id}`);
    return response.data.data;
  },

  createComponent: async (component: Partial<PayrollComponent>): Promise<PayrollComponent> => {
    const response = await apiClient.post('/payroll/components', component);
    return response.data.data;
  },

  updateComponent: async (id: number, component: Partial<PayrollComponent>): Promise<PayrollComponent> => {
    const response = await apiClient.put(`/payroll/components/${id}`, component);
    return response.data.data;
  },

  deleteComponent: async (id: number): Promise<void> => {
    await apiClient.delete(`/payroll/components/${id}`);
  },

  // ============ PAYROLL PERIODS ============
  // Payroll Periods
  getPeriods: async (organizationId: number): Promise<PayrollPeriod[]> => {
    const response = await apiClient.get(`/payroll/periods?organizationId=${organizationId}`);
    return response.data.data;
  },
  
  getPeriodsPaginated: async (
    organizationId: number,
    page: number,
    size: number,
    filters?: PeriodFilters
  ): Promise<PaginatedResponse<PayrollPeriod>> => {
    const params = new URLSearchParams({
      organizationId: organizationId.toString(),
      page: page.toString(),
      size: size.toString(),
    });
    
    if (filters?.status) params.append('status', filters.status);
    if (filters?.search) params.append('search', filters.search);
    if (filters?.periodType) params.append('periodType', filters.periodType);
    if (filters?.startDate) params.append('startDate', filters.startDate);
    if (filters?.endDate) params.append('endDate', filters.endDate);
    
    const response = await apiClient.get(`/payroll/periods/paginated?${params.toString()}`);
    return response.data.data;
  },

  getPeriodById: async (periodId: number): Promise<PayrollPeriod> => {
    const response = await apiClient.get(`/payroll/periods/${periodId}`);
    return response.data.data;
  },

  createPeriod: async (data: CreatePeriodRequest): Promise<PayrollPeriod> => {
    const response = await apiClient.post('/payroll/periods', null, { params: data });
    return response.data.data;
  },

  updatePeriod: async (periodId: number, data: UpdatePeriodRequest): Promise<PayrollPeriod> => {
    const response = await apiClient.put(`/payroll/periods/${periodId}`, null, { params: data });
    return response.data.data;
  },

  deletePeriod: async (periodId: number): Promise<void> => {
    await apiClient.delete(`/payroll/periods/${periodId}`);
  },

  // Payroll Processing
  processPeriod: async (periodId: number): Promise<ProcessPayrollResponse> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/process`);
    return response.data.data;
  },

  getJobStatus: async (periodId: number): Promise<PayrollJobStatus> => {
    const response = await apiClient.get(`/payroll/periods/${periodId}/job-status`);
    return response.data.data;
  },

  recalculatePeriod: async (periodId: number): Promise<void> => {
    await apiClient.post(`/payroll/periods/${periodId}/recalculate`);
  },

  approvePeriod: async (periodId: number): Promise<void> => {
    await apiClient.post(`/payroll/periods/${periodId}/approve`);
  },

  markAsPaid: async (periodId: number): Promise<void> => {
    await apiClient.post(`/payroll/periods/${periodId}/paid`);
  },

  closePeriod: async (periodId: number): Promise<void> => {
    await apiClient.post(`/payroll/periods/${periodId}/close`);
  },

  unlockPeriod: async (periodId: number, reason: string): Promise<PayrollPeriod> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/unlock`, null, {
      params: { reason }
    });
    return response.data.data;
  },

  // 3-Level Approval Workflow
  preparePayroll: async (periodId: number): Promise<PayrollPeriod> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/prepare`);
    return response.data.data;
  },

  reviewPayroll: async (periodId: number): Promise<PayrollPeriod> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/review`);
    return response.data.data;
  },

  finalApprovePayroll: async (periodId: number): Promise<PayrollPeriod> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/final-approve`);
    return response.data.data;
  },

  rejectPayroll: async (periodId: number, reason: string): Promise<PayrollPeriod> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/reject`, null, {
      params: { reason }
    });
    return response.data.data;
  },

  // Line Item Editing (Level 1 - PREPARED stage)
  updateLineItem: async (lineItemId: number, amount: number): Promise<PayrollLineItem> => {
    const response = await apiClient.put(`/payroll/periods/line-items/${lineItemId}`, null, {
      params: { amount }
    });
    return response.data.data;
  },

  addLineItem: async (recordId: number, componentName: string, componentCode: string, 
                      category: string, amount: number): Promise<PayrollLineItem> => {
    const response = await apiClient.post(`/payroll/periods/records/${recordId}/line-items`, null, {
      params: { componentName, componentCode, category, amount }
    });
    return response.data.data;
  },

  deleteLineItem: async (lineItemId: number): Promise<void> => {
    await apiClient.delete(`/payroll/periods/line-items/${lineItemId}`);
  },

  recalculateEmployeeRecord: async (recordId: number): Promise<void> => {
    await apiClient.post(`/payroll/periods/records/${recordId}/recalculate`);
  },

  // Partial Approval (Level 1)
  approveRecordLevel1: async (recordId: number): Promise<EmployeePayrollRecord> => {
    const response = await apiClient.post(`/payroll/periods/records/${recordId}/approve-level1`);
    return response.data.data;
  },

  unapproveRecordLevel1: async (recordId: number): Promise<EmployeePayrollRecord> => {
    const response = await apiClient.post(`/payroll/periods/records/${recordId}/unapprove-level1`);
    return response.data.data;
  },

  bulkApproveLevel1: async (recordIds: number[]): Promise<number> => {
    const response = await apiClient.post(`/payroll/periods/records/bulk-approve-level1`, recordIds);
    return response.data.data;
  },

  approveAllLevel1: async (periodId: number): Promise<number> => {
    const response = await apiClient.post(`/payroll/periods/${periodId}/approve-all-level1`);
    return response.data.data;
  },

  rejectRecord: async (recordId: number, reason: string): Promise<EmployeePayrollRecord> => {
    const response = await apiClient.post(`/payroll/periods/records/${recordId}/reject`, null, {
      params: { reason }
    });
    return response.data.data;
  },

  restoreRecord: async (recordId: number): Promise<EmployeePayrollRecord> => {
    const response = await apiClient.post(`/payroll/periods/records/${recordId}/restore`);
    return response.data.data;
  },

  getApprovalStats: async (periodId: number): Promise<ApprovalStats> => {
    const response = await apiClient.get(`/payroll/periods/${periodId}/approval-stats`);
    return response.data.data;
  },

  // Payroll Records
  getPeriodRecords: async (periodId: number): Promise<EmployeePayrollRecord[]> => {
    const response = await apiClient.get(`/payroll/periods/${periodId}/records`);
    return response.data.data;
  },

  getEmployeeRecord: async (recordId: number): Promise<EmployeePayrollRecord> => {
    const response = await apiClient.get(`/payroll/records/${recordId}`);
    return response.data.data;
  },

  getRecordLineItems: async (recordId: number): Promise<PayrollLineItem[]> => {
    const response = await apiClient.get(`/payroll/records/${recordId}/line-items`);
    return response.data.data;
  },

  getLineItems: async (recordId: number): Promise<PayrollLineItem[]> => {
    const response = await apiClient.get(`/payroll/periods/records/${recordId}/line-items`);
    return response.data.data;
  },

  // Payroll Runs
  getPeriodRuns: async (periodId: number): Promise<PayrollRun[]> => {
    const response = await apiClient.get(`/payroll/periods/${periodId}/runs`);
    return response.data.data;
  },

  // Payslip PDF
  getPayslipPdf: async (recordId: number): Promise<Blob> => {
    const response = await apiClient.get(`/payroll/records/${recordId}/payslip`, {
      responseType: 'blob',
    });
    return response.data;
  },
};

export interface ApprovalStats {
  totalRecords: number;
  approvedCount: number;
  rejectedCount: number;
  pendingCount: number;
  isPartiallyApproved: boolean;
  approvalPercentage: number;
}

export interface PayrollJobStatus {
  jobId: number;
  payrollPeriodId: number;
  status: 'QUEUED' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  totalEmployees: number;
  processedEmployees: number;
  failedEmployees: number;
  progressPercentage: number;
  startedAt?: string;
  completedAt?: string;
  errorMessage?: string;
  durationSeconds?: number;
  statusMessage?: string;
}

export interface ProcessPayrollResponse {
  jobId: number;
  periodId: number;
  status: string;
  totalEmployees: number;
}

export default payrollApi;
