export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}

export interface PageResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
  last: boolean;
}

export interface Country {
  id: number;
  name: string;
  code: string;
  isoCode: string;
  currencyCode: string;
  currencyName: string;
  currencySymbol: string;
  timezone: string;
  dateFormat: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Organization {
  id: number;
  name: string;
  legalName: string;
  registrationNumber: string;
  taxNumber: string;
  countryId: number;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  stateProvince?: string;
  postalCode?: string;
  phoneNumber: string;
  email: string;
  website?: string;
  logoUrl?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PayFrequency {
  id: number;
  name: string;
  code: string;
  periodsPerYear: number;
  description: string;
  active: boolean;
}

export interface EmploymentType {
  id: number;
  name: string;
  code: string;
  description: string;
  active: boolean;
}

export interface PaymentMethod {
  id: number;
  name: string;
  code: string;
  requiresBankDetails: boolean;
  description: string;
  active: boolean;
}

export interface Employee {
  // IDs
  id?: number;
  employeeNumber?: string;
  organizationId: number;
  branchId?: number;
  branchName?: string;
  departmentId?: number;
  departmentName?: string;

  // Personal Information
  firstName: string;
  middleName?: string;
  lastName: string;
  dateOfBirth: string;
  gender?: string;
  maritalStatus?: string;
  nationality?: string;
  nationalId?: string;
  passportNumber?: string;

  // Contact Information
  personalEmail?: string;
  workEmail?: string;
  mobilePhone: string;
  homePhone?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;

  // Address
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  countryId?: number;
  countryName?: string;

  // Employment Information
  hireDate: string;
  confirmationDate?: string;
  probationEndDate?: string;
  terminationDate?: string;
  terminationReason?: string;
  employmentTypeId: number;
  employmentTypeName?: string;
  jobTitleId: number;
  jobTitleName?: string;
  employeeGradeId?: number;
  employeeGradeName?: string;
  reportsToEmployeeId?: number;
  reportsToEmployeeName?: string;
  employmentStatus?: string;
  active?: boolean;

  // Other
  photoUrl?: string;
  bio?: string;
  userId?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface EmployeeCreateRequest {
  organizationId: number;
  branchId?: number;
  departmentId?: number;

  // Personal Information
  firstName: string;
  middleName?: string;
  lastName: string;
  dateOfBirth: string;
  gender?: string;
  maritalStatus?: string;
  nationality?: string;
  nationalId?: string;
  passportNumber?: string;

  // Contact Information
  personalEmail?: string;
  workEmail?: string;
  mobilePhone: string;
  homePhone?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;

  // Address
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  countryId?: number;

  // Employment Information
  hireDate: string;
  probationEndDate?: string;
  employmentTypeId: number;
  jobTitleId: number;
  employeeGradeId?: number;
  reportsToEmployeeId?: number;
}

// PayrollComponent moved to payrollApi.ts - import from there for payroll-related types

export interface PayrollComponentType {
  id?: number;
  name: string;
  code: string;
  description?: string;
  calculationCategory: 'EARNING' | 'DEDUCTION' | 'BENEFIT' | 'TAX' | 'STATUTORY';
  systemType?: boolean;
  active?: boolean;
}

// PayrollPeriod moved to payrollApi.ts - import from there for payroll-related types

// PayrollRecord (EmployeePayrollRecord) moved to payrollApi.ts - import from there

export interface EmployeeSalaryStructure {
  id?: number;
  employeeId: number;
  effectiveDate: string;
  endDate?: string;
  basicSalary: number;
  currencyCode: string;
  payFrequencyId: number;
  payFrequencyName?: string;
  paymentMethodId?: number;
  paymentMethodName?: string;
  active?: boolean;
  approvedBy?: number;
  approvedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}
