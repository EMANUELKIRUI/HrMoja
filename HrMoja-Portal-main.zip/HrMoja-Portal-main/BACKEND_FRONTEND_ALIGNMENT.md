# Backend-Frontend Alignment Documentation

## Employee Management - Complete Alignment ✅

### **Backend EmployeeDto → Frontend Employee Type**

| Backend Field | Frontend Field | Type | Notes |
|--------------|---------------|------|-------|
| `id` | `id` | number | ✅ |
| `employeeNumber` | `employeeNumber` | string | ✅ |
| `organizationId` | `organizationId` | number | ✅ Required |
| `branchId` | `branchId` | number | ✅ Optional |
| `branchName` | `branchName` | string | ✅ |
| `departmentId` | `departmentId` | number | ✅ |
| `departmentName` | `departmentName` | string | ✅ |

**Personal Information:**
| Backend Field | Frontend Field | Type | Required |
|--------------|---------------|------|----------|
| `firstName` | `firstName` | string | ✅ Yes |
| `middleName` | `middleName` | string | ⚪ No |
| `lastName` | `lastName` | string | ✅ Yes |
| `dateOfBirth` | `dateOfBirth` | LocalDate | ✅ Yes |
| `gender` | `gender` | string | ⚪ No |
| `maritalStatus` | `maritalStatus` | string | ⚪ No |
| `nationality` | `nationality` | string | ⚪ No |
| `nationalId` | `nationalId` | string | ⚪ No |
| `passportNumber` | `passportNumber` | string | ⚪ No |

**Contact Information:**
| Backend Field | Frontend Field | Type | Required |
|--------------|---------------|------|----------|
| `personalEmail` | `personalEmail` | string | ⚪ No |
| `workEmail` | `workEmail` | string | ⚪ No |
| `mobilePhone` | `mobilePhone` | string | ✅ Yes |
| `homePhone` | `homePhone` | string | ⚪ No |
| `emergencyContactName` | `emergencyContactName` | string | ⚪ No |
| `emergencyContactPhone` | `emergencyContactPhone` | string | ⚪ No |
| `emergencyContactRelationship` | `emergencyContactRelationship` | string | ⚪ No |

**Address:**
| Backend Field | Frontend Field | Type | Required |
|--------------|---------------|------|----------|
| `addressLine1` | `addressLine1` | string | ⚪ No |
| `addressLine2` | `addressLine2` | string | ⚪ No |
| `city` | `city` | string | ⚪ No |
| `stateProvince` | `stateProvince` | string | ⚪ No |
| `postalCode` | `postalCode` | string | ⚪ No |
| `countryId` | `countryId` | number | ⚪ No |
| `countryName` | `countryName` | string | ⚪ No |

**Employment Information:**
| Backend Field | Frontend Field | Type | Required |
|--------------|---------------|------|----------|
| `hireDate` | `hireDate` | LocalDate | ✅ Yes |
| `confirmationDate` | `confirmationDate` | LocalDate | ⚪ No |
| `probationEndDate` | `probationEndDate` | LocalDate | ⚪ No |
| `terminationDate` | `terminationDate` | LocalDate | ⚪ No |
| `terminationReason` | `terminationReason` | string | ⚪ No |
| `employmentTypeId` | `employmentTypeId` | number | ✅ Yes |
| `employmentTypeName` | `employmentTypeName` | string | ⚪ No |
| `jobTitleId` | `jobTitleId` | number | ✅ Yes |
| `jobTitleName` | `jobTitleName` | string | ⚪ No |
| `employeeGradeId` | `employeeGradeId` | number | ⚪ No |
| `employeeGradeName` | `employeeGradeName` | string | ⚪ No |
| `reportsToEmployeeId` | `reportsToEmployeeId` | number | ⚪ No |
| `reportsToEmployeeName` | `reportsToEmployeeName` | string | ⚪ No |
| `employmentStatus` | `employmentStatus` | string | ⚪ No |
| `isActive` | `isActive` | boolean | ⚪ No |

**Other:**
| Backend Field | Frontend Field | Type | Required |
|--------------|---------------|------|----------|
| `photoUrl` | `photoUrl` | string | ⚪ No |
| `bio` | `bio` | string | ⚪ No |
| `userId` | `userId` | number | ⚪ No |
| `createdAt` | `createdAt` | LocalDateTime | ⚪ No |
| `updatedAt` | `updatedAt` | LocalDateTime | ⚪ No |

---

## API Endpoints Alignment

### **Backend EmployeeController → Frontend employeesApi**

| Backend Endpoint | Frontend Method | Params | Aligned |
|-----------------|----------------|--------|---------|
| `POST /api/employees` | `createEmployee(request)` | EmployeeCreateRequest | ✅ |
| `GET /api/employees/{id}` | `getEmployeeById(id)` | id: number | ✅ |
| `GET /api/employees/number/{number}` | `getEmployeeByNumber(number)` | number: string | ✅ |
| `GET /api/employees/organization/{orgId}` | `getAllEmployees(orgId)` | orgId: number | ✅ |
| `GET /api/employees/organization/{orgId}/paginated` | `getEmployeesByOrganization(orgId, page, size, search)` | Pageable | ✅ |
| `GET /api/employees/organization/{orgId}/search` | `searchEmployees(orgId, search, page, size)` | Pageable | ✅ |
| `PUT /api/employees/{id}` | `updateEmployee(id, employee)` | EmployeeDto | ✅ |
| `DELETE /api/employees/{id}?reason=` | `deactivateEmployee(id, reason)` | id, reason | ✅ |

---

## EmployeesPage Table Columns

| Column | Backend Field | Status |
|--------|--------------|--------|
| Employee # | `employeeNumber` | ✅ |
| Full Name | `firstName` + `lastName` | ✅ |
| Email | `workEmail` | ✅ Fixed |
| Job Title | `jobTitleName` | ✅ Fixed |
| Department | `departmentName` | ✅ Added |
| Hire Date | `hireDate` | ✅ |
| Status | `isActive` | ✅ Fixed |

---

## Required Fields for Creating Employee

### **Minimum Required Fields** (Backend validation):
1. ✅ `organizationId` - Required
2. ✅ `firstName` - Required
3. ✅ `lastName` - Required
4. ✅ `dateOfBirth` - Required (must be in the past)
5. ✅ `mobilePhone` - Required
6. ✅ `hireDate` - Required
7. ✅ `employmentTypeId` - Required
8. ✅ `jobTitleId` - Required

### **Optional But Recommended**:
- `branchId` - Branch assignment
- `departmentId` - Department assignment
- `workEmail` - Work email (validated if provided)
- `personalEmail` - Personal email (validated if provided)
- `gender` - Gender
- `nationality` - Nationality
- `nationalId` - National ID number
- `employeeGradeId` - Grade/level
- `reportsToEmployeeId` - Reporting manager

---

## Permission Requirements

| Action | Required Permission | Notes |
|--------|-------------------|-------|
| Create Employee | `EMPLOYEE_CREATE` | ✅ |
| View Employee | `EMPLOYEE_READ` | ✅ |
| Update Employee | `EMPLOYEE_UPDATE` | ✅ |
| Deactivate Employee | `EMPLOYEE_DELETE` | ✅ (soft delete) |

---

## Next Steps

1. ✅ Types aligned with backend
2. ✅ API client aligned with backend
3. ✅ Table columns use correct field names
4. 🔄 Create Add Employee multi-step form
5. 🔄 Get organizationId from auth context
6. 🔄 Fetch reference data (employment types, job titles, departments, branches)
