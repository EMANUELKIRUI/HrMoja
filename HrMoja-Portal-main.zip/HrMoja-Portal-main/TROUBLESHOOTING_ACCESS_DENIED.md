# Troubleshooting: Access Denied & Failed to Load Employees

## Issues Identified

### 1. ❌ Axios Import Issue (FIXED)
**Problem**: `import apiClient from './axios.config'` should be `import { apiClient } from './axios.config'`

**Files Fixed**:
- ✅ `employees.api.ts`
- ✅ `branches.api.ts`
- ✅ `departments.api.ts`
- ✅ `job-titles.api.ts`

**Result**: API calls will now use correct baseURL `http://localhost:8080/api`

---

### 2. ❌ Access Denied - Missing Permissions

**Error**: `org.springframework.security.access.AccessDeniedException: Access Denied`

**Cause**: User doesn't have required permissions to access endpoints.

#### Required Permissions for Employee Management:

| Endpoint | Required Permission |
|----------|-------------------|
| `GET /api/employees/organization/{id}/paginated` | `EMPLOYEE_READ` |
| `GET /api/employees/organization/{id}` | `EMPLOYEE_READ` |
| `POST /api/employees` | `EMPLOYEE_CREATE` |
| `PUT /api/employees/{id}` | `EMPLOYEE_UPDATE` |
| `DELETE /api/employees/{id}` | `EMPLOYEE_DELETE` |

#### Required Permissions for Settings:

| Endpoint | Required Permission |
|----------|-------------------|
| `GET /api/settings/branches/organization/{id}` | `SETTINGS_READ` |
| `GET /api/settings/departments/organization/{id}` | `SETTINGS_READ` |
| `GET /api/settings/job-titles/organization/{id}` | `SETTINGS_READ` |
| `GET /api/settings/employment-types` | `SETTINGS_READ` |

---

## How to Fix Access Denied

### Option 1: Check Current User's Permissions

**In Backend, check user's roles and permissions:**

```sql
-- Check user's roles
SELECT u.username, r.name as role_name
FROM users u
JOIN user_roles ur ON u.id = ur.user_id
JOIN roles r ON ur.role_id = r.id
WHERE u.username = 'your-username';

-- Check role's permissions
SELECT r.name as role_name, p.name as permission_name
FROM roles r
JOIN role_permissions rp ON r.id = rp.role_id
JOIN permissions p ON rp.permission_id = p.id
WHERE r.name IN ('ORGANIZATION_SUPER_ADMIN', 'PLATFORM_ADMIN');
```

### Option 2: Grant Missing Permissions

**You need to ensure the user's role has these permissions:**

**For Organization Admin (ORGANIZATION_SUPER_ADMIN):**
- ✅ `EMPLOYEE_READ`
- ✅ `EMPLOYEE_CREATE`
- ✅ `EMPLOYEE_UPDATE`
- ✅ `EMPLOYEE_DELETE`
- ✅ `SETTINGS_READ`
- ✅ `SETTINGS_MANAGE`

**For Platform Admin:**
- ✅ All organization permissions
- ✅ `ORGANIZATION_CREATE`
- ✅ `ORGANIZATION_UPDATE`
- ✅ `USER_MANAGE`
- ✅ `PLATFORM_SETTINGS_MANAGE`

### Option 3: Add Permissions via SQL

```sql
-- Grant EMPLOYEE_READ to ORGANIZATION_SUPER_ADMIN role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.name = 'ORGANIZATION_SUPER_ADMIN'
  AND p.name IN (
    'EMPLOYEE_READ',
    'EMPLOYEE_CREATE',
    'EMPLOYEE_UPDATE',
    'EMPLOYEE_DELETE',
    'SETTINGS_READ',
    'SETTINGS_MANAGE'
  )
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions rp2
    WHERE rp2.role_id = r.id AND rp2.permission_id = p.id
  );
```

---

## Testing Steps

### 1. Clear Browser Cache & Tokens
```javascript
// Open browser console (F12) and run:
localStorage.clear();
sessionStorage.clear();
```

### 2. Login Again
- Go to `/login`
- Login with credentials
- Check browser console for JWT token

### 3. Verify Token Contains Permissions
```javascript
// In browser console, decode JWT:
const token = localStorage.getItem('token');
if (token) {
  const payload = JSON.parse(atob(token.split('.')[1]));
  console.log('Permissions:', payload.permissions);
  console.log('Roles:', payload.roles);
}
```

### 4. Expected Token Payload
```json
{
  "sub": "admin",
  "permissions": [
    "EMPLOYEE_READ",
    "EMPLOYEE_CREATE",
    "EMPLOYEE_UPDATE",
    "EMPLOYEE_DELETE",
    "SETTINGS_READ",
    "SETTINGS_MANAGE"
  ],
  "roles": ["ORGANIZATION_SUPER_ADMIN"],
  "organizationId": 1,
  "organizationName": "Case Hospitals"
}
```

---

## Backend Check

### Verify Permission Annotations

**EmployeeController.java:**
```java
@GetMapping("/organization/{organizationId}/paginated")
@PreAuthorize("hasAuthority('EMPLOYEE_READ')") // ← Check this
```

**SettingsController.java:**
```java
@GetMapping("/branches/organization/{organizationId}/active")
@PreAuthorize("hasAuthority('SETTINGS_READ')") // ← Check this
```

---

## Quick Fix for Development

**Temporarily disable security (NOT for production):**

In `SecurityConfig.java`, you can temporarily allow all requests:
```java
.authorizeHttpRequests(auth -> auth
    .anyRequest().permitAll() // ⚠️ DEVELOPMENT ONLY
)
```

---

## Next Steps

1. ✅ Fix axios imports (DONE)
2. 🔄 Check user permissions in database
3. 🔄 Grant missing permissions if needed
4. 🔄 Clear cache and re-login
5. ✅ Test employees page again
