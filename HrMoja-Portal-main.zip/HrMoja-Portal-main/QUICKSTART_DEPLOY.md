# Quick Deployment Setup

This is a quick reference guide to get your HrMoja Frontend deployed. For detailed instructions, see [DEPLOYMENT.md](./DEPLOYMENT.md).

## 📋 Pre-Deployment Checklist

- [ ] Push code to GitHub repository
- [ ] Server with Docker installed
- [ ] SSH access to server configured
- [ ] GitHub secrets configured

## 🔐 GitHub Secrets (Required)

Add these in: **Repository → Settings → Secrets and variables → Actions**

```
SERVER_HOST=your-server-ip
SERVER_USER=ubuntu
SERVER_PORT=22
SSH_PRIVATE_KEY=your-private-key
VITE_API_URL=http://your-backend-api:8080/api
```

## 🖥️ Server Setup (One-Time)

```bash
# 1. Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# 2. Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# 3. Create app directory
sudo mkdir -p /opt/hrmoja-portal
sudo chown $USER:$USER /opt/hrmoja-portal

# 4. Clone repository
cd /opt/hrmoja-portal
git clone YOUR_REPO_URL .

# 5. Create .env file
cat > .env << EOF
VITE_API_URL=http://YOUR_BACKEND_IP:8080/api
NODE_ENV=production
EOF

# 6. Allow HTTP traffic
sudo ufw allow 80/tcp
```

## 🚀 Deploy

### Option 1: Auto-Deploy (Recommended)
```bash
git add .
git commit -m "Deploy to production"
git push origin main
```
✨ GitHub Actions will automatically deploy!

### Option 2: Manual Deploy
1. Go to GitHub → Actions → "Manual Deployment"
2. Click "Run workflow"
3. Select environment
4. Click "Run workflow" button

### Option 3: Server Deploy
```bash
ssh user@server
cd /opt/hrmoja-portal
git pull origin main
docker-compose up -d --build
```

## 🔍 Verify Deployment

```bash
# Check health
curl http://your-server-ip/health

# View logs
docker logs hrmoja-frontend -f

# Check status
docker ps | grep hrmoja-frontend
```

## 🐛 Quick Troubleshooting

**Container won't start:**
```bash
docker logs hrmoja-frontend
docker-compose down && docker-compose up -d --build
```

**Port already in use:**
```bash
sudo netstat -tulpn | grep :80
# Kill the process or change port in docker-compose.yml
```

**Build fails:**
```bash
docker system prune -a
docker-compose build --no-cache
```

## 📁 Files Created

```
.
├── .github/
│   └── workflows/
│       ├── ci-cd.yml          # Auto deployment
│       └── deploy-manual.yml  # Manual deployment
├── Dockerfile                 # Multi-stage build
├── docker-compose.yml         # Container config
├── nginx.conf                 # Web server config
├── .dockerignore             # Build optimization
├── .env.example              # Environment template
├── DEPLOYMENT.md             # Full documentation
└── QUICKSTART_DEPLOY.md      # This file
```

## 🎯 What Happens on Deploy?

1. **Build** → Install dependencies & build React app
2. **Test** → Run linter (optional)
3. **Docker** → Create optimized container image
4. **Deploy** → SSH to server, pull code, restart containers
5. **Verify** → Health check to confirm deployment

## 📊 Monitor After Deploy

- **GitHub Actions**: Check workflow status in Actions tab
- **Server Logs**: `docker logs -f hrmoja-frontend`
- **Health Check**: `curl http://localhost/health`

## 🔄 Update Backend API URL

In GitHub Secrets, update `VITE_API_URL`:
```
VITE_API_URL=https://api.yourdomain.com/api
```

Or on server in `/opt/hrmoja-portal/.env`:
```bash
VITE_API_URL=https://api.yourdomain.com/api
```

## 📚 Need More Help?

- Full guide: [DEPLOYMENT.md](./DEPLOYMENT.md)
- Docker issues: `docker logs hrmoja-frontend`
- GitHub Actions: Check Actions tab in repository

---

**Ready to deploy?** Push to `main` branch and watch the magic happen! ✨
