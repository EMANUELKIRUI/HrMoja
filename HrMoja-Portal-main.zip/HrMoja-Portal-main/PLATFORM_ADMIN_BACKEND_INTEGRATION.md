# Platform Administrator Backend Integration Guide

## ✅ Available Backend Endpoints for Platform Admin

### 1. **Organizations Management** ✅ READY
**Endpoint**: `/api/settings/organizations`  
**Controller**: `OrganizationController.java`

| Method | Endpoint | Permission | Status | Frontend Integration |
|--------|----------|-----------|--------|---------------------|
| GET | `/api/settings/organizations` | SETTINGS_READ | ✅ Ready | ✅ Integrated |
| GET | `/api/settings/organizations/active` | SETTINGS_READ | ✅ Ready | ✅ Can integrate |
| GET | `/api/settings/organizations/{id}` | SETTINGS_READ | ✅ Ready | ✅ Can integrate |
| POST | `/api/settings/organizations` | SETTINGS_MANAGE | ✅ Ready | ✅ Integrated |
| PUT | `/api/settings/organizations/{id}` | SETTINGS_MANAGE | ✅ Ready | ⚠️ TODO |
| DELETE | `/api/settings/organizations/{id}` | SETTINGS_MANAGE | ✅ Ready | ⚠️ TODO |

**Frontend Files**:
- API Client: `src/api/organizations.api.ts` ✅
- Page: `src/features/organizations/OrganizationsPage.tsx` ✅
- Dialog: `src/features/organizations/CreateOrganizationDialog.tsx` ✅

---

### 2. **Organization Registration** ✅ READY
**Endpoint**: `/api/organization`  
**Controller**: `OrganizationRegistrationController.java`

| Method | Endpoint | Permission | Status | Use Case |
|--------|----------|-----------|--------|----------|
| POST | `/api/organization/register` | Public | ✅ Ready | New org self-registration |
| GET | `/api/organization/check-username/{username}` | Public | ✅ Ready | Username validation |
| GET | `/api/organization/check-email/{email}` | Public | ✅ Ready | Email validation |

**Notes**: This is for **self-service org registration**. Platform admins use `/api/settings/organizations` instead.

---

### 3. **Countries Management** ✅ READY
**Endpoint**: `/api/settings/countries`  
**Controller**: `CountryController.java`

| Method | Endpoint | Permission | Status | Usage |
|--------|----------|-----------|--------|-------|
| GET | `/api/settings/countries` | SETTINGS_READ | ✅ Ready | List all countries |
| GET | `/api/settings/countries/active` | SETTINGS_READ | ✅ Ready | Active countries only |
| GET | `/api/settings/countries/{id}` | SETTINGS_READ | ✅ Ready | Get by ID |
| POST | `/api/settings/countries` | SETTINGS_MANAGE | ✅ Ready | Add new country |
| PUT | `/api/settings/countries/{id}` | SETTINGS_MANAGE | ✅ Ready | Update country |
| DELETE | `/api/settings/countries/{id}` | SETTINGS_MANAGE | ✅ Ready | Deactivate country |

**Integration TODO**: Create countries API client and management page for platform settings.

---

### 4. **Employees (Platform-wide)** ✅ READY
**Endpoint**: `/api/employees`  
**Controller**: `EmployeeController.java`

| Method | Endpoint | Permission | Status | Notes |
|--------|----------|-----------|--------|-------|
| GET | `/api/employees/organization/{organizationId}` | EMPLOYEE_READ | ✅ Ready | All employees by org |
| GET | `/api/employees/organization/{organizationId}/paginated` | EMPLOYEE_READ | ✅ Ready | Paginated list |
| GET | `/api/employees/organization/{organizationId}/search` | EMPLOYEE_READ | ✅ Ready | Search employees |

**Platform Admin Use**: Can query employees across all organizations for analytics.

---

### 5. **Departments** ✅ READY
**Endpoint**: `/api/settings/departments`  
**Controller**: `DepartmentController.java`

| Method | Endpoint | Permission | Status |
|--------|----------|-----------|--------|
| GET | `/api/settings/departments/organization/{organizationId}` | SETTINGS_READ | ✅ Ready |
| GET | `/api/settings/departments/organization/{organizationId}/active` | SETTINGS_READ | ✅ Ready |

**Platform Admin Use**: View department structures across organizations.

---

### 6. **Payroll Reports (Analytics)** ✅ READY
**Endpoint**: `/api/payroll/reports`  
**Controller**: `PayrollReportController.java`

| Method | Endpoint | Permission | Status | Use Case |
|--------|----------|-----------|--------|----------|
| GET | `/api/payroll/reports/periods/{periodId}/summary` | PAYROLL_READ | ✅ Ready | Payroll summary |
| GET | `/api/payroll/reports/periods/{periodId}/departments` | PAYROLL_READ | ✅ Ready | Department reports |
| GET | `/api/payroll/reports/periods/{periodId}/statutory/paye` | PAYROLL_READ | ✅ Ready | PAYE reports |
| GET | `/api/payroll/reports/periods/{periodId}/statutory/nssf` | PAYROLL_READ | ✅ Ready | NSSF reports |
| GET | `/api/payroll/reports/periods/{periodId}/statutory/lst` | PAYROLL_READ | ✅ Ready | LST reports |
| GET | `/api/payroll/reports/periods/{periodId}/export/excel` | PAYROLL_READ | ✅ Ready | Excel export |

**Platform Admin Use**: System-wide payroll analytics and statutory compliance reports.

---

### 7. **System Settings** ✅ READY
**Endpoint**: `/api/settings`  
**Controller**: `SettingsController.java`

| Method | Endpoint | Permission | Status | Description |
|--------|----------|-----------|--------|-------------|
| GET | `/api/settings/pay-frequencies` | SETTINGS_READ | ✅ Ready | Pay frequency types |
| GET | `/api/settings/employment-types` | SETTINGS_READ | ✅ Ready | Employment types |
| GET | `/api/settings/payment-methods` | SETTINGS_READ | ✅ Ready | Payment methods |
| GET | `/api/settings/banks/country/{countryId}` | SETTINGS_READ | ✅ Ready | Banks by country |
| POST | `/api/settings/pay-frequencies` | SETTINGS_MANAGE | ✅ Ready | Create pay frequency |
| POST | `/api/settings/employment-types` | SETTINGS_MANAGE | ✅ Ready | Create employment type |
| POST | `/api/settings/banks` | SETTINGS_MANAGE | ✅ Ready | Create bank |

**Platform Admin Use**: Manage global platform settings and reference data.

---

## ❌ Missing Backend Endpoints

### 1. **Platform Users Management** ❌ NOT IMPLEMENTED
**Required Endpoints**:
```
GET    /api/platform/users                    # List all platform admins
POST   /api/platform/users                    # Create platform admin
PUT    /api/platform/users/{id}               # Update platform admin
DELETE /api/platform/users/{id}               # Deactivate admin
GET    /api/platform/users/{id}/audit-logs    # User activity logs
```

**Required Permissions**: `PLATFORM_ADMIN_MANAGE`, `PLATFORM_ADMIN_READ`

---

### 2. **Role & Permission Management** ❌ NOT IMPLEMENTED
**Required Endpoints**:
```
GET    /api/security/roles                    # List all roles
POST   /api/security/roles                    # Create role
PUT    /api/security/roles/{id}               # Update role
DELETE /api/security/roles/{id}               # Delete role
GET    /api/security/permissions              # List all permissions
POST   /api/security/roles/{id}/permissions   # Assign permissions to role
```

**Required Permissions**: `SECURITY_MANAGE`, `SECURITY_READ`

---

### 3. **Platform Analytics** ❌ NOT IMPLEMENTED
**Required Endpoints**:
```
GET    /api/platform/analytics/overview       # Platform-wide stats
GET    /api/platform/analytics/organizations  # Org growth metrics
GET    /api/platform/analytics/users          # User growth metrics
GET    /api/platform/analytics/system-health  # System health metrics
GET    /api/platform/analytics/revenue        # Revenue analytics
```

**Required Permissions**: `PLATFORM_ANALYTICS_READ`

---

### 4. **System Audit Logs** ❌ NOT IMPLEMENTED
**Required Endpoints**:
```
GET    /api/platform/audit-logs               # Platform-wide audit logs
GET    /api/platform/audit-logs/user/{userId} # User-specific logs
GET    /api/platform/audit-logs/organization/{orgId} # Org-specific logs
```

**Required Permissions**: `AUDIT_LOG_READ`

---

### 5. **Platform Settings (Advanced)** ❌ PARTIALLY IMPLEMENTED
**Additional Needed**:
```
GET    /api/platform/settings                 # Get platform config
PUT    /api/platform/settings                 # Update platform config
POST   /api/platform/settings/maintenance     # Toggle maintenance mode
GET    /api/platform/settings/feature-flags   # Get feature flags
PUT    /api/platform/settings/feature-flags   # Update feature flags
```

**Required Permissions**: `PLATFORM_SETTINGS_MANAGE`

---

## 📊 Integration Priority Roadmap

### Phase 1: Core Organization Management ✅ COMPLETE
- [x] Organizations CRUD
- [x] Create Organization Dialog
- [x] Organizations List Page

### Phase 2: Platform Analytics 🔄 IN PROGRESS
- [ ] Create platform analytics API endpoints
- [ ] Integrate with Platform Admin Dashboard
- [ ] Add real-time stats (org count, user count, system health)

### Phase 3: User Management ⏳ PENDING
- [ ] Create Platform Users API endpoints
- [ ] Build Platform Users management page
- [ ] Implement role assignment UI

### Phase 4: Security & Roles ⏳ PENDING
- [ ] Create Role & Permission API endpoints
- [ ] Build Security management page
- [ ] Implement permission matrix UI

### Phase 5: System Settings ⏳ PENDING
- [ ] Create Platform Settings API endpoints
- [ ] Build Platform Settings page
- [ ] Implement feature flags management

### Phase 6: Reporting & Audit ⏳ PENDING
- [ ] Create Audit Logs API endpoints
- [ ] Build System Reports page
- [ ] Implement export functionality

---

## 🔐 Permission Model for Platform Admin

### Required Roles:
- **SUPER_ADMIN**: Full platform access
- **PLATFORM_ADMIN**: Platform management (limited)

### Required Permissions:
```
PLATFORM_ADMIN_MANAGE      # Manage platform administrators
PLATFORM_ANALYTICS_READ     # View platform analytics
SECURITY_MANAGE            # Manage roles and permissions
AUDIT_LOG_READ             # View audit logs
PLATFORM_SETTINGS_MANAGE   # Manage platform settings
```

### Existing Permissions (Available):
```
SETTINGS_MANAGE            # Manage system settings
SETTINGS_READ              # Read system settings
EMPLOYEE_READ              # Read employees (all orgs)
PAYROLL_READ               # Read payroll data (all orgs)
```

---

## 🎯 Next Steps for Full Integration

1. **Backend Development Needed**:
   - Create `PlatformAdminController` for platform-wide operations
   - Create `SecurityController` for role/permission management
   - Create `AuditLogController` for audit trail
   - Create `PlatformAnalyticsService` for metrics aggregation

2. **Frontend Integration**:
   - Create API clients for new endpoints
   - Wire up real data to Platform Admin Dashboard
   - Implement edit/delete for organizations
   - Build Platform Users CRUD interface
   - Build Security management interface

3. **Testing**:
   - Test role-based access control
   - Test multi-org data isolation
   - Test permission enforcement
   - End-to-end platform admin workflows

---

## 📝 Available for Immediate Integration

### ✅ Ready Now:
1. **Organizations Management** - Fully functional with backend
2. **Organization Stats** - Can aggregate from existing data
3. **Country Management** - Backend ready, needs frontend
4. **System Settings** - Backend ready for reference data

### ⚠️ Needs Backend First:
1. Platform Users Management
2. Role & Permission Management
3. Platform-wide Analytics API
4. Audit Logs
5. Feature Flags Management

---

**Last Updated**: 2025-10-25  
**Backend API Base**: `http://localhost:8080/api`  
**API Documentation**: `http://localhost:8080/api/swagger-ui.html`
