# Organization Admin Dashboard Plan

## Overview
Organization Admin dashboard is organization-specific. Each admin only sees and manages data for their own organization.

---

## Features Roadmap

### ✅ Phase 1: Core Setup (Current)
- [ ] Organization Admin Layout component
- [ ] Organization Admin Dashboard page
- [ ] Routing and navigation
- [ ] Auth context integration (get organizationId from token)

### 🔄 Phase 2: Employee Management
- [ ] Employees List page (filtered by organizationId)
- [ ] Add Employee dialog/page
- [ ] Edit Employee functionality
- [ ] Employee profile view
- [ ] Employee status management (active/inactive)
- [ ] Employee search and filters

### 🔄 Phase 3: Department & Branch Management
- [ ] Departments/Branches list
- [ ] Add Department/Branch
- [ ] Edit Department/Branch
- [ ] Assign employees to departments
- [ ] Department hierarchy view

### 🔄 Phase 4: Payroll Management
- [ ] Payroll runs list
- [ ] Initiate payroll run
- [ ] Payroll processing status
- [ ] Employee salary structures
- [ ] Payroll reports
- [ ] Download payslips

### 🔄 Phase 5: Leave Management
- [ ] Leave requests list
- [ ] Leave approval workflow
- [ ] Leave calendar view
- [ ] Leave balance tracking
- [ ] Leave reports

### 🔄 Phase 6: Reports & Analytics
- [ ] Employee reports (headcount, turnover)
- [ ] Payroll reports (costs, deductions)
- [ ] Attendance reports
- [ ] Export to Excel/PDF

### 🔄 Phase 7: Organization Settings
- [ ] Update organization details
- [ ] Pay frequency configuration
- [ ] Tax configuration
- [ ] Payroll settings
- [ ] User management (add org users)

---

## Dashboard Metrics (Organization-Specific)

### Quick Stats Cards:
1. **Total Employees** - Count of all employees in organization
2. **Active Employees** - Currently active employees
3. **Departments** - Number of departments/branches
4. **This Month's Payroll** - Upcoming or recent payroll status

### Charts:
1. **Employee Growth** - Line chart showing employee count over time
2. **Department Distribution** - Pie chart of employees by department
3. **Payroll Costs** - Bar chart of monthly payroll costs
4. **Leave Requests** - Status breakdown (pending, approved, rejected)

### Recent Activity:
- Recent hires
- Pending leave approvals
- Upcoming payroll runs
- Recent payroll completions

---

## Navigation Structure

### Sidebar Menu:
1. 📊 **Dashboard** - Overview metrics
2. 👥 **Employees** - Employee management
3. 🏢 **Departments** - Department/branch management
4. 💰 **Payroll** - Payroll processing and reports
5. 🏖️ **Leave** - Leave management
6. 📈 **Reports** - Analytics and reports
7. ⚙️ **Settings** - Organization settings

---

## API Integration

### Organization Context:
- Get `organizationId` from JWT token (stored in auth context)
- All API calls automatically filtered by organizationId
- Backend validates user belongs to organization

### Key APIs:
- `/api/employees?organizationId={id}`
- `/api/departments?organizationId={id}`
- `/api/payroll/runs?organizationId={id}`
- `/api/leaves?organizationId={id}`
- `/api/reports/employees?organizationId={id}`

---

## Authentication & Authorization

### Role: `ORGANIZATION_SUPER_ADMIN`

### Permissions:
- Full CRUD on employees within organization
- Manage departments and branches
- Process payroll runs
- Approve leave requests
- View all reports for organization
- Configure organization settings

### Context:
- User's `organizationId` extracted from JWT
- All operations scoped to user's organization
- Cannot access other organizations' data

---

## UI/UX Differences from Platform Admin

| Feature | Platform Admin | Organization Admin |
|---------|---------------|-------------------|
| Scope | All organizations | Single organization |
| Organizations | Can manage all | Can only update their own |
| Employees | Cannot manage | Full CRUD access |
| Payroll | Cannot access | Full access |
| Dashboard | Platform-wide metrics | Org-specific metrics |
| Menu | Platform focus | HR/Payroll focus |

---

## Technical Stack

Same as Platform Admin:
- React 18 + TypeScript
- Material-UI v5
- TanStack Query
- React Hook Form + Zod
- Axios with interceptors
- Recharts for analytics

---

## Next Steps

1. ✅ Create `OrganizationAdminLayout.tsx`
2. ✅ Create `OrganizationAdminDashboard.tsx`
3. ✅ Update routing in `AppRoutes.tsx`
4. Create Employee Management pages
5. Implement backend employee APIs
6. Continue with other features...
